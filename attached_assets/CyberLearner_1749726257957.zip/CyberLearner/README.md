# Cody Verse - Modern Educational Learning Platform

A cutting-edge Progressive Web App featuring AI-driven learning with a clean, modern educational interface inspired by Duolingo, Khan Academy, and Coursera. Designed for engaging, accessible learning experiences with comprehensive progress tracking.

## Key Features

- **Modern Educational Design**: Clean, bright interface with energetic blue (#3B82F6) primary colors and accessible typography
- **Enhanced Typography System**: Professional Inter font for readability, JetBrains Mono for code, and Orbitron for headings
- **Multilingual Support**: Full localization for English, Portuguese, and Spanish
- **Interactive Learning Modules**: Comprehensive MCP (Model Context Protocol) training with hands-on exercises
- **AI-Powered Assistant**: Dynamic Cody character with contextual learning guidance
- **Gamified Progress System**: Achievement tracking, XP rewards, and level progression
- **PWA Functionality**: Offline access with service worker implementation
- **Alchemy Discovery Game**: Interactive element combination system for exploratory learning
- **Responsive Design**: Optimized for mobile, tablet, and desktop experiences

## Technology Stack

- **Frontend**: React 18 with TypeScript for type safety
- **Styling**: Tailwind CSS 3.4+ with ShadCN/UI component library
- **State Management**: TanStack React Query v5 for server state
- **Routing**: Wouter for lightweight client-side routing
- **Backend**: Express.js with comprehensive middleware
- **Database**: PostgreSQL with Drizzle ORM for type-safe queries
- **AI Integration**: OpenAI GPT-4o for intelligent learning assistance
- **Build Tool**: Vite for fast development and optimized builds
- **Code Quality**: TypeScript strict mode with comprehensive error handling

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- PostgreSQL database (automatically configured in Replit environment)

### Quick Start (Replit)

1. Fork this Repl or import from GitHub
2. The application will automatically install dependencies
3. Database is pre-configured - no additional setup needed
4. Click "Run" to start the development server

### Local Development Setup

1. Clone the repository
   ```bash
   git clone https://github.com/yourusername/cody-verse.git
   cd cody-verse
   ```

2. Install dependencies
   ```bash
   npm install
   ```

3. Set up environment variables
   Create a `.env` file with:
   ```bash
   DATABASE_URL=postgresql://username:password@localhost:5432/codyverse
   OPENAI_API_KEY=your_openai_api_key_here
   ```

4. Initialize the database
   ```bash
   npm run db:push
   ```

5. Start the development server
   ```bash
   npm run dev
   ```

The application will be available at `http://localhost:5000`

## Project Structure

```
cody-verse/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   │   ├── characters/ # AI assistant character system
│   │   │   ├── interactive/# Interactive learning modules
│   │   │   ├── tutorial/   # Onboarding tutorials
│   │   │   └── ui/         # ShadCN/UI components
│   │   ├── pages/          # Application pages/routes
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility libraries
│   │   └── utils/          # Helper functions
├── server/                 # Express.js backend
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API route definitions
│   ├── storage.ts         # Database abstraction layer
│   ├── type-utils.ts      # Type-safe utilities
│   └── db.ts              # Database connection
├── shared/                 # Shared TypeScript definitions
│   ├── schema.ts          # Drizzle database schemas
│   ├── types.ts           # Common type definitions
│   └── integration-stability.ts # Performance monitoring
└── public/                 # Static assets and PWA files
```

## Features Overview

### 🎯 Learning Modules
- **Interactive MCP Training**: Comprehensive Model Context Protocol tutorials
- **Code Challenges**: Real-time coding exercises with instant feedback
- **Scenario Explorer**: Practical application scenarios
- **Concept Mapping**: Visual learning relationships

### 🤖 AI Assistant
- **Cody Character**: Intelligent learning companion
- **Contextual Help**: Real-time assistance during exercises
- **Progress Guidance**: Personalized learning path recommendations

### 🏆 Gamification
- **Achievement System**: Unlock badges for milestones
- **XP & Levels**: Progress tracking with experience points
- **Alchemy Game**: Discovery-based mini-game for exploration

### 🌍 Accessibility
- **Multilingual Support**: English, Portuguese, Spanish
- **Responsive Design**: Mobile-first, works on all devices
- **PWA Features**: Offline functionality, installable
- **Modern Typography**: Enhanced readability with professional fonts

## API Documentation

### Authentication Endpoints
- `POST /api/auth/login` - User authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/logout` - User logout

### Learning Module Endpoints
- `GET /api/modules` - Fetch all learning modules
- `GET /api/modules/:id` - Get specific module
- `GET /api/challenges/module/:moduleId` - Get challenges for module

### Progress Tracking Endpoints
- `GET /api/users/:userId/progress` - User progress data
- `POST /api/users/:userId/progress` - Update progress
- `GET /api/users/:userId/achievements` - User achievements

### Alchemy Game Endpoints
- `GET /api/alchemy/elements` - All alchemy elements
- `POST /api/users/:userId/alchemy/combine` - Combine elements

## Development Guidelines

### Code Quality Standards
- **TypeScript Strict Mode**: Full type safety enforcement
- **Error Handling**: Comprehensive try-catch with user-friendly messages
- **API Validation**: Zod schema validation for all endpoints
- **Performance**: Optimized queries and lazy loading

### Design System
- **Colors**: Blue primary (#3B82F6), green success (#16A34A), orange motivation (#F97316)
- **Typography**: Inter (body), JetBrains Mono (code), Orbitron (headings)
- **Components**: ShadCN/UI for consistent design patterns
- **Responsive**: Mobile-first approach with Tailwind CSS

## Deployment

### Replit Deployment (Recommended)
1. Fork this repository on Replit
2. Environment variables are automatically configured
3. Click "Deploy" in the Replit interface
4. Application will be available at your assigned `.replit.app` domain

### Manual Deployment
For platforms supporting Node.js + PostgreSQL:

1. Set environment variables:
   ```bash
   DATABASE_URL=your_postgresql_connection_string
   OPENAI_API_KEY=your_openai_api_key
   ```

2. Build and deploy:
   ```bash
   npm run build
   npm start
   ```

## Contributing

We welcome contributions! Please:

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## Performance Metrics

- **Page Load Time**: < 3 seconds (optimized with Vite)
- **First Contentful Paint**: < 2 seconds
- **Mobile Performance**: 95+ Lighthouse score
- **Accessibility**: WCAG 2.1 AA compliant

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

**Built with ❤️ using modern web technologies for accessible, engaging education.**