// CyberLearn AI - Service Worker for PWA functionality

const CACHE_NAME = 'cyberlearn-cache-v1';

// Assets to cache immediately on install
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/favicon.svg',
  '/icons/cody-cat.svg'
];

// Assets to cache on first use
const DYNAMIC_CACHE_URLS = [
  '/learning-module/1',
  '/achievements',
  '/profile'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Caching static files');
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => self.skipWaiting())
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.filter((name) => {
          return name !== CACHE_NAME;
        }).map((name) => {
          console.log('Service Worker: Clearing old cache:', name);
          return caches.delete(name);
        })
      );
    }).then(() => {
      console.log('Service Worker: Now ready to handle fetches!');
      return self.clients.claim();
    })
  );
});

// Helper function to detect API requests
const isApiRequest = (url) => {
  return url.pathname.startsWith('/api/');
};

// Helper function to determine if a request should be cached
const shouldCache = (url) => {
  // Don't cache API requests
  if (isApiRequest(url)) return false;
  
  // Don't cache query parameters for dynamic content
  if (url.search && url.search.length > 0) return false;
  
  // Cache HTML, CSS, JS, font files
  const fileExtension = url.pathname.split('.').pop().toLowerCase();
  const cacheableExtensions = ['html', 'css', 'js', 'svg', 'woff', 'woff2', 'ttf', 'otf'];
  
  if (cacheableExtensions.includes(fileExtension)) return true;
  
  // Cache main routes without extensions (they'll be handled by the router)
  if (!fileExtension) return true;
  
  return false;
};

// Fetch event - serve from cache, then network
self.addEventListener('fetch', (event) => {
  // Skip non-GET requests
  if (event.request.method !== 'GET') return;
  
  const requestUrl = new URL(event.request.url);
  
  // API requests should always go to the network
  if (isApiRequest(requestUrl)) {
    return;
  }
  
  event.respondWith(
    caches.match(event.request)
      .then((cachedResponse) => {
        // Return cached response if found
        if (cachedResponse) {
          return cachedResponse;
        }
        
        // Otherwise fetch from network
        return fetch(event.request)
          .then((response) => {
            // Don't cache if response is not valid
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Check if this resource should be cached
            if (shouldCache(requestUrl)) {
              // Clone the response to cache it and return it
              const responseToCache = response.clone();
              caches.open(CACHE_NAME)
                .then((cache) => {
                  cache.put(event.request, responseToCache);
                });
            }
            
            return response;
          })
          .catch(() => {
            // Fallback for navigation routes when offline
            if (event.request.mode === 'navigate') {
              return caches.match('/');
            }
            
            return null;
          });
      })
  );
});

// Background sync for offline actions
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-user-progress') {
    event.waitUntil(syncUserProgress());
  }
});

// Push event - handle push notifications
self.addEventListener('push', (event) => {
  if (!event.data) return;
  
  const data = event.data.json();
  
  const options = {
    body: data.body || 'New notification from CyberLearn',
    icon: '/icons/favicon.svg',
    badge: '/icons/cody-cat.svg',
    vibrate: [100, 50, 100],
    data: {
      url: data.url || '/'
    }
  };
  
  event.waitUntil(
    self.registration.showNotification(data.title || 'CyberLearn Notification', options)
  );
});

// Notification click event - handle notification clicks
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  // Open the URL from the notification data or default to home
  const urlToOpen = event.notification.data?.url || '/';
  
  event.waitUntil(
    clients.matchAll({
      type: 'window',
      includeUncontrolled: true
    })
    .then((windowClients) => {
      // Check if there's already a window open with the URL
      for (let i = 0; i < windowClients.length; i++) {
        const client = windowClients[i];
        if (client.url === urlToOpen && 'focus' in client) {
          return client.focus();
        }
      }
      
      // If not, open a new window
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});

// Function to handle syncing user progress when coming back online
async function syncUserProgress() {
  // In a real app, this would pull from IndexedDB and sync with the server
  console.log('Syncing user progress after being offline');
  
  // Here we would retrieve offline actions from IndexedDB
  // and submit them to the server
  
  return Promise.resolve();
}
