import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import {
  BookOpen,
  Code,
  ArrowRight,
  Code2,
  Brain,
  Server,
  Trophy,
  Users,
  TrendingUp,
  Clock,
  Star,
  Play,
  Zap,
  Target,
  ChevronRight,
  Sparkles,
  Activity
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import ModernLayout from '@/components/ui/layouts/ModernLayout';
import { ModernCard, LearningModuleCard } from '@/components/ui/modern-card';
import DashboardGrid, { StatsWidget, QuickAction } from '@/components/ui/dashboard-grid';
import { useUserPreferences } from '@/hooks/use-preferences';

export default function ModernHome() {
  const [_, navigate] = useLocation();
  const { language } = useUserPreferences();
  
  // Demo user data
  const [user] = useState({
    id: 1,
    username: 'cyberlearner',
    displayName: 'Cyber Learner',
    level: 3,
    xp: 2350,
    avatar: '/icons/cody-cat.svg'
  });

  // SEO optimization
  useEffect(() => {
    document.title = "Cody Verse | AI Learning Platform";
    const metaDescription = document.querySelector('meta[name="description"]') || document.createElement('meta');
    metaDescription.setAttribute('name', 'description');
    metaDescription.setAttribute('content', 'Immersive AI learning platform with cyberpunk interface. Learn AI, ML, and server architecture with personalized assistants.');
    if (!document.querySelector('meta[name="description"]')) {
      document.head.appendChild(metaDescription);
    }
  }, []);

  // Fetch data with optimized queries
  const { data: modules, isLoading: modulesLoading } = useQuery<any[]>({
    queryKey: ['/api/modules'],
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  const { data: userProgress } = useQuery<any[]>({
    queryKey: [`/api/users/${user.id}/progress`],
    staleTime: 2 * 60 * 1000,
  });

  // Calculate progress statistics
  const totalModules = modules?.length || 0;
  const completedModules = userProgress?.filter(p => p.completed).length || 0;
  const overallProgress = totalModules > 0 ? Math.round((completedModules / totalModules) * 100) : 0;

  // Featured learning paths
  const learningPaths = [
    {
      id: 1,
      title: "AI Fundamentals",
      description: "Master the core concepts of artificial intelligence and machine learning with hands-on projects.",
      icon: Brain as any,
      difficulty: "Beginner",
      estimatedTime: "4 weeks",
      studentsEnrolled: 1240,
      rating: 4.8,
      progress: 65
    },
    {
      id: 2,
      title: "MCP Server Architecture", 
      description: "Learn to build and deploy scalable AI model servers using modern cloud infrastructure.",
      icon: Server as any,
      difficulty: "Intermediate",
      estimatedTime: "6 weeks",
      studentsEnrolled: 856,
      rating: 4.9,
      progress: 30
    },
    {
      id: 3,
      title: "AI Agent Development",
      description: "Create intelligent agents that can reason, plan, and execute complex tasks autonomously.",
      icon: Code2 as any,
      difficulty: "Advanced",
      estimatedTime: "8 weeks",
      studentsEnrolled: 542,
      rating: 4.7,
      progress: 0
    }
  ];

  // Quick actions
  const quickActions = [
    {
      title: "Start Learning",
      description: "Jump into your next module",
      icon: Play as any,
      onClick: () => navigate('/learning-module/1'),
      variant: 'primary' as const
    },
    {
      title: "Take Challenge",
      description: "Test your skills",
      icon: Target as any,
      onClick: () => navigate('/challenge/1'),
      variant: 'secondary' as const
    },
    {
      title: "Browse Projects",
      description: "Explore community creations",
      icon: Code as any,
      onClick: () => navigate('/projects'),
      variant: 'outline' as const
    }
  ];

  return (
    <ModernLayout user={user} showAssistant={true}>
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Hero Section */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden bg-gradient-to-r from-gray-900/50 via-gray-800/50 to-gray-900/50 backdrop-blur-sm border border-gray-700 rounded-2xl p-8 md:p-12"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-blue-500/10" />
          <div className="relative z-10">
            <div className="flex flex-col lg:flex-row items-center justify-between">
              <div className="flex-1 space-y-6 lg:pr-8">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                    Welcome to the Future of Learning
                  </h1>
                  <p className="text-xl text-gray-300 mt-4 leading-relaxed">
                    Master AI and machine learning through immersive, hands-on experiences in our cyberpunk-inspired learning environment.
                  </p>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="flex flex-wrap gap-4"
                >
                  <Button 
                    size="lg"
                    onClick={() => navigate('/learning-module/1')}
                    className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white px-8 py-3"
                  >
                    <Play className="mr-2 h-5 w-5" />
                    Start Learning Now
                  </Button>
                  <Button 
                    size="lg"
                    variant="outline"
                    onClick={() => navigate('/achievements')}
                    className="border-cyan-500 text-cyan-400 hover:bg-cyan-500/20 px-8 py-3"
                  >
                    <Trophy className="mr-2 h-5 w-5" />
                    View Achievements
                  </Button>
                </motion.div>
              </div>

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 }}
                className="flex-shrink-0 mt-8 lg:mt-0"
              >
                <div className="relative">
                  <div className="w-64 h-64 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-full flex items-center justify-center">
                    <Brain className="w-32 h-32 text-cyan-400" />
                  </div>
                  <div className="absolute inset-0 rounded-full border-2 border-cyan-500/30 animate-pulse" />
                </div>
              </motion.div>
            </div>
          </div>
        </motion.section>

        {/* Stats Overview */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <DashboardGrid columns={4} gap="md">
            <StatsWidget
              title="Learning Progress"
              value={`${overallProgress}%`}
              subtitle={`${completedModules}/${totalModules} modules completed`}
              icon={TrendingUp as any}
              trend="up"
              trendValue="+12%"
            />
            <StatsWidget
              title="Total XP"
              value={user.xp.toLocaleString()}
              subtitle="Experience points earned"
              icon={Star as any}
              trend="up"
              trendValue="+250"
            />
            <StatsWidget
              title="Current Level"
              value={user.level}
              subtitle="AI Learning Level"
              icon={Zap as any}
              trend="stable"
              trendValue="Level 3"
            />
            <StatsWidget
              title="Study Streak"
              value="7 days"
              subtitle="Keep it up!"
              icon={Activity as any}
              trend="up"
              trendValue="+2 days"
            />
          </DashboardGrid>
        </motion.section>

        {/* Available Modules */}
        {!modulesLoading && modules && modules.length > 0 && (
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-bold text-white flex items-center">
                <BookOpen className="mr-3 h-8 w-8 text-cyan-400" />
                Módulos de Aprendizado
              </h2>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Brain className="w-4 h-4" />
                <span>{modules.length} módulos disponíveis</span>
              </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {modules.map((module: any, index: number) => {
                const moduleProgress = userProgress?.find((p: any) => p.moduleId === module.id);
                const progressPercent = moduleProgress?.progress || 0;
                const isCompleted = moduleProgress?.completed || false;
                
                return (
                  <motion.div
                    key={module.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 * index }}
                    className="group"
                  >
                    <div className="relative h-full bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 hover:border-cyan-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/10">
                      {/* Status Badge */}
                      <div className="absolute top-4 right-4">
                        {isCompleted ? (
                          <div className="flex items-center gap-1 bg-green-500/20 text-green-400 px-2 py-1 rounded-full text-xs font-medium">
                            <Trophy className="w-3 h-3" />
                            Concluído
                          </div>
                        ) : progressPercent > 0 ? (
                          <div className="flex items-center gap-1 bg-blue-500/20 text-blue-400 px-2 py-1 rounded-full text-xs font-medium">
                            <Play className="w-3 h-3" />
                            Em Progresso
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 bg-gray-500/20 text-gray-400 px-2 py-1 rounded-full text-xs font-medium">
                            <BookOpen className="w-3 h-3" />
                            Novo
                          </div>
                        )}
                      </div>

                      {/* Module Icon */}
                      <div className="mb-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                          <Brain className="w-6 h-6 text-cyan-400" />
                        </div>
                      </div>

                      {/* Module Info */}
                      <div className="mb-4">
                        <h3 className="text-xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                          {module.title}
                        </h3>
                        <p className="text-gray-400 text-sm leading-relaxed line-clamp-3">
                          {module.description || 'Módulo abrangente de aprendizado em IA e tecnologias modernas'}
                        </p>
                      </div>

                      {/* Progress Bar */}
                      {progressPercent > 0 && (
                        <div className="mb-4">
                          <div className="flex justify-between text-xs text-gray-400 mb-1">
                            <span>Progresso</span>
                            <span>{Math.round(progressPercent)}%</span>
                          </div>
                          <div className="w-full bg-gray-700 rounded-full h-2">
                            <div 
                              className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${progressPercent}%` }}
                            />
                          </div>
                        </div>
                      )}

                      {/* Module Stats */}
                      <div className="grid grid-cols-3 gap-2 mb-6 text-center">
                        <div className="bg-gray-800/50 rounded-lg p-2">
                          <div className="text-xs text-gray-400">Duração</div>
                          <div className="text-sm font-semibold text-white">45min</div>
                        </div>
                        <div className="bg-gray-800/50 rounded-lg p-2">
                          <div className="text-xs text-gray-400">Nível</div>
                          <div className="text-sm font-semibold text-white">Iniciante</div>
                        </div>
                        <div className="bg-gray-800/50 rounded-lg p-2">
                          <div className="text-xs text-gray-400">XP</div>
                          <div className="text-sm font-semibold text-white">100</div>
                        </div>
                      </div>

                      {/* Action Button */}
                      <Button 
                        className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white group-hover:shadow-lg group-hover:shadow-cyan-500/25 transition-all duration-300"
                        onClick={() => navigate(`/learning-module/${module.id}`)}
                      >
                        {isCompleted ? (
                          <>
                            <Trophy className="w-4 h-4 mr-2" />
                            Revisar Módulo
                          </>
                        ) : progressPercent > 0 ? (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Continuar
                          </>
                        ) : (
                          <>
                            <ArrowRight className="w-4 h-4 mr-2" />
                            Iniciar Módulo
                          </>
                        )}
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.section>
        )}

        {/* Featured Learning Paths */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white flex items-center">
              <Sparkles className="mr-3 h-6 w-6 text-cyan-400" />
              Featured Learning Paths
            </h2>
            <Button variant="ghost" className="text-cyan-400 hover:text-cyan-300">
              Explore All <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          </div>

          <DashboardGrid columns={3} gap="lg">
            {learningPaths.map((path) => (
              <ModernCard
                key={path.id}
                title={path.title}
                description={path.description}
                badge={path.difficulty}
                badgeVariant={path.difficulty === 'Beginner' ? 'secondary' : path.difficulty === 'Intermediate' ? 'default' : 'destructive'}
                stats={[
                  { icon: Clock, value: path.estimatedTime, label: "Duration" },
                  { icon: Users, value: path.studentsEnrolled.toLocaleString(), label: "Students" },
                  { icon: Star, value: path.rating, label: "Rating" }
                ]}
                action={{
                  label: path.progress > 0 ? "Continue" : "Start Learning",
                  onClick: () => navigate(`/learning-module/${path.id}`)
                }}
                variant="interactive"
                gradient
              />
            ))}
          </DashboardGrid>
        </motion.section>

        {/* Quick Actions */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Target className="mr-3 h-6 w-6 text-cyan-400" />
            Quick Actions
          </h2>

          <DashboardGrid columns={3} gap="md">
            {quickActions.map((action, index) => (
              <QuickAction
                key={index}
                title={action.title}
                description={action.description}
                icon={action.icon}
                onClick={action.onClick}
                variant={action.variant}
              />
            ))}
          </DashboardGrid>
        </motion.section>

        {/* Progress Overview */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-gray-800/30 backdrop-blur-sm border border-gray-700 rounded-xl p-6"
        >
          <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
            <TrendingUp className="mr-2 h-5 w-5 text-cyan-400" />
            Your Learning Journey
          </h3>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-300">Overall Progress</span>
              <span className="text-cyan-400 font-medium">{overallProgress}%</span>
            </div>
            <Progress value={overallProgress} className="h-2" />
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-white">{completedModules}</div>
                <div className="text-sm text-gray-400">Modules Completed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">{totalModules - completedModules}</div>
                <div className="text-sm text-gray-400">Modules Remaining</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">7</div>
                <div className="text-sm text-gray-400">Day Streak</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">12h</div>
                <div className="text-sm text-gray-400">Time Spent</div>
              </div>
            </div>
          </div>
        </motion.section>
      </div>
    </ModernLayout>
  );
}