import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import {
  Award,
  Star,
  Trophy,
  Sparkles,
  Filter,
  CheckCircle,
  ChevronDown,
  Search
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import ModernLayout from '@/components/ui/layouts/ModernLayout';
import { ResponsiveGrid } from '@/components/ui/responsive-grid';
import AchievementBadge from '@/components/ui/game/AchievementBadge';
import ProgressBar from '@/components/ui/game/ProgressBar';
import { useProgress } from '@/hooks/use-progress';

export default function Achievements() {
  const [filter, setFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [newlyUnlocked, setNewlyUnlocked] = useState<number[]>([]);
  
  // Mock user for the demo
  const [user] = useState({
    id: 1,
    username: 'cyberlearner',
    displayName: 'Cyber Learner',
    level: 3,
    xp: 2350,
    preferredCharacter: 'NEXUS'
  });
  
  // Fetch all achievements
  const { data: allAchievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ['/api/achievements'],
  });
  
  // Get user achievements
  const { 
    achievements: userAchievements, 
    isLoading: userAchievementsLoading,
    getUnlockedAchievementsCount
  } = useProgress({ userId: user.id });
  
  // Simulate newly unlocked achievements for demo
  useEffect(() => {
    if (Array.isArray(userAchievements) && userAchievements.length > 0) {
      // For demo purposes, mark the most recent achievement as newly unlocked
      const mostRecentAchievement = userAchievements.reduce((latest: any, current: any) => {
        return new Date(current.unlockedAt) > new Date(latest.unlockedAt) ? current : latest;
      }, userAchievements[0]);
      
      setNewlyUnlocked([mostRecentAchievement.achievementId]);
    }
  }, [userAchievements]);
  
  // Process achievements data
  const processedAchievements = React.useMemo(() => {
    if (!Array.isArray(allAchievements) || !Array.isArray(userAchievements)) return [];
    
    return allAchievements.map((achievement: any) => {
      const userAchievement = userAchievements.find(
        (ua: any) => ua.achievementId === achievement.id
      );
      
      return {
        ...achievement,
        unlocked: !!userAchievement,
        unlockedAt: userAchievement?.unlockedAt || null,
        isNew: newlyUnlocked.includes(achievement.id)
      };
    });
  }, [allAchievements, userAchievements, newlyUnlocked]);
  
  // Filter achievements
  const filteredAchievements = React.useMemo(() => {
    if (!processedAchievements) return [];
    
    return processedAchievements.filter((achievement) => {
      // Apply search filter
      const matchesSearch = 
        achievement.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        achievement.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      // Apply category filter
      let matchesFilter = true;
      if (filter === 'unlocked') {
        matchesFilter = achievement.unlocked;
      } else if (filter === 'locked') {
        matchesFilter = !achievement.unlocked;
      }
      
      return matchesSearch && matchesFilter;
    });
  }, [processedAchievements, filter, searchQuery]);
  
  // Group achievements by type
  const achievementsByType = React.useMemo(() => {
    if (!processedAchievements) return {};
    
    return processedAchievements.reduce((acc: any, achievement) => {
      const condition = typeof achievement.condition === 'string' 
        ? JSON.parse(achievement.condition) 
        : achievement.condition;
      
      const type = condition?.type || 'other';
      if (!acc[type]) {
        acc[type] = [];
      }
      acc[type].push(achievement);
      return acc;
    }, {});
  }, [processedAchievements]);
  
  // Get achievement icon based on type
  const getAchievementIcon = (achievement: any) => {
    const condition = typeof achievement.condition === 'string' 
      ? JSON.parse(achievement.condition) 
      : achievement.condition;
    
    switch (condition?.type) {
      case 'module_completion':
        return <Award className="h-5 w-5 text-primary" />;
      case 'challenge_completion':
        return <Trophy className="h-5 w-5 text-secondary" />;
      case 'learning_streak':
        return <Star className="h-5 w-5 text-accent" />;
      default:
        return <Sparkles className="h-5 w-5 text-primary" />;
    }
  };
  
  const isLoading = achievementsLoading || userAchievementsLoading;
  
  return (
    <ModernLayout>
      <ResponsiveGrid>
        <div className="lg:col-span-4 space-y-6">
          {/* Stats summary */}
          <Card className="bg-cardBackground border-gray-700">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              <div className="flex flex-col items-center justify-center text-center p-4 bg-primary/10 rounded-lg border border-primary/30">
                <Award className="h-10 w-10 text-primary mb-2" />
                <h3 className="text-2xl font-bold text-white">{getUnlockedAchievementsCount()}</h3>
                <p className="text-white/70">Achievements Earned</p>
              </div>
              
              <div className="flex flex-col items-center justify-center text-center p-4 bg-secondary/10 rounded-lg border border-secondary/30">
                <Star className="h-10 w-10 text-secondary mb-2" />
                <h3 className="text-2xl font-bold text-white">{user.level}</h3>
                <p className="text-white/70">Current Level</p>
              </div>
              
              <div className="flex flex-col items-center justify-center text-center p-4 bg-accent/10 rounded-lg border border-accent/30">
                <Trophy className="h-10 w-10 text-accent mb-2" />
                <h3 className="text-2xl font-bold text-white">{user.xp}</h3>
                <p className="text-white/70">Total XP</p>
              </div>
            </div>
            
            <div className="mt-6">
              <p className="text-sm text-white/70 mb-2">Level Progress</p>
              <ProgressBar level={user.level} currentXp={user.xp} />
            </div>
          </CardContent>
        </Card>
        
          {/* Achievements list */}
          <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-2">
              <Trophy className="h-6 w-6 text-primary" />
              <h2 className="text-xl font-bold">Achievements Gallery</h2>
              {!isLoading && (
                <Badge className="bg-primary/20 text-primary border-primary/30">
                  {Array.isArray(userAchievements) ? userAchievements.length : 0} / {Array.isArray(allAchievements) ? allAchievements.length : 0}
                </Badge>
              )}
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <div className="relative w-full sm:w-auto">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-white/50" />
                <Input
                  placeholder="Search achievements..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-gray-800 border-gray-700 w-full sm:w-[200px]"
                />
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="border-gray-700">
                    <Filter className="mr-2 h-4 w-4" />
                    Filter
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-gray-900 border-gray-700">
                  <DropdownMenuCheckboxItem
                    checked={filter === 'all'}
                    onCheckedChange={() => setFilter('all')}
                    className="text-white"
                  >
                    All Achievements
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={filter === 'unlocked'}
                    onCheckedChange={() => setFilter('unlocked')}
                    className="text-white"
                  >
                    Unlocked Only
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={filter === 'locked'}
                    onCheckedChange={() => setFilter('locked')}
                    className="text-white"
                  >
                    Locked Only
                  </DropdownMenuCheckboxItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          
          {isLoading ? (
            <div className="h-64 flex items-center justify-center">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              >
                <Trophy className="h-10 w-10 text-primary" />
              </motion.div>
            </div>
          ) : (
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="mb-6 bg-gray-900/50">
                <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-black">
                  <Sparkles className="h-4 w-4 mr-2" />
                  All
                </TabsTrigger>
                <TabsTrigger value="by-type" className="data-[state=active]:bg-primary data-[state=active]:text-black">
                  <Filter className="h-4 w-4 mr-2" />
                  By Type
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="all" className="m-0 space-y-6">
                {filteredAchievements.length === 0 ? (
                  <div className="text-center py-12 bg-gray-900/30 rounded-lg border border-gray-800">
                    <Trophy className="h-12 w-12 text-white/30 mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-white/80 mb-2">No Achievements Found</h3>
                    <p className="text-white/60 max-w-md mx-auto">
                      {searchQuery 
                        ? "No achievements match your search criteria. Try a different search term." 
                        : filter === 'unlocked' 
                          ? "You haven't unlocked any achievements yet. Complete challenges and modules to earn achievements!" 
                          : "No achievements available. Check back soon!"}
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    <AnimatePresence>
                      {filteredAchievements.map((achievement) => (
                        <motion.div
                          key={achievement.id}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                          transition={{ duration: 0.3 }}
                          className="flex justify-center"
                        >
                          <AchievementBadge
                            title={achievement.title}
                            description={achievement.description}
                            icon={achievement.icon}
                            xpReward={achievement.xpReward}
                            unlocked={achievement.unlocked}
                            animateUnlock={achievement.isNew}
                          />
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="by-type" className="m-0 space-y-6">
                {Object.keys(achievementsByType).length === 0 ? (
                  <div className="text-center py-12 bg-gray-900/30 rounded-lg border border-gray-800">
                    <Trophy className="h-12 w-12 text-white/30 mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-white/80 mb-2">No Achievements Found</h3>
                    <p className="text-white/60">Check back soon for more achievements to unlock!</p>
                  </div>
                ) : (
                  <div className="space-y-8">
                    {Object.entries(achievementsByType).map(([type, achievements]) => {
                      // Only show categories that match the current filter
                      const filteredTypeAchievements = (achievements as any[]).filter(achievement => {
                        if (filter === 'unlocked') return achievement.unlocked;
                        if (filter === 'locked') return !achievement.unlocked;
                        return true;
                      });
                      
                      if (filteredTypeAchievements.length === 0) return null;
                      
                      // Format type name for display
                      const formatTypeName = (type: string) => {
                        switch(type) {
                          case 'module_completion': return 'Learning Modules';
                          case 'challenge_completion': return 'Challenges';
                          case 'learning_streak': return 'Learning Streaks';
                          case 'level_up': return 'Level Milestones';
                          case 'project_milestone': return 'Project Milestones';
                          default: return 'Other Achievements';
                        }
                      };
                      
                      return (
                        <div key={type}>
                          <div className="flex items-center mb-4">
                            {type === 'module_completion' && <Award className="h-5 w-5 text-primary mr-2" />}
                            {type === 'challenge_completion' && <Trophy className="h-5 w-5 text-secondary mr-2" />}
                            {type === 'learning_streak' && <Star className="h-5 w-5 text-accent mr-2" />}
                            {!['module_completion', 'challenge_completion', 'learning_streak'].includes(type) && (
                              <Sparkles className="h-5 w-5 text-primary mr-2" />
                            )}
                            <h3 className="text-lg font-bold">{formatTypeName(type)}</h3>
                          </div>
                          
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                            {filteredTypeAchievements.map((achievement: any) => (
                              <motion.div
                                key={achievement.id}
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ duration: 0.3 }}
                                className="flex justify-center"
                              >
                                <AchievementBadge
                                  title={achievement.title}
                                  description={achievement.description}
                                  icon={achievement.icon}
                                  xpReward={achievement.xpReward}
                                  unlocked={achievement.unlocked}
                                  animateUnlock={achievement.isNew}
                                />
                              </motion.div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          )}
          </div>
        </div>
      </ResponsiveGrid>
    </ModernLayout>
  );
}
