import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ROUTES, LOCALIZED_CONTENT } from "@/lib/constants";
import { apiRequest } from "@/lib/queryClient";
import { useUserPreferences } from "@/hooks/use-preferences";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { language } = useUserPreferences();
  const { toast } = useToast();
  
  // Get content based on selected language
  const content = LOCALIZED_CONTENT[language] || LOCALIZED_CONTENT['en'];

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!username || !password) {
      toast({
        title: language === 'pt-br' ? "Erro" : "Error",
        description: content.field_required,
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      const response = await apiRequest<{ id: number }>(
        "POST",
        "/api/auth/login",
        { username, password }
      );
      
      if (response) {
        // Store user ID in localStorage to maintain login state
        localStorage.setItem("userId", String(response.id));
        
        // Redirect to home page
        setLocation(ROUTES.HOME);
        
        toast({
          title: content.login_title,
          description: content.success_login
        });
      }
    } catch (error) {
      toast({
        title: language === 'pt-br' ? "Erro" : "Error",
        description: content.error_login,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-black to-gray-900 p-4">
      <Card className="w-full max-w-md border-gray-800 bg-gray-950 text-gray-200 shadow-lg shadow-blue-900/20">
        <CardHeader className="space-y-1">
          <CardTitle className="text-3xl font-bold tracking-tight text-center text-blue-500">
            {content.login_title}
          </CardTitle>
          <CardDescription className="text-center text-gray-400">
            {content.login_description}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="username" className="text-sm font-medium text-gray-300">
                {content.username_label}
              </label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-gray-900 border-gray-700 text-gray-200"
                required
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="password" className="text-sm font-medium text-gray-300">
                {content.password_label}
              </label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-900 border-gray-700 text-gray-200"
                required
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              disabled={isLoading}
            >
              {isLoading ? (
                <span className="flex items-center">
                  <span className="animate-spin mr-2">⟳</span> 
                  {content.processing}
                </span>
              ) : (
                content.login_button
              )}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-sm text-gray-400">
            {content.register_prompt}{" "}
            <Link to={ROUTES.REGISTER} className="text-blue-500 hover:text-blue-400 underline">
              {content.register_link}
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}