import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useRoute, Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import {
  ArrowLeft,
  Play,
  CheckCircle,
  Trophy,
  Info,
  Lightbulb,
  Award,
  Gamepad2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import CodeEditor from '@/components/ui/code/CodeEditor';
import ModernLayout from '@/components/ui/layouts/ModernLayout';
import { ResponsiveGrid } from '@/components/ui/responsive-grid';
import AssistantCharacter from '@/components/characters/AssistantCharacter';
import { useProgress } from '@/hooks/use-progress';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { ROUTES } from '@/lib/constants';

export default function Challenge() {
  const [match, params] = useRoute('/challenge/:id');
  const challengeId = match ? parseInt(params.id) : 1;
  const { toast } = useToast();
  const [completed, setCompleted] = useState(false);
  const [showAssistant, setShowAssistant] = useState(false);
  const [attempts, setAttempts] = useState(0);
  
  // Mock user for the demo
  const [user] = useState({
    id: 1,
    username: 'cyberlearner',
    displayName: 'Cyber Learner',
    level: 3,
    xp: 2350,
    preferredCharacter: 'NEXUS'
  });
  
  // Get progress tracking hooks
  const { 
    updateChallengeStatus,
    checkAndUnlockAchievements
  } = useProgress({ userId: user.id });
  
  // Fetch challenge data
  const { data: challenge, isLoading: challengeLoading } = useQuery({
    queryKey: [`/api/challenges/${challengeId}`],
  });
  
  // Fetch all achievements to check if any should be unlocked
  const { data: allAchievements } = useQuery({
    queryKey: ['/api/achievements'],
  });
  
  // Fetch user challenge data
  const { data: userChallenge, isLoading: userChallengeLoading } = useQuery({
    queryKey: [`/api/users/${user.id}/challenges`],
    select: (data) => data.find((c: any) => c.challengeId === challengeId)
  });
  
  // Parse challenge content from JSON
  const challengeContent = challenge ? 
    (typeof challenge.content === 'string' ? JSON.parse(challenge.content) : challenge.content) : 
    {};
  
  // Parse challenge hints from JSON
  const challengeHints = challenge ? 
    (typeof challenge.hints === 'string' ? JSON.parse(challenge.hints) : challenge.hints) : 
    [];
  
  // Set initial state from user challenge data
  useEffect(() => {
    if (userChallenge) {
      setCompleted(userChallenge.completed);
      setAttempts(userChallenge.attempts);
    }
  }, [userChallenge]);
  
  // Handle successful challenge completion
  const handleChallengeComplete = async (isCorrect: boolean) => {
    if (isCorrect) {
      // Update attempt count
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      
      if (!completed) {
        setCompleted(true);
        
        // Update challenge status on the server
        try {
          await updateChallengeStatus.mutateAsync({
            challengeId,
            completed: true,
            attempts: newAttempts
          });
          
          // Check if any achievements should be unlocked
          checkAndUnlockAchievements(allAchievements);
          
          // Show success message
          toast({
            title: 'Challenge Completed!',
            description: `Congratulations! You've earned ${challenge.xpReward} XP.`,
            variant: 'default',
          });
        } catch (error) {
          console.error('Error updating challenge status:', error);
        }
      }
    } else {
      // Just increment attempts for incorrect solutions
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      
      try {
        await updateChallengeStatus.mutateAsync({
          challengeId,
          completed: false,
          attempts: newAttempts
        });
      } catch (error) {
        console.error('Error updating challenge attempts:', error);
      }
    }
  };
  
  // Toggle assistant visibility
  const toggleAssistant = () => {
    setShowAssistant(!showAssistant);
  };
  
  if (challengeLoading) {
    return (
      <ModernLayout>
        <div className="flex justify-center items-center h-64">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          >
            <Gamepad2 className="h-10 w-10 text-secondary" />
          </motion.div>
        </div>
      </ModernLayout>
    );
  }
  
  if (!challenge) {
    return (
      <ModernLayout>
        <Card className="max-w-lg mx-auto">
          <CardContent className="pt-6">
            <p className="mb-4 text-white/80">
              Sorry, we couldn't find the challenge you're looking for. It may have been moved or deleted.
            </p>
            <Button asChild>
              <Link to={ROUTES.HOME}>Return Home</Link>
            </Button>
          </CardContent>
        </Card>
      </ModernLayout>
    );
  }

  return (
    <ModernLayout>
      <ResponsiveGrid>
        {/* Main challenge area */}
        <div className="lg:col-span-3">
          <Card className="bg-glass-background border-glass-border backdrop-filter backdrop-blur-lg shadow-lg overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-primary via-secondary to-accent opacity-80"></div>
            
            <CardHeader className="border-b border-border/30 bg-gradient-to-b from-muted/20 to-transparent py-5">
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <div>
                  <Button 
                    variant="ghost" 
                    asChild 
                    className="mb-2 -ml-2 text-muted-foreground hover:text-foreground transition-colors group"
                  >
                    <Link to={ROUTES.LEARNING_MODULE.replace(':id', challenge.moduleId.toString())}>
                      <div className="flex items-center">
                        <div className="w-6 h-6 rounded-full bg-muted/20 flex items-center justify-center mr-2 group-hover:bg-muted/30 transition-colors">
                          <ArrowLeft className="h-3.5 w-3.5" />
                        </div>
                        <span>Back to Module</span>
                      </div>
                    </Link>
                  </Button>
                  <div className="flex flex-wrap items-center gap-2">
                    <CardTitle className="text-xl font-bold">{challenge.title}</CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-gradient-to-r from-secondary/90 to-secondary/70 text-black font-medium px-2.5 py-1 shadow-sm">
                        {challenge.difficulty}
                      </Badge>
                      {completed && (
                        <Badge className="bg-gradient-to-r from-primary/90 to-primary/70 text-black font-medium px-2.5 py-1 shadow-sm">
                          <Trophy className="mr-1.5 h-3.5 w-3.5" />
                          Completed
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  className="border-secondary/30 text-secondary hover:bg-secondary/10 hover:border-secondary/50 transition-colors rounded-md shadow-sm"
                  onClick={toggleAssistant}
                >
                  <Info className="mr-2 h-4 w-4" />
                  Precisa de Ajuda?
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="p-6 pt-5">
              <div>
                <div className="prose prose-invert max-w-none prose-headings:text-foreground prose-a:text-secondary mb-6">
                  <p className="text-muted-foreground text-base leading-relaxed">{challenge.description}</p>
                  
                  {/* Challenge instructions - Design aprimorado */}
                  <div className="my-6 p-5 bg-gradient-to-br from-muted/30 to-muted/10 rounded-lg border border-border/40 shadow-md">
                    <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center">
                      <div className="p-1.5 rounded-full bg-primary/10 mr-2">
                        <Play className="h-4 w-4 text-primary" />
                      </div>
                      Instruções
                    </h3>
                    <p className="text-muted-foreground mb-4 leading-relaxed">{challengeContent.instructions}</p>
                    
                    <h4 className="text-foreground font-medium mt-5 mb-3 flex items-center">
                      <div className="w-1.5 h-1.5 rounded-full bg-secondary mr-2"></div>
                      Passos a seguir:
                    </h4>
                    <ol className="list-decimal list-outside space-y-2 text-muted-foreground ml-5">
                      {challengeContent.steps?.map((step: string, index: number) => (
                        <li key={index} className="pl-1">{step}</li>
                      ))}
                    </ol>
                  </div>
                  
                  {/* Code example - Design aprimorado */}
                  {challengeContent.codeExample && (
                    <div className="my-6 p-5 bg-gradient-to-br from-primary/5 to-transparent rounded-lg border border-primary/20 shadow-md">
                      <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center">
                        <div className="p-1.5 rounded-full bg-primary/10 mr-2">
                          <Play className="h-4 w-4 text-primary" />
                        </div>
                        Exemplo
                      </h3>
                      <div className="bg-background/80 p-4 rounded-md border border-border/50 text-sm font-mono shadow-inner">
                        {challengeContent.codeExample}
                      </div>
                    </div>
                  )}
                </div>
                
                <Separator className="my-6 bg-border/40" />
                
                <div className="flex items-center mb-4">
                  <h3 className="text-xl font-bold text-foreground">Sua Solução</h3>
                  {!completed && (
                    <Badge className="bg-secondary/20 text-secondary ml-3 font-medium">
                      Código em andamento
                    </Badge>
                  )}
                </div>
                
                <div className="rounded-lg overflow-hidden border border-border/50 shadow-md">
                  <CodeEditor 
                    initialCode={challengeContent.initialCode || "// Escreva sua solução aqui"}
                    language={challengeContent.language || "javascript"}
                    challengeId={challengeId}
                    onEvaluate={handleChallengeComplete}
                    readOnly={completed && !!userChallenge?.completed}
                  />
                </div>
                
                {completed && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-6 p-5 bg-gradient-to-br from-primary/10 via-accent/5 to-transparent rounded-lg border border-primary/30 shadow-md"
                  >
                    <div className="flex items-center">
                      <div className="p-1.5 rounded-full bg-primary/20 mr-3">
                        <CheckCircle className="h-5 w-5 text-primary" />
                      </div>
                      <h3 className="text-lg font-bold text-foreground">Desafio Concluído!</h3>
                    </div>
                    <p className="mt-3 text-muted-foreground leading-relaxed pl-9">
                      Parabéns! Você completou com sucesso este desafio e ganhou <span className="text-primary font-medium">{challenge.xpReward} XP</span>. 
                      Agora você pode avançar para o próximo desafio ou continuar explorando outros módulos.
                    </p>
                    <div className="mt-4 flex flex-wrap gap-3 pl-9">
                      <Button 
                        asChild 
                        className="bg-gradient-to-r from-primary to-primary/90 hover:opacity-90 text-black font-medium shadow-md transition-all duration-200"
                      >
                        <Link to={ROUTES.LEARNING_MODULE.replace(':id', challenge.moduleId.toString())}>
                          Voltar ao Módulo
                        </Link>
                      </Button>
                      <Button 
                        variant="outline" 
                        className="border-primary/40 text-primary hover:bg-primary/10 hover:border-primary/60 transition-colors shadow-sm"
                      >
                        <Award className="mr-2 h-4 w-4" />
                        Ver Conquistas
                      </Button>
                    </div>
                  </motion.div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Sidebar redesenhada */}
        <div className="space-y-5">
          {/* Challenge info card */}
          <Card className="bg-glass-background border-glass-border backdrop-filter backdrop-blur-lg shadow-md overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-secondary/70 to-secondary/30"></div>
            
            <CardHeader className="pb-3 pt-5 border-b border-border/20">
              <CardTitle className="text-lg font-bold flex items-center">
                <div className="p-1.5 rounded-full bg-secondary/10 mr-2">
                  <Info className="h-4 w-4 text-secondary" />
                </div>
                Informações do Desafio
              </CardTitle>
            </CardHeader>
            
            <CardContent className="pt-4">
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-muted/20 to-transparent p-3 rounded-md">
                  <p className="text-muted-foreground text-xs uppercase font-medium tracking-wide mb-1">Dificuldade</p>
                  <div className="flex items-center">
                    <div className={`w-2 h-2 rounded-full mr-2 ${
                      challenge.difficulty === 'Beginner' ? 'bg-emerald-500' :
                      challenge.difficulty === 'Intermediate' ? 'bg-blue-500' :
                      challenge.difficulty === 'Advanced' ? 'bg-amber-500' :
                      'bg-rose-500'
                    }`}></div>
                    <p className="font-medium text-foreground">{challenge.difficulty}</p>
                  </div>
                </div>
                
                <div className="bg-gradient-to-r from-muted/20 to-transparent p-3 rounded-md">
                  <p className="text-muted-foreground text-xs uppercase font-medium tracking-wide mb-1">Módulo</p>
                  <Button 
                    variant="link" 
                    asChild 
                    className="p-0 h-auto text-secondary hover:text-secondary/80 font-medium"
                  >
                    <Link to={ROUTES.LEARNING_MODULE.replace(':id', challenge.moduleId.toString())}>
                      Módulo {challenge.moduleId}
                    </Link>
                  </Button>
                </div>
                
                <div className="bg-gradient-to-r from-primary/10 to-transparent p-3 rounded-md">
                  <p className="text-muted-foreground text-xs uppercase font-medium tracking-wide mb-1">Recompensa XP</p>
                  <p className="font-medium text-primary flex items-center">
                    <Trophy className="h-3.5 w-3.5 mr-1.5" />
                    +{challenge.xpReward} XP
                  </p>
                </div>
                
                <div className="bg-gradient-to-r from-muted/20 to-transparent p-3 rounded-md">
                  <p className="text-muted-foreground text-xs uppercase font-medium tracking-wide mb-1">Suas Tentativas</p>
                  <p className="font-medium text-foreground">{attempts} tentativa{attempts !== 1 ? 's' : ''}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Hints card */}
          <Card className="bg-glass-background border-glass-border backdrop-filter backdrop-blur-lg shadow-md overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary/70 to-primary/30"></div>
            
            <CardHeader className="pb-3 pt-5 border-b border-border/20">
              <CardTitle className="text-lg font-bold flex items-center">
                <div className="p-1.5 rounded-full bg-primary/10 mr-2">
                  <Lightbulb className="h-4 w-4 text-primary" />
                </div>
                Dicas
              </CardTitle>
            </CardHeader>
            
            <CardContent className="pt-4">
              {challengeHints && challengeHints.length > 0 ? (
                <div className="space-y-3">
                  {challengeHints.map((hint: string, index: number) => (
                    <div key={index} className="p-4 bg-gradient-to-r from-muted/30 to-transparent rounded-md border border-border/30 shadow-sm">
                      <div className="flex">
                        <div className="text-xs font-bold bg-primary/20 text-primary h-5 w-5 rounded-full flex items-center justify-center mr-2.5 mt-0.5 flex-shrink-0">
                          {index + 1}
                        </div>
                        <p className="text-sm text-muted-foreground">{hint}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground p-3">Nenhuma dica disponível para este desafio.</p>
              )}
            </CardContent>
            
            <CardFooter className="pt-0 pb-5">
              <Button 
                className="w-full bg-gradient-to-r from-secondary to-secondary/90 hover:opacity-90 text-black font-medium shadow-md"
                onClick={toggleAssistant}
              >
                <Info className="h-4 w-4 mr-2" />
                Obter Ajuda do Assistente IA
              </Button>
            </CardFooter>
          </Card>
        </div>
      </ResponsiveGrid>
      
      {/* AI Assistant Character (conditionally rendered) */}
      {showAssistant && (
        <AssistantCharacter 
          character={user.preferredCharacter} 
          context={`challenge: ${challenge.title}, user needs help solving a ${challenge.difficulty} difficulty coding challenge related to ${challenge.description}`}
          initialMessage={`Need help with this challenge? Let me give you a hint: ${challengeHints[0] || "Think about how the system would process the inputs you receive."}`}
          minimized={false}
        />
      )}
    </ModernLayout>
  );
}
