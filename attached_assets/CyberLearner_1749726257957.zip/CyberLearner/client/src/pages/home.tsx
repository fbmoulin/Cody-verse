import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { prefetchImages } from '@/utils/performance';
import {
  BookOpen,
  Code,
  ArrowRight,
  Code2,
  Layers,
  ChevronRight,
  Award,
  Brain,
  Server
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import ProgressBar from '@/components/ui/game/ProgressBar';
import ModernLayout from '@/components/ui/layouts/ModernLayout';
import { COLORS, ROUTES, LOCALIZED_CONTENT } from '@/lib/constants';
import { apiRequest } from '@/lib/queryClient';
import { useUserPreferences } from '@/hooks/use-preferences';
import OnboardingTutorial from '@/components/tutorial/OnboardingTutorial';
import { SkeletonLoader } from '@/components/ui/optimized-loading';
import { OptimizedImage } from '@/components/ui/optimized-image';

export default function Home() {
  const [_, navigate] = useLocation();
  const [showWelcomeBanner, setShowWelcomeBanner] = useState(true);
  const [showTutorial, setShowTutorial] = useState(true);
  const { language } = useUserPreferences();
  const localizedContent = LOCALIZED_CONTENT[language];
  
  // Aplicar configurações de SEO para a página inicial
  useEffect(() => {
    // Configurar título e meta tags dinâmicas
    document.title = "Cody Verse | Plataforma de Aprendizado de IA";
    
    // Atualizar meta description
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', 'Plataforma de aprendizado imersiva de IA com interface cyberpunk. Aprenda sobre IA, ML e arquitetura de servidores com assistentes personalizados.');
  }, []);
  
  // Mock user for the demo
  const [user] = useState({
    id: 1,
    username: 'cyberlearner',
    displayName: 'Cyber Learner',
    level: 3,
    xp: 2350,
    preferredCharacter: 'CODY'
  });
  
  // Tutorial completed handler
  const handleTutorialComplete = () => {
    setShowTutorial(false);
  };
  
  // Preload important resources to improve perceived performance
  useEffect(() => {
    // Prefetch important images that will be used in the app
    prefetchImages([
      '/icons/brain-icon.svg',
      '/icons/cody-cat.svg',
      '/icons/nexus-assistant.svg',
      '/icons/echo-assistant.svg'
    ]);
  }, []);
  
  // Fetch modules with optimized stale time
  const { data: modules, isLoading: modulesLoading } = useQuery<any[]>({
    queryKey: ['/api/modules'],
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
  });
  
  // Fetch user progress with optimized settings
  const { data: userProgress, isLoading: progressLoading } = useQuery<any[]>({
    queryKey: [`/api/users/${user.id}/progress`],
    staleTime: 2 * 60 * 1000, // 2 minutes
    refetchOnWindowFocus: true,
  });
  
  // Calculate current progress
  const continueLearningModule = modules && Array.isArray(modules) && modules.length > 0 ? modules[0] : null;
  
  // Featured paths for the homepage
  const getLocalizedPaths = () => {
    switch(language) {
      case 'pt-br':
        return [
          {
            title: "Fundamentos de IA",
            description: "Aprenda os conceitos fundamentais de inteligência artificial e aprendizado de máquina.",
            icon: <Brain className="h-8 w-8 text-primary" />,
            color: COLORS.primary,
            path: ROUTES.LEARNING_MODULE.replace(':id', '1')
          },
          {
            title: "Arquitetura de Servidores MCP",
            description: "Entenda como os servidores MCP funcionam para hospedar e executar modelos de IA de forma eficiente.",
            icon: <Server className="h-8 w-8 text-secondary" />,
            color: COLORS.secondary,
            path: ROUTES.LEARNING_MODULE.replace(':id', '2')
          },
          {
            title: "Criação de Agentes de IA",
            description: "Construa seus próprios agentes de IA que podem realizar tarefas e responder a comandos.",
            icon: <Code2 className="h-8 w-8 text-accent" />,
            color: COLORS.accent,
            path: ROUTES.LEARNING_MODULE.replace(':id', '3')
          }
        ];
      case 'es':
        return [
          {
            title: "Fundamentos de IA",
            description: "Aprende los conceptos fundamentales de inteligencia artificial y aprendizaje automático.",
            icon: <Brain className="h-8 w-8 text-primary" />,
            color: COLORS.primary,
            path: ROUTES.LEARNING_MODULE.replace(':id', '1')
          },
          {
            title: "Arquitectura de Servidores MCP",
            description: "Comprende cómo funcionan los servidores MCP para alojar y ejecutar modelos de IA de manera eficiente.",
            icon: <Server className="h-8 w-8 text-secondary" />,
            color: COLORS.secondary,
            path: ROUTES.LEARNING_MODULE.replace(':id', '2')
          },
          {
            title: "Creación de Agentes de IA",
            description: "Construye tus propios agentes de IA que pueden realizar tareas y responder a comandos.",
            icon: <Code2 className="h-8 w-8 text-accent" />,
            color: COLORS.accent,
            path: ROUTES.LEARNING_MODULE.replace(':id', '3')
          }
        ];
      default:
        return [
          {
            title: "AI Fundamentals",
            description: "Learn the core concepts of artificial intelligence and machine learning.",
            icon: <Brain className="h-8 w-8 text-primary" />,
            color: COLORS.primary,
            path: ROUTES.LEARNING_MODULE.replace(':id', '1')
          },
          {
            title: "MCP Server Architecture",
            description: "Understand how MCP servers work to host and run AI models efficiently.",
            icon: <Server className="h-8 w-8 text-secondary" />,
            color: COLORS.secondary,
            path: ROUTES.LEARNING_MODULE.replace(':id', '2')
          },
          {
            title: "AI Agent Creation",
            description: "Build your own AI agents that can perform tasks and respond to prompts.",
            icon: <Code2 className="h-8 w-8 text-accent" />,
            color: COLORS.accent,
            path: ROUTES.LEARNING_MODULE.replace(':id', '3')
          }
        ];
    }
  };
  
  const learningPaths = getLocalizedPaths();

  // Demo announcements
  const getLocalizedAnnouncements = () => {
    switch(language) {
      case 'pt-br':
        return [
          {
            title: "Novo Desafio Adicionado",
            description: "Construa um modelo de classificação de texto em nosso novo desafio.",
            date: "2 horas atrás"
          },
          {
            title: "Destaque da Comunidade",
            description: "Veja os melhores projetos criados pela nossa comunidade esta semana.",
            date: "Ontem"
          }
        ];
      case 'es':
        return [
          {
            title: "Nuevo Desafío Añadido",
            description: "Construye un modelo de clasificación de texto en nuestro nuevo desafío.",
            date: "hace 2 horas"
          },
          {
            title: "Destacados de la Comunidad",
            description: "Mira los mejores proyectos creados por nuestra comunidad esta semana.",
            date: "Ayer"
          }
        ];
      default:
        return [
          {
            title: "New Challenge Added",
            description: "Build a text classification model in our newest challenge.",
            date: "2 hours ago"
          },
          {
            title: "Community Showcase",
            description: "See the top projects created by our community this week.",
            date: "Yesterday"
          }
        ];
    }
  };
  
  const announcements = getLocalizedAnnouncements();

  return (
    <ModernLayout>
      {/* Tutorial Interativo com Personagem Animado */}
      {showTutorial && (
        <OnboardingTutorial 
          onComplete={handleTutorialComplete}
          userId={user.id}
        />
      )}
      {/* Auth Buttons - Mostra opções de login/registro visíveis */}
      <div className="flex justify-center mb-4 md:mb-6">
        <div className="w-full bg-card border border-border p-3 md:p-4 rounded-lg shadow-sm flex flex-col md:flex-row items-center gap-3 md:gap-4">
          <div className="text-center md:text-left w-full md:w-auto">
            <h3 className="heading-sm font-display text-foreground">{localizedContent.welcome_title}</h3>
            <p className="body-sm text-muted-foreground">{localizedContent.login_prompt}</p>
          </div>
          <div className="flex gap-3 w-full md:w-auto mt-2 md:mt-0">
            <Button 
              variant="outline" 
              className="flex-1 md:flex-auto"
              onClick={() => navigate(ROUTES.LOGIN)}
            >
              {localizedContent.login_title}
            </Button>
            <Button 
              className="flex-1 md:flex-auto"
              onClick={() => navigate(ROUTES.REGISTER)}
            >
              {localizedContent.register_title}
            </Button>
          </div>
        </div>
      </div>
      
      {/* Welcome Banner */}
      {showWelcomeBanner && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="relative mb-5 md:mb-8 overflow-hidden rounded-lg border border-border bg-gradient-to-r from-primary/5 to-secondary/5"
        >
          <div className="flex flex-col sm:flex-row items-center p-4 sm:p-6">
            {/* Animated Cyber Animal - Optimized with GPU acceleration */}
            <div className="w-20 h-20 sm:w-32 sm:h-32 flex-shrink-0 mb-3 sm:mb-0 sm:mr-6 bg-primary/20 rounded-full flex items-center justify-center">
              <motion.div
                className="optimize-gpu"
                animate={{ 
                  scale: [1, 1.05, 1],
                  rotate: [0, 2, 0, -2, 0]
                }}
                transition={{ 
                  duration: 4, 
                  repeat: Infinity,
                  repeatType: "reverse" 
                }}
              >
                <Brain className="w-12 h-12 sm:w-20 sm:h-20 text-primary" />
              </motion.div>
            </div>
            
            <div className="flex-1 text-center sm:text-left">
              <h2 className="heading-md font-display text-foreground mb-2">
                {localizedContent.welcome_title}
              </h2>
              <p className="body-lg text-muted-foreground mb-3 sm:mb-4">
                {localizedContent.welcome_subtitle}
              </p>
              <div className="flex flex-wrap gap-2 justify-center sm:justify-start">
                <Button 
                  onClick={() => navigate(ROUTES.LEARNING_MODULE.replace(':id', '1'))}
                  className="bg-primary text-black hover:bg-primary/80"
                  size="sm"
                  aria-label="Get started with learning modules"
                >
                  <BookOpen className="mr-2 h-4 w-4" />
                  {localizedContent.get_started}
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setShowWelcomeBanner(false)}
                  className="border-primary/50 text-primary hover:bg-primary/20"
                  size="sm"
                  aria-label="Dismiss welcome banner"
                >
                  {language === 'en' ? 'Dismiss' : language === 'pt-br' ? 'Dispensar' : 'Descartar'}
                </Button>
              </div>
            </div>
            
            {/* Abstract tech patterns */}
            <div className="absolute -top-10 -right-10 w-40 h-40 opacity-20 hidden sm:block">
              <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="50" r="40" stroke="#00FFFF" fill="none" strokeWidth="0.5" />
                <circle cx="50" cy="50" r="30" stroke="#00FFFF" fill="none" strokeWidth="0.5" />
                <circle cx="50" cy="50" r="20" stroke="#00FFFF" fill="none" strokeWidth="0.5" />
                <line x1="10" y1="50" x2="90" y2="50" stroke="#FFD700" strokeWidth="0.5" />
                <line x1="50" y1="10" x2="50" y2="90" stroke="#FFD700" strokeWidth="0.5" />
              </svg>
            </div>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        {/* Main content column */}
        <div className="md:col-span-2 space-y-4 md:space-y-6">
          {/* Continue Learning Section */}
          <Card className="bg-cardBackground border-gray-700 overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10 pb-3">
              <CardTitle className="text-lg flex items-center">
                <BookOpen className="mr-2 h-5 w-5 text-primary" />
                {localizedContent.continue_learning}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              {modulesLoading ? (
                <div className="h-24 flex items-center justify-center">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  >
                    <BookOpen className="h-6 w-6 text-secondary" />
                  </motion.div>
                </div>
              ) : continueLearningModule ? (
                <div>
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h3 className="text-white font-medium">
                        {language === 'en' 
                          ? continueLearningModule.title 
                          : language === 'pt-br' 
                            ? (continueLearningModule.title === "Introduction to AI and MCP Systems" || 
                               continueLearningModule.title === "Introduction to AI and MCP Servers")
                              ? "Introdução à IA e Servidores MCP"
                              : continueLearningModule.title
                            : (continueLearningModule.title === "Introduction to AI and MCP Systems" ||
                               continueLearningModule.title === "Introduction to AI and MCP Servers")
                              ? "Introducción a la IA y Servidores MCP"
                              : continueLearningModule.title
                        }
                      </h3>
                      <p className="text-sm text-white/70 mt-1">
                        {language === 'en' 
                          ? `${continueLearningModule.description.substring(0, 100)}...`
                          : language === 'pt-br'
                            ? (continueLearningModule.description.includes("Learn about AI fundamentals") ||
                               continueLearningModule.description.includes("Learn the basics of AI") ||
                               continueLearningModule.title === "Introduction to AI and MCP Systems" ||
                               continueLearningModule.title === "Introduction to AI and MCP Servers")
                              ? "Aprenda os conceitos básicos de IA e a arquitetura de servidores MCP. Este módulo cobre fundamentos essenciais..."
                              : `${continueLearningModule.description.substring(0, 100)}...`
                            : (continueLearningModule.description.includes("Learn about AI fundamentals") ||
                               continueLearningModule.description.includes("Learn the basics of AI") ||
                               continueLearningModule.title === "Introduction to AI and MCP Systems" ||
                               continueLearningModule.title === "Introduction to AI and MCP Servers")
                              ? "Aprende los conceptos básicos de IA y la arquitectura de servidores MCP. Este módulo cubre fundamentos esenciales..."
                              : `${continueLearningModule.description.substring(0, 100)}...`
                        }
                      </p>
                    </div>
                    <Button 
                      size="sm"
                      asChild
                      className="bg-secondary hover:bg-secondary/80 text-black"
                    >
                      <Link to={ROUTES.LEARNING_MODULE.replace(':id', continueLearningModule.id.toString())}>
                        {localizedContent.continue_module}
                        <ChevronRight className="ml-1 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                  
                  <ProgressBar 
                    level={1} 
                    currentXp={350} 
                    label={false}
                  />
                  
                  <div className="mt-2 flex justify-between text-xs">
                    <span className="text-white/60">
                      {language === 'en' ? '30% complete' : 
                       language === 'pt-br' ? '30% completo' : 
                       '30% completado'}
                    </span>
                    <span className="text-primary">
                      {language === 'en' ? `+${continueLearningModule.xpReward} XP on completion` : 
                       language === 'pt-br' ? `+${continueLearningModule.xpReward} XP ao completar` : 
                       `+${continueLearningModule.xpReward} XP al completar`}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-white/70 mb-3">
                    {language === 'en' ? 'No modules found. Start your first lesson!' : 
                     language === 'pt-br' ? 'Nenhum módulo encontrado. Inicie sua primeira lição!' : 
                     'No se encontraron módulos. ¡Comienza tu primera lección!'}
                  </p>
                  <Button className="bg-primary hover:bg-primary/80 text-black">
                    <BookOpen className="mr-2 h-4 w-4" />
                    {language === 'en' ? 'Browse Modules' : 
                     language === 'pt-br' ? 'Explorar Módulos' : 
                     'Explorar Módulos'}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Learning Paths */}
          <div>
            <h2 className="text-xl font-bold mb-3 flex items-center">
              <Layers className="mr-2 text-primary" />
              {localizedContent.modules_title}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              {learningPaths.map((path, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Card className="bg-cardBackground border-gray-700 h-full flex flex-col">
                    <CardHeader className="pb-2 pt-3 px-3 sm:px-4 sm:pt-4">
                      <div className="mb-2 flex justify-center sm:justify-start">
                        {path.icon}
                      </div>
                      <CardTitle className="text-base text-center sm:text-left">{path.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-2 pb-3 px-3 sm:px-4 flex-1">
                      <p className="text-sm text-white/70 text-center sm:text-left">{path.description}</p>
                    </CardContent>
                    <div className="p-3 sm:p-4 pt-0 mt-auto">
                      <Button 
                        asChild
                        className="w-full bg-gray-800 hover:bg-gray-700 border border-gray-700 text-sm"
                        size="sm"
                      >
                        <Link to={path.path}>
                          {language === 'en' ? 'Explore Path' : 
                           language === 'pt-br' ? 'Explorar Módulo' : 
                           'Explorar Módulo'}
                          <ArrowRight className="ml-2 h-3 w-3 sm:h-4 sm:w-4" />
                        </Link>
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* User Progress Card */}
          <Card className="bg-cardBackground border-gray-700">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-accent/10 pb-3">
              <CardTitle className="text-lg flex items-center">
                <Award className="mr-2 h-5 w-5 text-primary" />
                {language === 'en' ? 'Your Progress' : 
                 language === 'pt-br' ? 'Seu Progresso' : 
                 'Tu Progreso'}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-3">
                  <span className="text-primary text-xl font-bold">{user.level}</span>
                </div>
                <div>
                  <h3 className="font-medium">
                    {language === 'en' ? `Level ${user.level} Explorer` : 
                     language === 'pt-br' ? `Explorador Nível ${user.level}` : 
                     `Explorador Nivel ${user.level}`}
                  </h3>
                  <p className="text-sm text-white/70">
                    {language === 'en' ? 'Keep learning to level up!' : 
                     language === 'pt-br' ? 'Continue aprendendo para subir de nível!' : 
                     '¡Sigue aprendiendo para subir de nivel!'}
                  </p>
                </div>
              </div>
              
              <ProgressBar 
                level={user.level} 
                currentXp={user.xp} 
              />
              
              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="bg-gray-800/50 rounded-md p-3 text-center">
                  <p className="text-2xl font-bold text-primary">2</p>
                  <p className="text-xs text-white/70">
                    {language === 'en' ? 'Modules Completed' : 
                     language === 'pt-br' ? 'Módulos Completados' : 
                     'Módulos Completados'}
                  </p>
                </div>
                <div className="bg-gray-800/50 rounded-md p-3 text-center">
                  <p className="text-2xl font-bold text-secondary">5</p>
                  <p className="text-xs text-white/70">
                    {language === 'en' ? 'Challenges Solved' : 
                     language === 'pt-br' ? 'Desafios Resolvidos' : 
                     'Desafíos Resueltos'}
                  </p>
                </div>
              </div>
              
              <Button 
                className="w-full mt-4 bg-primary hover:bg-primary/80 text-black"
                asChild
              >
                <Link to={ROUTES.ACHIEVEMENTS}>
                  {language === 'en' ? 'View Achievements' :
                   language === 'pt-br' ? 'Ver Conquistas' :
                   'Ver Logros'}
                  <Award className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
          
          {/* Announcements */}
          <Card className="bg-cardBackground border-gray-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">
                {language === 'en' ? 'Announcements' : 
                 language === 'pt-br' ? 'Anúncios' : 
                 'Anuncios'}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-3">
                {announcements.map((announcement, index) => (
                  <div 
                    key={index}
                    className="border-b border-gray-800 last:border-0 pb-3 last:pb-0"
                  >
                    <h4 className="font-medium">{announcement.title}</h4>
                    <p className="text-sm text-white/70 mt-1">{announcement.description}</p>
                    <p className="text-xs text-secondary mt-1">{announcement.date}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          {/* Project Showcase */}
          <Card className="bg-cardBackground border-gray-700 border-t-4 border-t-accent">
            <CardContent className="pt-4">
              <h3 className="font-bold mb-2 flex items-center">
                <Code className="mr-2 h-5 w-5 text-accent" />
                {language === 'en' ? 'Start Building' : 
                 language === 'pt-br' ? 'Comece a Construir' : 
                 'Empieza a Construir'}
              </h3>
              <p className="text-sm text-white/70 mb-3">
                {language === 'en' ? 'Ready to create your own AI project? Use our guided project builder to deploy your first app!' :
                 language === 'pt-br' ? 'Pronto para criar seu próprio projeto de IA? Use nosso construtor de projetos guiado para implantar seu primeiro aplicativo!' :
                 '¿Listo para crear tu propio proyecto de IA? ¡Utiliza nuestro constructor de proyectos guiado para implementar tu primera aplicación!'}
              </p>
              <Button 
                className="w-full bg-accent hover:bg-accent/80 text-white"
                asChild
              >
                <Link to={ROUTES.PROJECT_BUILDER}>
                  {language === 'en' ? 'Launch Project Builder' :
                   language === 'pt-br' ? 'Iniciar Construtor de Projetos' :
                   'Iniciar Constructor de Proyectos'}
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </ModernLayout>
  );
}
