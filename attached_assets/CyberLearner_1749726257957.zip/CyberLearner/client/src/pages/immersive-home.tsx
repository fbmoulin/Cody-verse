import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { GamifiedDashboard } from "@/components/ui/gamified-dashboard";
import { 
  Play, 
  Trophy, 
  Zap, 
  Brain, 
  Target, 
  Star,
  ChevronRight,
  BookOpen,
  Users,
  Flame,
  Award,
  TrendingUp,
  Calendar,
  Clock,
  CheckCircle2,
  Crown
} from "lucide-react";

export default function ImmersiveHome() {
  const [selectedPath, setSelectedPath] = useState<string | null>(null);
  const [dailyStreak, setDailyStreak] = useState(7);
  const [currentXP, setCurrentXP] = useState(1247);

  const { data: modules, isLoading: modulesLoading } = useQuery({
    queryKey: ['/api/modules'],
    queryFn: async () => {
      const res = await fetch('/api/modules');
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
  });

  const { data: userProgress } = useQuery({
    queryKey: ['/api/users/1/progress'],
    queryFn: async () => {
      const res = await fetch('/api/users/1/progress');
      return res.json();
    },
    staleTime: 2 * 60 * 1000,
  });

  const achievements = [
    { id: 1, title: "Primeiro Código", icon: "🎯", unlocked: true, rarity: 'common' as const, description: "Completou sua primeira lição" },
    { id: 2, title: "Sequência de 7 dias", icon: "🔥", unlocked: true, rarity: 'rare' as const, description: "Manteve uma sequência de 7 dias" },
    { id: 3, title: "Expert em MCP", icon: "🧠", unlocked: false, rarity: 'epic' as const, description: "Domine todos os módulos MCP" },
    { id: 4, title: "Colaborador", icon: "👥", unlocked: false, rarity: 'legendary' as const, description: "Ajude outros desenvolvedores" }
  ];

  const learningPaths = [
    {
      id: "mcp-fundamentals",
      title: "Fundamentos MCP",
      description: "Domine os conceitos básicos do Model Context Protocol",
      difficulty: "Iniciante",
      estimatedTime: "2-3 semanas",
      modules: 4,
      color: "from-blue-500 to-cyan-500",
      icon: Brain,
      progress: 75
    },
    {
      id: "server-development",
      title: "Desenvolvimento de Servidores",
      description: "Construa servidores MCP robustos e escaláveis",
      difficulty: "Intermediário",
      estimatedTime: "3-4 semanas",
      modules: 6,
      color: "from-purple-500 to-pink-500",
      icon: Zap,
      progress: 45
    },
    {
      id: "integration-mastery",
      title: "Maestria em Integração",
      description: "Integre MCP com sistemas complexos e APIs",
      difficulty: "Avançado",
      estimatedTime: "4-6 semanas",
      modules: 8,
      color: "from-orange-500 to-red-500",
      icon: Target,
      progress: 20
    }
  ];

  const stats = {
    currentXP,
    level: Math.floor(currentXP / 1000) + 1,
    streak: dailyStreak,
    totalTime: 2863, // minutes
    completedModules: 12,
    rank: 3,
    achievements
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600">
        <div className="absolute inset-0 bg-black/20" />
        <motion.div 
          className="relative z-10 max-w-6xl mx-auto px-6 py-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex items-center justify-between mb-8 bg-white/10 backdrop-blur-md rounded-2xl p-4">
            <div className="flex items-center space-x-6">
              <Avatar className="h-12 w-12 ring-4 ring-white/30">
                <AvatarImage src="/api/placeholder/48/48" />
                <AvatarFallback className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold">
                  DV
                </AvatarFallback>
              </Avatar>
              <div>
                <h2 className="text-white font-bold text-lg">Olá, Desenvolvedor!</h2>
                <p className="text-white/80 text-sm">Nível {stats.level} • {currentXP} XP</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-orange-500/20 px-3 py-2 rounded-full">
                <Flame className="h-5 w-5 text-orange-400" />
                <span className="text-white font-bold">{dailyStreak}</span>
              </div>
              <div className="flex items-center space-x-2 bg-yellow-500/20 px-3 py-2 rounded-full">
                <Trophy className="h-5 w-5 text-yellow-400" />
                <span className="text-white font-bold">47</span>
              </div>
            </div>
          </div>

          <div className="text-center text-white">
            <motion.h1 
              className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              Domine o MCP
            </motion.h1>
            <motion.p 
              className="text-xl md:text-2xl mb-8 text-white/90 max-w-3xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              Transforme-se em um expert em Model Context Protocol com nossa plataforma interativa de aprendizado
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.8 }}
            >
              <Button 
                size="lg" 
                className="bg-white text-purple-600 hover:bg-white/90 px-8 py-4 text-lg font-semibold"
              >
                <Play className="mr-2 h-5 w-5" />
                Continuar Aprendendo
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white/10 px-8 py-4 text-lg font-semibold"
              >
                <BookOpen className="mr-2 h-5 w-5" />
                Explorar Cursos
              </Button>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-6 py-12">
        <Tabs defaultValue="learning-paths" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8 bg-white shadow-lg">
            <TabsTrigger value="learning-paths" className="text-sm font-medium">
              <Brain className="mr-2 h-4 w-4" />
              Trilhas
            </TabsTrigger>
            <TabsTrigger value="daily-challenge" className="text-sm font-medium">
              <Target className="mr-2 h-4 w-4" />
              Desafio Diário
            </TabsTrigger>
            <TabsTrigger value="achievements" className="text-sm font-medium">
              <Trophy className="mr-2 h-4 w-4" />
              Conquistas
            </TabsTrigger>
            <TabsTrigger value="dashboard" className="text-sm font-medium">
              <TrendingUp className="mr-2 h-4 w-4" />
              Dashboard
            </TabsTrigger>
          </TabsList>

          {/* Learning Paths */}
          <TabsContent value="learning-paths" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {learningPaths.map((path, index) => (
                <motion.div
                  key={path.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                >
                  <Card className="group hover:shadow-xl transition-all duration-300 overflow-hidden border-0 bg-white">
                    <div className={`h-3 bg-gradient-to-r ${path.color}`} />
                    <div className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className={`p-3 rounded-xl bg-gradient-to-r ${path.color} text-white`}>
                          <path.icon className="h-6 w-6" />
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {path.difficulty}
                        </Badge>
                      </div>
                      
                      <h3 className="font-bold text-lg mb-2 group-hover:text-purple-600 transition-colors">
                        {path.title}
                      </h3>
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                        {path.description}
                      </p>
                      
                      <div className="space-y-3">
                        <div className="flex items-center justify-between text-sm text-gray-500">
                          <span className="flex items-center">
                            <Clock className="mr-1 h-4 w-4" />
                            {path.estimatedTime}
                          </span>
                          <span>{path.modules} módulos</span>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Progresso</span>
                            <span className="font-medium">{path.progress}%</span>
                          </div>
                          <Progress value={path.progress} className="h-2" />
                        </div>
                        
                        <Button 
                          className="w-full mt-4 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                          onClick={() => setSelectedPath(path.id)}
                        >
                          Continuar
                          <ChevronRight className="ml-2 h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Daily Challenge */}
          <TabsContent value="daily-challenge">
            <Card className="p-8 text-center bg-gradient-to-r from-yellow-50 to-orange-50 border-0">
              <div className="max-w-md mx-auto">
                <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center">
                  <Target className="h-10 w-10" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Desafio do Dia</h3>
                <p className="text-gray-600 mb-6">
                  Implemente um servidor MCP simples que responda a comandos de listagem de arquivos
                </p>
                <div className="flex items-center justify-center space-x-4 mb-6">
                  <Badge className="bg-green-100 text-green-800">+50 XP</Badge>
                  <Badge className="bg-blue-100 text-blue-800">Intermediário</Badge>
                  <Badge className="bg-purple-100 text-purple-800">15 min</Badge>
                </div>
                <Button size="lg" className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                  Aceitar Desafio
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Achievements */}
          <TabsContent value="achievements">
            <div className="grid gap-4 md:grid-cols-2">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                >
                  <Card className={`p-6 ${achievement.unlocked ? 'bg-gradient-to-r from-green-50 to-emerald-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
                    <div className="flex items-center space-x-4">
                      <div className={`text-4xl ${achievement.unlocked ? 'grayscale-0' : 'grayscale'}`}>
                        {achievement.icon}
                      </div>
                      <div className="flex-1">
                        <h4 className={`font-bold text-lg ${achievement.unlocked ? 'text-green-800' : 'text-gray-500'}`}>
                          {achievement.title}
                        </h4>
                        <p className={`text-sm ${achievement.unlocked ? 'text-green-600' : 'text-gray-400'}`}>
                          {achievement.description}
                        </p>
                      </div>
                      {achievement.unlocked && (
                        <CheckCircle2 className="h-6 w-6 text-green-500" />
                      )}
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* Gamified Dashboard */}
          <TabsContent value="dashboard">
            <GamifiedDashboard stats={stats} />
          </TabsContent>
        </Tabs>
      </div>

      {/* Floating Action Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 1, duration: 0.3 }}
      >
        <Button
          size="lg"
          className="rounded-full h-14 w-14 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 shadow-lg"
        >
          <Play className="h-6 w-6" />
        </Button>
      </motion.div>
    </div>
  );
}