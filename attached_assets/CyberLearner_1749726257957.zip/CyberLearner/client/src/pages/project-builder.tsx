import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import {
  Box,
  Play,
  Server,
  Code,
  ArrowRight,
  Check,
  ExternalLink,
  Download,
  Cloud,
  AlertCircle,
  Settings
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import CodeEditor from '@/components/ui/code/CodeEditor';
import ModernLayout from '@/components/ui/layouts/ModernLayout';
import { COLORS } from '@/lib/constants';

// Project templates
const PROJECT_TEMPLATES = [
  {
    id: 'ai-chat',
    title: 'AI Chat Assistant',
    description: 'Build a simple AI chat assistant with OpenAI integration',
    difficulty: 'beginner',
    tech: ['JavaScript', 'HTML/CSS', 'OpenAI API'],
    image: 'ai-chat.svg',
    estimatedTime: '2-3 hours'
  },
  {
    id: 'text-analyzer',
    title: 'Text Analysis Tool',
    description: 'Create a tool that analyzes text sentiment and key phrases',
    difficulty: 'intermediate',
    tech: ['JavaScript', 'React', 'OpenAI API'],
    image: 'text-analyzer.svg',
    estimatedTime: '3-4 hours'
  },
  {
    id: 'image-generator',
    title: 'AI Image Generator',
    description: 'Build an app that generates images from text descriptions',
    difficulty: 'intermediate',
    tech: ['JavaScript', 'React', 'OpenAI API'],
    image: 'image-generator.svg',
    estimatedTime: '4-5 hours'
  }
];

// Project steps (for selected template)
const PROJECT_STEPS = [
  {
    id: 'setup',
    title: 'Project Setup',
    description: 'Set up your development environment and project structure',
    completed: false
  },
  {
    id: 'api-integration',
    title: 'API Integration',
    description: 'Connect to the OpenAI API for AI functionality',
    completed: false
  },
  {
    id: 'frontend',
    title: 'Frontend Development',
    description: 'Build the user interface and interactive elements',
    completed: false
  },
  {
    id: 'testing',
    title: 'Testing & Debugging',
    description: 'Test your application and fix any issues',
    completed: false
  },
  {
    id: 'deployment',
    title: 'Deployment',
    description: 'Deploy your project to make it accessible online',
    completed: false
  }
];

export default function ProjectBuilder() {
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  
  // Mock user for the demo
  const [user] = useState({
    id: 1,
    username: 'cyberlearner',
    displayName: 'Cyber Learner',
    preferredCharacter: 'NEXUS'
  });
  
  // Get selected template details
  const selectedTemplateDetails = PROJECT_TEMPLATES.find(t => t.id === selectedTemplate);
  
  // Calculate progress
  const projectProgress = Math.round((completedSteps.length / PROJECT_STEPS.length) * 100);
  
  // Mark step as completed
  const completeCurrentStep = () => {
    const currentStepId = PROJECT_STEPS[currentStep].id;
    if (!completedSteps.includes(currentStepId)) {
      setCompletedSteps([...completedSteps, currentStepId]);
    }
    
    // Move to the next step if not on the last one
    if (currentStep < PROJECT_STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };
  
  // Reset project
  const resetProject = () => {
    setSelectedTemplate(null);
    setCurrentStep(0);
    setCompletedSteps([]);
  };
  
  // Render template selection screen
  const renderTemplateSelection = () => (
    <div className="space-y-6">
      <div className="max-w-2xl">
        <h2 className="text-xl md:text-2xl font-bold mb-2">Choose Your Project</h2>
        <p className="text-white/70">
          Select a project template to get started. Each template provides you with a 
          step-by-step guide to build your own AI-powered application.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        {PROJECT_TEMPLATES.map((template) => (
          <motion.div 
            key={template.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            whileHover={{ scale: 1.03 }}
          >
            <Card className="bg-cardBackground border-gray-700 h-full">
              <CardHeader className="pb-2">
                <div className="mb-3 h-12 w-12 rounded-lg bg-primary/20 flex items-center justify-center">
                  <Box className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>{template.title}</CardTitle>
              </CardHeader>
              <CardContent className="pt-2">
                <p className="text-white/70 text-sm mb-4">
                  {template.description}
                </p>
                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-white/60">Difficulty</p>
                    <p className="text-sm font-medium">{template.difficulty}</p>
                  </div>
                  <div>
                    <p className="text-xs text-white/60">Technologies</p>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {template.tech.map((tech, idx) => (
                        <span 
                          key={idx} 
                          className="text-xs bg-gray-800 text-white/80 px-2 py-1 rounded"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-white/60">Estimated Time</p>
                    <p className="text-sm font-medium">{template.estimatedTime}</p>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={() => setSelectedTemplate(template.id)}
                  className="w-full bg-primary hover:bg-primary/80 text-black"
                >
                  Select Template
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
  
  // Render project workspace
  const renderProjectWorkspace = () => {
    if (!selectedTemplateDetails) return null;
    
    const currentStepDetails = PROJECT_STEPS[currentStep];
    
    return (
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row gap-4 md:items-center justify-between">
          <div>
            <h2 className="text-xl md:text-2xl font-bold flex items-center">
              <span className="mr-2">{selectedTemplateDetails.title}</span>
              <span className="text-xs bg-gray-800 text-white/80 px-2 py-1 rounded">
                {selectedTemplateDetails.difficulty}
              </span>
            </h2>
            <p className="text-white/70 mt-1">
              Building a {selectedTemplateDetails.description.toLowerCase()}
            </p>
          </div>
          
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={resetProject}
              className="border-gray-700"
            >
              Cancel Project
            </Button>
          </div>
        </div>
        
        {/* Progress indicator */}
        <div className="bg-cardBackground border border-gray-700 rounded-md p-4">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-medium">Project Progress</h3>
            <span className="text-sm text-white/70">{projectProgress}% Complete</span>
          </div>
          <Progress value={projectProgress} className="h-2" />
          
          <div className="flex justify-between mt-4">
            {PROJECT_STEPS.map((step, idx) => (
              <div 
                key={step.id} 
                className="relative flex flex-col items-center"
                style={{ minWidth: '20%' }}
              >
                <button
                  onClick={() => setCurrentStep(idx)}
                  className={`
                    w-8 h-8 rounded-full flex items-center justify-center
                    ${idx === currentStep ? 'bg-primary text-black' : 
                      completedSteps.includes(step.id) ? 'bg-primary/20 text-primary' : 
                      'bg-gray-800 text-white/50'}
                  `}
                >
                  {completedSteps.includes(step.id) ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    <span>{idx + 1}</span>
                  )}
                </button>
                <span className={`text-xs mt-2 text-center ${
                  idx === currentStep ? 'text-primary' : 
                  completedSteps.includes(step.id) ? 'text-white/70' : 
                  'text-white/50'
                }`}>
                  {step.title}
                </span>
                
                {/* Connector line */}
                {idx < PROJECT_STEPS.length - 1 && (
                  <div 
                    className={`absolute top-4 left-1/2 w-full h-[2px] -translate-y-1/2 z-0 ${
                      completedSteps.includes(step.id) ? 'bg-primary/50' : 'bg-gray-700'
                    }`}
                    style={{ transform: 'translateY(-50%) translateX(50%)' }}
                  />
                )}
              </div>
            ))}
          </div>
        </div>
        
        {/* Current step content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="bg-cardBackground border-gray-700">
              <CardHeader className="pb-3 border-b border-gray-700">
                <CardTitle className="text-lg">
                  Step {currentStep + 1}: {currentStepDetails.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="prose prose-invert max-w-none">
                  <p>{currentStepDetails.description}</p>
                  
                  {/* Step-specific content */}
                  {currentStepDetails.id === 'setup' && (
                    <>
                      <h3>Setting Up Your Project</h3>
                      <p>
                        Let's begin by setting up the basic structure for your {selectedTemplateDetails.title.toLowerCase()}.
                        You'll need the following files and dependencies:
                      </p>
                      
                      <div className="bg-gray-800/50 p-4 rounded-md border border-gray-700 my-4">
                        <h4 className="text-primary">Project Structure</h4>
                        <pre className="text-white/80 text-sm my-2 bg-transparent p-0">
{`my-ai-project/
├── index.html
├── styles.css
├── script.js
└── package.json`}
                        </pre>
                      </div>
                      
                      <p>
                        First, create a new directory for your project and initialize it:
                      </p>
                      
                      <CodeEditor
                        language="bash"
                        initialCode={`mkdir ${selectedTemplateDetails.id}\ncd ${selectedTemplateDetails.id}\nnpm init -y`}
                        readOnly={true}
                      />
                      
                      <p className="mt-4">
                        Now, let's install the necessary dependencies:
                      </p>
                      
                      <CodeEditor
                        language="bash"
                        initialCode={`npm install openai dotenv express`}
                        readOnly={true}
                      />
                    </>
                  )}
                  
                  {currentStepDetails.id === 'api-integration' && (
                    <>
                      <h3>Integrating with OpenAI API</h3>
                      <p>
                        Now that we have our project set up, let's integrate with the OpenAI API.
                        You'll need an API key from OpenAI to get started.
                      </p>
                      
                      <div className="bg-gray-800/50 p-4 rounded-md border border-gray-700 my-4">
                        <h4 className="text-primary">API Integration Steps</h4>
                        <ol className="list-decimal list-inside text-white/80">
                          <li>Set up environment variables for your API key</li>
                          <li>Initialize the OpenAI client</li>
                          <li>Create a function to handle API requests</li>
                        </ol>
                      </div>
                      
                      <p>
                        Create a .env file for your API key:
                      </p>
                      
                      <CodeEditor
                        language="bash"
                        initialCode={`OPENAI_API_KEY=your_api_key_here`}
                        readOnly={true}
                      />
                      
                      <p className="mt-4">
                        Now, let's set up the OpenAI client in a file called api.js:
                      </p>
                      
                      <CodeEditor
                        language="javascript"
                        initialCode={`// api.js
const { OpenAI } = require('openai');
require('dotenv').config();

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || 'default_key',
});

// Function to generate a response
async function generateResponse(prompt) {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [{ role: "user", content: prompt }],
    });
    
    return response.choices[0].message.content;
  } catch (error) {
    console.error('Error calling OpenAI:', error);
    throw error;
  }
}

module.exports = { generateResponse };`}
                        readOnly={true}
                      />
                    </>
                  )}
                  
                  {currentStepDetails.id === 'frontend' && (
                    <>
                      <h3>Building the User Interface</h3>
                      <p>
                        Let's create a simple but effective user interface for your {selectedTemplateDetails.title.toLowerCase()}.
                        We'll use HTML, CSS, and JavaScript to build a responsive UI.
                      </p>
                      
                      <p>First, let's create the HTML structure:</p>
                      
                      <CodeEditor
                        language="html"
                        initialCode={`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${selectedTemplateDetails.title}</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="container">
    <header>
      <h1>${selectedTemplateDetails.title}</h1>
      <p>Built with OpenAI technology</p>
    </header>
    
    <main>
      <div class="chat-container">
        <div class="messages" id="messages"></div>
        
        <div class="input-area">
          <textarea 
            id="user-input" 
            placeholder="Type your message here..."
          ></textarea>
          <button id="send-btn">Send</button>
        </div>
      </div>
    </main>
    
    <footer>
      <p>Created as part of CyberLearn AI Course</p>
    </footer>
  </div>
  
  <script src="script.js"></script>
</body>
</html>`}
                        readOnly={true}
                      />
                      
                      <p className="mt-4">Now, let's add some CSS styling:</p>
                      
                      <CodeEditor
                        language="css"
                        initialCode={`/* styles.css */
:root {
  --primary: #FFD700;
  --secondary: #00FFFF;
  --background: #1A1A1A;
  --accent: #FF1493;
  --text: #FFFFFF;
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: 'Roboto', sans-serif;
  background-color: var(--background);
  color: var(--text);
  line-height: 1.6;
}

.container {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem 1rem;
}

header {
  text-align: center;
  margin-bottom: 2rem;
}

header h1 {
  color: var(--primary);
  font-family: 'Orbitron', sans-serif;
  margin-bottom: 0.5rem;
}

.chat-container {
  background-color: rgba(26, 26, 26, 0.6);
  border: 1px solid rgba(255, 215, 0, 0.3);
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 0 10px rgba(0, 255, 255, 0.2);
}

.messages {
  height: 400px;
  overflow-y: auto;
  padding: 1rem;
}

.message {
  margin-bottom: 1rem;
  padding: 0.8rem;
  border-radius: 8px;
  max-width: 80%;
}

.user-message {
  background-color: rgba(255, 215, 0, 0.2);
  margin-left: auto;
  border-right: 3px solid var(--primary);
}

.ai-message {
  background-color: rgba(0, 255, 255, 0.2);
  margin-right: auto;
  border-left: 3px solid var(--secondary);
}

.input-area {
  display: flex;
  padding: 1rem;
  background-color: rgba(0, 0, 0, 0.3);
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

textarea {
  flex: 1;
  background-color: rgba(255, 255, 255, 0.1);
  color: var(--text);
  border: none;
  padding: 0.8rem;
  border-radius: 4px;
  resize: none;
  height: 60px;
}

button {
  background-color: var(--primary);
  color: black;
  border: none;
  border-radius: 4px;
  padding: 0 1rem;
  margin-left: 0.5rem;
  cursor: pointer;
  font-weight: bold;
  transition: all 0.2s ease;
}

button:hover {
  background-color: rgba(255, 215, 0, 0.8);
}

footer {
  text-align: center;
  margin-top: 2rem;
  color: rgba(255, 255, 255, 0.6);
  font-size: 0.9rem;
}`}
                        readOnly={true}
                      />
                    </>
                  )}
                  
                  {currentStepDetails.id === 'testing' && (
                    <>
                      <h3>Testing Your Application</h3>
                      <p>
                        Now it's time to test your application to make sure everything works correctly.
                        Let's go through a simple testing process:
                      </p>
                      
                      <div className="bg-gray-800/50 p-4 rounded-md border border-gray-700 my-4">
                        <h4 className="text-primary">Testing Checklist</h4>
                        <ul className="list-disc list-inside text-white/80">
                          <li>Verify API integration is working</li>
                          <li>Test user interface responsiveness</li>
                          <li>Check error handling</li>
                          <li>Test on different devices/browsers</li>
                        </ul>
                      </div>
                      
                      <p>
                        Let's add some code to test our API integration:
                      </p>
                      
                      <CodeEditor
                        language="javascript"
                        initialCode={`// test-api.js
const { generateResponse } = require('./api');

async function testAPI() {
  try {
    console.log('Testing API connection...');
    const response = await generateResponse('Hello, can you give me a brief introduction to AI?');
    console.log('API Response:', response);
    console.log('API test successful!');
  } catch (error) {
    console.error('API test failed:', error);
  }
}

testAPI();`}
                        readOnly={true}
                      />
                      
                      <p className="mt-4">
                        Now, let's run the test to verify our API integration:
                      </p>
                      
                      <CodeEditor
                        language="bash"
                        initialCode={`node test-api.js`}
                        readOnly={true}
                      />
                      
                      <p className="mt-4">
                        Next, create a simple script to help with browser testing:
                      </p>
                      
                      <CodeEditor
                        language="javascript"
                        initialCode={`// browser-test.js
document.addEventListener('DOMContentLoaded', () => {
  // Test UI responsiveness
  console.log('Testing UI responsiveness...');
  const messagingArea = document.getElementById('messages');
  const userInput = document.getElementById('user-input');
  const sendButton = document.getElementById('send-btn');
  
  // Test message display
  function addTestMessage(text, isUser) {
    const messageDiv = document.createElement('div');
    messageDiv.className = isUser ? 'message user-message' : 'message ai-message';
    messageDiv.textContent = text;
    messagingArea.appendChild(messageDiv);
    messagingArea.scrollTop = messagingArea.scrollHeight;
  }
  
  // Add some test messages
  addTestMessage('Hello, I am testing this chat interface', true);
  addTestMessage('I am the AI assistant. I am here to help you test this interface.', false);
  
  // Test button functionality
  sendButton.addEventListener('click', () => {
    const text = userInput.value.trim();
    if (text) {
      addTestMessage(text, true);
      userInput.value = '';
      
      // Simulate AI response
      setTimeout(() => {
        addTestMessage('This is a simulated response for testing purposes.', false);
      }, 1000);
    }
  });
  
  console.log('UI test initialized. Try interacting with the interface.');
});`}
                        readOnly={true}
                      />
                    </>
                  )}
                  
                  {currentStepDetails.id === 'deployment' && (
                    <>
                      <h3>Deploying Your Project</h3>
                      <p>
                        Now that your project is built and tested, it's time to deploy it so others can use it.
                        We'll look at a few simple deployment options:
                      </p>
                      
                      <div className="bg-gray-800/50 p-4 rounded-md border border-gray-700 my-4">
                        <h4 className="text-primary">Deployment Options</h4>
                        <ul className="list-disc list-inside text-white/80">
                          <li>GitHub Pages (for static front-end)</li>
                          <li>Vercel or Netlify (for full-stack apps)</li>
                          <li>Replit (for educational projects)</li>
                        </ul>
                      </div>
                      
                      <p>
                        Let's set up our project for deployment by creating a simple server:
                      </p>
                      
                      <CodeEditor
                        language="javascript"
                        initialCode={`// server.js
const express = require('express');
const path = require('path');
const { generateResponse } = require('./api');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files
app.use(express.static('public'));
app.use(express.json());

// API endpoint for generating responses
app.post('/api/chat', async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }
    
    const response = await generateResponse(message);
    res.json({ response });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Failed to generate response' });
  }
});

// Serve the main HTML file for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});`}
                        readOnly={true}
                      />
                      
                      <p className="mt-4">
                        Create a package.json file with the necessary scripts:
                      </p>
                      
                      <CodeEditor
                        language="json"
                        initialCode={`{
  "name": "${selectedTemplateDetails.id}",
  "version": "1.0.0",
  "description": "${selectedTemplateDetails.description}",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "dotenv": "^16.0.3",
    "express": "^4.18.2",
    "openai": "^4.0.0"
  },
  "devDependencies": {
    "nodemon": "^2.0.22"
  }
}`}
                        readOnly={true}
                      />
                      
                      <p className="mt-4">
                        Finally, let's create a README.md file for your project:
                      </p>
                      
                      <CodeEditor
                        language="markdown"
                        initialCode={`# ${selectedTemplateDetails.title}

${selectedTemplateDetails.description}

## Features
- Interactive user interface
- OpenAI API integration
- Real-time response generation

## Setup
1. Clone this repository
2. Install dependencies: \`npm install\`
3. Create a .env file with your OpenAI API key: \`OPENAI_API_KEY=your_key_here\`
4. Start the development server: \`npm run dev\`

## Deployment
This project can be deployed to platforms like Vercel, Netlify, or Replit.

## Technologies Used
${selectedTemplateDetails.tech.join(', ')}

## Created with CyberLearn AI Learning Platform`}
                        readOnly={true}
                      />
                    </>
                  )}
                </div>
                
                <div className="flex justify-between mt-8 pt-4 border-t border-gray-700">
                  <Button
                    variant="outline"
                    onClick={() => currentStep > 0 && setCurrentStep(currentStep - 1)}
                    disabled={currentStep === 0}
                    className="border-gray-700"
                  >
                    Previous Step
                  </Button>
                  
                  {currentStep < PROJECT_STEPS.length - 1 ? (
                    <Button
                      onClick={completeCurrentStep}
                      className="bg-primary hover:bg-primary/80 text-black"
                    >
                      Complete & Continue
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  ) : (
                    <Button
                      onClick={completeCurrentStep}
                      className="bg-secondary hover:bg-secondary/80 text-black"
                    >
                      <Check className="mr-2 h-4 w-4" />
                      Finish Project
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="space-y-4">
            <Card className="bg-cardBackground border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center">
                  <Server className="mr-2 h-5 w-5 text-secondary" />
                  Resources
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="item-1" className="border-gray-700">
                    <AccordionTrigger className="text-white hover:text-primary">
                      OpenAI Documentation
                    </AccordionTrigger>
                    <AccordionContent className="text-white/70">
                      <p className="mb-2">
                        The official OpenAI API documentation provides detailed guides, examples, and reference materials.
                      </p>
                      <Button variant="link" className="p-0 h-auto text-secondary flex items-center" asChild>
                        <a href="https://platform.openai.com/docs/introduction" target="_blank" rel="noopener noreferrer">
                          Visit Documentation
                          <ExternalLink className="ml-1 h-3 w-3" />
                        </a>
                      </Button>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="item-2" className="border-gray-700">
                    <AccordionTrigger className="text-white hover:text-primary">
                      Deployment Guides
                    </AccordionTrigger>
                    <AccordionContent className="text-white/70">
                      <ul className="space-y-2">
                        <li>
                          <Button variant="link" className="p-0 h-auto text-secondary flex items-center" asChild>
                            <a href="https://vercel.com/docs" target="_blank" rel="noopener noreferrer">
                              Vercel Deployment
                              <ExternalLink className="ml-1 h-3 w-3" />
                            </a>
                          </Button>
                        </li>
                        <li>
                          <Button variant="link" className="p-0 h-auto text-secondary flex items-center" asChild>
                            <a href="https://docs.netlify.com" target="_blank" rel="noopener noreferrer">
                              Netlify Deployment
                              <ExternalLink className="ml-1 h-3 w-3" />
                            </a>
                          </Button>
                        </li>
                        <li>
                          <Button variant="link" className="p-0 h-auto text-secondary flex items-center" asChild>
                            <a href="https://docs.replit.com" target="_blank" rel="noopener noreferrer">
                              Replit Hosting
                              <ExternalLink className="ml-1 h-3 w-3" />
                            </a>
                          </Button>
                        </li>
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="item-3" className="border-gray-700">
                    <AccordionTrigger className="text-white hover:text-primary">
                      Code Examples
                    </AccordionTrigger>
                    <AccordionContent className="text-white/70">
                      <p className="mb-2">
                        Find additional code examples and templates to help with your project.
                      </p>
                      <Button variant="link" className="p-0 h-auto text-secondary flex items-center" asChild>
                        <a href="https://github.com/openai/openai-cookbook" target="_blank" rel="noopener noreferrer">
                          OpenAI Cookbook
                          <ExternalLink className="ml-1 h-3 w-3" />
                        </a>
                      </Button>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
            
            <Card className="bg-cardBackground border-gray-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center">
                  <Settings className="mr-2 h-5 w-5 text-primary" />
                  Project Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-white/80 mb-2">Template</h4>
                    <p className="text-white text-sm">{selectedTemplateDetails.title}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-white/80 mb-2">Technologies</h4>
                    <div className="flex flex-wrap gap-1">
                      {selectedTemplateDetails.tech.map((tech, idx) => (
                        <span 
                          key={idx} 
                          className="text-xs bg-gray-800 text-white/80 px-2 py-1 rounded"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-white/80 mb-2">Actions</h4>
                    <div className="space-y-2">
                      <Button 
                        variant="outline" 
                        className="w-full justify-start border-gray-700 text-white/80"
                        disabled={true}
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download Project
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full justify-start border-gray-700 text-white/80"
                        disabled={true}
                      >
                        <Cloud className="mr-2 h-4 w-4" />
                        Deploy Project
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-cardBackground border-gray-700 border-t-4 border-t-accent">
              <CardContent className="p-4">
                <div className="flex items-start">
                  <AlertCircle className="h-5 w-5 text-accent mr-2 mt-0.5" />
                  <div>
                    <h3 className="font-medium mb-1">Need Help?</h3>
                    <p className="text-sm text-white/70">
                      Connect with your AI assistant for guidance or check out the community forums for more help.
                    </p>
                    <Button className="mt-3 bg-accent hover:bg-accent/80 text-white">
                      Ask for Help
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  };

  return (
    <ModernLayout>
      {selectedTemplate ? renderProjectWorkspace() : renderTemplateSelection()}
    </ModernLayout>
  );
}
