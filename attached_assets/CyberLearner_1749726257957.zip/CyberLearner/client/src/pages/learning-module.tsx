import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Play, 
  CheckCircle, 
  Clock, 
  Trophy, 
  Target, 
  BookOpen, 
  Code, 
  Brain,
  Star,
  ChevronRight,
  ArrowLeft,
  Lightbulb
} from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import ModernLayout from "@/components/ui/layouts/ModernLayout";
import { ResponsiveGrid } from "@/components/ui/responsive-grid";

import { InteractiveModule } from "@/components/interactive";
import { PerformanceMonitor, useDebounced, useMemoizedContentParser } from "@/utils/performance";
import { useModuleData, useUserProgress, useProgressMutation } from "@/utils/optimized-queries";

import type { Module, Challenge, UserProgress } from "@shared/schema";

// Enhanced content renderer component with improved design and performance
function LessonContent({ content, onSectionComplete, moduleId }: { content: any; onSectionComplete: () => void; moduleId: string }) {
  const [currentSection, setCurrentSection] = useState(0);
  const [completedSections, setCompletedSections] = useState<Set<number>>(new Set());
  
  // Use memoized content parser for better performance
  const parsedContent = useMemoizedContentParser(content);
  const sections = parsedContent.sections || [];
  
  // Load completed sections from localStorage on component mount
  useEffect(() => {
    if (moduleId) {
      const progressKey = `module_${moduleId}_progress`;
      const savedProgress = localStorage.getItem(progressKey);
      if (savedProgress) {
        try {
          const completedArray = JSON.parse(savedProgress);
          setCompletedSections(new Set(completedArray));
        } catch (error) {
          console.warn('Could not load saved progress:', error);
        }
      }
    }
  }, [moduleId]);
  
  const handleSectionComplete = async (index: number) => {
    const newCompleted = new Set(completedSections);
    newCompleted.add(index);
    setCompletedSections(newCompleted);
    
    // Save progress to localStorage for persistence
    if (moduleId) {
      const progressKey = `module_${moduleId}_progress`;
      localStorage.setItem(progressKey, JSON.stringify(Array.from(newCompleted)));
      
      // Calculate completion percentage
      const totalSections = sections.length;
      const completedCount = newCompleted.size;
      const progressPercent = Math.round((completedCount / totalSections) * 100);
      
      // Save to server (if user is logged in)
      try {
        const userId = localStorage.getItem('userId') || '1'; // Default user for demo
        await fetch(`/api/users/${userId}/progress`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            moduleId: parseInt(moduleId),
            progress: progressPercent,
            completed: progressPercent === 100
          })
        });
      } catch (error) {
        console.warn('Could not save progress to server:', error);
      }
    }
    
    onSectionComplete();
  };

  const getSectionIcon = (index: number) => {
    if (completedSections.has(index)) return <CheckCircle className="w-5 h-5 text-green-500" />;
    if (index === currentSection) return <Play className="w-5 h-5 text-blue-500" />;
    return <BookOpen className="w-5 h-5 text-gray-400" />;
  };

  if (sections.length === 0) {
    return (
      <div className="text-center py-12">
        <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <p className="text-gray-500 text-lg">Nenhum conteúdo disponível</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Section Navigation */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/30 dark:to-purple-950/30 rounded-xl p-6 border border-blue-200 dark:border-blue-800">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Brain className="w-5 h-5 text-blue-600" />
            Progresso do Módulo
          </h3>
          <Badge variant="secondary" className="text-sm">
            {completedSections.size} de {sections.length} seções
          </Badge>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {sections.map((section: any, index: number) => (
            <Button
              key={index}
              variant={index === currentSection ? "default" : completedSections.has(index) ? "secondary" : "outline"}
              size="sm"
              className="justify-start text-xs h-8"
              onClick={() => setCurrentSection(index)}
            >
              {getSectionIcon(index)}
              <span className="ml-1 truncate">Seção {index + 1}</span>
            </Button>
          ))}
        </div>
        
        <Progress value={(completedSections.size / sections.length) * 100} className="mt-4" />
      </div>

      {/* Current Section Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSection}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="border-l-4 border-l-gradient-to-b from-blue-500 to-purple-500 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-blue-50/50 to-purple-50/50 dark:from-blue-950/20 dark:to-purple-950/20">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className="text-xs">
                      Seção {currentSection + 1} de {sections.length}
                    </Badge>
                    {completedSections.has(currentSection) && (
                      <Badge variant="secondary" className="text-xs bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Concluída
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-2xl font-bold text-foreground leading-tight">
                    {sections[currentSection]?.title}
                  </CardTitle>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
                    disabled={currentSection === 0}
                  >
                    <ArrowLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentSection(Math.min(sections.length - 1, currentSection + 1))}
                    disabled={currentSection === sections.length - 1}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-8">
              <div className="prose prose-lg prose-slate dark:prose-invert max-w-none">
                <div className="text-muted-foreground leading-relaxed space-y-6">
                  {sections[currentSection]?.content.split('\n').map((paragraph: string, idx: number) => (
                    <p key={idx} className="text-base leading-7">
                      {paragraph}
                    </p>
                  ))}
                </div>
                
                {/* Examples Section */}
                {sections[currentSection]?.examples && sections[currentSection].examples.length > 0 && (
                  <div className="mt-8 space-y-4">
                    <h4 className="text-lg font-semibold text-foreground flex items-center gap-2">
                      <Code className="w-5 h-5 text-blue-500" />
                      Exemplos Práticos
                    </h4>
                    {sections[currentSection].examples.map((example: any, idx: number) => (
                      <Card key={idx} className="bg-gradient-to-r from-blue-50/50 to-indigo-50/50 dark:from-blue-950/20 dark:to-indigo-950/20 border-blue-200 dark:border-blue-800">
                        <CardHeader className="pb-3">
                          <CardTitle className="text-base font-medium text-blue-700 dark:text-blue-300">
                            {example.title}
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="text-sm text-muted-foreground leading-relaxed">
                            {example.content.split('\n').map((line: string, lineIdx: number) => (
                              <p key={lineIdx} className="mb-2">
                                {line}
                              </p>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
              
              {!completedSections.has(currentSection) && (
                <div className="mt-8 pt-6 border-t border-border">
                  <Button 
                    onClick={() => handleSectionComplete(currentSection)}
                    className="w-full sm:w-auto bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Marcar como Concluída
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>

      {/* Quick Navigation */}
      <div className="flex justify-between items-center">
        <Button
          variant="outline"
          onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
          disabled={currentSection === 0}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Seção Anterior
        </Button>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Lightbulb className="w-4 h-4" />
          <span>{completedSections.size}/{sections.length} seções concluídas</span>
        </div>
        
        <Button
          variant="outline"
          onClick={() => setCurrentSection(Math.min(sections.length - 1, currentSection + 1))}
          disabled={currentSection === sections.length - 1}
          className="flex items-center gap-2"
        >
          Próxima Seção
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}

export default function LearningModule() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Get module ID from URL
  const moduleId = parseInt(location.split('/module/')[1] || '1');
  
  const handleNavigateBack = () => navigate('/');
  
  const handleSectionComplete = () => {
    updateProgressMutation.mutate({
      moduleId,
      progress: Math.min(100, (moduleProgress?.progress || 0) + 10),
      completed: false,
    });
  };

  // Data fetching
  const { data: module, isLoading: moduleLoading } = useQuery({
    queryKey: ['/api/modules', moduleId],
    queryFn: () => fetch(`/api/modules/${moduleId}`).then(res => res.json()),
  });

  const { data: challenges, isLoading: challengesLoading } = useQuery({
    queryKey: ['/api/challenges/module', moduleId],
    queryFn: () => fetch(`/api/challenges/module?moduleId=${moduleId}`).then(res => res.json()),
  });

  const { data: userProgress, isLoading: progressLoading } = useQuery({
    queryKey: ['/api/user/progress'],
    queryFn: () => fetch('/api/user/progress').then(res => res.json()),
  });

  // Progress calculation
  const moduleProgress = Array.isArray(userProgress) 
    ? userProgress.find((p: any) => p.moduleId === moduleId)
    : null;
  const progressPercentage = moduleProgress?.progress || 0;
  const isCompleted = moduleProgress?.completed || false;

  // Mutations
  const updateProgressMutation = useMutation({
    mutationFn: async (data: { moduleId: number; progress: number; completed: boolean }) => {
      const response = await fetch('/api/user/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update progress');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/progress'] });
      toast({
        title: "Progresso Atualizado",
        description: "Seu progresso de aprendizado foi salvo.",
      });
    },
  });

  if (moduleLoading || progressLoading) {
    return (
      <ModernLayout>
        <div className="flex items-center justify-center min-h-screen">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          >
            <Brain className="w-12 h-12 text-primary" />
          </motion.div>
        </div>
      </ModernLayout>
    );
  }

  return (
    <ModernLayout>
      <ResponsiveGrid className="gap-6">
        {/* Enhanced Header Section */}
        <div className="col-span-full">
          <div className="flex items-center gap-4 mb-8">
            <Button 
              variant="outline" 
              onClick={handleNavigateBack}
              className="flex items-center gap-2 hover:bg-primary/10 border-primary/20"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar ao Dashboard
            </Button>
          </div>

          <div className="bg-gradient-to-br from-blue-600/10 via-purple-600/10 to-pink-600/10 rounded-2xl p-8 border border-white/10 backdrop-blur-sm">
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="flex-1">
                <div className="flex items-start gap-4 mb-6">
                  <div className="p-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl shadow-lg">
                    <BookOpen className="w-8 h-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <h1 className="text-4xl font-bold text-white mb-3 leading-tight">
                      {module?.title || 'Módulo de Aprendizado'}
                    </h1>
                    <p className="text-lg text-gray-300 leading-relaxed max-w-2xl">
                      {module?.description || 'Aprimore suas habilidades com este módulo abrangente sobre IA e tecnologias modernas'}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 mb-6">
                  <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 border-blue-500/30 px-3 py-1">
                    <Clock className="w-4 h-4 mr-2" />
                    {module?.estimatedTime || '45 minutos'}
                  </Badge>
                  <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-500/30 px-3 py-1">
                    <Target className="w-4 h-4 mr-2" />
                    {module?.difficulty || 'Iniciante'}
                  </Badge>
                  <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 px-3 py-1">
                    <Trophy className="w-4 h-4 mr-2" />
                    {module?.xpReward || 100} XP
                  </Badge>
                  {isCompleted && (
                    <Badge variant="secondary" className="bg-purple-500/20 text-purple-300 border-purple-500/30 px-3 py-1">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Concluído
                    </Badge>
                  )}
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-300 font-medium">Progresso do Módulo</span>
                    <span className="text-white font-semibold">{Math.round(progressPercentage)}%</span>
                  </div>
                  <Progress 
                    value={progressPercentage} 
                    className="h-3 bg-white/10" 
                  />
                </div>
              </div>

              <div className="lg:w-80">
                <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-white flex items-center gap-2">
                      <Brain className="w-5 h-5 text-blue-400" />
                      Estatísticas
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-white/5 rounded-lg">
                        <div className="text-2xl font-bold text-white">{challenges?.length || 0}</div>
                        <div className="text-xs text-gray-400">Desafios</div>
                      </div>
                      <div className="text-center p-3 bg-white/5 rounded-lg">
                        <div className="text-2xl font-bold text-green-400">{Math.round(progressPercentage)}%</div>
                        <div className="text-xs text-gray-400">Concluído</div>
                      </div>
                    </div>
                    
                    {!isCompleted && (
                      <Button 
                        onClick={() => updateProgressMutation.mutate({ moduleId, progress: progressPercentage + 10, completed: false })}
                        disabled={updateProgressMutation.isPending}
                        className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Continuar Aprendizado
                      </Button>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Section */}
        <div className="col-span-full">
          <Tabs defaultValue="content" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-white/5 border-white/10">
              <TabsTrigger value="content" className="data-[state=active]:bg-white/10">
                <BookOpen className="w-4 h-4 mr-2" />
                Conteúdo
              </TabsTrigger>
              <TabsTrigger value="challenges" className="data-[state=active]:bg-white/10">
                <Code className="w-4 h-4 mr-2" />
                Desafios
              </TabsTrigger>
              <TabsTrigger value="interactive" className="data-[state=active]:bg-white/10">
                <Brain className="w-4 h-4 mr-2" />
                Interativo
              </TabsTrigger>
            </TabsList>

            <TabsContent value="content" className="mt-6">
              <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-blue-400" />
                    {module?.title || 'Conteúdo do Módulo'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <LessonContent 
                    content={module?.content} 
                    onSectionComplete={handleSectionComplete}
                    moduleId={String(moduleId)}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="challenges" className="mt-6">
              <div className="space-y-4">
                {challengesLoading ? (
                  <div className="grid gap-4">
                    {[1, 2, 3].map((i) => (
                      <Card key={i} className="bg-white/5 border-white/10 backdrop-blur-sm">
                        <CardContent className="p-6">
                          <div className="animate-pulse space-y-3">
                            <div className="h-4 bg-white/10 rounded w-3/4"></div>
                            <div className="h-3 bg-white/10 rounded w-1/2"></div>
                            <div className="h-8 bg-white/10 rounded w-24"></div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : challenges?.length > 0 ? (
                  <div className="grid gap-4">
                    {challenges.map((challenge: any) => (
                      <Card key={challenge.id} className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <h3 className="text-lg font-semibold text-white mb-2">
                                {challenge.title}
                              </h3>
                              <p className="text-gray-300 mb-4">
                                {challenge.description}
                              </p>
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" className="text-xs">
                                  {challenge.difficulty || 'Iniciante'}
                                </Badge>
                                <Badge variant="outline" className="text-xs">
                                  {challenge.xpReward || 50} XP
                                </Badge>
                              </div>
                            </div>
                            <Button 
                              variant="outline"
                              className="ml-4 hover:bg-primary/20"
                            >
                              <Play className="w-4 h-4 mr-2" />
                              Iniciar
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
                    <CardContent className="p-12 text-center">
                      <Code className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-white mb-2">
                        Nenhum Desafio Disponível
                      </h3>
                      <p className="text-gray-400">
                        Os desafios para este módulo estão sendo preparados.
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>

            <TabsContent value="interactive" className="mt-6">
              <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
                <CardContent className="p-6">
                  <InteractiveModule 
                    moduleId={moduleId}
                    content={module?.content}
                    onSectionComplete={handleSectionComplete}
                  />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar with Objectives and Key Concepts */}
        <div className="col-span-full lg:col-span-4">
          <div className="space-y-6">
            <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Target className="w-5 h-5 text-green-400" />
                  Objetivos de Aprendizagem
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {module?.objectives?.map((objective: string, index: number) => (
                    <li key={index} className="flex items-start gap-2 text-gray-300">
                      <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                      <span className="text-sm">{objective}</span>
                    </li>
                  )) || (
                    <>
                      <li className="flex items-start gap-2 text-gray-300">
                        <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">Compreender fundamentos de IA</span>
                      </li>
                      <li className="flex items-start gap-2 text-gray-300">
                        <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">Implementar soluções práticas</span>
                      </li>
                      <li className="flex items-start gap-2 text-gray-300">
                        <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">Aplicar conhecimentos em projetos</span>
                      </li>
                    </>
                  )}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-yellow-400" />
                  Conceitos-Chave
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {module?.concepts?.map((concept: string, index: number) => (
                    <Badge key={index} variant="outline" className="text-xs bg-white/5 border-white/20 text-gray-300">
                      {concept}
                    </Badge>
                  )) || (
                    <>
                      <Badge variant="outline" className="text-xs bg-white/5 border-white/20 text-gray-300">
                        Inteligência Artificial
                      </Badge>
                      <Badge variant="outline" className="text-xs bg-white/5 border-white/20 text-gray-300">
                        Machine Learning
                      </Badge>
                      <Badge variant="outline" className="text-xs bg-white/5 border-white/20 text-gray-300">
                        MCP Protocol
                      </Badge>
                      <Badge variant="outline" className="text-xs bg-white/5 border-white/20 text-gray-300">
                        API Development
                      </Badge>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </ResponsiveGrid>
    </ModernLayout>
  );
}