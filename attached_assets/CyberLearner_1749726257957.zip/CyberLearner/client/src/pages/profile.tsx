import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useQuery, useMutation } from '@tanstack/react-query';
import {
  User,
  Settings,
  Award,
  Clock,
  LogOut,
  Save,
  Edit,
  ChevronRight,
  Check,
  Key,
  Shield,
  Bell,
  Eye,
  EyeOff,
  Brain,
  Bot
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from '@/components/ui/separator';
import ModernLayout from '@/components/ui/layouts/ModernLayout';
import { ResponsiveGrid } from '@/components/ui/responsive-grid';
import { ModernCard } from '@/components/ui/modern-card';
import { useToast } from '@/hooks/use-toast';
import { useProgress } from '@/hooks/use-progress';
import { apiRequest } from '@/lib/queryClient';
import { CHARACTERS } from '@/lib/constants';
import ProgressBar from '@/components/ui/game/ProgressBar';
import CharacterSelection from '@/components/characters/CharacterSelection';

export default function Profile() {
  const { toast } = useToast();
  const [editingProfile, setEditingProfile] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [profileForm, setProfileForm] = useState({
    displayName: '',
    username: '',
    password: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  // Mock user for the demo
  const [user, setUser] = useState({
    id: 1,
    username: 'cyberlearner',
    displayName: 'Cyber Learner',
    level: 3,
    xp: 2350,
    preferredCharacter: 'NEXUS'
  });
  
  // Get progress metrics
  const { 
    calculateOverallProgress,
    getCompletedModulesCount,
    getCompletedChallengesCount,
    getUnlockedAchievementsCount,
    formatXpProgress
  } = useProgress({ userId: user.id });
  
  // Get all user progress
  const { data: userProgress, isLoading: userProgressLoading } = useQuery({
    queryKey: [`/api/users/${user.id}/progress`],
  });
  
  // Get user challenges
  const { data: userChallenges, isLoading: userChallengesLoading } = useQuery({
    queryKey: [`/api/users/${user.id}/challenges`],
  });
  
  // Get user achievements
  const { data: userAchievements, isLoading: userAchievementsLoading } = useQuery({
    queryKey: [`/api/users/${user.id}/achievements`],
  });
  
  // Update user preferences mutation
  const updatePreferences = useMutation({
    mutationFn: async ({ 
      preferredCharacter 
    }: { 
      preferredCharacter: string 
    }) => {
      return apiRequest('PATCH', `/api/users/${user.id}/preferences`, { preferredCharacter });
    },
    onSuccess: (data) => {
      setUser({
        ...user,
        preferredCharacter: data.preferredCharacter
      });
      
      toast({
        title: 'Preferences Updated',
        description: 'Your preferences have been saved successfully.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Update Failed',
        description: 'Failed to update preferences. Please try again.',
        variant: 'destructive',
      });
    }
  });
  
  // Handle character selection
  const handleCharacterChange = (character: string) => {
    updatePreferences.mutate({ preferredCharacter: character });
  };
  
  // Handle form changes
  const handleProfileFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProfileForm({
      ...profileForm,
      [e.target.name]: e.target.value
    });
  };
  
  // Start editing profile
  const startEditingProfile = () => {
    setProfileForm({
      ...profileForm,
      displayName: user.displayName,
      username: user.username,
      password: '',
      newPassword: '',
      confirmPassword: ''
    });
    setEditingProfile(true);
  };
  
  // Cancel profile editing
  const cancelProfileEditing = () => {
    setEditingProfile(false);
    setShowPassword(false);
  };
  
  // Save profile changes
  const saveProfileChanges = () => {
    // This would be an API call in a real app
    // For the demo, we'll just update the state
    
    if (profileForm.newPassword && profileForm.newPassword !== profileForm.confirmPassword) {
      toast({
        title: 'Password Mismatch',
        description: 'New password and confirmation do not match.',
        variant: 'destructive',
      });
      return;
    }
    
    setUser({
      ...user,
      displayName: profileForm.displayName,
      username: profileForm.username
    });
    
    toast({
      title: 'Profile Updated',
      description: 'Your profile has been updated successfully.',
    });
    
    setEditingProfile(false);
    setShowPassword(false);
  };
  
  // Handle logout
  const handleLogout = () => {
    toast({
      title: 'Logged Out',
      description: 'You have been logged out successfully.',
    });
    // In a real app, this would clear authentication state
  };
  
  // Calculate XP progress
  const xpProgress = formatXpProgress(user.xp);
  
  // Loading state
  const isLoading = userProgressLoading || userChallengesLoading || userAchievementsLoading;
  
  return (
    <ModernLayout>
      <ResponsiveGrid>
        {/* Main profile section */}
        <div className="md:col-span-2 space-y-6">
          {/* Profile card */}
          <Card className="bg-cardBackground border-gray-700">
            <CardHeader className="pb-4 flex flex-row justify-between items-start">
              <div className="flex flex-col">
                <CardTitle className="text-xl">Profile Information</CardTitle>
                <p className="text-white/60 text-sm mt-1">Manage your personal information</p>
              </div>
              {!editingProfile && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={startEditingProfile}
                  className="border-primary/50 text-primary hover:bg-primary/20"
                >
                  <Edit className="h-4 w-4 mr-1" />
                  Edit Profile
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {!editingProfile ? (
                <div className="flex flex-col sm:flex-row gap-6">
                  <div className="flex flex-col items-center">
                    <Avatar className="h-24 w-24 border-2 border-primary/70">
                      <AvatarFallback className="bg-primary/20 text-primary text-3xl">
                        {user.displayName.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <Badge className="mt-3 bg-primary/70 text-black">
                      Level {user.level}
                    </Badge>
                    <p className="text-white/70 text-sm mt-2">
                      {xpProgress.totalXp} XP total
                    </p>
                  </div>
                  
                  <div className="flex-1 space-y-4">
                    <div>
                      <h3 className="text-2xl font-bold">{user.displayName}</h3>
                      <p className="text-white/70">@{user.username}</p>
                    </div>
                    
                    <div className="flex flex-wrap gap-3">
                      <div className="bg-gray-800/50 px-3 py-2 rounded-md border border-gray-700 flex items-center">
                        <Award className="h-4 w-4 text-primary mr-2" />
                        <span className="text-sm text-white/80">
                          {getUnlockedAchievementsCount()} Achievements
                        </span>
                      </div>
                      
                      <div className="bg-gray-800/50 px-3 py-2 rounded-md border border-gray-700 flex items-center">
                        <Brain className="h-4 w-4 text-secondary mr-2" />
                        <span className="text-sm text-white/80">
                          {getCompletedModulesCount()} Modules
                        </span>
                      </div>
                      
                      <div className="bg-gray-800/50 px-3 py-2 rounded-md border border-gray-700 flex items-center">
                        <Clock className="h-4 w-4 text-accent mr-2" />
                        <span className="text-sm text-white/80">
                          Joined Apr 2023
                        </span>
                      </div>
                    </div>
                    
                    <div className="pt-3">
                      <p className="text-sm text-white/70 mb-2">Level Progress</p>
                      <ProgressBar 
                        level={user.level} 
                        currentXp={user.xp} 
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="displayName">Display Name</Label>
                      <Input
                        id="displayName"
                        name="displayName"
                        value={profileForm.displayName}
                        onChange={handleProfileFormChange}
                        className="bg-gray-900 border-gray-700"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input
                        id="username"
                        name="username"
                        value={profileForm.username}
                        onChange={handleProfileFormChange}
                        className="bg-gray-900 border-gray-700"
                      />
                    </div>
                  </div>
                  
                  <Separator className="my-4 bg-gray-700" />
                  
                  <div>
                    <h3 className="text-lg font-medium mb-3">Update Password</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="currentPassword">Current Password</Label>
                        <div className="relative">
                          <Input
                            id="currentPassword"
                            name="password"
                            type={showPassword ? "text" : "password"}
                            value={profileForm.password}
                            onChange={handleProfileFormChange}
                            className="bg-gray-900 border-gray-700 pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="newPassword">New Password</Label>
                          <Input
                            id="newPassword"
                            name="newPassword"
                            type={showPassword ? "text" : "password"}
                            value={profileForm.newPassword}
                            onChange={handleProfileFormChange}
                            className="bg-gray-900 border-gray-700"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="confirmPassword">Confirm New Password</Label>
                          <Input
                            id="confirmPassword"
                            name="confirmPassword"
                            type={showPassword ? "text" : "password"}
                            value={profileForm.confirmPassword}
                            onChange={handleProfileFormChange}
                            className="bg-gray-900 border-gray-700"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
            {editingProfile && (
              <CardFooter className="flex justify-end gap-2 pt-0">
                <Button 
                  variant="outline" 
                  onClick={cancelProfileEditing}
                  className="border-gray-700"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={saveProfileChanges}
                  className="bg-primary hover:bg-primary/80 text-black"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </Button>
              </CardFooter>
            )}
          </Card>
          
          {/* Learning progress */}
          <Card className="bg-cardBackground border-gray-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-xl">Learning Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="modules">
                <TabsList className="bg-gray-900/50 mb-4">
                  <TabsTrigger value="modules" className="data-[state=active]:bg-primary data-[state=active]:text-black">
                    <Brain className="h-4 w-4 mr-2" />
                    Modules
                  </TabsTrigger>
                  <TabsTrigger value="challenges" className="data-[state=active]:bg-secondary data-[state=active]:text-black">
                    <Award className="h-4 w-4 mr-2" />
                    Challenges
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="modules" className="space-y-4">
                  {isLoading ? (
                    <div className="h-32 flex items-center justify-center">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      >
                        <Brain className="h-6 w-6 text-primary" />
                      </motion.div>
                    </div>
                  ) : userProgress && userProgress.length > 0 ? (
                    <div className="space-y-4">
                      {userProgress.map((progress: any) => (
                        <div 
                          key={progress.id} 
                          className="p-3 border border-gray-700 rounded-md bg-gray-800/50"
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <div className="flex items-center">
                                <h4 className="font-medium">Module {progress.moduleId}</h4>
                                {progress.completed && (
                                  <Badge className="ml-2 bg-primary/70 text-black">
                                    <Check className="h-3 w-3 mr-1" />
                                    Completed
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-white/60">
                                Last accessed: {new Date(progress.lastAccessed).toLocaleDateString()}
                              </p>
                            </div>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-secondary"
                              asChild
                            >
                              <a href={`/learning-module/${progress.moduleId}`}>
                                Continue
                                <ChevronRight className="h-4 w-4 ml-1" />
                              </a>
                            </Button>
                          </div>
                          
                          <div className="w-full bg-gray-700 h-1.5 rounded-full overflow-hidden">
                            <div 
                              className="bg-primary h-full rounded-full"
                              style={{ width: `${progress.progress}%` }}
                            />
                          </div>
                          <div className="flex justify-between mt-1">
                            <span className="text-xs text-white/60">{progress.progress}%</span>
                            {!progress.completed && progress.progress > 0 && (
                              <span className="text-xs text-primary">In progress</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-10 border border-gray-700 rounded-md bg-gray-900/30">
                      <Brain className="h-10 w-10 text-white/30 mx-auto mb-3" />
                      <h3 className="text-lg font-medium text-white/80 mb-1">No Modules Started</h3>
                      <p className="text-white/60 max-w-md mx-auto">
                        You haven't started any learning modules yet. Begin your learning journey by exploring our modules.
                      </p>
                      <Button 
                        className="mt-4 bg-primary hover:bg-primary/80 text-black"
                        asChild
                      >
                        <a href="/learning-module/1">
                          Start Learning
                        </a>
                      </Button>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="challenges" className="space-y-4">
                  {isLoading ? (
                    <div className="h-32 flex items-center justify-center">
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                      >
                        <Award className="h-6 w-6 text-secondary" />
                      </motion.div>
                    </div>
                  ) : userChallenges && userChallenges.length > 0 ? (
                    <div className="space-y-4">
                      {userChallenges.map((challenge: any) => (
                        <div 
                          key={challenge.id} 
                          className="p-3 border border-gray-700 rounded-md bg-gray-800/50"
                        >
                          <div className="flex justify-between items-start mb-1">
                            <div>
                              <div className="flex items-center">
                                <h4 className="font-medium">Challenge {challenge.challengeId}</h4>
                                {challenge.completed && (
                                  <Badge className="ml-2 bg-secondary/70 text-black">
                                    <Check className="h-3 w-3 mr-1" />
                                    Completed
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-white/60">
                                {challenge.attempts} attempt{challenge.attempts !== 1 ? 's' : ''}
                                {challenge.lastAttempt && ` • Last attempt: ${new Date(challenge.lastAttempt).toLocaleDateString()}`}
                              </p>
                            </div>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-secondary"
                              asChild
                            >
                              <a href={`/challenge/${challenge.challengeId}`}>
                                {challenge.completed ? 'Review' : 'Try Again'}
                                <ChevronRight className="h-4 w-4 ml-1" />
                              </a>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-10 border border-gray-700 rounded-md bg-gray-900/30">
                      <Award className="h-10 w-10 text-white/30 mx-auto mb-3" />
                      <h3 className="text-lg font-medium text-white/80 mb-1">No Challenges Attempted</h3>
                      <p className="text-white/60 max-w-md mx-auto">
                        You haven't attempted any challenges yet. Complete modules to unlock challenges.
                      </p>
                      <Button 
                        className="mt-4 bg-secondary hover:bg-secondary/80 text-black"
                        asChild
                      >
                        <a href="/learning-module/1">
                          Explore Modules
                        </a>
                      </Button>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Assistant character selection */}
          <Card className="bg-cardBackground border-gray-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center">
                <Bot className="h-5 w-5 text-primary mr-2" />
                AI Assistant Selection
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-white/70 text-sm mb-4">
                Choose your preferred AI assistant character to guide you through your learning journey:
              </p>
              
              <CharacterSelection 
                selectedCharacter={user.preferredCharacter}
                onCharacterSelect={handleCharacterChange}
                userId={user.id}
              />
            </CardContent>
          </Card>
          
          {/* Account settings */}
          <Card className="bg-cardBackground border-gray-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center">
                <Settings className="h-5 w-5 text-primary mr-2" />
                Account Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-white">Email Notifications</Label>
                    <p className="text-xs text-white/60">
                      Receive notifications about your progress
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator className="bg-gray-700" />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-white">Two-Factor Authentication</Label>
                    <p className="text-xs text-white/60">
                      Add an extra layer of security
                    </p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="border-secondary/50 text-secondary hover:bg-secondary/20"
                  >
                    <Shield className="h-4 w-4 mr-1" />
                    Setup
                  </Button>
                </div>
                
                <Separator className="bg-gray-700" />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-white">API Access</Label>
                    <p className="text-xs text-white/60">
                      Generate API keys for integrations
                    </p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="border-gray-700"
                  >
                    <Key className="h-4 w-4 mr-1" />
                    Manage
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Danger zone */}
          <Card className="bg-gray-900/70 border-gray-700 border-t-2 border-t-red-500">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-white/90">Danger Zone</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button 
                  variant="outline" 
                  className="w-full border-gray-700 text-white/80 hover:text-white hover:bg-gray-800"
                  onClick={handleLogout}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
                
                <Button 
                  variant="outline" 
                  className="w-full border-red-800/50 text-red-500 hover:bg-red-900/20 hover:text-red-400"
                >
                  Delete Account
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </ResponsiveGrid>
    </ModernLayout>
  );
}
