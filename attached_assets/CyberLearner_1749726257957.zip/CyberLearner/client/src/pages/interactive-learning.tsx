import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Play, 
  Pause,
  CheckCircle2, 
  Brain, 
  Lightbulb, 
  Code, 
  ArrowRight, 
  ArrowLeft,
  RotateCcw,
  Zap,
  Target,
  BookOpen,
  Volume2,
  VolumeX,
  Settings,
  HelpCircle,
  Star,
  Trophy,
  Timer,
  Eye,
  EyeOff
} from "lucide-react";
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

// Revolutionary Interactive Learning Interface
export default function InteractiveLearning() {
  const { moduleId } = useParams();
  const [, setLocation] = useLocation();
  
  // Learning state management
  const [currentSection, setCurrentSection] = useState(0);
  const [completedSections, setCompletedSections] = useState<Set<number>>(new Set());
  const [userAnswer, setUserAnswer] = useState("");
  const [showHint, setShowHint] = useState(false);
  const [isCodeVisible, setIsCodeVisible] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [timeSpent, setTimeSpent] = useState(0);
  const [streak, setStreak] = useState(0);
  const [xpEarned, setXpEarned] = useState(0);
  
  // Learning analytics
  const [learningPath, setLearningPath] = useState<string[]>([]);
  const [difficultyLevel, setDifficultyLevel] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [personalizedContent, setPersonalizedContent] = useState<any>(null);
  
  const timerRef = useRef<NodeJS.Timeout>();

  // Fetch module content
  const { data: moduleContent, isLoading } = useQuery({
    queryKey: ['/api/modules', moduleId],
    queryFn: async () => {
      const res = await fetch(`/api/modules/${moduleId}`);
      return res.json();
    },
    enabled: !!moduleId,
  });

  // Start timer on component mount
  useEffect(() => {
    timerRef.current = setInterval(() => {
      setTimeSpent(prev => prev + 1);
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // Interactive learning content structure
  const learningContent = {
    sections: [
      {
        id: 0,
        type: "introduction",
        title: "Bem-vindo ao MCP",
        content: {
          text: "O Model Context Protocol (MCP) é uma especificação aberta que permite a comunicação padronizada entre aplicações de IA e fontes de dados externas.",
          visual: "🚀",
          keyPoints: [
            "Protocolo aberto e padronizado",
            "Comunicação segura entre sistemas",
            "Extensibilidade para diferentes fontes de dados"
          ]
        },
        interaction: {
          type: "choice",
          question: "Qual é o principal benefício do MCP?",
          options: [
            "Padronização da comunicação",
            "Velocidade de processamento",
            "Redução de custos",
            "Interface gráfica melhorada"
          ],
          correct: 0,
          explanation: "Correto! O MCP padroniza a comunicação entre sistemas de IA e fontes de dados."
        }
      },
      {
        id: 1,
        type: "concept",
        title: "Arquitetura do MCP",
        content: {
          text: "O MCP funciona através de uma arquitetura cliente-servidor onde o cliente (aplicação de IA) se conecta a servidores MCP que expõem recursos específicos.",
          diagram: "client-server-architecture",
          codeExample: `// Exemplo de cliente MCP básico
import { Client } from '@modelcontextprotocol/sdk/client/index.js';

const client = new Client(
  {
    name: "meu-cliente",
    version: "1.0.0"
  },
  {
    capabilities: {
      resources: {},
      tools: {},
      prompts: {}
    }
  }
);`
        },
        interaction: {
          type: "drag-drop",
          question: "Organize os componentes da arquitetura MCP:",
          items: ["Cliente (IA)", "Servidor MCP", "Fonte de Dados", "Protocolo"],
          correctOrder: [0, 3, 1, 2],
          explanation: "A ordem correta mostra o fluxo: Cliente → Protocolo → Servidor → Fonte de Dados"
        }
      },
      {
        id: 2,
        type: "practice",
        title: "Implementação Prática",
        content: {
          text: "Vamos implementar um servidor MCP simples que expõe recursos de arquivo.",
          challenge: "Crie um servidor que liste arquivos de um diretório",
          template: `import { Server } from '@modelcontextprotocol/sdk/server/index.js';

const server = new Server(
  {
    name: "file-server",
    version: "1.0.0"
  },
  {
    capabilities: {
      resources: {}
    }
  }
);

// TODO: Implement resource handler
server.setRequestHandler(/* complete this */);`,
          solution: `import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { ListResourcesRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import fs from 'fs/promises';

const server = new Server(
  {
    name: "file-server",
    version: "1.0.0"
  },
  {
    capabilities: {
      resources: {}
    }
  }
);

server.setRequestHandler(ListResourcesRequestSchema, async () => {
  const files = await fs.readdir('./');
  return {
    resources: files.map(file => ({
      uri: \`file://\${file}\`,
      name: file,
      mimeType: "text/plain"
    }))
  };
});`
        },
        interaction: {
          type: "code-completion",
          question: "Complete o código para implementar o handler de recursos:",
          blanks: [
            "ListResourcesRequestSchema",
            "fs.readdir('./')",
            "file://\${file}"
          ],
          hints: [
            "Use o schema apropriado para listar recursos",
            "Leia o diretório atual",
            "Use o protocolo file:// para URIs"
          ]
        }
      },
      {
        id: 3,
        type: "assessment",
        title: "Verificação de Conhecimento",
        content: {
          text: "Agora vamos testar seu entendimento sobre MCP com um quiz interativo.",
          assessmentType: "adaptive"
        },
        interaction: {
          type: "multi-step-quiz",
          questions: [
            {
              question: "Qual método é usado para registrar handlers no servidor MCP?",
              type: "single-choice",
              options: ["setRequestHandler", "addHandler", "registerHandler", "createHandler"],
              correct: 0,
              difficulty: "easy"
            },
            {
              question: "Quais capabilities um servidor MCP pode ter?",
              type: "multiple-choice",
              options: ["resources", "tools", "prompts", "databases"],
              correct: [0, 1, 2],
              difficulty: "medium"
            },
            {
              question: "Complete o código para criar um recurso MCP:",
              type: "code-fill",
              template: "{ uri: '__BLANK__', name: 'example.txt', __BLANK__: 'text/plain' }",
              answers: ["file://example.txt", "mimeType"],
              difficulty: "hard"
            }
          ]
        }
      }
    ]
  };

  const currentSectionData = learningContent.sections[currentSection];

  // Handle section completion
  const handleSectionComplete = async (earnedXP: number = 10) => {
    setCompletedSections(prev => new Set(prev).add(currentSection));
    setXpEarned(prev => prev + earnedXP);
    setStreak(prev => prev + 1);
    
    // Play success sound
    if (soundEnabled) {
      // Audio feedback would go here
      console.log("🎉 Section completed!");
    }
    
    // Auto-advance after celebration
    setTimeout(() => {
      if (currentSection < learningContent.sections.length - 1) {
        setCurrentSection(prev => prev + 1);
      }
    }, 2000);
  };

  // Render different interaction types
  const renderInteraction = () => {
    const interaction = currentSectionData.interaction;
    
    switch (interaction.type) {
      case "choice":
        return (
          <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <h4 className="font-bold text-lg mb-4 flex items-center">
              <Brain className="mr-2 h-5 w-5 text-blue-500" />
              {interaction.question}
            </h4>
            <div className="grid gap-3 mb-4">
              {interaction.options.map((option: string, index: number) => (
                <Button
                  key={index}
                  variant="outline"
                  className="text-left justify-start h-auto p-4 hover:bg-blue-100"
                  onClick={() => {
                    if (index === interaction.correct) {
                      handleSectionComplete(15);
                    }
                  }}
                >
                  <span className="w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-3 text-sm font-bold">
                    {String.fromCharCode(65 + index)}
                  </span>
                  {option}
                </Button>
              ))}
            </div>
          </Card>
        );
        
      case "code-completion":
        return (
          <Card className="p-6 bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <h4 className="font-bold text-lg mb-4 flex items-center">
              <Code className="mr-2 h-5 w-5 text-green-500" />
              {interaction.question}
            </h4>
            
            <div className="bg-gray-900 rounded-lg p-4 mb-4">
              <SyntaxHighlighter 
                language="javascript" 
                style={oneDark}
                customStyle={{ background: 'transparent', padding: 0 }}
              >
                {currentSectionData.content.template || ""}
              </SyntaxHighlighter>
            </div>
            
            <div className="space-y-2 mb-4">
              {interaction.blanks.map((blank: string, index: number) => (
                <div key={index} className="flex items-center space-x-2">
                  <span className="text-sm font-medium w-12">#{index + 1}:</span>
                  <input
                    type="text"
                    className="flex-1 px-3 py-2 border rounded-md"
                    placeholder={`Complete o código...`}
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setShowHint(!showHint)}
                  >
                    <HelpCircle className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
            
            {showHint && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                <h5 className="font-medium text-yellow-800 mb-2">💡 Dicas:</h5>
                <ul className="text-sm text-yellow-700 space-y-1">
                  {interaction.hints.map((hint: string, index: number) => (
                    <li key={index}>• {hint}</li>
                  ))}
                </ul>
              </div>
            )}
            
            <Button 
              className="w-full bg-green-600 hover:bg-green-700"
              onClick={() => handleSectionComplete(20)}
            >
              <CheckCircle2 className="mr-2 h-4 w-4" />
              Verificar Solução
            </Button>
          </Card>
        );
        
      default:
        return (
          <Button 
            className="w-full bg-purple-600 hover:bg-purple-700"
            onClick={() => handleSectionComplete()}
          >
            Continuar
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        );
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando módulo interativo...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header with Progress */}
      <div className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setLocation('/')}
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
              <div>
                <h1 className="font-bold text-xl">{moduleContent?.title || "Módulo Interativo"}</h1>
                <p className="text-sm text-gray-500">
                  Seção {currentSection + 1} de {learningContent.sections.length}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm">
                <Timer className="h-4 w-4 text-gray-500" />
                <span>{Math.floor(timeSpent / 60)}:{(timeSpent % 60).toString().padStart(2, '0')}</span>
              </div>
              
              <div className="flex items-center space-x-2 text-sm">
                <Zap className="h-4 w-4 text-yellow-500" />
                <span className="font-bold">{xpEarned} XP</span>
              </div>
              
              <div className="flex items-center space-x-2 text-sm">
                <Trophy className="h-4 w-4 text-orange-500" />
                <span className="font-bold">{streak}</span>
              </div>
              
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setSoundEnabled(!soundEnabled)}
              >
                {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
              </Button>
            </div>
          </div>
          
          <div className="mt-4">
            <div className="flex justify-between text-sm text-gray-500 mb-2">
              <span>Progresso do Módulo</span>
              <span>{Math.round(((currentSection + 1) / learningContent.sections.length) * 100)}%</span>
            </div>
            <Progress 
              value={((currentSection + 1) / learningContent.sections.length) * 100} 
              className="h-2"
            />
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSection}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="space-y-8"
          >
            {/* Section Header */}
            <div className="text-center">
              <div className="text-6xl mb-4">
                {currentSectionData.content.visual || "📚"}
              </div>
              <h2 className="text-3xl font-bold mb-4">{currentSectionData.title}</h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                {currentSectionData.content.text}
              </p>
            </div>

            {/* Content Display */}
            {currentSectionData.content.keyPoints && (
              <Card className="p-6">
                <h3 className="font-bold text-lg mb-4 flex items-center">
                  <Lightbulb className="mr-2 h-5 w-5 text-yellow-500" />
                  Pontos Principais
                </h3>
                <ul className="space-y-2">
                  {currentSectionData.content.keyPoints.map((point: string, index: number) => (
                    <motion.li
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center space-x-3"
                    >
                      <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span>{point}</span>
                    </motion.li>
                  ))}
                </ul>
              </Card>
            )}

            {/* Code Example */}
            {currentSectionData.content.codeExample && (
              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold text-lg flex items-center">
                    <Code className="mr-2 h-5 w-5 text-blue-500" />
                    Exemplo de Código
                  </h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsCodeVisible(!isCodeVisible)}
                  >
                    {isCodeVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                
                {isCodeVisible && (
                  <div className="bg-gray-900 rounded-lg overflow-hidden">
                    <SyntaxHighlighter 
                      language="javascript" 
                      style={oneDark}
                      customStyle={{ margin: 0 }}
                    >
                      {currentSectionData.content.codeExample}
                    </SyntaxHighlighter>
                  </div>
                )}
              </Card>
            )}

            {/* Interactive Section */}
            <div className="space-y-6">
              {renderInteraction()}
            </div>

            {/* Navigation */}
            <div className="flex justify-between items-center pt-8">
              <Button
                variant="outline"
                onClick={() => setCurrentSection(Math.max(0, currentSection - 1))}
                disabled={currentSection === 0}
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Anterior
              </Button>
              
              <div className="flex space-x-2">
                {learningContent.sections.map((_, index) => (
                  <div
                    key={index}
                    className={`w-3 h-3 rounded-full ${
                      index === currentSection 
                        ? 'bg-purple-600' 
                        : completedSections.has(index)
                        ? 'bg-green-500'
                        : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>
              
              <Button
                onClick={() => setCurrentSection(Math.min(learningContent.sections.length - 1, currentSection + 1))}
                disabled={currentSection === learningContent.sections.length - 1}
              >
                Próximo
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}