import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import CyberpunkTheme from "@/components/ui/theme/CyberpunkTheme";
import { useEffect } from "react";
import { registerServiceWorker, setupPWAInstallPrompt } from "@/components/pwa/register-sw";
import { UserPreferencesProvider } from "@/hooks/use-preferences";
import { ROUTES } from "@/lib/constants";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import ModernHome from "@/pages/modern-home";
import ImmersiveHome from "@/pages/immersive-home";
import InteractiveLearning from "@/pages/interactive-learning";
import LearningModule from "@/pages/learning-module";
import Challenge from "@/pages/challenge";
import ProjectBuilder from "@/pages/project-builder";
import Achievements from "@/pages/achievements";
import Profile from "@/pages/profile";
import Login from "@/pages/login";
import Register from "@/pages/register";

// Loading component with cyberpunk aesthetic that respects user's language
import { useUserPreferences } from "@/hooks/use-preferences";

const LoadingScreen = () => {
  const { language } = useUserPreferences();
  
  const loadingText = language === 'pt-br' 
    ? 'Carregando...' 
    : language === 'es' 
      ? 'Cargando...' 
      : 'Loading...';
      
  const preparingText = language === 'pt-br' 
    ? 'Preparando seu ambiente de aprendizado' 
    : language === 'es' 
      ? 'Preparando tu entorno de aprendizaje' 
      : 'Preparing your learning environment';
  
  return (
    <div className="fixed inset-0 bg-gray-900 flex flex-col items-center justify-center z-50">
      <div className="w-16 h-16 relative mb-4">
        <div className="absolute w-full h-full border-t-4 border-primary rounded-full animate-spin"></div>
        <div className="absolute w-full h-full border-r-4 border-secondary rounded-full animate-pulse opacity-75"></div>
      </div>
      <div className="text-xl text-primary font-bold">{loadingText}</div>
      <div className="text-sm text-gray-400 mt-2">{preparingText}</div>
    </div>
  );
};

function Router() {
  // Prefetch important routes for better performance
  useEffect(() => {
    const prefetchRoutes = async () => {
      // Simulate prefetching by loading important resources
      const img = new Image();
      img.src = '/icons/cody-cat.svg';
    };
    
    prefetchRoutes();
  }, []);

  return (
    <Switch>
      <Route path={ROUTES.HOME} component={ImmersiveHome} />
      <Route path="/interactive/:moduleId" component={InteractiveLearning} />
      <Route path={ROUTES.LOGIN} component={Login} />
      <Route path={ROUTES.REGISTER} component={Register} />
      <Route path={ROUTES.LEARNING_MODULE} component={LearningModule} />
      <Route path={ROUTES.CHALLENGE} component={Challenge} />
      <Route path={ROUTES.PROJECT_BUILDER} component={ProjectBuilder} />
      <Route path={ROUTES.ACHIEVEMENTS} component={Achievements} />
      <Route path={ROUTES.PROFILE} component={Profile} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Register service worker for PWA functionality
  useEffect(() => {
    // Register service worker
    registerServiceWorker();
    
    // Setup PWA install prompt
    setupPWAInstallPrompt();
    
    // Performance improvements
    // Add passive event listeners to touch events
    document.addEventListener('touchstart', () => {}, { passive: true });
    document.addEventListener('touchmove', () => {}, { passive: true });
    
    // Preload important images
    const preloadImages = ['/icons/cody-cat.svg', '/icons/favicon.svg'];
    preloadImages.forEach(src => {
      const img = new Image();
      img.src = src;
    });
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <UserPreferencesProvider>
        <CyberpunkTheme>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </CyberpunkTheme>
      </UserPreferencesProvider>
    </QueryClientProvider>
  );
}

export default App;
