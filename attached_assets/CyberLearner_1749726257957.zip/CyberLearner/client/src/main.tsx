import { createRoot } from "react-dom/client";
import App from "./App";
import { globalOptimizer } from "./lib/global-optimizer";
import "./index.css";

// Initialize global optimizations
globalOptimizer.initialize().then(() => {
  createRoot(document.getElementById("root")!).render(<App />);
}).catch(console.error);
