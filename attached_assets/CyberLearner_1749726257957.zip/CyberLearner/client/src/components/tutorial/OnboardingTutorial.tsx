import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, X, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUserPreferences } from '@/hooks/use-preferences';
import { LOCALIZED_CONTENT } from '@/lib/constants';
import { TUTORIAL_IDS } from '@/lib/tutorial-constants';
import CodyImage from '@/components/ui/characters/CodyImage';
import { useIsMobile } from '@/hooks/use-mobile';

interface TutorialStep {
  id: string;
  title: string;
  content: string;
  position: 'center' | 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  targetElement?: string;
  action?: string;
  animation?: 'bounce' | 'pulse' | 'wave' | 'highlight';
}

interface OnboardingTutorialProps {
  onComplete: () => void;
  initialStep?: number;
  userId: number;
}

const OnboardingTutorial: React.FC<OnboardingTutorialProps> = ({
  onComplete,
  initialStep = 0,
  userId
}) => {
  const { language } = useUserPreferences();
  const localizedContent = LOCALIZED_CONTENT[language] || LOCALIZED_CONTENT.en;
  const isMobile = useIsMobile();
  
  const [currentStep, setCurrentStep] = useState(initialStep);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  
  const tutorialSteps: TutorialStep[] = [
    {
      id: TUTORIAL_IDS.WELCOME,
      title: localizedContent.tutorial_welcome_title || "Bem-vindo ao CodyVerse!",
      content: localizedContent.tutorial_welcome_content || "Vamos explorar esta plataforma incrível de aprendizado sobre IA juntos. Estou aqui para guiá-lo!",
      position: 'center',
      animation: 'bounce'
    },
    {
      id: TUTORIAL_IDS.NAVIGATION,
      title: localizedContent.tutorial_nav_title || "Navegação",
      content: localizedContent.tutorial_nav_content || "Use o menu lateral para navegar entre as diferentes seções do aplicativo.",
      position: 'top-left',
      targetElement: '#sidebar',
      animation: 'pulse'
    },
    {
      id: TUTORIAL_IDS.LEARNING_MODULES,
      title: localizedContent.tutorial_modules_title || "Módulos de Aprendizado",
      content: localizedContent.tutorial_modules_content || "Aqui você encontrará módulos de aprendizado sobre IA e tecnologia. Cada módulo tem desafios e recompensas!",
      position: 'bottom-left',
      targetElement: '#learning-modules',
      animation: 'wave'
    },
    {
      id: TUTORIAL_IDS.ASSISTANT,
      title: localizedContent.tutorial_assistant_title || "Seu Assistente Pessoal",
      content: localizedContent.tutorial_assistant_content || "Eu sou Cody, seu assistente de IA! Posso ajudar com dúvidas e fornecer orientações durante seu aprendizado.",
      position: 'bottom-right',
      targetElement: '#assistant-character',
      animation: 'pulse'
    },
    {
      id: TUTORIAL_IDS.PROFILE,
      title: localizedContent.tutorial_profile_title || "Seu Perfil",
      content: localizedContent.tutorial_profile_content || "Acompanhe seu progresso, conquistas e nível no seu perfil pessoal.",
      position: 'top-right',
      targetElement: '#user-profile',
      animation: 'highlight'
    }
  ];
  
  const currentTutorialStep = tutorialSteps[currentStep];
  
  // Sincroniza o status do tutorial com o servidor
  useEffect(() => {
    const updateTutorialStatus = async () => {
      try {
        // Determinar se o tutorial está completo verificando se todos os passos foram concluídos
        const allCompleted = tutorialSteps.every(step => completedSteps.includes(step.id));
        
        await fetch(`/api/users/${userId}/tutorial-status`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            userId,
            completed: allCompleted,
            completedSteps: completedSteps,
            lastUpdated: new Date()
          })
        });
      } catch (error) {
        console.error("Erro ao atualizar status do tutorial:", error);
      }
    };
    
    if (completedSteps.length > 0) {
      updateTutorialStatus();
    }
  }, [completedSteps, userId, tutorialSteps]);
  
  // Foca no elemento correto quando o tutorial inicializa
  useEffect(() => {
    // Pequeno atraso para garantir que os elementos estejam renderizados
    const timeoutId = setTimeout(() => {
      const dialogElement = document.querySelector('[role="dialog"]');
      if (dialogElement instanceof HTMLElement) {
        dialogElement.focus();
      }
    }, 100);
    
    return () => clearTimeout(timeoutId);
  }, []);
  
  const nextStep = () => {
    // Marcar o passo atual como concluído
    if (!completedSteps.includes(currentTutorialStep.id)) {
      setCompletedSteps(prev => [...prev, currentTutorialStep.id]);
    }
    
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onComplete();
    }
  };
  
  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };
  
  const skipTutorial = () => {
    onComplete();
  };
  
  const MobileTutorial = () => (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      <div 
        className="bg-gray-900 border-t border-primary rounded-t-xl shadow-lg shadow-primary/20"
        role="dialog"
        aria-modal="true"
        aria-labelledby="tutorial-title"
        tabIndex={-1}
      >
        {/* Assistive text para leitores de tela */}
        <div className="sr-only">
          <h1>{language === 'en' 
              ? `Interactive app tutorial, step ${currentStep + 1} of ${tutorialSteps.length}` 
              : language === 'pt-br' 
                ? `Tutorial interativo do aplicativo, passo ${currentStep + 1} de ${tutorialSteps.length}` 
                : `Tutorial interactivo de la aplicación, paso ${currentStep + 1} de ${tutorialSteps.length}`}
          </h1>
          <p>{language === 'en' 
              ? 'Use the buttons at the bottom of the panel or swipe to navigate between steps' 
              : language === 'pt-br' 
                ? 'Use os botões no final do painel ou deslize para navegar entre os passos' 
                : 'Use los botones en la parte inferior del panel o deslice para navegar entre los pasos'}</p>
        </div>
        
        {/* Progress indicator com maior contraste visual */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="flex gap-1.5" role="progressbar" aria-valuemin={0} aria-valuemax={tutorialSteps.length} aria-valuenow={currentStep + 1}>
            {tutorialSteps.map((step, index) => (
              <div
                key={index}
                className={`h-1.5 rounded-full ${
                  index === currentStep 
                    ? 'bg-primary w-6' 
                    : completedSteps.includes(tutorialSteps[index].id)
                      ? 'bg-green-500 w-3' 
                      : 'bg-gray-600 w-3'
                }`}
                aria-label={
                  language === 'en'
                    ? index === currentStep
                      ? `Current step ${index + 1} of ${tutorialSteps.length}`
                      : completedSteps.includes(step.id)
                        ? `Step ${index + 1} completed`
                        : `Step ${index + 1}`
                    : language === 'pt-br'
                      ? index === currentStep
                        ? `Passo atual ${index + 1} de ${tutorialSteps.length}`
                        : completedSteps.includes(step.id)
                          ? `Passo ${index + 1} completo`
                          : `Passo ${index + 1}`
                      : index === currentStep
                        ? `Paso actual ${index + 1} de ${tutorialSteps.length}`
                        : completedSteps.includes(step.id)
                          ? `Paso ${index + 1} completado`
                          : `Paso ${index + 1}`
                }
              />
            ))}
          </div>
        </div>
        
        {/* Header com melhor contraste de cores */}
        <div className="flex justify-between items-center px-4 py-3 border-b border-gray-800">
          <div className="flex items-center gap-2">
            <div 
              className="w-8 h-8 rounded-full overflow-hidden border-2 border-primary/50 flex-shrink-0 bg-gray-900"
              aria-hidden="true"
            >
              <CodyImage />
            </div>
            <h2 id="tutorial-title" className="font-bold text-primary text-lg">{currentTutorialStep.title}</h2>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={skipTutorial}
            className="text-gray-400 hover:text-white p-2"
            aria-label={language === 'en' 
              ? "Close tutorial" 
              : language === 'pt-br' 
                ? "Fechar tutorial" 
                : "Cerrar tutorial"}
          >
            <X size={18} />
          </Button>
        </div>
        
        {/* Content com melhor contraste e tamanho de texto */}
        <div className="p-4">
          <p className="text-gray-200 mb-5 text-base leading-relaxed">{currentTutorialStep.content}</p>
          
          {currentTutorialStep.animation === 'bounce' && (
            <motion.div 
              className="flex justify-center mb-5"
              animate={!reducedMotion ? { y: [0, -10, 0] } : {}}
              transition={{ repeat: !reducedMotion ? Infinity : 0, duration: 1.5, ease: "easeInOut" }}
              aria-hidden="true"
            >
              <div className="w-12 h-12 relative">
                <CodyImage />
                {completedSteps.includes(currentTutorialStep.id) && (
                  <div className="absolute -top-1 -right-1 bg-green-500 rounded-full p-0.5">
                    <CheckCircle2 size={16} className="text-black" />
                  </div>
                )}
              </div>
            </motion.div>
          )}
          
          {/* Controles de navegação com tamanho e espaçamento melhores */}
          <div className="flex gap-3 mt-4" role="navigation" aria-label={
            language === 'en' 
              ? "Tutorial navigation" 
              : language === 'pt-br' 
                ? "Navegação do tutorial" 
                : "Navegación del tutorial"
          }>
            {currentStep > 0 && (
              <Button
                variant="outline"
                size="lg"
                onClick={prevStep}
                className="border-gray-700 hover:border-gray-600 flex-1 min-h-12 py-3"
                aria-label={
                  language === 'en' 
                    ? "Go back to previous step" 
                    : language === 'pt-br' 
                      ? "Voltar para o passo anterior" 
                      : "Volver al paso anterior"
                }
              >
                {localizedContent.tutorial_prev || "Anterior"}
              </Button>
            )}
            
            <Button 
              size="lg"
              onClick={nextStep}
              className={`bg-primary text-black hover:bg-primary/90 flex-1 ${currentStep === 0 ? 'w-full' : ''} min-h-12 py-3`}
              aria-label={
                language === 'en'
                  ? currentStep < tutorialSteps.length - 1 
                    ? "Move to next step" 
                    : "Complete tutorial"
                  : language === 'pt-br'
                    ? currentStep < tutorialSteps.length - 1 
                      ? "Avançar para o próximo passo" 
                      : "Concluir tutorial"
                    : currentStep < tutorialSteps.length - 1 
                      ? "Avanzar al siguiente paso" 
                      : "Completar tutorial"
              }
            >
              {currentStep < tutorialSteps.length - 1 
                ? (localizedContent.tutorial_next || "Próximo") 
                : (localizedContent.tutorial_finish || "Concluir")}
              {currentStep < tutorialSteps.length - 1 && <ArrowRight size={16} className="ml-1" aria-hidden="true" />}
            </Button>
          </div>
          
          {/* Teclado virtual para acessibilidade */}
          <div className="flex justify-center items-center gap-2 mt-4 pt-2 border-t border-gray-800">
            <Button
              variant="outline"
              size="sm"
              onClick={skipTutorial}
              className="text-xs border-gray-700 hover:border-gray-600"
              aria-label={
                language === 'en' 
                  ? "Close tutorial with keyboard" 
                  : language === 'pt-br' 
                    ? "Fechar tutorial com teclado" 
                    : "Cerrar tutorial con teclado"
              }
            >
              ESC
            </Button>
            
            {currentStep > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={prevStep}
                className="text-xs border-gray-700 hover:border-gray-600"
                aria-label={
                  language === 'en' 
                    ? "Go back to previous step with keyboard" 
                    : language === 'pt-br' 
                      ? "Voltar para o passo anterior com teclado" 
                      : "Volver al paso anterior con teclado"
                }
              >
                ←
              </Button>
            )}
            
            <Button
              variant="outline"
              size="sm"
              onClick={nextStep}
              className="text-xs border-gray-700 hover:border-gray-600"
              aria-label={
                language === 'en' 
                  ? "Move to next step with keyboard" 
                  : language === 'pt-br' 
                    ? "Avançar para o próximo passo com teclado" 
                    : "Avanzar al siguiente paso con teclado"
              }
            >
              →
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
  
  const DesktopTutorial = () => {
    const getPositionClasses = (position: string) => {
      switch (position) {
        case 'top-left':
          return 'top-4 left-4';
        case 'top-right':
          return 'top-4 right-4';
        case 'bottom-left':
          return 'bottom-4 left-4';
        case 'bottom-right':
          return 'bottom-4 right-4';
        default:
          return 'top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2';
      }
    };
    
    return (
      <div 
        className={`absolute ${getPositionClasses(currentTutorialStep.position)} z-50`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="desktop-tutorial-title"
        tabIndex={-1}
      >
        {/* Container para foco e navegação por teclado */}
        <div className="w-96 rounded-xl border border-primary shadow-lg shadow-primary/20 bg-gray-900/95 backdrop-blur-md overflow-hidden focus-within:ring-2 focus-within:ring-primary">
          {/* Assistive text para leitores de tela */}
          <div className="sr-only">
            <h1>Tutorial interativo do aplicativo, passo {currentStep + 1} de {tutorialSteps.length}</h1>
            <p>Use as setas do teclado ou os botões para navegar entre os passos</p>
          </div>
          
          {/* Header com título e indicadores de progresso */}
          <div className="p-4 border-b border-gray-800 bg-gradient-to-r from-primary/20 to-secondary/20 flex justify-between items-start">
            <div className="flex items-center">
              <div 
                className="w-10 h-10 rounded-full overflow-hidden border-2 border-primary/50 flex-shrink-0 bg-gray-900"
                aria-hidden="true"
              >
                <CodyImage />
              </div>
              <div className="ml-2">
                <h2 id="desktop-tutorial-title" className="font-bold text-primary">{currentTutorialStep.title}</h2>
                <div 
                  className="flex items-center mt-1" 
                  role="progressbar" 
                  aria-valuemin={0} 
                  aria-valuemax={tutorialSteps.length} 
                  aria-valuenow={currentStep + 1}
                  aria-label={`Passo ${currentStep + 1} de ${tutorialSteps.length}`}
                >
                  {tutorialSteps.map((step, index) => (
                    <div
                      key={index}
                      className={`w-2 h-2 rounded-full mx-1 ${
                        index === currentStep 
                          ? 'bg-primary' 
                          : completedSteps.includes(tutorialSteps[index].id)
                            ? 'bg-green-500' 
                            : 'bg-gray-600'
                      }`}
                      aria-hidden="true"
                    />
                  ))}
                </div>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={skipTutorial}
              className="text-gray-400 hover:text-white -mt-2 -mr-2"
              aria-label="Fechar tutorial"
            >
              <X size={18} />
            </Button>
          </div>
          
          {/* Conteúdo com contraste melhorado */}
          <div className="p-4">
            <p className="text-sm text-gray-200 mb-4 leading-relaxed">{currentTutorialStep.content}</p>
            
            {/* Animação do personagem - marcada como decorativa e respeita preferências do usuário */}
            {currentTutorialStep.animation && (
              <motion.div 
                className="flex justify-center mb-4"
                animate={
                  !reducedMotion ? (
                    currentTutorialStep.animation === 'bounce' 
                      ? { y: [0, -10, 0] } 
                      : currentTutorialStep.animation === 'pulse' 
                        ? { scale: [1, 1.1, 1] }
                        : currentTutorialStep.animation === 'wave'
                          ? { rotate: [0, 5, 0, -5, 0] }
                          : {}
                  ) : {}
                }
                transition={{ 
                  repeat: !reducedMotion ? Infinity : 0, 
                  duration: currentTutorialStep.animation === 'bounce' ? 1.5 : 1,
                  ease: "easeInOut"
                }}
                aria-hidden="true"
              >
                <div className="w-16 h-16 relative">
                  <CodyImage />
                  {completedSteps.includes(currentTutorialStep.id) && (
                    <div className="absolute -top-1 -right-1 bg-green-500 rounded-full p-0.5">
                      <CheckCircle2 size={16} className="text-black" />
                    </div>
                  )}
                </div>
              </motion.div>
            )}
            
            {/* Controles de navegação com melhor acessibilidade */}
            <div className="flex justify-between mt-2" role="navigation" aria-label="Navegação do tutorial">
              <Button
                variant="outline"
                size="sm"
                onClick={prevStep}
                disabled={currentStep === 0}
                className="border-gray-700 text-gray-300 hover:text-white min-h-10"
                aria-label="Voltar para o passo anterior"
              >
                {localizedContent.tutorial_prev || "Anterior"}
              </Button>
              
              <Button 
                size="sm" 
                onClick={nextStep}
                className="bg-primary text-black hover:bg-primary/90 min-h-10"
                aria-label={currentStep < tutorialSteps.length - 1 
                  ? "Avançar para o próximo passo" 
                  : "Concluir tutorial"}
              >
                {currentStep < tutorialSteps.length - 1 
                  ? (localizedContent.tutorial_next || "Próximo") 
                  : (localizedContent.tutorial_finish || "Concluir")}
                {currentStep < tutorialSteps.length - 1 && <ArrowRight size={16} className="ml-1" aria-hidden="true" />}
              </Button>
            </div>
            
            {/* Atalhos de teclado para melhor acessibilidade */}
            <div className="flex items-center justify-center gap-2 mt-3 pt-2 border-t border-gray-800 text-xs text-gray-400">
              <div className="flex items-center gap-1">
                <kbd className="px-2 py-1 bg-gray-800 rounded border border-gray-700">ESC</kbd>
                <span>Fechar</span>
              </div>
              {currentStep > 0 && (
                <div className="flex items-center gap-1">
                  <kbd className="px-2 py-1 bg-gray-800 rounded border border-gray-700">←</kbd>
                  <span>Anterior</span>
                </div>
              )}
              <div className="flex items-center gap-1">
                <kbd className="px-2 py-1 bg-gray-800 rounded border border-gray-700">→</kbd>
                <span>Próximo</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  // Gerenciar navegação por teclado
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        skipTutorial();
      } else if (event.key === 'ArrowRight' || event.key === 'Enter') {
        nextStep();
      } else if (event.key === 'ArrowLeft') {
        if (currentStep > 0) {
          prevStep();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [currentStep]);

  // Suporte para alto contraste visual e redução de animações
  const reducedMotion = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  
  const handleOverlayClick = (e: React.MouseEvent) => {
    // Verifica se o clique foi no overlay e não nos elementos filhos
    if (e.target === e.currentTarget) {
      skipTutorial();
    }
  };

  return (
    <div 
      className="fixed inset-0 z-40" 
      onClick={handleOverlayClick}
      data-tutorial-active="true"
      aria-live="polite"
    >
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
        aria-hidden="true"
      />
      
      {/* Mensagens para leitores de tela quando o passo muda */}
      <div className="sr-only" aria-live="polite">
        {`Passo ${currentStep + 1} de ${tutorialSteps.length}: ${currentTutorialStep.title}`}
      </div>
      
      {isMobile ? <MobileTutorial /> : <DesktopTutorial />}
    </div>
  );
};

export default OnboardingTutorial;