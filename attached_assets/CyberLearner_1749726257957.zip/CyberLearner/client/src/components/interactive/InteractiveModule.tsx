import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useUserPreferences } from '@/hooks/use-preferences';
import { Quiz, QuizQuestion } from './Quiz';
import { CodeEditor } from './CodeEditor';
import { DragDrop, DragDropItem } from './DragDrop';
import { BookOpen, Code, ListOrdered, LightbulbIcon, TerminalSquare } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { motion, AnimatePresence } from 'framer-motion';

interface InteractiveModuleProps {
  moduleId: number | string;
  title?: string;
  description?: string;
  content?: any;
  quizQuestions?: QuizQuestion[];
  codeExercise?: {
    initialCode: string;
    language: string;
    description: string;
    hint?: string;
  };
  sequenceExercise?: {
    items: DragDropItem[];
    description: string;
    hint?: string;
  };
  onComplete?: () => void;
  onSectionComplete?: (sectionIndex: number) => void;
}

export function InteractiveModule({
  moduleId,
  title,
  description,
  content,
  quizQuestions,
  codeExercise,
  sequenceExercise,
  onComplete,
  onSectionComplete
}: InteractiveModuleProps) {
  const [activeTab, setActiveTab] = useState<string>('content');
  const [completedSections, setCompletedSections] = useState<string[]>([]);
  const [showCompletionMessage, setShowCompletionMessage] = useState(false);
  const { language } = useUserPreferences();
  const { toast } = useToast();

  // Calculate the number of interactive elements
  const interactiveCount = [
    quizQuestions?.length ? 1 : 0,
    codeExercise ? 1 : 0,
    sequenceExercise ? 1 : 0
  ].reduce((a, b) => a + b, 0);
  
  // Translated text
  const translations = {
    en: {
      content: 'Content',
      quiz: 'Quiz',
      code: 'Code Exercise',
      sequence: 'Sequence',
      interactive: 'Interactive',
      elements: 'elements',
      complete: 'Complete!',
      markComplete: 'Mark as Complete',
      moduleCompleted: 'Module Completed!',
      allSectionsCompleted: 'Congratulations! You\'ve completed all sections of this module.',
      continueModule: 'Continue to Next Module'
    },
    'pt-br': {
      content: 'Conteúdo',
      quiz: 'Quiz',
      code: 'Exercício de Código',
      sequence: 'Sequência',
      interactive: 'Interativo',
      elements: 'elementos',
      complete: 'Completo!',
      markComplete: 'Marcar como Completo',
      moduleCompleted: 'Módulo Concluído!',
      allSectionsCompleted: 'Parabéns! Você completou todas as seções deste módulo.',
      continueModule: 'Continuar para o Próximo Módulo'
    },
    es: {
      content: 'Contenido',
      quiz: 'Cuestionario',
      code: 'Ejercicio de Código',
      sequence: 'Secuencia',
      interactive: 'Interactivo',
      elements: 'elementos',
      complete: '¡Completo!',
      markComplete: 'Marcar como Completo',
      moduleCompleted: '¡Módulo Completado!',
      allSectionsCompleted: '¡Felicidades! Has completado todas las secciones de este módulo.',
      continueModule: 'Continuar al Siguiente Módulo'
    }
  };
  
  const t = translations[language as keyof typeof translations] || translations.en;
  
  const handleComplete = async (section: string) => {
    if (completedSections.includes(section)) return;
    
    // Mark this section as completed
    const newCompletedSections = [...completedSections, section];
    setCompletedSections(newCompletedSections);
    
    // Calculate progress percentage
    const totalSections = 1 + interactiveCount; // Content + interactive elements
    const progress = Math.round((newCompletedSections.length / totalSections) * 100);
    
    // Save progress to the server
    try {
      const userId = localStorage.getItem('userId');
      if (userId) {
        await apiRequest('POST', `/api/users/${userId}/progress/${moduleId}`, {
          completed: progress === 100,
          progress
        });
        
        // If all sections are completed, show completion message
        if (newCompletedSections.length === totalSections) {
          setShowCompletionMessage(true);
          
          // Call the onComplete callback
          if (onComplete) {
            onComplete();
          }
        }
      }
    } catch (error) {
      console.error('Failed to save progress:', error);
    }
  };
  
  return (
    <div className="space-y-6">
      <Card className="border-gray-700 bg-gray-900/60 backdrop-blur-sm">
        <CardHeader>
          <div className="flex flex-wrap justify-between items-start gap-2">
            <div>
              <CardTitle className="text-2xl text-blue-400">{title}</CardTitle>
              <CardDescription className="text-gray-300">{description}</CardDescription>
            </div>
            
            <Badge 
              variant="outline" 
              className="bg-blue-900/30 border-blue-700 text-blue-300 py-1"
            >
              {interactiveCount} {t.interactive} {t.elements}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="content" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 sm:grid-cols-4 bg-gray-800 border-gray-700">
              <TabsTrigger 
                value="content" 
                className="data-[state=active]:bg-gray-700"
              >
                <BookOpen className="h-4 w-4 mr-2" /> 
                {t.content}
                {completedSections.includes('content') && (
                  <span className="ml-2 w-2 h-2 bg-green-500 rounded-full"></span>
                )}
              </TabsTrigger>
              
              {quizQuestions && quizQuestions.length > 0 && (
                <TabsTrigger 
                  value="quiz" 
                  className="data-[state=active]:bg-gray-700"
                >
                  <LightbulbIcon className="h-4 w-4 mr-2" /> 
                  {t.quiz}
                  {completedSections.includes('quiz') && (
                    <span className="ml-2 w-2 h-2 bg-green-500 rounded-full"></span>
                  )}
                </TabsTrigger>
              )}
              
              {codeExercise && (
                <TabsTrigger 
                  value="code" 
                  className="data-[state=active]:bg-gray-700"
                >
                  <TerminalSquare className="h-4 w-4 mr-2" /> 
                  {t.code}
                  {completedSections.includes('code') && (
                    <span className="ml-2 w-2 h-2 bg-green-500 rounded-full"></span>
                  )}
                </TabsTrigger>
              )}
              
              {sequenceExercise && (
                <TabsTrigger 
                  value="sequence" 
                  className="data-[state=active]:bg-gray-700"
                >
                  <ListOrdered className="h-4 w-4 mr-2" /> 
                  {t.sequence}
                  {completedSections.includes('sequence') && (
                    <span className="ml-2 w-2 h-2 bg-green-500 rounded-full"></span>
                  )}
                </TabsTrigger>
              )}
            </TabsList>
            
            <TabsContent value="content" className="mt-4">
              <div className="prose prose-invert max-w-none">
                <div dangerouslySetInnerHTML={{ __html: content }} />
              </div>
              {!completedSections.includes('content') && (
                <div className="mt-6 flex justify-end">
                  <Button 
                    onClick={() => handleComplete('content')}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {t.markComplete}
                  </Button>
                </div>
              )}
            </TabsContent>
            
            {quizQuestions && quizQuestions.length > 0 && (
              <TabsContent value="quiz" className="mt-4">
                <Quiz 
                  questions={quizQuestions} 
                  moduleId={moduleId}
                  onComplete={() => handleComplete('quiz')}
                />
              </TabsContent>
            )}
            
            {codeExercise && (
              <TabsContent value="code" className="mt-4">
                <CodeEditor 
                  initialCode={codeExercise.initialCode}
                  language={codeExercise.language}
                  title={t.code}
                  description={codeExercise.description}
                  hint={codeExercise.hint}
                  moduleId={moduleId}
                  onCodeRun={() => {
                    if (!completedSections.includes('code')) {
                      handleComplete('code');
                    }
                  }}
                />
              </TabsContent>
            )}
            
            {sequenceExercise && (
              <TabsContent value="sequence" className="mt-4">
                <DragDrop 
                  items={sequenceExercise.items}
                  title={t.sequence}
                  description={sequenceExercise.description}
                  hint={sequenceExercise.hint}
                  moduleId={moduleId}
                  onComplete={(isCorrect) => {
                    if (isCorrect && !completedSections.includes('sequence')) {
                      handleComplete('sequence');
                    }
                  }}
                />
              </TabsContent>
            )}
          </Tabs>
        </CardContent>
      </Card>
      
      <AnimatePresence>
        {showCompletionMessage && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed bottom-6 right-6 max-w-md"
          >
            <Card className="bg-green-900/90 border-green-600 backdrop-blur-sm shadow-lg">
              <CardHeader>
                <CardTitle className="text-green-300">{t.moduleCompleted}</CardTitle>
                <CardDescription className="text-green-200">
                  {t.allSectionsCompleted}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={() => {
                    toast({
                      title: t.complete,
                      description: t.allSectionsCompleted
                    });
                    setShowCompletionMessage(false);
                  }}
                  className="w-full bg-green-700 hover:bg-green-600 text-white"
                >
                  {t.continueModule}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}