import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, Clock, Zap, Target, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Scenario {
  title: string;
  description: string;
  tools: string[];
  outcome: string;
}

interface ScenarioExplorerProps {
  scenarios: Scenario[];
  onScenarioComplete?: (scenario: Scenario) => void;
}

export function ScenarioExplorer({ scenarios, onScenarioComplete }: ScenarioExplorerProps) {
  const [selectedScenario, setSelectedScenario] = useState<number | null>(null);
  const [completedScenarios, setCompletedScenarios] = useState<Set<number>>(new Set());
  const [explorationStep, setExplorationStep] = useState(0);

  const handleScenarioSelect = (index: number) => {
    setSelectedScenario(index);
    setExplorationStep(0);
  };

  const handleStepNext = () => {
    const scenario = scenarios[selectedScenario!];
    if (explorationStep < scenario.tools.length) {
      setExplorationStep(prev => prev + 1);
    } else {
      setCompletedScenarios(prev => new Set([...prev, selectedScenario!]));
      onScenarioComplete?.(scenario);
      setSelectedScenario(null);
      setExplorationStep(0);
    }
  };

  const progressPercentage = selectedScenario !== null 
    ? (explorationStep / scenarios[selectedScenario].tools.length) * 100 
    : 0;

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h3 className="text-xl font-bold text-cyan-300 mb-2">Real-World AI Applications</h3>
        <p className="text-slate-300">Explore how AI agents solve complex problems in different industries</p>
        <div className="mt-4 flex items-center justify-center gap-4">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <span className="text-sm text-slate-300">{completedScenarios.size} completed</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-slate-300">{scenarios.length - completedScenarios.size} remaining</span>
          </div>
        </div>
      </div>

      {selectedScenario === null ? (
        // Scenario Selection
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {scenarios.map((scenario, index) => {
            const isCompleted = completedScenarios.has(index);
            
            return (
              <Card 
                key={index}
                className={cn(
                  "cursor-pointer transition-all duration-300 hover:scale-105",
                  "bg-gradient-to-br from-slate-900 to-slate-800 border-slate-700",
                  "hover:border-cyan-500/50 hover:shadow-lg hover:shadow-cyan-500/20",
                  isCompleted && "border-green-500/50 bg-green-500/5"
                )}
                onClick={() => handleScenarioSelect(index)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-lg text-cyan-300">
                      {scenario.title}
                    </CardTitle>
                    {isCompleted && (
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-300 text-sm mb-4 leading-relaxed">
                    {scenario.description}
                  </p>
                  
                  <div className="mb-3">
                    <h4 className="text-xs font-semibold text-slate-400 mb-2">TOOLS USED</h4>
                    <div className="flex flex-wrap gap-1">
                      {scenario.tools.slice(0, 3).map((tool, toolIndex) => (
                        <Badge key={toolIndex} variant="secondary" className="text-xs">
                          {tool}
                        </Badge>
                      ))}
                      {scenario.tools.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{scenario.tools.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-green-400">
                    <Target className="w-3 h-3" />
                    <span>{scenario.outcome}</span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        // Scenario Exploration
        <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/20">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-xl text-cyan-300">
                  {scenarios[selectedScenario].title}
                </CardTitle>
                <p className="text-slate-300 mt-2">
                  {scenarios[selectedScenario].description}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedScenario(null)}
                className="text-slate-400 hover:text-white"
              >
                ← Back
              </Button>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* Progress */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-slate-300">
                  Step {explorationStep + 1} of {scenarios[selectedScenario].tools.length + 1}
                </span>
                <span className="text-sm text-slate-400">
                  {Math.round(progressPercentage)}% complete
                </span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
            </div>

            {/* Current Step */}
            <div className="p-6 rounded-lg bg-slate-800/50 border border-slate-700">
              {explorationStep < scenarios[selectedScenario].tools.length ? (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center">
                      <Zap className="w-4 h-4 text-cyan-400" />
                    </div>
                    <h4 className="text-lg font-semibold text-cyan-300">
                      Tool: {scenarios[selectedScenario].tools[explorationStep]}
                    </h4>
                  </div>
                  
                  <p className="text-slate-300 mb-4">
                    {getToolDescription(scenarios[selectedScenario].tools[explorationStep])}
                  </p>
                  
                  <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-600">
                    <h5 className="font-medium text-cyan-200 mb-2">How it works:</h5>
                    <p className="text-slate-300 text-sm">
                      {getToolWorkflow(scenarios[selectedScenario].tools[explorationStep])}
                    </p>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
                      <Target className="w-4 h-4 text-green-400" />
                    </div>
                    <h4 className="text-lg font-semibold text-green-300">
                      Results Achieved
                    </h4>
                  </div>
                  
                  <p className="text-slate-300 mb-4">
                    By combining these AI tools and techniques, the system achieved:
                  </p>
                  
                  <div className="bg-green-500/10 p-4 rounded-lg border border-green-500/30">
                    <p className="text-green-200 font-medium">
                      {scenarios[selectedScenario].outcome}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Tool Chain Visualization */}
            <div>
              <h4 className="text-sm font-semibold text-slate-400 mb-3">WORKFLOW CHAIN</h4>
              <div className="flex items-center gap-2 overflow-x-auto pb-2">
                {scenarios[selectedScenario].tools.map((tool, index) => (
                  <React.Fragment key={index}>
                    <div
                      className={cn(
                        "flex-shrink-0 px-3 py-2 rounded-lg text-xs font-medium transition-all",
                        index <= explorationStep 
                          ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/50"
                          : "bg-slate-700/50 text-slate-400 border border-slate-600"
                      )}
                    >
                      {tool}
                    </div>
                    {index < scenarios[selectedScenario].tools.length - 1 && (
                      <ArrowRight className="w-3 h-3 text-slate-500 flex-shrink-0" />
                    )}
                  </React.Fragment>
                ))}
                <ArrowRight className="w-3 h-3 text-slate-500 flex-shrink-0" />
                <div
                  className={cn(
                    "flex-shrink-0 px-3 py-2 rounded-lg text-xs font-medium transition-all",
                    explorationStep >= scenarios[selectedScenario].tools.length
                      ? "bg-green-500/20 text-green-300 border border-green-500/50"
                      : "bg-slate-700/50 text-slate-400 border border-slate-600"
                  )}
                >
                  Result
                </div>
              </div>
            </div>

            {/* Next Button */}
            <div className="flex justify-center">
              <Button
                onClick={handleStepNext}
                className="bg-cyan-600 hover:bg-cyan-700 text-white px-8"
              >
                {explorationStep < scenarios[selectedScenario].tools.length ? 'Next Step' : 'Complete Scenario'}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function getToolDescription(tool: string): string {
  const descriptions: Record<string, string> = {
    "Database Query": "Retrieves and analyzes customer data, transaction history, and account information to provide context for support requests.",
    "Ticket Creation": "Automatically generates support tickets with proper categorization, priority levels, and routing to appropriate departments.",
    "Email Sender": "Sends personalized responses, confirmations, and follow-up communications to customers through various channels.",
    "Knowledge Search": "Searches through comprehensive knowledge bases, documentation, and previous solutions to find relevant answers.",
    "Code Analysis": "Examines code quality, identifies potential bugs, security vulnerabilities, and adherence to coding standards.",
    "Test Runner": "Executes automated tests, reports results, and identifies failing test cases with detailed diagnostics.",
    "Documentation Generator": "Creates and updates technical documentation, API references, and code comments automatically.",
    "Git Integration": "Manages version control operations, branch management, and code collaboration workflows.",
    "Data Processor": "Handles large datasets, performs ETL operations, and prepares data for analysis and visualization.",
    "Chart Generator": "Creates interactive visualizations, graphs, and dashboards from processed data.",
    "Report Builder": "Compiles comprehensive reports with insights, trends, and actionable recommendations.",
    "Alert System": "Monitors key metrics and sends notifications when thresholds are exceeded or anomalies are detected."
  };
  
  return descriptions[tool] || "This tool performs specialized operations to support the AI workflow.";
}

function getToolWorkflow(tool: string): string {
  const workflows: Record<string, string> = {
    "Database Query": "Connects to customer databases → Executes optimized queries → Validates data integrity → Returns structured results for AI processing.",
    "Ticket Creation": "Analyzes customer issue → Determines priority and category → Creates ticket with proper metadata → Routes to appropriate team → Sends confirmation.",
    "Email Sender": "Generates personalized content → Validates recipient information → Applies templates and branding → Sends via SMTP → Tracks delivery status.",
    "Knowledge Search": "Processes user query → Searches indexed knowledge base → Ranks results by relevance → Extracts key information → Returns formatted answers.",
    "Code Analysis": "Parses source code → Applies static analysis rules → Checks against style guides → Identifies issues → Generates detailed reports.",
    "Test Runner": "Discovers test files → Executes test suites → Captures results and logs → Generates coverage reports → Notifies stakeholders.",
    "Documentation Generator": "Analyzes code structure → Extracts comments and annotations → Generates formatted documentation → Updates existing docs → Publishes to repository.",
    "Git Integration": "Monitors repository changes → Manages branch operations → Handles merge conflicts → Updates commit history → Synchronizes with remote repositories.",
    "Data Processor": "Ingests raw data → Validates and cleans data → Applies transformations → Optimizes for analysis → Stores in structured format.",
    "Chart Generator": "Analyzes data patterns → Selects appropriate visualization types → Generates interactive charts → Applies styling and branding → Exports in multiple formats.",
    "Report Builder": "Collects data from multiple sources → Applies analysis algorithms → Generates insights and trends → Formats professional reports → Distributes to stakeholders.",
    "Alert System": "Monitors data streams → Evaluates against thresholds → Detects anomalies → Generates alerts → Sends notifications via multiple channels."
  };
  
  return workflows[tool] || "This tool follows a structured workflow to accomplish its specific objectives.";
}