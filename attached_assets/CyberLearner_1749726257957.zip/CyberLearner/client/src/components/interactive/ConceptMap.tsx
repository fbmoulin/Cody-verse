import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Info, Zap, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Concept {
  id: string;
  label: string;
  description: string;
  color: string;
}

interface Connection {
  from: string;
  to: string;
  label?: string;
}

interface ConceptMapProps {
  title: string;
  concepts: Concept[];
  connections: Connection[];
  onConceptClick?: (concept: Concept) => void;
}

export function ConceptMap({ title, concepts, connections, onConceptClick }: ConceptMapProps) {
  const [selectedConcept, setSelectedConcept] = useState<string | null>(null);
  const [animationStep, setAnimationStep] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setAnimationStep(prev => (prev + 1) % connections.length);
    }, 3000);

    return () => clearInterval(timer);
  }, [connections.length]);

  const handleConceptClick = (concept: Concept) => {
    setSelectedConcept(concept.id);
    onConceptClick?.(concept);
  };

  const getConnectedConcepts = (conceptId: string) => {
    const connected = new Set<string>();
    connections.forEach(conn => {
      if (conn.from === conceptId) connected.add(conn.to);
      if (conn.to === conceptId) connected.add(conn.from);
    });
    return connected;
  };

  return (
    <Card className="p-6 bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/20">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-cyan-300 mb-2 flex items-center gap-2">
          <Zap className="w-5 h-5" />
          {title}
        </h3>
        <p className="text-slate-300 text-sm">
          Click on concepts to explore their connections and learn more
        </p>
      </div>

      <div className="relative">
        {/* Concepts Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
          {concepts.map((concept) => {
            const isSelected = selectedConcept === concept.id;
            const isConnected = selectedConcept && getConnectedConcepts(selectedConcept).has(concept.id);
            
            return (
              <Button
                key={concept.id}
                variant="outline"
                className={cn(
                  "h-auto p-4 flex flex-col items-center text-center transition-all duration-300",
                  "border-2 hover:scale-105 hover:shadow-lg",
                  isSelected && "ring-2 ring-cyan-400 shadow-cyan-400/50",
                  isConnected && "border-yellow-400 bg-yellow-400/10",
                  !isSelected && !isConnected && "border-slate-600 hover:border-cyan-400"
                )}
                style={{
                  borderColor: isSelected ? concept.color : undefined,
                  backgroundColor: isSelected ? `${concept.color}20` : undefined
                }}
                onClick={() => handleConceptClick(concept)}
              >
                <div 
                  className="w-3 h-3 rounded-full mb-2"
                  style={{ backgroundColor: concept.color }}
                />
                <span className="font-medium text-sm">{concept.label}</span>
              </Button>
            );
          })}
        </div>

        {/* Connection Visualization */}
        {selectedConcept && (
          <div className="mb-6">
            <h4 className="text-lg font-semibold text-cyan-300 mb-3 flex items-center gap-2">
              <ArrowRight className="w-4 h-4" />
              Connections
            </h4>
            <div className="grid gap-2">
              {connections
                .filter(conn => conn.from === selectedConcept || conn.to === selectedConcept)
                .map((conn, index) => {
                  const otherConceptId = conn.from === selectedConcept ? conn.to : conn.from;
                  const otherConcept = concepts.find(c => c.id === otherConceptId);
                  const isOutgoing = conn.from === selectedConcept;
                  
                  return (
                    <div 
                      key={index}
                      className="flex items-center gap-3 p-3 rounded-lg bg-slate-800/50 border border-slate-700"
                    >
                      <div 
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: otherConcept?.color }}
                      />
                      <span className="text-slate-300">
                        {isOutgoing ? '→' : '←'} {otherConcept?.label}
                      </span>
                      {conn.label && (
                        <Badge variant="secondary" className="text-xs">
                          {conn.label}
                        </Badge>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* Concept Details */}
        {selectedConcept && (
          <Card className="bg-slate-800/50 border-slate-700">
            <CardContent className="p-4">
              {(() => {
                const concept = concepts.find(c => c.id === selectedConcept);
                return concept ? (
                  <div>
                    <div className="flex items-center gap-3 mb-3">
                      <div 
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: concept.color }}
                      />
                      <h5 className="text-lg font-semibold text-cyan-300">
                        {concept.label}
                      </h5>
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      {concept.description}
                    </p>
                  </div>
                ) : null;
              })()}
            </CardContent>
          </Card>
        )}

        {/* Animation Hint */}
        <div className="mt-4 flex items-center gap-2 text-xs text-slate-400">
          <Info className="w-3 h-3" />
          <span>Connections animate automatically to show relationships</span>
        </div>
      </div>
    </Card>
  );
}