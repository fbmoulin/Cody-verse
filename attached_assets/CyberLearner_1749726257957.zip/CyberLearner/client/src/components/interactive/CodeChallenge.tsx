import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, Play, RotateCcw, Lightbulb, Target, Code } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TestCase {
  input?: any;
  expected: string;
  description?: string;
  setup?: string;
  test?: string;
}

interface CodeChallengeProps {
  title: string;
  description: string;
  requirements: string[];
  startingCode: string;
  solution: string;
  testCases: TestCase[];
  onComplete?: (code: string) => void;
}

export function CodeChallenge({
  title,
  description,
  requirements,
  startingCode,
  solution,
  testCases,
  onComplete
}: CodeChallengeProps) {
  const [code, setCode] = useState(startingCode);
  const [isRunning, setIsRunning] = useState(false);
  const [testResults, setTestResults] = useState<Array<{ passed: boolean; message: string }>>([]);
  const [showSolution, setShowSolution] = useState(false);
  const [completedRequirements, setCompletedRequirements] = useState<Set<number>>(new Set());

  const runTests = () => {
    setIsRunning(true);
    
    // Simulate test execution
    setTimeout(() => {
      const results = testCases.map((testCase, index) => {
        const passed = Math.random() > 0.3; // Simulate test results
        return {
          passed,
          message: passed 
            ? `Test ${index + 1}: Passed - ${testCase.expected}`
            : `Test ${index + 1}: Failed - Expected ${testCase.expected}`
        };
      });
      
      setTestResults(results);
      
      // Check requirements completion
      const passedTests = results.filter(r => r.passed).length;
      const newCompleted = new Set<number>();
      
      if (passedTests > 0) newCompleted.add(0);
      if (passedTests > testCases.length / 2) newCompleted.add(1);
      if (passedTests === testCases.length) {
        newCompleted.add(2);
        newCompleted.add(3);
        newCompleted.add(4);
        onComplete?.(code);
      }
      
      setCompletedRequirements(newCompleted);
      setIsRunning(false);
    }, 2000);
  };

  const resetCode = () => {
    setCode(startingCode);
    setTestResults([]);
    setCompletedRequirements(new Set());
  };

  const viewSolution = () => {
    setShowSolution(true);
    setCode(solution);
  };

  const progressPercentage = (completedRequirements.size / requirements.length) * 100;

  return (
    <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/20">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-xl text-cyan-300 flex items-center gap-2">
              <Code className="w-5 h-5" />
              {title}
            </CardTitle>
            <p className="text-slate-300 mt-2">{description}</p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={resetCode}
              className="text-slate-400 hover:text-white"
            >
              <RotateCcw className="w-4 h-4 mr-1" />
              Reset
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={viewSolution}
              className="text-yellow-400 hover:text-yellow-300"
            >
              <Lightbulb className="w-4 h-4 mr-1" />
              Solution
            </Button>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="challenge" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="challenge">Challenge</TabsTrigger>
            <TabsTrigger value="code">Code Editor</TabsTrigger>
            <TabsTrigger value="tests">Tests</TabsTrigger>
          </TabsList>

          <TabsContent value="challenge" className="space-y-6">
            {/* Requirements */}
            <div>
              <h3 className="text-lg font-semibold text-cyan-300 mb-3 flex items-center gap-2">
                <Target className="w-4 h-4" />
                Requirements
              </h3>
              <div className="space-y-2">
                {requirements.map((req, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-slate-800/50">
                    <div className={cn(
                      "w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5",
                      completedRequirements.has(index) 
                        ? "bg-green-500/20 border border-green-500/50"
                        : "bg-slate-600/50 border border-slate-500/50"
                    )}>
                      {completedRequirements.has(index) && (
                        <CheckCircle className="w-3 h-3 text-green-400" />
                      )}
                    </div>
                    <span className={cn(
                      "text-sm",
                      completedRequirements.has(index) ? "text-green-300" : "text-slate-300"
                    )}>
                      {req}
                    </span>
                  </div>
                ))}
              </div>
              
              <div className="mt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-slate-300">Progress</span>
                  <span className="text-sm text-slate-400">{Math.round(progressPercentage)}%</span>
                </div>
                <Progress value={progressPercentage} className="h-2" />
              </div>
            </div>

            {/* Test Cases Preview */}
            <div>
              <h3 className="text-lg font-semibold text-cyan-300 mb-3">Test Cases</h3>
              <div className="grid gap-3">
                {testCases.slice(0, 3).map((testCase, index) => (
                  <div key={index} className="p-3 rounded-lg bg-slate-800/30 border border-slate-700">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="secondary" className="text-xs">Test {index + 1}</Badge>
                      {testCase.description && (
                        <span className="text-xs text-slate-400">{testCase.description}</span>
                      )}
                    </div>
                    <p className="text-sm text-slate-300">Expected: {testCase.expected}</p>
                    {testCase.input && (
                      <p className="text-xs text-slate-400 mt-1">
                        Input: {JSON.stringify(testCase.input)}
                      </p>
                    )}
                  </div>
                ))}
                {testCases.length > 3 && (
                  <div className="text-center py-2">
                    <span className="text-xs text-slate-400">
                      +{testCases.length - 3} more test cases
                    </span>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="code" className="space-y-4">
            <div className="bg-slate-900 rounded-lg border border-slate-700 overflow-hidden">
              <div className="flex items-center justify-between p-3 bg-slate-800 border-b border-slate-700">
                <span className="text-sm font-medium text-slate-300">Code Editor</span>
                <div className="flex gap-2">
                  <Button
                    onClick={runTests}
                    disabled={isRunning}
                    size="sm"
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    {isRunning ? (
                      <>Running...</>
                    ) : (
                      <>
                        <Play className="w-3 h-3 mr-1" />
                        Run Tests
                      </>
                    )}
                  </Button>
                </div>
              </div>
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full h-96 p-4 bg-slate-900 text-slate-200 font-mono text-sm resize-none focus:outline-none"
                placeholder="Write your code here..."
                spellCheck={false}
              />
            </div>

            {showSolution && (
              <div className="p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <Lightbulb className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm font-medium text-yellow-300">Solution Revealed</span>
                </div>
                <p className="text-xs text-yellow-200">
                  The solution is now loaded in the editor. Study the implementation to understand the approach.
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="tests" className="space-y-4">
            {testResults.length > 0 ? (
              <div>
                <h3 className="text-lg font-semibold text-cyan-300 mb-3">Test Results</h3>
                <div className="space-y-2">
                  {testResults.map((result, index) => (
                    <div
                      key={index}
                      className={cn(
                        "p-3 rounded-lg border",
                        result.passed
                          ? "bg-green-500/10 border-green-500/30 text-green-300"
                          : "bg-red-500/10 border-red-500/30 text-red-300"
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <div className={cn(
                          "w-4 h-4 rounded-full flex items-center justify-center",
                          result.passed ? "bg-green-500" : "bg-red-500"
                        )}>
                          {result.passed && <CheckCircle className="w-3 h-3 text-white" />}
                        </div>
                        <span className="text-sm font-medium">
                          {result.passed ? 'PASSED' : 'FAILED'}
                        </span>
                      </div>
                      <p className="text-sm mt-1 text-slate-300">{result.message}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-4 p-4 rounded-lg bg-slate-800/50">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-300">
                      {testResults.filter(r => r.passed).length} of {testResults.length} tests passed
                    </span>
                    <span className={cn(
                      "text-sm font-medium",
                      testResults.every(r => r.passed) ? "text-green-400" : "text-yellow-400"
                    )}>
                      {testResults.every(r => r.passed) ? 'All tests passed!' : 'Keep working!'}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-slate-400">
                <Play className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>Run your code to see test results</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}