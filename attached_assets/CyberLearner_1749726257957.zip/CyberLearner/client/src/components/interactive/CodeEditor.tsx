import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useUserPreferences } from '@/hooks/use-preferences';
import { PlayCircle, RotateCcw, Share2, Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { motion } from 'framer-motion';
import { apiRequest } from '@/lib/queryClient';

interface CodeEditorProps {
  initialCode?: string;
  language?: string;
  title?: string;
  description?: string;
  hint?: string;
  moduleId: number;
  challengeId?: number;
  readOnly?: boolean;
  onCodeRun?: (code: string, result: string) => void;
}

export function CodeEditor({
  initialCode = '// Write your code here\nconsole.log("Hello, Cody Verse!");',
  language = 'javascript',
  title = 'Code Playground',
  description = 'Try out your code and see the results in real-time',
  hint,
  moduleId,
  challengeId,
  readOnly = false,
  onCodeRun
}: CodeEditorProps) {
  const [code, setCode] = useState(initialCode);
  const [result, setResult] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [isShowingHint, setIsShowingHint] = useState(false);
  const { toast } = useToast();
  const { language: userLanguage } = useUserPreferences();
  
  // Create textarea with line numbers
  const lines = code.split('\n').length;
  
  // Reset the component if initialCode changes
  useEffect(() => {
    setCode(initialCode);
    setResult('');
  }, [initialCode]);
  
  // Translations for UI elements
  const translations = {
    en: {
      run: 'Run Code',
      clear: 'Reset',
      share: 'Share',
      showHint: 'Show Hint',
      hideHint: 'Hide Hint',
      result: 'Result:',
      copied: 'Code copied to clipboard!',
      running: 'Running...'
    },
    'pt-br': {
      run: 'Executar Código',
      clear: 'Reiniciar',
      share: 'Compartilhar',
      showHint: 'Mostrar Dica',
      hideHint: 'Ocultar Dica',
      result: 'Resultado:',
      copied: 'Código copiado para a área de transferência!',
      running: 'Executando...'
    },
    es: {
      run: 'Ejecutar Código',
      clear: 'Reiniciar',
      share: 'Compartir',
      showHint: 'Mostrar Pista',
      hideHint: 'Ocultar Pista',
      result: 'Resultado:',
      copied: 'Código copiado al portapapeles!',
      running: 'Ejecutando...'
    }
  };
  
  const t = translations[userLanguage as keyof typeof translations] || translations.en;
  
  const handleRunCode = async () => {
    setIsRunning(true);
    setResult('');
    
    try {
      let output = '';
      
      // For JavaScript code, we can use Function to run it safely
      if (language === 'javascript') {
        try {
          // Create a sandboxed environment to capture console.log
          const originalConsoleLog = console.log;
          let logs: string[] = [];
          
          // Override console.log
          console.log = (...args) => {
            logs.push(args.map(arg => 
              typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
            ).join(' '));
          };
          
          // Run the code in a try-catch block
          try {
            // eslint-disable-next-line no-new-func
            const runCode = new Function(code);
            runCode();
          } catch (error) {
            logs.push(`Error: ${error}`);
          }
          
          // Restore original console.log
          console.log = originalConsoleLog;
          
          // Set the output
          output = logs.join('\n');
        } catch (error) {
          output = `Error: ${error}`;
        }
      } else {
        // For other languages, we'd need to use an API
        // For demo purposes, we'll simulate the code execution
        const response = await apiRequest('POST', '/api/code/execute', {
          code,
          language,
        });
        
        output = response.output || 'No output';
      }
      
      setResult(output);
      
      // Save user's progress if there's a challengeId
      if (challengeId) {
        const userId = localStorage.getItem('userId');
        if (userId) {
          await apiRequest('POST', `/api/users/${userId}/challenges/${challengeId}`, {
            completed: true,
            code
          });
        }
      }
      
      // Notify parent component
      if (onCodeRun) {
        onCodeRun(code, output);
      }
    } catch (error) {
      setResult(`Error: ${error}`);
    } finally {
      setIsRunning(false);
    }
  };
  
  const handleResetCode = () => {
    setCode(initialCode);
    setResult('');
  };
  
  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    toast({
      title: t.copied,
      duration: 2000
    });
  };
  
  const handleToggleHint = () => {
    setIsShowingHint(!isShowingHint);
  };
  
  return (
    <Card className="border-gray-700 bg-gray-900/60 backdrop-blur-sm shadow-neon-blue overflow-hidden">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-xl text-blue-400">{title}</CardTitle>
            <CardDescription className="text-gray-300">{description}</CardDescription>
          </div>
          {hint && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={handleToggleHint}
                    className="text-gray-400 hover:text-blue-400"
                  >
                    <Info className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="left">
                  {isShowingHint ? t.hideHint : t.showHint}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
        
        {isShowingHint && hint && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-2 p-3 bg-blue-900/20 border border-blue-800 rounded-md text-blue-100"
          >
            {hint}
          </motion.div>
        )}
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="relative rounded-md border border-gray-700 overflow-hidden">
          <div className="flex">
            {/* Line numbers */}
            <div className="bg-gray-800 text-gray-500 text-xs p-2 text-right select-none w-12">
              {Array.from({ length: lines }, (_, i) => i + 1).map(num => (
                <div key={num} className="leading-relaxed">{num}</div>
              ))}
            </div>
            
            {/* Code editor */}
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full bg-gray-900 text-gray-200 p-2 leading-relaxed font-mono text-sm resize-none focus:outline-none focus:ring-1 focus:ring-blue-500"
              rows={Math.max(10, lines)}
              disabled={readOnly}
              spellCheck="false"
              data-gramm="false"
            />
          </div>
        </div>
        
        {result && (
          <div className="mt-4 space-y-2">
            <div className="text-sm font-medium text-gray-400">{t.result}</div>
            <div className="bg-black rounded-md p-3 font-mono text-sm text-gray-300 overflow-x-auto max-h-48">
              <pre className="whitespace-pre-wrap">{result}</pre>
            </div>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex space-x-2 justify-between">
        <div className="space-x-2">
          <Button
            variant="outline"
            onClick={handleResetCode}
            className="border-gray-700 text-gray-300 hover:bg-gray-800"
            disabled={code === initialCode || isRunning}
          >
            <RotateCcw className="mr-2 h-4 w-4" />
            {t.clear}
          </Button>
          
          <Button
            variant="outline"
            onClick={handleCopyCode}
            className="border-gray-700 text-gray-300 hover:bg-gray-800"
          >
            <Share2 className="mr-2 h-4 w-4" />
            {t.share}
          </Button>
        </div>
        
        <Button
          onClick={handleRunCode}
          className="bg-blue-600 hover:bg-blue-700 text-white"
          disabled={isRunning || readOnly}
        >
          {isRunning ? (
            <>
              <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
              {t.running}
            </>
          ) : (
            <>
              <PlayCircle className="mr-2 h-4 w-4" />
              {t.run}
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}