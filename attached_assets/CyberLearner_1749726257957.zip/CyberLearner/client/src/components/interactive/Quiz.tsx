import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, XCircle, ArrowRight, RotateCcw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { useUserPreferences } from '@/hooks/use-preferences';
import { apiRequest } from '@/lib/queryClient';

export interface QuizQuestion {
  id: number;
  text: string;
  options: {
    id: string;
    text: string;
    isCorrect: boolean;
  }[];
  explanation: string;
}

interface QuizProps {
  questions: QuizQuestion[];
  moduleId: number;
  onComplete?: (score: number, totalQuestions: number) => void;
  title?: string;
  description?: string;
}

export function Quiz({ 
  questions, 
  moduleId, 
  onComplete, 
  title = 'Test Your Knowledge', 
  description = 'Answer the following questions to check your understanding'
}: QuizProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [showAnimation, setShowAnimation] = useState(false);
  const { toast } = useToast();
  const { language } = useUserPreferences();
  
  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex) / questions.length) * 100;
  
  // Translations for UI elements
  const translations = {
    en: {
      check: 'Check Answer',
      next: 'Next Question',
      correct: 'Correct!',
      incorrect: 'Incorrect',
      complete: 'Quiz Completed',
      score: 'Your Score:',
      tryAgain: 'Try Again',
      selectOption: 'Please select an option',
      congratulations: 'Congratulations!',
      completed: 'You\'ve completed the quiz with a score of',
      explanation: 'Explanation:',
      of: 'of',
      restart: 'Restart Quiz'
    },
    'pt-br': {
      check: 'Verificar Resposta',
      next: 'Próxima Pergunta',
      correct: 'Correto!',
      incorrect: 'Incorreto',
      complete: 'Quiz Completado',
      score: 'Sua Pontuação:',
      tryAgain: 'Tentar Novamente',
      selectOption: 'Por favor, selecione uma opção',
      congratulations: 'Parabéns!',
      completed: 'Você completou o quiz com uma pontuação de',
      explanation: 'Explicação:',
      of: 'de',
      restart: 'Reiniciar Quiz'
    },
    es: {
      check: 'Verificar Respuesta',
      next: 'Siguiente Pregunta',
      correct: '¡Correcto!',
      incorrect: 'Incorrecto',
      complete: 'Cuestionario Completado',
      score: 'Tu Puntuación:',
      tryAgain: 'Intentar de Nuevo',
      selectOption: 'Por favor, selecciona una opción',
      congratulations: '¡Felicidades!',
      completed: 'Has completado el cuestionario con una puntuación de',
      explanation: 'Explicación:',
      of: 'de',
      restart: 'Reiniciar Cuestionario'
    }
  };
  
  const t = translations[language as keyof typeof translations] || translations.en;
  
  useEffect(() => {
    // Reset state when questions change
    setCurrentQuestionIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setCorrectAnswers(0);
    setIsCompleted(false);
  }, [questions]);
  
  const handleOptionSelect = (optionId: string) => {
    if (!isAnswered) {
      setSelectedOption(optionId);
    }
  };
  
  const handleCheckAnswer = async () => {
    if (!selectedOption) {
      toast({
        title: t.selectOption,
        variant: 'destructive'
      });
      return;
    }
    
    setIsAnswered(true);
    const selectedOptionObj = currentQuestion.options.find(option => option.id === selectedOption);
    
    if (selectedOptionObj?.isCorrect) {
      setCorrectAnswers(prev => prev + 1);
      setShowAnimation(true);
      
      // Add a slight delay to show the animation
      await new Promise(resolve => setTimeout(resolve, 800));
      setShowAnimation(false);
    }
    
    // Save user's progress
    try {
      const userId = localStorage.getItem('userId');
      if (userId) {
        await apiRequest('POST', `/api/users/${userId}/challenges/${moduleId}`, {
          completed: isCompleted,
          progress: ((currentQuestionIndex + 1) / questions.length) * 100,
          score: correctAnswers
        });
      }
    } catch (error) {
      console.error('Failed to save progress:', error);
    }
  };
  
  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setIsCompleted(true);
      if (onComplete) {
        onComplete(correctAnswers, questions.length);
      }
    }
  };
  
  const handleRestartQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setCorrectAnswers(0);
    setIsCompleted(false);
  };
  
  // Determine if the selected option is correct
  const isCorrect = isAnswered && 
    currentQuestion.options.find(option => option.id === selectedOption)?.isCorrect;
  
  return (
    <div className="w-full max-w-3xl mx-auto">
      {!isCompleted ? (
        <Card className="border-gray-700 bg-gray-900/60 backdrop-blur-sm shadow-neon-blue">
          <CardHeader>
            <div className="flex justify-between items-center mb-2">
              <CardTitle className="text-xl text-blue-400">{title}</CardTitle>
              <span className="text-sm text-gray-400">
                {currentQuestionIndex + 1} {t.of} {questions.length}
              </span>
            </div>
            <CardDescription className="text-gray-300">{description}</CardDescription>
            <Progress value={progress} className="h-2 mt-2 bg-gray-800" />
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="relative">
              <motion.div
                initial={{ opacity: 1 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="mb-4 text-lg font-medium text-white"
              >
                {currentQuestion.text}
              </motion.div>
              
              <RadioGroup className="space-y-3" value={selectedOption || ''} onValueChange={handleOptionSelect}>
                {currentQuestion.options.map((option) => (
                  <div 
                    key={option.id}
                    className={`relative flex items-center rounded-lg border p-4 cursor-pointer transition-all ${
                      isAnswered ? (
                        option.isCorrect 
                          ? 'border-green-500 bg-green-900/20' 
                          : selectedOption === option.id 
                            ? 'border-red-500 bg-red-900/20'
                            : 'border-gray-700'
                      ) : (
                        selectedOption === option.id
                          ? 'border-blue-500 bg-blue-900/20'
                          : 'border-gray-700 hover:border-gray-500'
                      )
                    }`}
                  >
                    <RadioGroupItem 
                      value={option.id} 
                      id={option.id}
                      disabled={isAnswered} 
                      className="text-white"
                    />
                    <Label 
                      htmlFor={option.id} 
                      className={`ml-3 flex-grow cursor-pointer ${
                        isAnswered && option.isCorrect ? 'text-green-400' : 'text-gray-200'
                      }`}
                    >
                      {option.text}
                    </Label>
                    {isAnswered && option.isCorrect && (
                      <CheckCircle className="h-5 w-5 text-green-500 ml-2" />
                    )}
                    {isAnswered && !option.isCorrect && selectedOption === option.id && (
                      <XCircle className="h-5 w-5 text-red-500 ml-2" />
                    )}
                  </div>
                ))}
              </RadioGroup>
              
              {/* Success animation */}
              <AnimatePresence>
                {showAnimation && isCorrect && (
                  <motion.div 
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 1.5, opacity: 0 }}
                    transition={{ duration: 0.5 }}
                    className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10 text-green-400 text-4xl font-bold"
                  >
                    {t.correct}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            {isAnswered && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 rounded-lg bg-gray-800 border border-gray-700"
              >
                <h4 className="font-medium text-blue-400 mb-1">{t.explanation}</h4>
                <p className="text-gray-300">{currentQuestion.explanation}</p>
              </motion.div>
            )}
          </CardContent>
          
          <CardFooter className="flex justify-between">
            {!isAnswered ? (
              <Button 
                onClick={handleCheckAnswer} 
                className="ml-auto bg-blue-600 hover:bg-blue-700"
              >
                {t.check}
              </Button>
            ) : (
              <Button 
                onClick={handleNextQuestion} 
                className="ml-auto bg-blue-600 hover:bg-blue-700 flex items-center gap-2"
              >
                {t.next} <ArrowRight className="h-4 w-4" />
              </Button>
            )}
          </CardFooter>
        </Card>
      ) : (
        <Card className="border-gray-700 bg-gray-900/60 backdrop-blur-sm shadow-neon-blue">
          <CardHeader>
            <CardTitle className="text-xl text-blue-400">{t.complete}</CardTitle>
            <CardDescription className="text-gray-300">
              {t.congratulations}
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center justify-center py-6">
              <div className="text-5xl font-bold mb-2 text-blue-400">
                {correctAnswers} <span className="text-gray-400">/ {questions.length}</span>
              </div>
              <p className="text-gray-300 mb-4">
                {t.completed} {Math.round((correctAnswers / questions.length) * 100)}%
              </p>
              
              <Progress 
                value={(correctAnswers / questions.length) * 100} 
                className="h-4 w-full max-w-md bg-gray-800"
              />
            </div>
          </CardContent>
          
          <CardFooter className="flex justify-center">
            <Button
              onClick={handleRestartQuiz}
              variant="outline"
              className="border-blue-500 text-blue-400 hover:bg-blue-900/20 flex items-center gap-2"
            >
              <RotateCcw className="h-4 w-4" /> {t.restart}
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}