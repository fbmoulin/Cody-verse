import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { BookOpen, Code2, Brain, Zap } from 'lucide-react';
import { ConceptMap } from './ConceptMap';
import { ScenarioExplorer } from './ScenarioExplorer';
import { CodeChallenge } from './CodeChallenge';
import { CyberQuiz } from '@/components/ui/interactive/CyberQuiz';
import { CyberCodeEditor } from '@/components/ui/interactive/CyberCodeEditor';
import { CyberDragDrop } from '@/components/ui/interactive/CyberDragDrop';

interface ContentSection {
  title: string;
  type: string;
  content: any;
}

interface ContentRendererProps {
  section: ContentSection;
  onSectionComplete?: (sectionId: string) => void;
}

export function ContentRenderer({ section, onSectionComplete }: ContentRendererProps) {
  const renderContent = () => {
    switch (section.type) {
      case 'text':
        return (
          <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-xl text-cyan-300 flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                {section.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-invert max-w-none">
                <p className="text-slate-200 leading-relaxed text-lg">
                  {section.content}
                </p>
              </div>
            </CardContent>
          </Card>
        );

      case 'interactive':
        if (section.content.type === 'concept_map') {
          return (
            <ConceptMap
              title={section.content.title}
              concepts={section.content.concepts}
              connections={section.content.connections}
              onConceptClick={(concept) => {
                console.log('Concept clicked:', concept);
              }}
            />
          );
        }
        
        if (section.content.type === 'scenario_explorer') {
          return (
            <ScenarioExplorer
              scenarios={section.content.scenarios}
              onScenarioComplete={(scenario) => {
                console.log('Scenario completed:', scenario);
                onSectionComplete?.(section.title);
              }}
            />
          );
        }

        if (section.content.type === 'component_builder') {
          return (
            <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-xl text-cyan-300 flex items-center gap-2">
                  <Brain className="w-5 h-5" />
                  {section.content.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6 md:grid-cols-2">
                  {section.content.components.map((component: any, index: number) => (
                    <Card key={index} className="bg-slate-800/50 border-slate-700">
                      <CardHeader className="pb-3">
                        <h4 className="text-lg font-semibold text-cyan-300">
                          {component.name}
                        </h4>
                      </CardHeader>
                      <CardContent>
                        <p className="text-slate-300 mb-4">{component.description}</p>
                        
                        <div className="mb-4">
                          <h5 className="text-sm font-semibold text-slate-400 mb-2">EXAMPLES</h5>
                          <div className="flex flex-wrap gap-1">
                            {component.examples.map((example: string, exIndex: number) => (
                              <Badge key={exIndex} variant="secondary" className="text-xs">
                                {example}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        {component.connections && (
                          <div>
                            <h5 className="text-sm font-semibold text-slate-400 mb-2">CONNECTS TO</h5>
                            <div className="flex flex-wrap gap-1">
                              {component.connections.map((conn: string, connIndex: number) => (
                                <Badge key={connIndex} variant="outline" className="text-xs border-cyan-500/50">
                                  {conn}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        }

        if (section.content.type === 'code_challenge') {
          return (
            <CodeChallenge
              title={section.content.title}
              description={section.content.description}
              requirements={section.content.requirements}
              startingCode={section.content.startingCode}
              solution={section.content.solution}
              testCases={section.content.testCases}
              onComplete={(code) => {
                console.log('Code challenge completed:', code);
                onSectionComplete?.(section.title);
              }}
            />
          );
        }

        if (section.content.type === 'drag_drop') {
          return (
            <CyberDragDrop
              title={section.content.title}
              items={section.content.items}
              correctOrder={section.content.correctOrder}
              instruction={section.content.instruction}
              onComplete={(result) => {
                console.log('Drag drop completed:', result);
                onSectionComplete?.(section.title);
              }}
            />
          );
        }

        if (section.content.type === 'pattern_explorer') {
          return (
            <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/20">
              <CardHeader>
                <CardTitle className="text-xl text-cyan-300 flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  {section.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6">
                  {section.content.patterns.map((pattern: any, index: number) => (
                    <Card key={index} className="bg-slate-800/50 border-slate-700">
                      <CardHeader className="pb-3">
                        <h4 className="text-lg font-semibold text-cyan-300">
                          {pattern.name}
                        </h4>
                        <p className="text-slate-300">{pattern.description}</p>
                      </CardHeader>
                      <CardContent>
                        <div className="mb-4">
                          <h5 className="text-sm font-semibold text-slate-400 mb-2">STEPS</h5>
                          <div className="grid gap-2">
                            {pattern.steps.map((step: string, stepIndex: number) => (
                              <div key={stepIndex} className="flex items-center gap-3">
                                <div className="w-6 h-6 rounded-full bg-cyan-500/20 flex items-center justify-center text-xs text-cyan-300 font-medium">
                                  {stepIndex + 1}
                                </div>
                                <span className="text-slate-300">{step}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-600">
                          <h5 className="font-medium text-cyan-200 mb-2">Example:</h5>
                          <p className="text-slate-300 text-sm">{pattern.example}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        }

        return (
          <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-slate-700">
            <CardContent className="pt-6">
              <p className="text-slate-400">Interactive content type not yet supported: {section.content.type}</p>
            </CardContent>
          </Card>
        );

      case 'code_demo':
        return (
          <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-cyan-500/20">
            <CardHeader>
              <CardTitle className="text-xl text-cyan-300 flex items-center gap-2">
                <Code2 className="w-5 h-5" />
                {section.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <CyberCodeEditor
                initialCode={section.content.code}
                language={section.content.language}
                readOnly={true}
                showLineNumbers={true}
                theme="dark"
              />
              {section.content.explanation && (
                <div className="mt-4 p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                  <h5 className="font-medium text-cyan-200 mb-2">Explanation:</h5>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    {section.content.explanation}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        );

      case 'quiz':
        return (
          <CyberQuiz
            questions={section.content}
            onComplete={(results) => {
              console.log('Quiz completed:', results);
              onSectionComplete?.(section.title);
            }}
          />
        );

      default:
        return (
          <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-xl text-cyan-300">
                {section.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400">
                Content type "{section.type}" is not yet supported.
              </p>
              <pre className="mt-4 p-4 bg-slate-800 rounded text-xs text-slate-300 overflow-auto">
                {JSON.stringify(section.content, null, 2)}
              </pre>
            </CardContent>
          </Card>
        );
    }
  };

  return (
    <div className="space-y-6">
      {renderContent()}
    </div>
  );
}