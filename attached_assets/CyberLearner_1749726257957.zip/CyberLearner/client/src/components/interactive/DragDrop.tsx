import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useUserPreferences } from '@/hooks/use-preferences';
import { CheckCircle2, XCircle, RefreshCw, LightbulbIcon } from 'lucide-react';
import { motion, AnimatePresence, Reorder } from 'framer-motion';
import { apiRequest } from '@/lib/queryClient';

export interface DragDropItem {
  id: string;
  content: string;
  correctPosition: number;
}

interface DragDropProps {
  items: DragDropItem[];
  title?: string;
  description?: string;
  moduleId: number;
  challengeId?: number;
  onComplete?: (isCorrect: boolean) => void;
  hint?: string;
}

export function DragDrop({
  items,
  title = 'Arrange in Order',
  description = 'Drag and drop the items into the correct sequence',
  moduleId,
  challengeId,
  onComplete,
  hint
}: DragDropProps) {
  const [shuffledItems, setShuffledItems] = useState<DragDropItem[]>([]);
  const [isChecking, setIsChecking] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showHint, setShowHint] = useState(false);
  const { toast } = useToast();
  const { language } = useUserPreferences();
  
  // Translations for UI elements
  const translations = {
    en: {
      check: 'Check Order',
      tryAgain: 'Try Again',
      correct: 'Correct!',
      incorrect: 'Not quite right. Try again!',
      showHint: 'Show Hint',
      hideHint: 'Hide Hint',
      reset: 'Reset Order'
    },
    'pt-br': {
      check: 'Verificar Ordem',
      tryAgain: 'Tentar Novamente',
      correct: 'Correto!',
      incorrect: 'Não está certo. Tente novamente!',
      showHint: 'Mostrar Dica',
      hideHint: 'Ocultar Dica',
      reset: 'Redefinir Ordem'
    },
    es: {
      check: 'Verificar Orden',
      tryAgain: 'Intentar de Nuevo',
      incorrect: '¡No es correcto. Inténtalo de nuevo!',
      correct: '¡Correcto!',
      showHint: 'Mostrar Pista',
      hideHint: 'Ocultar Pista',
      reset: 'Restablecer Orden'
    }
  };
  
  const t = translations[language as keyof typeof translations] || translations.en;
  
  // Initialize with shuffled items
  useEffect(() => {
    shuffleItems();
  }, [items]);
  
  const shuffleItems = () => {
    // Create a copy and shuffle it
    const itemsCopy = [...items];
    for (let i = itemsCopy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [itemsCopy[i], itemsCopy[j]] = [itemsCopy[j], itemsCopy[i]];
    }
    setShuffledItems(itemsCopy);
    setIsCorrect(null);
  };
  
  const checkOrder = async () => {
    setIsChecking(true);
    
    // Check if the current order matches the correct order
    const isOrderCorrect = shuffledItems.every((item, index) => {
      return item.correctPosition === index + 1;
    });
    
    setIsCorrect(isOrderCorrect);
    
    // Save progress if there's a challengeId
    if (challengeId) {
      try {
        const userId = localStorage.getItem('userId');
        if (userId) {
          await apiRequest('POST', `/api/users/${userId}/challenges/${challengeId}`, {
            completed: isOrderCorrect,
            progress: isOrderCorrect ? 100 : 50
          });
        }
      } catch (error) {
        console.error('Failed to save progress:', error);
      }
    }
    
    // Notify parent component
    if (onComplete) {
      onComplete(isOrderCorrect);
    }
    
    setIsChecking(false);
  };
  
  const handleReset = () => {
    shuffleItems();
  };
  
  const toggleHint = () => {
    setShowHint(!showHint);
  };
  
  return (
    <Card className="border-gray-700 bg-gray-900/60 backdrop-blur-sm shadow-neon-blue">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl text-blue-400">{title}</CardTitle>
            <CardDescription className="text-gray-300">{description}</CardDescription>
          </div>
          {hint && (
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleHint}
              className="text-gray-400 hover:text-blue-400 -mt-1"
            >
              <LightbulbIcon className="h-4 w-4 mr-1" />
              {showHint ? t.hideHint : t.showHint}
            </Button>
          )}
        </div>
        
        <AnimatePresence>
          {showHint && hint && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="mt-2 p-3 bg-blue-900/20 border border-blue-800 rounded-md text-blue-100"
            >
              {hint}
            </motion.div>
          )}
        </AnimatePresence>
      </CardHeader>
      
      <CardContent className="pt-0">
        <Reorder.Group 
          axis="y" 
          values={shuffledItems} 
          onReorder={setShuffledItems}
          className="space-y-2"
        >
          {shuffledItems.map((item) => (
            <Reorder.Item
              key={item.id}
              value={item}
              className="cursor-grab active:cursor-grabbing"
            >
              <div 
                className={`p-4 rounded-md border flex items-center transition-colors ${
                  isCorrect === null
                    ? 'bg-gray-800 border-gray-700 hover:border-gray-600'
                    : isCorrect
                      ? 'bg-green-900/20 border-green-700'
                      : 'bg-red-900/20 border-red-700'
                }`}
              >
                <div className="w-7 h-7 rounded-full bg-gray-700 flex items-center justify-center text-white font-medium mr-3">
                  {shuffledItems.findIndex(i => i.id === item.id) + 1}
                </div>
                <div className="flex-grow text-gray-200">{item.content}</div>
                {isCorrect !== null && (
                  <div className="ml-2">
                    {item.correctPosition === shuffledItems.findIndex(i => i.id === item.id) + 1 ? (
                      <CheckCircle2 className="h-5 w-5 text-green-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500" />
                    )}
                  </div>
                )}
              </div>
            </Reorder.Item>
          ))}
        </Reorder.Group>
        
        {isCorrect !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`mt-4 p-3 rounded-md ${
              isCorrect 
                ? 'bg-green-900/20 border border-green-700 text-green-400' 
                : 'bg-red-900/20 border border-red-700 text-red-400'
            }`}
          >
            {isCorrect ? t.correct : t.incorrect}
          </motion.div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          onClick={handleReset}
          className="border-gray-700 text-gray-300 hover:bg-gray-800"
          disabled={isChecking}
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          {t.reset}
        </Button>
        
        <Button
          onClick={checkOrder}
          className={`${
            isCorrect === null
              ? 'bg-blue-600 hover:bg-blue-700'
              : isCorrect
                ? 'bg-green-600 hover:bg-green-700'
                : 'bg-red-600 hover:bg-red-700'
          } text-white`}
          disabled={isChecking}
        >
          {isChecking ? (
            <span className="flex items-center">
              <span className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></span>
              {t.check}
            </span>
          ) : isCorrect === null ? (
            t.check
          ) : (
            t.tryAgain
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}