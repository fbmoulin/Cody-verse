import React from 'react';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { useUserPreferences } from '@/hooks/use-preferences';
import { Globe } from 'lucide-react';
import type { Language } from '@/hooks/use-preferences';

// Flag emojis with language names
const languages: Record<Language, { name: string, flag: string }> = {
  'en': { name: 'English', flag: '🇺🇸' },
  'pt-br': { name: 'Português', flag: '🇧🇷' },
  'es': { name: 'Español', flag: '🇪🇸' }
};

interface LanguageSelectorProps {
  compact?: boolean;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({ compact = false }) => {
  const { language, setLanguage } = useUserPreferences();
  
  const currentLang = languages[language];
  
  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage);
  };
  
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="ghost" 
          size={compact ? "icon" : "default"} 
          className="text-white/80 hover:text-white"
        >
          {compact ? (
            <span className="text-xl">{currentLang.flag}</span>
          ) : (
            <>
              <span className="mr-2 text-xl">{currentLang.flag}</span>
              <span className="mr-1">{currentLang.name}</span>
              <Globe className="h-4 w-4 opacity-70" />
            </>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="bg-gray-900 border border-gray-700 min-w-[150px]">
        {Object.entries(languages).map(([langCode, langInfo]) => (
          <DropdownMenuItem 
            key={langCode}
            onClick={() => handleLanguageChange(langCode as Language)}
            className={`cursor-pointer flex items-center ${language === langCode ? 'bg-primary/20 text-primary' : ''}`}
          >
            <span className="mr-2 text-xl">{langInfo.flag}</span>
            <span>{langInfo.name}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default LanguageSelector;