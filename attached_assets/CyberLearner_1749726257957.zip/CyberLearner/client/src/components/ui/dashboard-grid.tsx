import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface DashboardGridProps {
  children: React.ReactNode;
  columns?: 1 | 2 | 3 | 4;
  gap?: 'sm' | 'md' | 'lg';
  className?: string;
}

const DashboardGrid: React.FC<DashboardGridProps> = ({
  children,
  columns = 3,
  gap = 'md',
  className
}) => {
  const columnClasses = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 md:grid-cols-2',
    3: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4'
  };

  const gapClasses = {
    sm: 'gap-3',
    md: 'gap-4 md:gap-6',
    lg: 'gap-6 md:gap-8'
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6, staggerChildren: 0.1 }}
      className={cn(
        'grid',
        columnClasses[columns],
        gapClasses[gap],
        className
      )}
    >
      {React.Children.map(children, (child, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          {child}
        </motion.div>
      ))}
    </motion.div>
  );
};

// Stats Widget Component
interface StatsWidgetProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: React.ComponentType<any>;
  trend?: 'up' | 'down' | 'stable';
  trendValue?: string;
  className?: string;
}

export const StatsWidget: React.FC<StatsWidgetProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  trendValue,
  className
}) => {
  const trendColors = {
    up: 'text-green-400',
    down: 'text-red-400',
    stable: 'text-gray-400'
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className={cn(
        'bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-lg p-6 hover:border-cyan-500/50 transition-all duration-300',
        className
      )}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-gray-400 uppercase tracking-wide">
          {title}
        </h3>
        {Icon && <Icon className="w-5 h-5 text-cyan-400" />}
      </div>
      
      <div className="flex items-end justify-between">
        <div>
          <p className="text-2xl font-bold text-white mb-1">{value}</p>
          {subtitle && (
            <p className="text-sm text-gray-400">{subtitle}</p>
          )}
        </div>
        
        {trend && trendValue && (
          <div className={cn('text-sm font-medium', trendColors[trend])}>
            {trend === 'up' && '↗'} 
            {trend === 'down' && '↘'} 
            {trend === 'stable' && '→'} 
            {trendValue}
          </div>
        )}
      </div>
    </motion.div>
  );
};

// Quick Action Button Component
interface QuickActionProps {
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  onClick: () => void;
  variant?: 'primary' | 'secondary' | 'outline';
  className?: string;
}

export const QuickAction: React.FC<QuickActionProps> = ({
  title,
  description,
  icon: Icon,
  onClick,
  variant = 'primary',
  className
}) => {
  const variants = {
    primary: 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white',
    secondary: 'bg-gray-800/50 hover:bg-gray-700/50 text-white border border-gray-700',
    outline: 'bg-transparent hover:bg-gray-800/30 text-gray-300 border border-gray-600 hover:border-cyan-500'
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={cn(
        'w-full p-6 rounded-lg transition-all duration-300 text-left group',
        variants[variant],
        className
      )}
    >
      <div className="flex items-start space-x-4">
        <div className="flex-shrink-0">
          <Icon className="w-8 h-8 group-hover:scale-110 transition-transform" />
        </div>
        <div>
          <h3 className="font-semibold mb-1 group-hover:text-cyan-300 transition-colors">
            {title}
          </h3>
          <p className="text-sm opacity-80">
            {description}
          </p>
        </div>
      </div>
    </motion.button>
  );
};

export default DashboardGrid;