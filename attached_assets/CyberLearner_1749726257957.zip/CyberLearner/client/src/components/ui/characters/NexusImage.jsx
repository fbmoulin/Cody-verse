import React from 'react';

const NexusImage = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80" className="w-full h-full">
      {/* Background */}
      <circle cx="40" cy="40" r="40" fill="#0D1117" />
      
      {/* Fox body and head with blue colors */}
      <path d="M40 70c15 0 25-10 25-30s-10-30-25-30-25 10-25 30 10 30 25 30z" 
        fill="#00CCFF" stroke="#0099CC" strokeWidth="1" />
      
      {/* Pointed fox ears */}
      <path d="M25 25l-5-15 15 5z" fill="#00CCFF" stroke="#0099CC" strokeWidth="1" />
      <path d="M55 25l5-15-15 5z" fill="#00CCFF" stroke="#0099CC" strokeWidth="1" />
      <path d="M30 25l-3-8 7 2z" fill="#0066FF" stroke="#0055CC" strokeWidth="0.5" />
      <path d="M50 25l3-8-7 2z" fill="#0066FF" stroke="#0055CC" strokeWidth="0.5" />
      
      {/* Tech visor over eyes */}
      <rect x="25" y="30" width="30" height="10" rx="2" fill="#111" stroke="#0099CC" strokeWidth="0.5" />
      <rect x="25" y="32" width="30" height="6" fill="#00FFFF" fillOpacity="0.3" />
      <line x1="30" y1="35" x2="50" y2="35" stroke="#00FFFF" strokeWidth="0.75" strokeDasharray="2 1" />
      
      {/* Digital patterns */}
      <circle cx="32" cy="35" r="2" fill="#00FFFF" fillOpacity="0.8" />
      <circle cx="48" cy="35" r="2" fill="#00FFFF" fillOpacity="0.8" />
      
      {/* Muzzle */}
      <path d="M37 45a3 3 0 0 0 6 0" fill="#0099CC" />
      
      {/* Body details */}
      <path d="M30 50c2 3 8 3 10 0M40 50c2 3 8 3 10 0" stroke="#0066FF" strokeWidth="0.5" fill="none" />
      <rect x="37" y="50" width="6" height="10" fill="#0066FF" />
      <circle cx="40" cy="55" r="2" fill="#00FFFF" />
      
      {/* Tech interface */}
      <path d="M27 45c-2 5 0 15 3 20M53 45c2 5 0 15-3 20" stroke="#00FFFF" strokeWidth="0.5" strokeDasharray="1 1" />
    </svg>
  );
};

export default NexusImage;