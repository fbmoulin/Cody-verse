import React from 'react';

// Echo the Quantum Raven SVG component
const EchoImage: React.FC = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" className="w-full h-full">
      {/* Background circle */}
      <circle cx="150" cy="150" r="150" fill="#0D1117" />
      
      {/* Base raven body with black/pink accents */}
      <path d="M150 260c35 0 65-20 65-80 0-35-25-70-65-70s-65 35-65 70c0 60 30 80 65 80z" fill="#222222" stroke="#333333" strokeWidth="2" />
      
      {/* Head - sleek and streamlined */}
      <path d="M150 175c38 0 70-25 70-65 0-40-32-70-70-70s-70 30-70 70c0 40 32 65 70 65z" fill="#111111" stroke="#333333" strokeWidth="2" />
      
      {/* Digital highlights/texture */}
      <path d="M115 70l10-15M125 60l10-15M145 55l5-15M155 55l-5-15M175 60l-10-15M185 70l-10-15" stroke="#FF1493" strokeWidth="1" />
      
      {/* Raven feather textures */}
      <path d="M100 100c10 10 20 10 25 5M100 110c10 10 20 10 25 5M100 120c10 10 20 10 25 5" stroke="#333" strokeWidth="1" />
      <path d="M200 100c-10 10-20 10-25 5M200 110c-10 10-20 10-25 5M200 120c-10 10-20 10-25 5" stroke="#333" strokeWidth="1" />
      
      {/* Sharp, angled beak */}
      <path d="M140 130l10 15 10-15z" fill="#333" stroke="#444" strokeWidth="1" />
      
      {/* Glowing eyes */}
      <circle cx="125" cy="110" r="10" fill="#FF1493" fillOpacity="0.7" />
      <circle cx="175" cy="110" r="10" fill="#FF1493" fillOpacity="0.7" />
      <circle cx="125" cy="110" r="5" fill="#FFFFFF" />
      <circle cx="175" cy="110" r="5" fill="#FFFFFF" />
      
      {/* Quantum interface crown */}
      <path d="M110 80h80" stroke="#FF1493" strokeWidth="2" />
      <path d="M120 80v-15M140 80v-20M160 80v-20M180 80v-15" stroke="#FF1493" strokeWidth="2" />
      <circle cx="120" cy="65" r="3" fill="#FF1493" />
      <circle cx="140" cy="60" r="3" fill="#FF1493" />
      <circle cx="160" cy="60" r="3" fill="#FF1493" />
      <circle cx="180" cy="65" r="3" fill="#FF1493" />
      
      {/* Digital patterns on body */}
      <path d="M130 150h40M120 170h60M130 190h40M140 210h20" stroke="#FF1493" strokeWidth="1" strokeDasharray="3,2" />
      
      {/* Sleek tech outfit with pink accents */}
      <path d="M120 150c-5 10-5 40 0 60h60c5-20 5-50 0-60z" fill="#111" stroke="#333" strokeWidth="1" />
      <path d="M120 150l10 60h40l10-60z" fill="#222" stroke="#333" />
      
      {/* Accent lighting on outfit */}
      <path d="M130 150v60M170 150v60" stroke="#FF1493" strokeWidth="1" />
      <circle cx="130" cy="160" r="3" fill="#FF1493" />
      <circle cx="130" cy="180" r="3" fill="#FF1493" />
      <circle cx="130" cy="200" r="3" fill="#FF1493" />
      <circle cx="170" cy="160" r="3" fill="#FF1493" />
      <circle cx="170" cy="180" r="3" fill="#FF1493" />
      <circle cx="170" cy="200" r="3" fill="#FF1493" />
      
      {/* Central quantum core */}
      <circle cx="150" cy="180" r="12" fill="#222" stroke="#FF1493" strokeWidth="1" />
      <circle cx="150" cy="180" r="8" fill="#FF1493" fillOpacity="0.5" />
      <circle cx="150" cy="180" r="4" fill="#FFFFFF" />
      
      {/* Wings instead of arms */}
      <path d="M115 170c-30 10-50 30-40 50s30 10 45 0" fill="#111" stroke="#333" strokeWidth="2" />
      <path d="M185 170c30 10 50 30 40 50s-30 10-45 0" fill="#111" stroke="#333" strokeWidth="2" />
      
      {/* Digital feather patterns on wings */}
      <path d="M95 190l10 10M85 200l10 10M95 210l10 10" stroke="#FF1493" strokeWidth="1" />
      <path d="M205 190l-10 10M215 200l-10 10M205 210l-10 10" stroke="#FF1493" strokeWidth="1" />
      
      {/* Wing tips with energy effect */}
      <path d="M75 220l10-5M85 230l10-5M95 220l10-5" stroke="#FF1493" strokeWidth="1" strokeDasharray="2,1" />
      <path d="M225 220l-10-5M215 230l-10-5M205 220l-10-5" stroke="#FF1493" strokeWidth="1" strokeDasharray="2,1" />
      
      {/* Sleek digital talons */}
      <path d="M140 210v30M160 210v30" stroke="#333" strokeWidth="10" />
      <path d="M135 240l5 10 5-10M155 240l5 10 5-10" fill="#111" stroke="#333" strokeWidth="1" />
      <path d="M140 235l-5 10M140 235l0 10M140 235l5 10M160 235l-5 10M160 235l0 10M160 235l5 10" stroke="#FF1493" strokeWidth="1" />
      
      {/* Quantum tail effect */}
      <path d="M150 230c0 10 0 20-10 30" stroke="#111" strokeWidth="10" fill="none" />
      <path d="M150 230c0 10 0 20-10 30" stroke="#FF1493" strokeWidth="1" strokeDasharray="3,3" fill="none" />
      <path d="M140 250l-5 5M140 255l-5 5M140 260l-5 5" stroke="#FF1493" strokeWidth="1" />
    </svg>
  );
};

export default EchoImage;