import React from 'react';

const EchoImage = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80" className="w-full h-full">
      {/* Background */}
      <circle cx="40" cy="40" r="40" fill="#0D1117" />
      
      {/* Raven body with sleek black shape */}
      <path d="M40 70c15 0 25-10 25-30s-10-30-25-30-25 10-25 30 10 30 25 30z" 
        fill="#222222" stroke="#333333" strokeWidth="1" />
      
      {/* Digital highlights */}
      <path d="M25 30l5-10M30 25l5-10M35 22l5-8M45 22l-5-8M50 25l-5-10M55 30l-5-10" 
        stroke="#FF1493" strokeWidth="0.5" />
      
      {/* Feather textures */}
      <path d="M25 35c5 2 8 0 10-2M25 40c5 2 8 0 10-2M25 45c5 2 8 0 10-2" 
        stroke="#333" strokeWidth="0.5" />
      <path d="M55 35c-5 2-8 0-10-2M55 40c-5 2-8 0-10-2M55 45c-5 2-8 0-10-2" 
        stroke="#333" strokeWidth="0.5" />
      
      {/* Beak */}
      <path d="M35 40l5 5 5-5z" fill="#333" stroke="#444" strokeWidth="0.5" />
      
      {/* Glowing eyes */}
      <circle cx="32" cy="35" r="4" fill="#FF1493" fillOpacity="0.7" />
      <circle cx="48" cy="35" r="4" fill="#FF1493" fillOpacity="0.7" />
      <circle cx="32" cy="35" r="2" fill="#FFFFFF" />
      <circle cx="48" cy="35" r="2" fill="#FFFFFF" />
      
      {/* Quantum interface crown */}
      <path d="M30 25h20" stroke="#FF1493" strokeWidth="1" />
      <path d="M33 25v-5M37 25v-7M43 25v-7M47 25v-5" stroke="#FF1493" strokeWidth="1" />
      <circle cx="33" cy="20" r="1" fill="#FF1493" />
      <circle cx="37" cy="18" r="1" fill="#FF1493" />
      <circle cx="43" cy="18" r="1" fill="#FF1493" />
      <circle cx="47" cy="20" r="1" fill="#FF1493" />
      
      {/* Digital patterns on body */}
      <path d="M35 50h10M32 55h16M35 60h10" stroke="#FF1493" strokeWidth="0.5" strokeDasharray="2 1" />
      
      {/* Wings */}
      <path d="M25 45c-8 4-12 8-8 12s10 0 13-4" fill="#111" stroke="#333" strokeWidth="0.5" />
      <path d="M55 45c8 4 12 8 8 12s-10 0-13-4" fill="#111" stroke="#333" strokeWidth="0.5" />
      
      {/* Digital feathers */}
      <path d="M20 50l3 3M18 55l3 3" stroke="#FF1493" strokeWidth="0.5" />
      <path d="M60 50l-3 3M62 55l-3 3" stroke="#FF1493" strokeWidth="0.5" />
    </svg>
  );
};

export default EchoImage;