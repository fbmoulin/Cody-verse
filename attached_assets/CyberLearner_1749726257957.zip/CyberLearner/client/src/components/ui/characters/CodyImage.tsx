import React from 'react';

// Cody the Cyber Cat SVG component based on the reference image
const CodyImage: React.FC = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" className="w-full h-full">
      {/* Background circle with dark blue tint to create contrast */}
      <circle cx="150" cy="150" r="150" fill="#0D1117" />
      
      {/* Base yellow cat body with darker outline */}
      <path d="M150 260c35 0 65-20 65-80 0-35-25-70-65-70s-65 35-65 70c0 60 30 80 65 80z" fill="#FFD700" stroke="#E5A500" strokeWidth="2" />
      
      {/* Head - slightly wider and rounder than body */}
      <ellipse cx="150" cy="110" rx="70" ry="65" fill="#FFD700" stroke="#E5A500" strokeWidth="2" />
      
      {/* Shading and fur texture */}
      <path d="M150 175c35 0 65-25 65-65 0-40-30-65-65-65s-65 25-65 65c0 40 30 65 65 65z" fill="#FFDF30" />
      <path d="M130 60c-10 5-25 15-30 40M170 60c10 5 25 15 30 40" stroke="#E5A500" strokeWidth="2" fill="none" />
      
      {/* Ears */}
      <path d="M105 65l-15-30 25 15z" fill="#FFD700" stroke="#E5A500" strokeWidth="2" />
      <path d="M195 65l15-30-25 15z" fill="#FFD700" stroke="#E5A500" strokeWidth="2" />
      <path d="M110 65l-10-25 20 15z" fill="#00AAEE" stroke="#0088CC" strokeWidth="1" />
      <path d="M190 65l10-25-20 15z" fill="#00AAEE" stroke="#0088CC" strokeWidth="1" />
      
      {/* Eye area */}
      <ellipse cx="125" cy="110" rx="22" ry="20" fill="#FFD700" />
      <ellipse cx="175" cy="110" rx="22" ry="20" fill="#FFD700" />
      
      {/* Round glasses */}
      <circle cx="125" cy="110" r="20" fill="#222" stroke="#555" strokeWidth="3" />
      <circle cx="175" cy="110" r="20" fill="#222" stroke="#555" strokeWidth="3" />
      <line x1="145" y1="110" x2="155" y2="110" stroke="#555" strokeWidth="3" />
      
      {/* Glass lenses with amber tint */}
      <circle cx="125" cy="110" r="17" fill="#FFCC00" fillOpacity="0.3" />
      <circle cx="175" cy="110" r="17" fill="#FFCC00" fillOpacity="0.3" />
      
      {/* Eyes behind glasses */}
      <circle cx="125" cy="110" r="10" fill="#111" />
      <circle cx="175" cy="110" r="10" fill="#111" />
      <circle cx="122" cy="107" r="3" fill="#FFF" fillOpacity="0.7" />
      <circle cx="172" cy="107" r="3" fill="#FFF" fillOpacity="0.7" />
      
      {/* Tech headband with blue central element */}
      <path d="M95 75c20-15 90-15 110 0" stroke="#222" strokeWidth="8" fill="none" />
      <circle cx="150" cy="70" r="12" fill="#00AAEE" stroke="#0088CC" strokeWidth="1" />
      <circle cx="150" cy="70" r="6" fill="#0066FF" />
      <circle cx="100" cy="75" r="5" fill="#FFAA00" stroke="#E58800" strokeWidth="1" />
      <circle cx="200" cy="75" r="5" fill="#FFAA00" stroke="#E58800" strokeWidth="1" />
      
      {/* Cat face details */}
      <circle cx="150" cy="125" r="6" fill="#FF9999" stroke="#FF6666" strokeWidth="1" /> {/* Nose */}
      <path d="M135 135c5 5 25 5 30 0" stroke="#333" strokeWidth="1.5" fill="none" /> {/* Smile */}
      
      {/* Whiskers - made more visible */}
      <line x1="135" y1="127" x2="105" y2="120" stroke="#FFF" strokeWidth="1.5" />
      <line x1="135" y1="130" x2="105" y2="130" stroke="#FFF" strokeWidth="1.5" />
      <line x1="135" y1="133" x2="105" y2="140" stroke="#FFF" strokeWidth="1.5" />
      <line x1="165" y1="127" x2="195" y2="120" stroke="#FFF" strokeWidth="1.5" />
      <line x1="165" y1="130" x2="195" y2="130" stroke="#FFF" strokeWidth="1.5" />
      <line x1="165" y1="133" x2="195" y2="140" stroke="#FFF" strokeWidth="1.5" />
      
      {/* Black leather/vinyl jacket */}
      <path d="M120 150c-5 10-5 40 0 60h60c5-20 5-50 0-60z" fill="#222" stroke="#444" strokeWidth="2" />
      <path d="M120 150c0 10 0 30 5 55 l15-40 h20 l15 40 c5-25 5-45 5-55z" fill="#222" stroke="#444" />
      
      {/* Zipper */}
      <line x1="150" y1="150" x2="150" y2="210" stroke="#444" strokeWidth="2" />
      <circle cx="150" cy="150" r="2" fill="#888" />
      <circle cx="150" cy="210" r="2" fill="#888" />
      
      {/* Tech buttons and badges on jacket */}
      <circle cx="135" cy="165" r="10" fill="#FFD700" stroke="#E5A500" strokeWidth="1" />
      <circle cx="135" cy="165" r="6" fill="#00AAEE" />
      <circle cx="165" cy="165" r="10" fill="#00AAEE" stroke="#0088CC" strokeWidth="1" />
      <circle cx="165" cy="165" r="6" fill="#FFD700" />
      <circle cx="150" cy="190" r="12" fill="#00AAEE" stroke="#0088CC" strokeWidth="1" />
      <circle cx="150" cy="190" r="8" fill="#0066FF" />
      
      {/* Arms */}
      <path d="M110 170c-10 5-20 15-20 30s10 30 25 30" fill="#FFD700" stroke="#E5A500" strokeWidth="2" />
      <path d="M190 170c10 5 20 15 20 30s-10 30-25 30" fill="#FFD700" stroke="#E5A500" strokeWidth="2" />
      
      {/* Tech gauntlet on one arm, glove on other */}
      <circle cx="110" cy="225" r="10" fill="#222" stroke="#444" strokeWidth="1" />
      <circle cx="190" cy="225" r="10" fill="#00AAEE" stroke="#0088CC" strokeWidth="1" />
      <circle cx="190" cy="225" r="6" fill="#0066FF" />
      
      {/* Tail */}
      <path d="M120 230c-10 5-20 15-15 25s10 15 15 10" stroke="#FFD700" strokeWidth="15" fill="none" />
      <path d="M120 230c-10 5-20 15-15 25s10 15 15 10" stroke="#E5A500" strokeWidth="1" fill="none" />
      
      {/* Legs */}
      <rect x="135" y="210" width="15" height="30" fill="#222" stroke="#444" strokeWidth="1" />
      <rect x="150" y="210" width="15" height="30" fill="#222" stroke="#444" strokeWidth="1" />
      
      {/* Boots with orange/red details */}
      <path d="M130 240h25v12a5 5 0 0 1-5 5h-15a5 5 0 0 1-5-5z" fill="#222" stroke="#444" strokeWidth="1" />
      <path d="M145 240h25v12a5 5 0 0 1-5 5h-15a5 5 0 0 1-5-5z" fill="#222" stroke="#444" strokeWidth="1" />
      <rect x="130" y="240" width="25" height="4" fill="#FF5533" />
      <rect x="145" y="240" width="25" height="4" fill="#FF5533" />
    </svg>
  );
};

export default CodyImage;