import React from 'react';

// Nexus the Digital Fox SVG component
const NexusImage: React.FC = () => {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300" className="w-full h-full">
      {/* Background circle */}
      <circle cx="150" cy="150" r="150" fill="#0D1117" />
      
      {/* Base fox body with cyan/blue color scheme */}
      <path d="M150 260c35 0 65-20 65-80 0-35-25-70-65-70s-65 35-65 70c0 60 30 80 65 80z" fill="#00CCFF" stroke="#0099CC" strokeWidth="2" />
      
      {/* Head - slightly more angular than Cody's */}
      <path d="M150 175c35 0 65-25 65-65 0-40-30-65-65-65s-65 25-65 65c0 40 30 65 65 65z" fill="#00DDFF" stroke="#0099CC" strokeWidth="2" />
      
      {/* Shading and fur texture */}
      <path d="M130 60c-10 5-25 15-30 40M170 60c10 5 25 15 30 40" stroke="#0099CC" strokeWidth="2" fill="none" />
      
      {/* Pointed fox ears */}
      <path d="M100 70l-20-40 35 20z" fill="#00CCFF" stroke="#0099CC" strokeWidth="2" />
      <path d="M200 70l20-40-35 20z" fill="#00CCFF" stroke="#0099CC" strokeWidth="2" />
      <path d="M105 65l-15-30 25 15z" fill="#0066FF" stroke="#0055CC" strokeWidth="1" />
      <path d="M195 65l15-30-25 15z" fill="#0066FF" stroke="#0055CC" strokeWidth="1" />
      
      {/* Futuristic visor/glasses that cover eyes */}
      <path d="M105 95h90" stroke="#222" strokeWidth="3" fill="none" />
      <path d="M105 95v30a20 20 0 0 0 20 20h50a20 20 0 0 0 20-20v-30" fill="#222" stroke="#444" strokeWidth="2" />
      
      {/* Visor display elements */}
      <rect x="105" y="100" width="90" height="25" fill="#00FFFF" fillOpacity="0.3" />
      <path d="M110 105h80M110 110h80M110 115h80M110 120h80" stroke="#00FFFF" strokeWidth="1" strokeOpacity="0.5" />
      
      {/* Digital data visualization on visor */}
      <circle cx="120" cy="110" r="5" fill="#00FFFF" fillOpacity="0.7" />
      <circle cx="180" cy="110" r="5" fill="#00FFFF" fillOpacity="0.7" />
      <path d="M130 105l10 5-10 5M170 105l-10 5 10 5" stroke="#00FFFF" strokeWidth="1.5" fill="none" />
      <line x1="150" y1="105" x2="150" y2="120" stroke="#00FFFF" strokeWidth="1.5" />
      
      {/* Advanced tech elements on forehead */}
      <circle cx="150" cy="85" r="10" fill="#0066FF" stroke="#0055CC" strokeWidth="1" />
      <circle cx="150" cy="85" r="5" fill="#00FFFF" />
      <path d="M140 85h-15M160 85h15" stroke="#00FFFF" strokeWidth="1.5" />
      
      {/* Fox face details */}
      <path d="M145 135a5 5 0 0 0 10 0" fill="#222" /> {/* Nose */}
      <path d="M135 140c5 5 25 5 30 0" stroke="#0055CC" strokeWidth="1.5" fill="none" /> {/* Mouth */}
      
      {/* Holographic interface projected from shoulders */}
      <path d="M120 170a30 20 0 0 0 60 0" fill="#00FFFF" fillOpacity="0.2" stroke="#00FFFF" strokeWidth="1" strokeDasharray="5,2" />
      <path d="M130 160v20M140 160v20M150 160v20M160 160v20M170 160v20" stroke="#00FFFF" strokeWidth="1" strokeDasharray="3,3" />
      <path d="M125 165h50M125 175h50" stroke="#00FFFF" strokeWidth="1" />
      
      {/* Tech bodysuit design */}
      <path d="M120 150c-5 10-5 40 0 60h60c5-20 5-50 0-60z" fill="#005588" stroke="#0099CC" strokeWidth="2" />
      <path d="M120 150c0 10 0 30 5 55 l15-40 h20 l15 40 c5-25 5-45 5-55z" fill="#006699" stroke="#0099CC" />
      
      {/* Circuit patterns on suit */}
      <path d="M130 160h40M130 180h40M130 200h40" stroke="#00FFFF" strokeWidth="1" strokeDasharray="5,3" />
      <path d="M135 150v60M150 150v60M165 150v60" stroke="#00FFFF" strokeWidth="1" strokeDasharray="5,3" />
      
      {/* Energy core in center of chest */}
      <circle cx="150" cy="180" r="10" fill="#0066FF" stroke="#00FFFF" strokeWidth="1" />
      <circle cx="150" cy="180" r="5" fill="#FFFFFF" />
      
      {/* Tech elements at shoulders */}
      <circle cx="125" cy="160" r="5" fill="#00FFFF" />
      <circle cx="175" cy="160" r="5" fill="#00FFFF" />
      
      {/* Arms with tech gauntlets */}
      <path d="M110 170c-10 5-20 15-20 30s10 30 25 30" fill="#00CCFF" stroke="#0099CC" strokeWidth="2" />
      <path d="M190 170c10 5 20 15 20 30s-10 30-25 30" fill="#00CCFF" stroke="#0099CC" strokeWidth="2" />
      
      {/* Tech gauntlets on arms */}
      <path d="M110 220a10 10 0 0 0 10 10a10 10 0 0 0-10 10" fill="#005588" stroke="#0099CC" strokeWidth="1" />
      <path d="M190 220a10 10 0 0 1-10 10a10 10 0 0 1 10 10" fill="#005588" stroke="#0099CC" strokeWidth="1" />
      <circle cx="110" cy="225" r="5" fill="#00FFFF" />
      <circle cx="190" cy="225" r="5" fill="#00FFFF" />
      
      {/* Fox tail with energy effect */}
      <path d="M150 235c-10 5-40 10-35 30s20 10 25 5" stroke="#00CCFF" strokeWidth="15" fill="none" />
      <path d="M150 235c-10 5-40 10-35 30s20 10 25 5" stroke="#00FFFF" strokeWidth="1" strokeDasharray="5,5" fill="none" />
      
      {/* Tech boots */}
      <path d="M135 210h-15v30a5 5 0 0 0 5 5h10a5 5 0 0 0 5-5v-30z" fill="#005588" stroke="#0099CC" strokeWidth="1" />
      <path d="M165 210h15v30a5 5 0 0 1-5 5h-10a5 5 0 0 1-5-5v-30z" fill="#005588" stroke="#0099CC" strokeWidth="1" />
      <rect x="120" y="235" width="15" height="3" fill="#00FFFF" />
      <rect x="165" y="235" width="15" height="3" fill="#00FFFF" />
    </svg>
  );
};

export default NexusImage;