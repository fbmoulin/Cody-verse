import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Brain, 
  Clock, 
  Zap, 
  Target, 
  CheckCircle2, 
  ArrowRight,
  RotateCcw,
  Lightbulb,
  Code,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Star,
  Award,
  Timer,
  Flame
} from "lucide-react";

interface MicroLesson {
  id: string;
  title: string;
  type: 'concept' | 'practice' | 'quiz' | 'challenge';
  estimatedTime: number; // in seconds
  difficulty: 'easy' | 'medium' | 'hard';
  prerequisite?: string;
  content: {
    introduction: string;
    keyPoint: string;
    explanation: string;
    example?: string;
    codeSnippet?: string;
  };
  interaction: {
    type: 'single-choice' | 'multiple-choice' | 'code-fill' | 'drag-drop' | 'reflection';
    question: string;
    options?: string[];
    correct?: number | number[];
    feedback: {
      correct: string;
      incorrect: string;
      hint: string;
    };
  };
  spacedRepetition: {
    interval: number; // days until next review
    easeFactor: number; // how easy/hard user finds this
    reviewCount: number;
    lastReview?: Date;
    nextReview?: Date;
  };
}

interface LearningSession {
  targetTime: number; // minutes
  focusMode: boolean;
  adaptiveDifficulty: boolean;
  personalizedPath: boolean;
}

// Micro-Learning System Component
export function MicroLearningSystem({ 
  moduleId, 
  onComplete 
}: { 
  moduleId: string; 
  onComplete: (xp: number, time: number) => void;
}) {
  const [currentLesson, setCurrentLesson] = useState(0);
  const [sessionTime, setSessionTime] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [userAnswer, setUserAnswer] = useState<string | number | number[]>("");
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [sessionConfig, setSessionConfig] = useState<LearningSession>({
    targetTime: 15,
    focusMode: false,
    adaptiveDifficulty: true,
    personalizedPath: true
  });
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(new Set());
  const [streakCount, setStreakCount] = useState(0);
  const [xpEarned, setXpEarned] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const timerRef = useRef<NodeJS.Timeout>();
  const audioRef = useRef<HTMLAudioElement>();

  // Sample micro-lessons with spaced repetition data
  const microLessons: MicroLesson[] = [
    {
      id: "mcp-intro-1",
      title: "O que é MCP?",
      type: "concept",
      estimatedTime: 90,
      difficulty: "easy",
      content: {
        introduction: "Model Context Protocol (MCP) revoluciona como aplicações de IA se comunicam com fontes de dados.",
        keyPoint: "MCP é um protocolo aberto para comunicação padronizada",
        explanation: "Permite que qualquer aplicação de IA acesse dados de forma segura e consistente, eliminando integrações personalizadas complexas.",
        example: "Como um tradutor universal entre sua IA e qualquer banco de dados, API ou sistema de arquivos."
      },
      interaction: {
        type: "single-choice",
        question: "Qual é o principal benefício do MCP?",
        options: [
          "Padronização da comunicação entre IA e dados",
          "Redução do custo de hardware",
          "Melhoria da velocidade de processamento",
          "Interface gráfica mais bonita"
        ],
        correct: 0,
        feedback: {
          correct: "Exato! MCP padroniza como aplicações de IA acessam diferentes fontes de dados.",
          incorrect: "Não exatamente. O MCP foca na padronização da comunicação, não em aspectos técnicos específicos.",
          hint: "Pense no problema que o MCP resolve: cada fonte de dados tinha sua própria forma de integração."
        }
      },
      spacedRepetition: {
        interval: 1,
        easeFactor: 2.5,
        reviewCount: 0
      }
    },
    {
      id: "mcp-architecture-1",
      title: "Arquitetura Cliente-Servidor",
      type: "concept",
      estimatedTime: 120,
      difficulty: "medium",
      prerequisite: "mcp-intro-1",
      content: {
        introduction: "O MCP usa uma arquitetura cliente-servidor simples mas poderosa.",
        keyPoint: "Cliente (IA) conecta-se a Servidores (fontes de dados) via protocolo padronizado",
        explanation: "O cliente representa sua aplicação de IA (Claude, ChatGPT, etc.). O servidor MCP expõe recursos específicos (arquivos, APIs, bancos de dados).",
        codeSnippet: `// Cliente MCP básico
const client = new Client({
  name: "minha-ia",
  version: "1.0.0"
});

await client.connect(transport);`
      },
      interaction: {
        type: "drag-drop",
        question: "Organize o fluxo de comunicação MCP:",
        options: ["Cliente (IA)", "Protocolo MCP", "Servidor MCP", "Fonte de Dados"],
        correct: [0, 1, 2, 3],
        feedback: {
          correct: "Perfeito! O fluxo vai da IA através do protocolo para o servidor e depois para os dados.",
          incorrect: "Quase lá! Lembre-se: IA → Protocolo → Servidor → Dados",
          hint: "Comece com quem faz a solicitação (IA) e termine com onde estão os dados."
        }
      },
      spacedRepetition: {
        interval: 1,
        easeFactor: 2.5,
        reviewCount: 0
      }
    },
    {
      id: "mcp-implementation-1",
      title: "Implementando um Servidor",
      type: "practice",
      estimatedTime: 180,
      difficulty: "hard",
      prerequisite: "mcp-architecture-1",
      content: {
        introduction: "Vamos implementar um servidor MCP funcional.",
        keyPoint: "Servidores MCP expõem capabilities: resources, tools e prompts",
        explanation: "Cada capability permite diferentes tipos de interação. Resources para dados, tools para ações, prompts para templates.",
        codeSnippet: `import { Server } from '@modelcontextprotocol/sdk/server/index.js';

const server = new Server({
  name: "file-server",
  version: "1.0.0"
}, {
  capabilities: {
    resources: {}
  }
});`
      },
      interaction: {
        type: "code-fill",
        question: "Complete o código para listar recursos:",
        options: [
          "server.setRequestHandler(ListResourcesRequestSchema, async () => {",
          "  const files = await fs.readdir('./');",
          "  return { resources: files.map(file => ({ uri: `file://${file}`, name: file })) };",
          "});"
        ],
        feedback: {
          correct: "Excelente! Você implementou corretamente um handler de recursos MCP.",
          incorrect: "Revise a estrutura do handler. Lembre-se: schema, função async, retorno com resources.",
          hint: "Use ListResourcesRequestSchema e retorne um objeto com array 'resources'."
        }
      },
      spacedRepetition: {
        interval: 1,
        easeFactor: 2.5,
        reviewCount: 0
      }
    }
  ];

  const currentLessonData = microLessons[currentLesson];

  // Timer management
  useEffect(() => {
    if (isActive) {
      timerRef.current = setInterval(() => {
        setSessionTime(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive]);

  // Auto-start session
  useEffect(() => {
    setIsActive(true);
  }, []);

  // Spaced repetition algorithm
  const calculateNextReview = (lesson: MicroLesson, quality: number) => {
    const { interval, easeFactor, reviewCount } = lesson.spacedRepetition;
    
    let newInterval: number;
    let newEaseFactor = easeFactor;
    
    if (quality >= 3) {
      if (reviewCount === 0) {
        newInterval = 1;
      } else if (reviewCount === 1) {
        newInterval = 6;
      } else {
        newInterval = Math.round(interval * easeFactor);
      }
      newEaseFactor = easeFactor + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
    } else {
      newInterval = 1;
      newEaseFactor = Math.max(1.3, easeFactor - 0.2);
    }
    
    return {
      interval: newInterval,
      easeFactor: Math.max(1.3, newEaseFactor),
      reviewCount: reviewCount + 1,
      lastReview: new Date(),
      nextReview: new Date(Date.now() + newInterval * 24 * 60 * 60 * 1000)
    };
  };

  // Handle answer submission
  const handleAnswerSubmit = () => {
    const lesson = currentLessonData;
    let correct = false;
    
    if (lesson.interaction.type === "single-choice") {
      correct = userAnswer === lesson.interaction.correct;
    } else if (lesson.interaction.type === "multiple-choice") {
      const correctAnswers = lesson.interaction.correct as number[];
      const userAnswers = userAnswer as number[];
      correct = correctAnswers.length === userAnswers.length && 
                correctAnswers.every(a => userAnswers.includes(a));
    }
    
    setIsCorrect(correct);
    setShowFeedback(true);
    
    // Update spaced repetition data
    const quality = correct ? 4 : 2; // Simplified quality assessment
    const updatedSpacedRepetition = calculateNextReview(lesson, quality);
    
    // Award XP based on difficulty and correctness
    const baseXP = lesson.difficulty === 'easy' ? 10 : lesson.difficulty === 'medium' ? 15 : 20;
    const xpMultiplier = correct ? 1 : 0.5;
    const earnedXP = Math.round(baseXP * xpMultiplier);
    
    setXpEarned(prev => prev + earnedXP);
    
    if (correct) {
      setStreakCount(prev => prev + 1);
      setCompletedLessons(prev => new Set(prev).add(lesson.id));
    }
    
    // Play sound feedback
    if (soundEnabled) {
      playFeedbackSound(correct);
    }
  };

  const playFeedbackSound = (success: boolean) => {
    // In a real app, you'd play actual audio files
    console.log(success ? "🎉 Success sound!" : "❌ Try again sound!");
  };

  const handleNextLesson = () => {
    setShowFeedback(false);
    setUserAnswer("");
    
    if (currentLesson < microLessons.length - 1) {
      setCurrentLesson(prev => prev + 1);
    } else {
      // Session complete
      setIsActive(false);
      onComplete(xpEarned, sessionTime);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = ((currentLesson + 1) / microLessons.length) * 100;
  const estimatedTimeRemaining = microLessons.slice(currentLesson + 1).reduce((sum, lesson) => sum + lesson.estimatedTime, 0);

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Session Header */}
      <Card className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-blue-500" />
              <span className="font-mono text-lg">{formatTime(sessionTime)}</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <Flame className="h-5 w-5 text-orange-500" />
              <span className="font-bold">{streakCount}</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <Zap className="h-5 w-5 text-yellow-500" />
              <span className="font-bold">{xpEarned} XP</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSoundEnabled(!soundEnabled)}
            >
              {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsActive(!isActive)}
            >
              {isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </Button>
          </div>
        </div>
        
        <div className="mt-4">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Lição {currentLesson + 1} de {microLessons.length}</span>
            <span>~{Math.round(estimatedTimeRemaining / 60)}min restantes</span>
          </div>
          <Progress value={progressPercentage} className="h-2" />
        </div>
      </Card>

      {/* Lesson Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentLesson}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="p-8">
            <div className="space-y-6">
              {/* Lesson Header */}
              <div className="text-center">
                <Badge className={`mb-4 ${
                  currentLessonData.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                  currentLessonData.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {currentLessonData.difficulty === 'easy' ? 'Fácil' :
                   currentLessonData.difficulty === 'medium' ? 'Médio' : 'Difícil'}
                </Badge>
                
                <h2 className="text-3xl font-bold mb-4">{currentLessonData.title}</h2>
                
                <div className="flex items-center justify-center space-x-4 text-sm text-gray-500">
                  <span className="flex items-center">
                    <Timer className="mr-1 h-4 w-4" />
                    ~{Math.round(currentLessonData.estimatedTime / 60)}min
                  </span>
                  <span className="flex items-center">
                    <Brain className="mr-1 h-4 w-4" />
                    {currentLessonData.type === 'concept' ? 'Conceito' :
                     currentLessonData.type === 'practice' ? 'Prática' : 'Quiz'}
                  </span>
                </div>
              </div>

              {/* Content Sections */}
              <div className="space-y-6">
                <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                  <h3 className="font-bold text-lg mb-3 flex items-center">
                    <Lightbulb className="mr-2 h-5 w-5 text-blue-500" />
                    Introdução
                  </h3>
                  <p className="text-gray-700">{currentLessonData.content.introduction}</p>
                </div>

                <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                  <h3 className="font-bold text-lg mb-3 flex items-center">
                    <Target className="mr-2 h-5 w-5 text-green-500" />
                    Ponto-Chave
                  </h3>
                  <p className="text-green-800 font-medium">{currentLessonData.content.keyPoint}</p>
                </div>

                <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
                  <h3 className="font-bold text-lg mb-3">Explicação Detalhada</h3>
                  <p className="text-gray-700 mb-4">{currentLessonData.content.explanation}</p>
                  
                  {currentLessonData.content.example && (
                    <div className="bg-white p-4 rounded border-l-4 border-purple-400">
                      <p className="text-sm font-medium text-purple-700">Exemplo:</p>
                      <p className="text-gray-600 italic">{currentLessonData.content.example}</p>
                    </div>
                  )}
                </div>

                {currentLessonData.content.codeSnippet && (
                  <div className="bg-gray-900 p-6 rounded-lg">
                    <h3 className="font-bold text-lg mb-3 text-white flex items-center">
                      <Code className="mr-2 h-5 w-5" />
                      Código de Exemplo
                    </h3>
                    <pre className="text-green-400 text-sm overflow-x-auto">
                      <code>{currentLessonData.content.codeSnippet}</code>
                    </pre>
                  </div>
                )}
              </div>

              {/* Interactive Question */}
              {!showFeedback && (
                <div className="bg-yellow-50 p-6 rounded-lg border border-yellow-200">
                  <h3 className="font-bold text-lg mb-4 flex items-center">
                    <Brain className="mr-2 h-5 w-5 text-yellow-600" />
                    {currentLessonData.interaction.question}
                  </h3>
                  
                  {currentLessonData.interaction.type === 'single-choice' && (
                    <div className="space-y-3">
                      {currentLessonData.interaction.options?.map((option, index) => (
                        <label key={index} className="flex items-center space-x-3 cursor-pointer">
                          <input
                            type="radio"
                            name="answer"
                            value={index}
                            onChange={(e) => setUserAnswer(parseInt(e.target.value))}
                            className="text-yellow-600"
                          />
                          <span>{option}</span>
                        </label>
                      ))}
                    </div>
                  )}
                  
                  <Button 
                    onClick={handleAnswerSubmit}
                    disabled={userAnswer === ""}
                    className="mt-4 bg-yellow-600 hover:bg-yellow-700"
                  >
                    Verificar Resposta
                  </Button>
                </div>
              )}

              {/* Feedback */}
              {showFeedback && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`p-6 rounded-lg border ${
                    isCorrect 
                      ? 'bg-green-50 border-green-200' 
                      : 'bg-red-50 border-red-200'
                  }`}
                >
                  <div className="flex items-center space-x-3 mb-4">
                    {isCorrect ? (
                      <>
                        <CheckCircle2 className="h-6 w-6 text-green-500" />
                        <h3 className="font-bold text-lg text-green-800">Correto!</h3>
                      </>
                    ) : (
                      <>
                        <RotateCcw className="h-6 w-6 text-red-500" />
                        <h3 className="font-bold text-lg text-red-800">Tente Novamente</h3>
                      </>
                    )}
                  </div>
                  
                  <p className="mb-4">
                    {isCorrect 
                      ? currentLessonData.interaction.feedback.correct
                      : currentLessonData.interaction.feedback.incorrect
                    }
                  </p>
                  
                  {!isCorrect && (
                    <div className="bg-blue-100 p-4 rounded-lg mb-4">
                      <p className="text-sm text-blue-800">
                        💡 Dica: {currentLessonData.interaction.feedback.hint}
                      </p>
                    </div>
                  )}
                  
                  <Button onClick={handleNextLesson} className="w-full">
                    {currentLesson < microLessons.length - 1 ? 'Próxima Lição' : 'Finalizar Sessão'}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </motion.div>
              )}
            </div>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}