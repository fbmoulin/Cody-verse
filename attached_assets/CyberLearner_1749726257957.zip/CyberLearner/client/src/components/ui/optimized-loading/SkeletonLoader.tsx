import React from 'react';

interface SkeletonLoaderProps {
  className?: string;
  variant?: 'card' | 'text' | 'circle' | 'button' | 'module';
  width?: number | string;
  height?: number | string;
  count?: number;
}

/**
 * Skeleton loader component with cyberpunk styling
 * Creates placeholder UI elements that animate while content is loading
 */
const SkeletonLoader: React.FC<SkeletonLoaderProps> = ({
  className = '',
  variant = 'text',
  width,
  height,
  count = 1
}) => {
  // Basic style based on variant
  const getBaseStyle = () => {
    switch (variant) {
      case 'card':
        return 'rounded-lg w-full h-32';
      case 'text':
        return 'h-4 w-full rounded';
      case 'circle':
        return 'rounded-full w-12 h-12';
      case 'button':
        return 'h-9 w-24 rounded-md';
      case 'module':
        return 'h-36 w-full rounded-lg';
      default:
        return 'h-4 w-full rounded';
    }
  };

  // Custom neon pulse animation - cyberpunk-styled loading effect
  const getAnimationStyle = () => {
    return `
      bg-gradient-to-r from-gray-800 via-gray-700 to-gray-800 
      bg-[length:400%_100%] 
      animate-pulse
      relative
      overflow-hidden
      after:absolute
      after:inset-0
      after:bg-gradient-to-r
      after:from-transparent
      after:via-primary/10
      after:to-transparent
      after:animate-shimmer
    `;
  };

  // Generate multiple skeletons if count > 1
  const renderSkeletons = () => {
    return Array.from({ length: count }).map((_, index) => (
      <div
        key={index}
        className={`${getBaseStyle()} ${getAnimationStyle()} ${className}`}
        style={{ width, height }}
        aria-hidden="true"
        role="presentation"
      />
    ));
  };

  return (
    <div className={count > 1 ? 'space-y-2' : ''}>
      {renderSkeletons()}
    </div>
  );
};

export default React.memo(SkeletonLoader);