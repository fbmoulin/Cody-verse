import React, { Component, ReactNode } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class InteractiveErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Interactive component error:', error, errorInfo);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: undefined });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <Card className="border-red-700 bg-red-900/20 shadow-md">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-red-400 flex items-center">
              <AlertTriangle className="mr-2 h-5 w-5" />
              Interactive Component Error
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-red-300">
              Something went wrong with this interactive component. This shouldn't affect other parts of the learning module.
            </p>
            {this.state.error && (
              <details className="text-xs text-red-400 bg-red-900/30 p-2 rounded">
                <summary className="cursor-pointer">Technical Details</summary>
                <pre className="mt-2 overflow-auto">{this.state.error.message}</pre>
              </details>
            )}
            <Button
              onClick={this.handleReset}
              variant="outline"
              className="border-red-600 text-red-400 hover:bg-red-900/20"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Try Again
            </Button>
          </CardContent>
        </Card>
      );
    }

    return this.props.children;
  }
}