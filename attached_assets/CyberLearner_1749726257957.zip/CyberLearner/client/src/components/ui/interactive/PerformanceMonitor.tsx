import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, Zap, Clock } from 'lucide-react';

interface PerformanceMetrics {
  renderTime: number;
  interactionCount: number;
  lastInteraction: number;
  componentLoad: number;
}

interface PerformanceMonitorProps {
  componentName: string;
  children: React.ReactNode;
  showMetrics?: boolean;
}

export function PerformanceMonitor({ 
  componentName, 
  children, 
  showMetrics = false 
}: PerformanceMonitorProps) {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    renderTime: 0,
    interactionCount: 0,
    lastInteraction: 0,
    componentLoad: Date.now()
  });

  useEffect(() => {
    const startTime = performance.now();
    
    const measureRender = () => {
      const endTime = performance.now();
      setMetrics(prev => ({
        ...prev,
        renderTime: endTime - startTime
      }));
    };

    // Use requestAnimationFrame to measure after DOM updates
    requestAnimationFrame(measureRender);
  }, []);

  const trackInteraction = () => {
    setMetrics(prev => ({
      ...prev,
      interactionCount: prev.interactionCount + 1,
      lastInteraction: Date.now()
    }));
  };

  const getPerformanceColor = (time: number) => {
    if (time < 16) return 'text-green-400';
    if (time < 33) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div onClick={trackInteraction} onKeyDown={trackInteraction}>
      {children}
      
      {showMetrics && (
        <Card className="mt-2 border-gray-700 bg-gray-800/30 text-xs">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400 flex items-center">
              <Activity className="mr-1 h-3 w-3" />
              {componentName} Performance
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-3 gap-2">
              <div className="flex items-center">
                <Clock className="mr-1 h-3 w-3 text-gray-500" />
                <span className={getPerformanceColor(metrics.renderTime)}>
                  {metrics.renderTime.toFixed(1)}ms
                </span>
              </div>
              <div className="flex items-center">
                <Zap className="mr-1 h-3 w-3 text-gray-500" />
                <Badge variant="secondary" className="text-xs">
                  {metrics.interactionCount} interactions
                </Badge>
              </div>
              <div className="text-gray-500">
                Load: {((Date.now() - metrics.componentLoad) / 1000).toFixed(1)}s
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}