import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Activity, Bug, Settings, TrendingUp, AlertTriangle } from 'lucide-react';

interface DebugEvent {
  id: string;
  timestamp: number;
  component: string;
  type: 'interaction' | 'error' | 'performance' | 'render';
  data: any;
  severity: 'low' | 'medium' | 'high';
}

interface ComponentMetrics {
  name: string;
  renderCount: number;
  lastRenderTime: number;
  averageRenderTime: number;
  errorCount: number;
  interactionCount: number;
}

export function DebugDashboard() {
  const [isVisible, setIsVisible] = useState(false);
  const [events, setEvents] = useState<DebugEvent[]>([]);
  const [metrics, setMetrics] = useState<ComponentMetrics[]>([]);
  const [autoScroll, setAutoScroll] = useState(true);

  // Global debug event listener
  useEffect(() => {
    const handleDebugEvent = (event: CustomEvent<DebugEvent>) => {
      setEvents(prev => {
        const newEvents = [event.detail, ...prev].slice(0, 100); // Keep last 100 events
        return newEvents;
      });

      // Update component metrics
      setMetrics(prev => {
        const componentName = event.detail.component;
        const existing = prev.find(m => m.name === componentName);
        
        if (existing) {
          return prev.map(m => 
            m.name === componentName 
              ? {
                  ...m,
                  renderCount: event.detail.type === 'render' ? m.renderCount + 1 : m.renderCount,
                  errorCount: event.detail.type === 'error' ? m.errorCount + 1 : m.errorCount,
                  interactionCount: event.detail.type === 'interaction' ? m.interactionCount + 1 : m.interactionCount,
                  lastRenderTime: event.detail.type === 'performance' ? event.detail.data.renderTime : m.lastRenderTime,
                  averageRenderTime: event.detail.type === 'performance' 
                    ? (m.averageRenderTime + event.detail.data.renderTime) / 2 
                    : m.averageRenderTime
                }
              : m
          );
        } else {
          return [...prev, {
            name: componentName,
            renderCount: event.detail.type === 'render' ? 1 : 0,
            errorCount: event.detail.type === 'error' ? 1 : 0,
            interactionCount: event.detail.type === 'interaction' ? 1 : 0,
            lastRenderTime: event.detail.type === 'performance' ? event.detail.data.renderTime : 0,
            averageRenderTime: event.detail.type === 'performance' ? event.detail.data.renderTime : 0
          }];
        }
      });
    };

    window.addEventListener('debug-event', handleDebugEvent as EventListener);
    return () => window.removeEventListener('debug-event', handleDebugEvent as EventListener);
  }, []);

  const clearEvents = () => setEvents([]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-400 bg-red-900/20';
      case 'medium': return 'text-yellow-400 bg-yellow-900/20';
      default: return 'text-green-400 bg-green-900/20';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'error': return <AlertTriangle className="h-3 w-3" />;
      case 'performance': return <TrendingUp className="h-3 w-3" />;
      case 'interaction': return <Activity className="h-3 w-3" />;
      default: return <Bug className="h-3 w-3" />;
    }
  };

  if (!isVisible) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={() => setIsVisible(true)}
          size="sm"
          variant="outline"
          className="bg-gray-900/80 border-gray-700 text-gray-300 hover:bg-gray-800"
        >
          <Bug className="h-4 w-4 mr-1" />
          Debug
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 w-96 max-h-96">
      <Card className="border-gray-700 bg-gray-900/95 backdrop-blur-sm shadow-xl">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm text-blue-400 flex items-center">
              <Bug className="mr-2 h-4 w-4" />
              Debug Dashboard
            </CardTitle>
            <Button
              onClick={() => setIsVisible(false)}
              size="sm"
              variant="ghost"
              className="h-6 w-6 p-0 text-gray-400 hover:text-gray-200"
            >
              ×
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-4 pt-0">
          <Tabs defaultValue="events" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800">
              <TabsTrigger value="events" className="text-xs">Events</TabsTrigger>
              <TabsTrigger value="metrics" className="text-xs">Metrics</TabsTrigger>
              <TabsTrigger value="settings" className="text-xs">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="events" className="mt-2">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Badge variant="secondary" className="text-xs">
                    {events.length} events
                  </Badge>
                  <Button onClick={clearEvents} size="sm" variant="ghost" className="text-xs h-6">
                    Clear
                  </Button>
                </div>
                
                <div className="max-h-48 overflow-y-auto space-y-1">
                  {events.map(event => (
                    <div
                      key={event.id}
                      className={`p-2 rounded text-xs border ${getSeverityColor(event.severity)}`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1">
                          {getTypeIcon(event.type)}
                          <span className="font-medium">{event.component}</span>
                        </div>
                        <span className="text-xs opacity-60">
                          {new Date(event.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="text-xs opacity-80">
                        {event.type}: {JSON.stringify(event.data).slice(0, 50)}...
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="metrics" className="mt-2">
              <div className="space-y-2">
                {metrics.map(metric => (
                  <div key={metric.name} className="p-2 bg-gray-800/50 rounded text-xs">
                    <div className="font-medium text-gray-200 mb-1">{metric.name}</div>
                    <div className="grid grid-cols-2 gap-1 text-xs text-gray-400">
                      <div>Renders: {metric.renderCount}</div>
                      <div>Errors: {metric.errorCount}</div>
                      <div>Interactions: {metric.interactionCount}</div>
                      <div>Avg: {metric.averageRenderTime.toFixed(1)}ms</div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="settings" className="mt-2">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs text-gray-300">Auto-scroll events</label>
                  <Switch
                    checked={autoScroll}
                    onCheckedChange={setAutoScroll}
                    className="scale-75"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <label className="text-xs text-gray-300">Performance monitoring</label>
                  <Switch defaultChecked className="scale-75" />
                </div>
                <div className="flex items-center justify-between">
                  <label className="text-xs text-gray-300">Error tracking</label>
                  <Switch defaultChecked className="scale-75" />
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}

// Global debug event dispatcher
export const emitDebugEvent = (
  component: string,
  type: 'interaction' | 'error' | 'performance' | 'render',
  data: any,
  severity: 'low' | 'medium' | 'high' = 'low'
) => {
  const event = new CustomEvent('debug-event', {
    detail: {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      component,
      type,
      data,
      severity
    }
  });
  window.dispatchEvent(event);
};