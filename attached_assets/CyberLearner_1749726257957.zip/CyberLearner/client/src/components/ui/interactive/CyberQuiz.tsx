import React, { useState, useCallback, useMemo, memo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { CheckCircle, XCircle, RefreshCw, Target, TrendingUp } from 'lucide-react';
import { useOptimizedState, usePersistedState } from '@/hooks/use-optimized-state';
import { perf } from '@/lib/performance';

export interface QuizOption {
  id: string;
  text: string;
  isCorrect: boolean;
}

export interface QuizQuestion {
  question: string;
  options: QuizOption[];
  explanation: string;
}

interface CyberQuizProps {
  question: QuizQuestion;
  onComplete?: (wasCorrect: boolean) => void;
}

const CyberQuiz = memo(function CyberQuiz({ question, onComplete }: CyberQuizProps) {
  const [selectedOption, setSelectedOption] = useOptimizedState<string | null>(null, 'CyberQuiz');
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [quizStats, setQuizStats] = usePersistedState('quiz-stats', { totalAttempts: 0, correctAnswers: 0 });
  
  // Memoized calculations
  const successRate = useMemo(() => {
    if (quizStats.totalAttempts === 0) return 0;
    return Math.round((quizStats.correctAnswers / quizStats.totalAttempts) * 100);
  }, [quizStats]);

  const difficultyLevel = useMemo(() => {
    const optionCount = question.options.length;
    if (optionCount <= 2) return 'Easy';
    if (optionCount <= 3) return 'Medium';
    return 'Hard';
  }, [question.options.length]);
  
  const handleOptionSelect = useCallback((optionId: string) => {
    if (!isAnswered) {
      setSelectedOption(optionId);
      perf.measureRender('QuizOptionSelect', () => {});
    }
  }, [isAnswered, setSelectedOption]);
  
  const handleCheck = useCallback(() => {
    if (!selectedOption) return;
    
    const selectedOpt = question.options.find(opt => opt.id === selectedOption);
    if (selectedOpt) {
      const correct = selectedOpt.isCorrect;
      setIsCorrect(correct);
      setIsAnswered(true);
      setAttempts(prev => prev + 1);
      setShowExplanation(true);
      
      // Update global quiz statistics
      setQuizStats(prev => ({
        totalAttempts: prev.totalAttempts + 1,
        correctAnswers: prev.correctAnswers + (correct ? 1 : 0)
      }));
      
      if (onComplete) {
        onComplete(correct);
      }
    }
  }, [selectedOption, question.options, onComplete, setQuizStats]);
  
  const handleReset = useCallback(() => {
    setSelectedOption(null);
    setIsAnswered(false);
    setIsCorrect(false);
    setShowExplanation(false);
  }, [setSelectedOption]);
  
  return (
    <Card className="border-gray-700 bg-gray-900/60 shadow-md">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg text-blue-400 flex items-center gap-2">
              <Target className="h-5 w-5" />
              Quiz Challenge
            </CardTitle>
            <CardDescription className="text-gray-300">Test your knowledge</CardDescription>
          </div>
          <div className="text-right text-xs text-gray-400 space-y-1">
            <div className="flex items-center gap-1">
              <TrendingUp className="h-3 w-3" />
              {difficultyLevel}
            </div>
            {attempts > 0 && <div>Attempts: {attempts}</div>}
            {successRate > 0 && <div>Success: {successRate}%</div>}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-white font-medium">{question.question}</p>
        
        <div className="space-y-2">
          {question.options.map((option, index) => (
            <div
              key={option.id}
              onClick={() => handleOptionSelect(option.id)}
              className={`p-3 rounded-md border flex items-center transition-all duration-200 cursor-pointer ${
                isAnswered 
                  ? option.isCorrect
                    ? "border-green-500 bg-green-900/20 text-green-300 shadow-lg shadow-green-900/20"
                    : selectedOption === option.id
                      ? "border-red-500 bg-red-900/20 text-red-300"
                      : "border-gray-700 bg-gray-800/50 text-gray-400"
                  : selectedOption === option.id
                    ? "border-blue-500 bg-blue-900/20 text-blue-300 shadow-lg shadow-blue-900/20"
                    : "border-gray-700 bg-gray-800/50 text-gray-200 hover:bg-gray-800 hover:border-gray-600 hover:shadow-md"
              }`}
            >
              <div className="flex items-center w-full">
                <div className="w-6 h-6 rounded-full border border-current flex items-center justify-center mr-3 text-xs font-medium">
                  {String.fromCharCode(65 + index)}
                </div>
                <span className="flex-grow">{option.text}</span>
                {isAnswered && option.isCorrect && (
                  <CheckCircle className="h-5 w-5 text-green-500 ml-2" />
                )}
                {isAnswered && !option.isCorrect && selectedOption === option.id && (
                  <XCircle className="h-5 w-5 text-red-500 ml-2" />
                )}
              </div>
            </div>
          ))}
        </div>
        
        {showExplanation && (
          <div className={`p-4 rounded-md border transition-all duration-300 ${
            isCorrect 
              ? "bg-green-900/20 border-green-700 text-green-300"
              : "bg-red-900/20 border-red-700 text-red-300"
          }`}>
            <div className="flex items-center mb-2">
              {isCorrect ? (
                <CheckCircle className="h-5 w-5 mr-2" />
              ) : (
                <XCircle className="h-5 w-5 mr-2" />
              )}
              <div className="font-medium">
                {isCorrect ? "Excellent!" : "Not quite right"}
              </div>
            </div>
            <div className="text-sm leading-relaxed">{question.explanation}</div>
            {isCorrect && attempts === 1 && (
              <div className="mt-2 text-xs opacity-80">Perfect! You got it on your first try!</div>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter>
        {!isAnswered ? (
          <Button 
            onClick={handleCheck}
            disabled={!selectedOption}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            Check Answer
          </Button>
        ) : (
          <Button 
            onClick={handleReset}
            variant="outline"
            className="w-full border-blue-600 text-blue-400 hover:bg-blue-900/20"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Try Again
          </Button>
        )}
      </CardFooter>
    </Card>
  );
});

export default CyberQuiz;
export { CyberQuiz };