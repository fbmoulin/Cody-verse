import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, RotateCcw, Move } from 'lucide-react';

export interface DragItem {
  id: string;
  content: string;
  category: string;
}

export interface DropZone {
  id: string;
  title: string;
  acceptedCategories: string[];
  correctItems: string[];
}

interface CyberDragDropProps {
  title?: string;
  description?: string;
  items: DragItem[];
  dropZones: DropZone[];
  onComplete?: (isCorrect: boolean, score: number) => void;
}

export function CyberDragDrop({
  title = "Drag & Drop Challenge",
  description = "Drag items to their correct categories",
  items,
  dropZones,
  onComplete
}: CyberDragDropProps) {
  const [draggedItem, setDraggedItem] = useState<string | null>(null);
  const [droppedItems, setDroppedItems] = useState<Record<string, string[]>>({});
  const [isCompleted, setIsCompleted] = useState(false);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<Record<string, 'correct' | 'incorrect' | null>>({});

  const handleDragStart = (e: React.DragEvent, itemId: string) => {
    setDraggedItem(itemId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, zoneId: string) => {
    e.preventDefault();
    if (!draggedItem) return;

    const zone = dropZones.find(z => z.id === zoneId);
    const item = items.find(i => i.id === draggedItem);
    
    if (!zone || !item) return;

    // Remove item from other zones first
    const newDroppedItems = { ...droppedItems };
    Object.keys(newDroppedItems).forEach(zId => {
      newDroppedItems[zId] = newDroppedItems[zId]?.filter(itemId => itemId !== draggedItem) || [];
    });

    // Add to current zone
    if (!newDroppedItems[zoneId]) {
      newDroppedItems[zoneId] = [];
    }
    newDroppedItems[zoneId].push(draggedItem);

    setDroppedItems(newDroppedItems);
    setDraggedItem(null);
  };

  const checkAnswers = () => {
    let correctCount = 0;
    const newFeedback: Record<string, 'correct' | 'incorrect' | null> = {};

    dropZones.forEach(zone => {
      const droppedInZone = droppedItems[zone.id] || [];
      const isCorrect = zone.correctItems.length === droppedInZone.length &&
                       zone.correctItems.every(itemId => droppedInZone.includes(itemId));
      
      newFeedback[zone.id] = isCorrect ? 'correct' : 'incorrect';
      if (isCorrect) correctCount++;
    });

    const finalScore = Math.round((correctCount / dropZones.length) * 100);
    setScore(finalScore);
    setFeedback(newFeedback);
    setIsCompleted(true);

    if (onComplete) {
      onComplete(finalScore === 100, finalScore);
    }
  };

  const reset = () => {
    setDroppedItems({});
    setIsCompleted(false);
    setScore(0);
    setFeedback({});
    setDraggedItem(null);
  };

  const getItemsInZone = (zoneId: string) => {
    return (droppedItems[zoneId] || []).map(itemId => 
      items.find(item => item.id === itemId)
    ).filter((item): item is DragItem => item !== undefined);
  };

  const getAvailableItems = () => {
    const usedItems = new Set(Object.values(droppedItems).flat());
    return items.filter(item => !usedItems.has(item.id));
  };

  return (
    <Card className="border-gray-700 bg-gray-900/60 shadow-md">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg text-blue-400">{title}</CardTitle>
        <CardDescription className="text-gray-300">{description}</CardDescription>
        {isCompleted && (
          <div className="text-sm font-medium">
            Score: <span className={score === 100 ? "text-green-400" : "text-yellow-400"}>{score}%</span>
          </div>
        )}
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Available Items */}
        <div>
          <h4 className="text-sm font-medium text-gray-300 mb-3">Available Items</h4>
          <div className="flex flex-wrap gap-2 min-h-[60px] p-3 border border-gray-700 rounded-md bg-gray-800/30">
            {getAvailableItems().map(item => (
              <div
                key={item.id}
                draggable={!isCompleted}
                onDragStart={(e) => handleDragStart(e, item.id)}
                className={`px-3 py-2 bg-blue-600 text-white rounded-md cursor-move transition-all hover:bg-blue-700 flex items-center gap-2 ${
                  isCompleted ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                <Move className="h-3 w-3" />
                {item.content}
              </div>
            ))}
          </div>
        </div>

        {/* Drop Zones */}
        <div className="grid gap-4 md:grid-cols-2">
          {dropZones.map(zone => {
            const zoneItems = getItemsInZone(zone.id);
            const zoneFeedback = feedback[zone.id];
            
            return (
              <div
                key={zone.id}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, zone.id)}
                className={`p-4 border-2 border-dashed rounded-md min-h-[120px] transition-all ${
                  zoneFeedback === 'correct' 
                    ? 'border-green-500 bg-green-900/20' 
                    : zoneFeedback === 'incorrect'
                      ? 'border-red-500 bg-red-900/20'
                      : draggedItem
                        ? 'border-blue-500 bg-blue-900/20'
                        : 'border-gray-600 bg-gray-800/20'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-gray-200">{zone.title}</h4>
                  {zoneFeedback && (
                    <div className="flex items-center">
                      {zoneFeedback === 'correct' ? (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500" />
                      )}
                    </div>
                  )}
                </div>
                
                <div className="space-y-2">
                  {zoneItems.map(item => item && (
                    <div
                      key={item.id}
                      className="px-2 py-1 bg-gray-700 text-gray-200 rounded text-sm"
                    >
                      {item.content}
                    </div>
                  ))}
                  {zoneItems.length === 0 && (
                    <div className="text-gray-500 text-sm italic">Drop items here</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>

      <CardFooter className="space-x-2">
        <Button
          variant="outline"
          onClick={reset}
          className="border-gray-700 text-gray-300 hover:bg-gray-800"
        >
          <RotateCcw className="mr-2 h-4 w-4" />
          Reset
        </Button>
        
        <Button
          onClick={checkAnswers}
          disabled={isCompleted || getAvailableItems().length > 0}
          className="ml-auto bg-blue-600 hover:bg-blue-700 text-white"
        >
          {isCompleted ? 'Completed' : 'Check Answers'}
        </Button>
      </CardFooter>
    </Card>
  );
}