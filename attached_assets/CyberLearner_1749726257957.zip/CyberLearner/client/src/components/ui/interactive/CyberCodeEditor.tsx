import React, { useState, useCallback, useMemo, memo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { PlayCircle, RotateCcw, Info, Copy, Download } from 'lucide-react';
import { useOptimizedState, useDebouncedState } from '@/hooks/use-optimized-state';
import { perf } from '@/lib/performance';

interface CyberCodeEditorProps {
  initialCode: string;
  language?: string;
  title?: string;
  description?: string;
  hint?: string;
  onRun?: (code: string) => void;
}

const CyberCodeEditor = memo(function CyberCodeEditor({
  initialCode,
  language = 'javascript',
  title = 'Code Playground',
  description = 'Try modifying the code and run it to see the results',
  hint,
  onRun
}: CyberCodeEditorProps) {
  const [code, setCode] = useOptimizedState(initialCode, 'CyberCodeEditor');
  const [debouncedCode] = useDebouncedState(code, 500);
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [executionHistory, setExecutionHistory] = useState<string[]>([]);
  
  // Memoized calculations
  const lineCount = useMemo(() => code.split('\n').length, [code]);
  const codeComplexity = useMemo(() => {
    const lines = code.split('\n').filter(line => line.trim().length > 0);
    return {
      lines: lines.length,
      functions: (code.match(/function|def |const.*=>/g) || []).length,
      imports: (code.match(/import|from|require/g) || []).length
    };
  }, [debouncedCode]);
  
  const handleRunCode = useCallback(() => {
    const startTime = performance.now();
    setIsRunning(true);
    setOutput('');
    
    // Add to execution history
    setExecutionHistory(prev => [code, ...prev.slice(0, 4)]);
    
    // Simulate code execution with enhanced feedback
    const executionPromise = new Promise<string>((resolve) => {
      setTimeout(() => {
        try {
          let result = '';
          const executionTime = Math.floor(Math.random() * 200 + 50);
          
          if (language === 'javascript') {
            const originalConsoleLog = console.log;
            const logs: string[] = [];
            
            console.log = (...args) => {
              logs.push(args.map(arg => 
                typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
              ).join(' '));
            };
            
            try {
              // Secure code analysis simulation (no execution for security)
              const hasConsoleLog = code.includes('console.log');
              const hasFunctions = /function|=>|class/.test(code);
              const hasVariables = /let|const|var/.test(code);
              
              let analysisResult = 'Code analysis complete';
              if (hasConsoleLog) {
                // Extract console.log content for display
                const logMatches = code.match(/console\.log\([^)]*\)/g);
                if (logMatches) {
                  logs.push(...logMatches.map(match => {
                    const content = match.replace(/console\.log\((.*)\)/, '$1');
                    return content.replace(/['"]/g, '');
                  }));
                }
                analysisResult += '\n• Console output detected';
              }
              if (hasFunctions) analysisResult += '\n• Function definitions found';
              if (hasVariables) analysisResult += '\n• Variable declarations found';
              
              const output = logs.length > 0 ? logs.join('\n') : analysisResult;
              result = `🚀 JavaScript Analysis Complete\n${output}\n\n📊 Analysis time: ${executionTime}ms\n📝 Lines processed: ${codeComplexity.lines}\n🔒 Secure analysis mode`;
            } catch (error) {
              result = `❌ Analysis Error: ${error instanceof Error ? error.message : String(error)}\n\n🔍 Check your syntax and try again.`;
            }
            
            console.log = originalConsoleLog;
          } else if (language === 'python') {
            const lines = code.split('\n').filter(line => line.trim());
            const printStatements = lines.filter(line => line.trim().startsWith('print('));
            
            if (printStatements.length > 0) {
              const outputs = printStatements.map(line => {
                const match = line.match(/print\((.*)\)/);
                if (match) {
                  let content = match[1].trim();
                  if ((content.startsWith('"') && content.endsWith('"')) || 
                      (content.startsWith("'") && content.endsWith("'"))) {
                    content = content.slice(1, -1);
                  }
                  return content;
                }
                return 'undefined';
              });
              result = `🐍 Python Execution Complete\n${outputs.join('\n')}\n\n📊 Execution time: ${executionTime}ms\n📝 Print statements: ${printStatements.length}`;
            } else {
              result = `🐍 Python code processed successfully\n\n📊 Execution time: ${executionTime}ms\n📝 Lines: ${codeComplexity.lines}\n📦 Functions: ${codeComplexity.functions}`;
            }
          } else {
            result = `✅ ${language.toUpperCase()} Code Analysis Complete\n\n📊 Execution time: ${executionTime}ms\n📝 Code complexity: ${codeComplexity.lines} lines, ${codeComplexity.functions} functions\n🔒 Secure sandbox simulation active`;
          }
          
          resolve(result);
        } catch (error) {
          resolve(`❌ System Error: ${error instanceof Error ? error.message : String(error)}`);
        }
      }, Math.floor(Math.random() * 1000 + 500));
    });
    
    executionPromise
      .then(result => {
        setOutput(result);
        const endTime = performance.now();
        perf.measureRender('CodeExecution', () => {});
        
        if (onRun) {
          onRun(code);
        }
      })
      .finally(() => {
        setIsRunning(false);
      });
  }, [code, language, codeComplexity, onRun]);
  
  const handleReset = useCallback(() => {
    setCode(initialCode);
    setOutput('');
    setExecutionHistory([]);
  }, [initialCode, setCode]);
  
  const toggleHint = useCallback(() => {
    setShowHint(!showHint);
  }, [showHint]);

  const copyCode = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(code);
    } catch (err) {
      console.warn('Failed to copy code to clipboard');
    }
  }, [code]);

  const downloadCode = useCallback(() => {
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `code.${language === 'javascript' ? 'js' : language === 'python' ? 'py' : 'txt'}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [code, language]);
  
  return (
    <Card className="border-gray-700 bg-gray-900/60 shadow-md">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg text-blue-400">{title}</CardTitle>
            <CardDescription className="text-gray-300">{description}</CardDescription>
          </div>
          {hint && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={toggleHint}
              className="text-gray-400 hover:text-blue-400"
            >
              <Info className="h-4 w-4 mr-1" />
              {showHint ? 'Hide Hint' : 'Show Hint'}
            </Button>
          )}
        </div>
        
        {showHint && hint && (
          <div className="mt-2 p-3 bg-blue-900/20 border border-blue-800 rounded-md text-blue-100">
            {hint}
          </div>
        )}
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="relative rounded-md border border-gray-700 overflow-hidden">
          <div className="flex">
            {/* Line numbers */}
            <div className="bg-gray-800 text-gray-500 text-xs p-2 text-right select-none w-12">
              {Array.from({ length: lineCount }, (_, i) => i + 1).map(num => (
                <div key={num} className="leading-relaxed">{num}</div>
              ))}
            </div>
            
            {/* Code editor */}
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full bg-gray-900 text-gray-200 p-2 leading-relaxed font-mono text-sm resize-none focus:outline-none focus:ring-1 focus:ring-blue-500"
              rows={Math.max(8, lineCount)}
              spellCheck="false"
              data-gramm="false"
            />
          </div>
        </div>
        
        {output && (
          <div className="space-y-2">
            <div className="text-sm font-medium text-gray-400">Output:</div>
            <div className="bg-black rounded-md p-3 font-mono text-sm text-gray-300 overflow-x-auto max-h-40 overflow-y-auto">
              <pre className="whitespace-pre-wrap">{output}</pre>
            </div>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="space-x-2">
        <Button
          variant="outline"
          onClick={handleReset}
          className="border-gray-700 text-gray-300 hover:bg-gray-800"
          disabled={code === initialCode}
        >
          <RotateCcw className="mr-2 h-4 w-4" />
          Reset
        </Button>
        
        <Button
          onClick={handleRunCode}
          className="ml-auto w-32 bg-blue-600 hover:bg-blue-700 text-white"
          disabled={isRunning}
        >
          {isRunning ? (
            <>
              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
              Running...
            </>
          ) : (
            <>
              <PlayCircle className="mr-2 h-4 w-4" />
              Run Code
            </>
          )}
        </Button>
        
        <Button
          onClick={copyCode}
          variant="outline"
          size="sm"
          className="border-gray-700 text-gray-300 hover:bg-gray-800"
        >
          <Copy className="h-4 w-4" />
        </Button>
        
        <Button
          onClick={downloadCode}
          variant="outline"
          size="sm"
          className="border-gray-700 text-gray-300 hover:bg-gray-800"
        >
          <Download className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
});

export default CyberCodeEditor;
export { CyberCodeEditor };