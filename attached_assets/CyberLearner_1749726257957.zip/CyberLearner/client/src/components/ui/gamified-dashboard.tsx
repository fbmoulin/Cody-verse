import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Flame, 
  Trophy, 
  Star, 
  Zap, 
  Target, 
  Clock, 
  TrendingUp,
  Users,
  Award,
  Calendar,
  CheckCircle2,
  ArrowUp,
  Gift,
  Crown,
  Sparkles
} from "lucide-react";

interface LearningStats {
  currentXP: number;
  level: number;
  streak: number;
  totalTime: number;
  completedModules: number;
  rank: number;
  achievements: Achievement[];
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  unlockedAt?: Date;
}

interface Milestone {
  xp: number;
  title: string;
  reward: string;
  reached: boolean;
}

// Gamified Learning Dashboard Component
export function GamifiedDashboard({ stats }: { stats: LearningStats }) {
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [recentAchievement, setRecentAchievement] = useState<Achievement | null>(null);
  const [weeklyGoal, setWeeklyGoal] = useState(5);
  const [dailyProgress, setDailyProgress] = useState(3);

  const nextLevelXP = (stats.level + 1) * 1000;
  const currentLevelXP = stats.level * 1000;
  const progressToNextLevel = ((stats.currentXP - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100;

  const milestones: Milestone[] = [
    { xp: 500, title: "Primeiro Passo", reward: "Badge de Iniciante", reached: stats.currentXP >= 500 },
    { xp: 1000, title: "Desenvolvedor", reward: "Avatar Personalizado", reached: stats.currentXP >= 1000 },
    { xp: 2500, title: "Expert MCP", reward: "Certificado Digital", reached: stats.currentXP >= 2500 },
    { xp: 5000, title: "Mestre", reward: "Acesso VIP", reached: stats.currentXP >= 5000 }
  ];

  const weekData = [
    { day: 'Dom', xp: 120, completed: true },
    { day: 'Seg', xp: 200, completed: true },
    { day: 'Ter', xp: 150, completed: true },
    { day: 'Qua', xp: 0, completed: false },
    { day: 'Qui', xp: 0, completed: false },
    { day: 'Sex', xp: 0, completed: false },
    { day: 'Sab', xp: 0, completed: false }
  ];

  const leaderboard = [
    { name: "Ana Silva", xp: 3240, avatar: "AS", rank: 1, isUser: false },
    { name: "Carlos Santos", xp: 2890, avatar: "CS", rank: 2, isUser: false },
    { name: "Você", xp: stats.currentXP, avatar: "V", rank: stats.rank, isUser: true },
    { name: "Maria Costa", xp: 2100, avatar: "MC", rank: 4, isUser: false },
    { name: "João Pereira", xp: 1950, avatar: "JP", rank: 5, isUser: false }
  ];

  return (
    <div className="space-y-6">
      {/* Level Progress Card */}
      <Card className="p-6 bg-gradient-to-r from-purple-500 to-blue-600 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16" />
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12" />
        
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="bg-white/20 p-3 rounded-full">
                <Crown className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-2xl font-bold">Nível {stats.level}</h3>
                <p className="text-white/80">Desenvolvedor MCP</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold">{stats.currentXP.toLocaleString()}</p>
              <p className="text-white/80 text-sm">XP Total</p>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Progresso para Nível {stats.level + 1}</span>
              <span>{Math.round(progressToNextLevel)}%</span>
            </div>
            <Progress value={progressToNextLevel} className="h-3 bg-white/20" />
            <p className="text-xs text-white/70">
              {nextLevelXP - stats.currentXP} XP restantes
            </p>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Streak Card */}
        <Card className="p-4 bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
          <div className="flex items-center space-x-3">
            <div className="bg-orange-500 p-2 rounded-full">
              <Flame className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-orange-600">{stats.streak}</p>
              <p className="text-sm text-orange-700">Dias seguidos</p>
            </div>
          </div>
        </Card>

        {/* Rank Card */}
        <Card className="p-4 bg-gradient-to-br from-yellow-50 to-amber-50 border-yellow-200">
          <div className="flex items-center space-x-3">
            <div className="bg-yellow-500 p-2 rounded-full">
              <Trophy className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-yellow-600">#{stats.rank}</p>
              <p className="text-sm text-yellow-700">Ranking Global</p>
            </div>
          </div>
        </Card>

        {/* Time Card */}
        <Card className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-500 p-2 rounded-full">
              <Clock className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-blue-600">{Math.floor(stats.totalTime / 60)}h</p>
              <p className="text-sm text-blue-700">Tempo Total</p>
            </div>
          </div>
        </Card>

        {/* Achievements Card */}
        <Card className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <div className="flex items-center space-x-3">
            <div className="bg-green-500 p-2 rounded-full">
              <Award className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-green-600">
                {stats.achievements.filter(a => a.unlocked).length}
              </p>
              <p className="text-sm text-green-700">Conquistas</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Progress */}
        <Card className="p-6">
          <h3 className="font-bold text-lg mb-4 flex items-center">
            <Calendar className="mr-2 h-5 w-5 text-purple-500" />
            Progresso Semanal
          </h3>
          
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm text-gray-600">Meta: {weeklyGoal} dias</span>
            <span className="text-sm font-medium">{dailyProgress}/{weeklyGoal} dias</span>
          </div>
          
          <div className="grid grid-cols-7 gap-2 mb-4">
            {weekData.map((day, index) => (
              <div key={index} className="text-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-medium ${
                  day.completed 
                    ? 'bg-green-500 text-white' 
                    : index === 3 
                    ? 'bg-blue-100 text-blue-600 ring-2 ring-blue-300' 
                    : 'bg-gray-100 text-gray-400'
                }`}>
                  {day.completed ? <CheckCircle2 className="h-4 w-4" /> : day.day.charAt(0)}
                </div>
                <p className="text-xs mt-1 text-gray-500">{day.day}</p>
              </div>
            ))}
          </div>
          
          <Progress value={(dailyProgress / weeklyGoal) * 100} className="h-2" />
        </Card>

        {/* Milestones */}
        <Card className="p-6">
          <h3 className="font-bold text-lg mb-4 flex items-center">
            <Target className="mr-2 h-5 w-5 text-blue-500" />
            Marcos do Progresso
          </h3>
          
          <div className="space-y-3">
            {milestones.map((milestone, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  milestone.reached 
                    ? 'bg-green-500 text-white' 
                    : 'bg-gray-200 text-gray-400'
                }`}>
                  {milestone.reached ? <CheckCircle2 className="h-4 w-4" /> : index + 1}
                </div>
                <div className="flex-1">
                  <p className={`font-medium ${milestone.reached ? 'text-green-600' : 'text-gray-600'}`}>
                    {milestone.title}
                  </p>
                  <p className="text-xs text-gray-500">{milestone.reward}</p>
                </div>
                <Badge variant={milestone.reached ? "default" : "secondary"} className="text-xs">
                  {milestone.xp} XP
                </Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent Achievements */}
      <Card className="p-6">
        <h3 className="font-bold text-lg mb-4 flex items-center">
          <Sparkles className="mr-2 h-5 w-5 text-yellow-500" />
          Conquistas Recentes
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {stats.achievements.filter(a => a.unlocked).slice(0, 3).map((achievement) => (
            <div key={achievement.id} className="flex items-center space-x-3 p-3 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border border-yellow-200">
              <div className="text-2xl">{achievement.icon}</div>
              <div className="flex-1">
                <p className="font-medium text-yellow-800">{achievement.title}</p>
                <p className="text-xs text-yellow-600">{achievement.description}</p>
              </div>
              <Badge className={`text-xs ${
                achievement.rarity === 'legendary' ? 'bg-purple-500' :
                achievement.rarity === 'epic' ? 'bg-orange-500' :
                achievement.rarity === 'rare' ? 'bg-blue-500' : 'bg-gray-500'
              }`}>
                {achievement.rarity}
              </Badge>
            </div>
          ))}
        </div>
      </Card>

      {/* Mini Leaderboard */}
      <Card className="p-6">
        <h3 className="font-bold text-lg mb-4 flex items-center">
          <Users className="mr-2 h-5 w-5 text-green-500" />
          Ranking da Comunidade
        </h3>
        
        <div className="space-y-3">
          {leaderboard.slice(0, 5).map((user, index) => (
            <div key={index} className={`flex items-center space-x-3 p-3 rounded-lg ${
              user.isUser ? 'bg-purple-50 border border-purple-200' : 'bg-gray-50'
            }`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white ${
                user.rank === 1 ? 'bg-yellow-500' :
                user.rank === 2 ? 'bg-gray-400' :
                user.rank === 3 ? 'bg-orange-500' : 'bg-blue-500'
              }`}>
                {user.rank}
              </div>
              
              <Avatar className="h-8 w-8">
                <AvatarFallback className={user.isUser ? 'bg-purple-500' : 'bg-gray-500'}>
                  {user.avatar}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <p className={`font-medium ${user.isUser ? 'text-purple-700' : 'text-gray-700'}`}>
                  {user.name}
                </p>
              </div>
              
              <div className="text-right">
                <p className="font-bold text-sm">{user.xp.toLocaleString()}</p>
                <p className="text-xs text-gray-500">XP</p>
              </div>
              
              {user.rank <= 3 && (
                <div className="text-yellow-500">
                  <Crown className="h-4 w-4" />
                </div>
              )}
            </div>
          ))}
        </div>
        
        <Button variant="outline" className="w-full mt-4">
          Ver Ranking Completo
        </Button>
      </Card>

      {/* Level Up Animation */}
      <AnimatePresence>
        {showLevelUp && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50"
            onClick={() => setShowLevelUp(false)}
          >
            <motion.div
              initial={{ y: -50 }}
              animate={{ y: 0 }}
              className="bg-white p-8 rounded-2xl text-center max-w-md mx-4"
            >
              <div className="text-6xl mb-4">🎉</div>
              <h2 className="text-3xl font-bold mb-2">Parabéns!</h2>
              <p className="text-xl mb-4">Você subiu para o Nível {stats.level}!</p>
              <div className="bg-gradient-to-r from-purple-100 to-blue-100 p-4 rounded-lg mb-4">
                <p className="font-medium">Recompensa Desbloqueada:</p>
                <p className="text-sm text-gray-600">Nova badge e 100 XP bônus</p>
              </div>
              <Button onClick={() => setShowLevelUp(false)} className="w-full">
                Continuar
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}