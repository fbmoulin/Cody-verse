import React, { useEffect, ReactNode } from 'react';
import { ThemeProvider } from 'next-themes';

interface CyberpunkThemeProps {
  children: ReactNode;
}

const CyberpunkTheme: React.FC<CyberpunkThemeProps> = ({ children }) => {
  // This component is minimal as most styles are already in index.css
  useEffect(() => {
    // Add any dynamic theme initialization here
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (prefersDark) {
      document.documentElement.classList.add('dark');
    }
  }, []);

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      {children}
    </ThemeProvider>
  );
};

export default CyberpunkTheme;
