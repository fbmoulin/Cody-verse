import React, { useMemo } from 'react';

interface CodyVerseLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'default' | 'minimal' | 'text-only';
  animated?: boolean;
}

function CodyVerseLogo({
  className = '',
  size = 'md',
  variant = 'default',
  animated = true
}: CodyVerseLogoProps) {
  // Size mappings
  const sizeMap = {
    sm: { width: 120, height: 40 },
    md: { width: 180, height: 60 },
    lg: { width: 240, height: 80 },
    xl: { width: 300, height: 100 }
  };
  
  // Get dimensions based on size prop using useMemo to optimize
  const dimensions = useMemo(() => sizeMap[size], [size]);
  const { width, height } = dimensions;
  
  // Animation classes
  const pulseAnimation = animated ? "animate-pulse" : "";

  return (
    <div className={`inline-block ${className}`}>
      <svg
        width={width}
        height={height}
        viewBox="0 0 300 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Background grid pattern */}
        {variant !== 'text-only' && (
          <g opacity="0.2">
            <path d="M0 40h300M0 60h300M0 80h300M40 0v100M80 0v100M120 0v100M160 0v100M200 0v100M240 0v100" 
              stroke="#00FFFF" strokeWidth="0.5" strokeDasharray="2 3" />
          </g>
        )}

        {/* Brain circuit logo */}
        {variant !== 'text-only' && (
          <g>
            {/* Main brain outline */}
            <path d="M50 50c0-22 18-40 40-40s40 18 40 40-18 40-40 40-40-18-40-40z" 
              fill="#111111" stroke="#FFD700" strokeWidth="2" />
            
            {/* Circuit patterns */}
            <path d="M60 35c10 0 20 5 20 15M100 35c-10 0-20 5-20 15M60 65c10 0 20-5 20-15M100 65c-10 0-20-5-20-15" 
              stroke="#FFD700" strokeWidth="1.5" fill="none" />
            <path d="M75 25v10M85 25v10M75 65v10M85 65v10" 
              stroke="#FFD700" strokeWidth="1.5" fill="none" />
            
            {/* Neural connections */}
            <path d="M90 35c5 5 5 25 0 30M70 35c-5 5-5 25 0 30M80 30c-10 5-10 35 0 40" 
              stroke="#00FFFF" strokeWidth="1" fill="none" />
            
            {/* Energy nodes with optional animation */}
            <circle cx="90" cy="35" r="3" fill="#00FFFF" className={pulseAnimation} />
            <circle cx="70" cy="35" r="3" fill="#00FFFF" className={pulseAnimation} />
            <circle cx="90" cy="65" r="3" fill="#00FFFF" className={pulseAnimation} />
            <circle cx="70" cy="65" r="3" fill="#00FFFF" className={pulseAnimation} />
            <circle cx="80" cy="50" r="5" fill="#FFD700" className={pulseAnimation} />
            
            {/* Data streams */}
            <path d="M50 45h10M50 55h10M100 45h10M100 55h10" 
              stroke="#00FFFF" strokeWidth="1" strokeDasharray="2 1" />
          </g>
        )}
        
        {/* Cody Verse text */}
        {variant !== 'minimal' && (
          <g>
            {/* Main logo text */}
            <text x={variant === 'text-only' ? "30" : "120"} y="45" 
              fontFamily="'Arial', sans-serif" fontWeight="bold" fontSize="24" 
              fill="url(#textGradient)" letterSpacing="1">
              CODY VERSE
            </text>
            
            {/* Tagline */}
            <text x={variant === 'text-only' ? "30" : "120"} y="65" 
              fontFamily="'Arial', sans-serif" fontSize="12" 
              fill="#FFFFFF" opacity="0.8">
              AI LEARNING PLATFORM
            </text>
          </g>
        )}
        
        {/* Decorative elements */}
        {variant === 'default' && (
          <>
            <path d="M115 50h5M110 30l5 5M110 70l5-5" stroke="#FFD700" strokeWidth="1.5" />
            <path d="M270 40h-30M270 60h-30" stroke="#00FFFF" strokeWidth="1" strokeDasharray="3 2" />
            <circle cx="270" cy="40" r="2" fill="#00FFFF" className={pulseAnimation} />
            <circle cx="270" cy="60" r="2" fill="#00FFFF" className={pulseAnimation} />
          </>
        )}
        
        {/* Gradients */}
        <defs>
          <linearGradient id="textGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#FFD700" />
            <stop offset="100%" stopColor="#00FFFF" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

export default React.memo(CodyVerseLogo);