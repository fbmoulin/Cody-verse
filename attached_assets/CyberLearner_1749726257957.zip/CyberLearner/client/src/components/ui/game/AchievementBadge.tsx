import React from 'react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Award, LockKeyhole, Star } from 'lucide-react';

interface AchievementBadgeProps {
  title: string;
  description: string;
  icon?: string;
  xpReward: number;
  unlocked?: boolean;
  animateUnlock?: boolean;
  className?: string;
}

const AchievementBadge: React.FC<AchievementBadgeProps> = ({
  title,
  description,
  icon = "trophy",
  xpReward,
  unlocked = false,
  animateUnlock = false,
  className = ""
}) => {
  // Icon mapping
  const renderIcon = () => {
    switch (icon) {
      case 'trophy':
        return <Award className="w-5 h-5" />;
      case 'star':
        return <Star className="w-5 h-5" />;
      default:
        return <Award className="w-5 h-5" />;
    }
  };

  const badgeVariants = {
    locked: { 
      scale: 1, 
      filter: "grayscale(100%)", 
      opacity: 0.5 
    },
    unlocked: { 
      scale: 1, 
      filter: "grayscale(0%)", 
      opacity: 1 
    },
    unlocking: { 
      scale: [1, 1.2, 1], 
      filter: ["grayscale(100%)", "grayscale(0%)", "grayscale(0%)"],
      opacity: [0.5, 1, 1],
      boxShadow: [
        "0 0 0px rgba(255, 215, 0, 0)",
        "0 0 20px rgba(255, 215, 0, 0.8)",
        "0 0 5px rgba(255, 215, 0, 0.3)"
      ]
    }
  };

  const getAnimationState = () => {
    if (!unlocked) return "locked";
    if (animateUnlock) return "unlocking";
    return "unlocked";
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={`inline-block ${className}`}>
            <motion.div
              variants={badgeVariants}
              initial={unlocked ? "unlocked" : "locked"}
              animate={getAnimationState()}
              transition={{ duration: animateUnlock ? 1.8 : 0.3 }}
              className={`
                relative rounded-md p-1 flex items-center justify-center
                ${unlocked 
                  ? 'bg-gradient-to-br from-primary/30 to-secondary/30 border border-primary/50' 
                  : 'bg-gray-800/50 border border-gray-700'}
              `}
            >
              <div className="flex flex-col items-center p-2">
                <div className={`
                  w-12 h-12 rounded-full flex items-center justify-center mb-2
                  ${unlocked 
                    ? 'bg-primary text-black' 
                    : 'bg-gray-700 text-gray-400'}
                `}>
                  {unlocked ? renderIcon() : <LockKeyhole className="w-5 h-5" />}
                </div>
                
                <Badge 
                  variant={unlocked ? "default" : "outline"} 
                  className={`text-xs px-2 py-0 ${unlocked ? 'bg-primary/70 text-black' : 'bg-transparent text-gray-400'}`}
                >
                  +{xpReward} XP
                </Badge>
                
                <span className={`text-sm mt-1 font-semibold text-center truncate max-w-[80px] ${unlocked ? 'text-white' : 'text-gray-400'}`}>
                  {title}
                </span>
              </div>
              
              {/* Pulsing effect when newly unlocked */}
              {animateUnlock && (
                <motion.div
                  className="absolute inset-0 rounded-md"
                  animate={{
                    boxShadow: [
                      "0 0 0 0px rgba(255, 215, 0, 0)",
                      "0 0 0 4px rgba(255, 215, 0, 0.3)",
                      "0 0 0 8px rgba(255, 215, 0, 0)"
                    ]
                  }}
                  transition={{
                    duration: 2,
                    repeat: 3,
                    repeatType: "loop"
                  }}
                />
              )}
            </motion.div>
          </div>
        </TooltipTrigger>
        <TooltipContent side="top" className="bg-gray-900 border border-gray-700 p-3 max-w-xs">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <span className={`text-lg font-bold ${unlocked ? 'text-primary' : 'text-gray-400'}`}>
                {title}
              </span>
              {unlocked && (
                <Badge className="bg-primary/80 text-black text-xs">UNLOCKED</Badge>
              )}
              {!unlocked && (
                <Badge variant="outline" className="text-gray-400 text-xs">LOCKED</Badge>
              )}
            </div>
            <p className="text-sm text-gray-300">{description}</p>
            <p className="text-xs text-secondary mt-1">Reward: {xpReward} XP</p>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default AchievementBadge;
