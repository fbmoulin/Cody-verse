import React from 'react';
import { motion } from 'framer-motion';
import { Progress } from '@/components/ui/progress';
import { COLORS, XP_PER_LEVEL } from '@/lib/constants';

interface ProgressBarProps {
  level: number;
  currentXp: number;
  label?: boolean;
  className?: string;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  level,
  currentXp,
  label = true,
  className = ''
}) => {
  // Calculate XP progress for current level
  const xpForCurrentLevel = (level - 1) * XP_PER_LEVEL;
  const xpToNextLevel = level * XP_PER_LEVEL;
  const currentLevelXp = currentXp - xpForCurrentLevel;
  const xpNeededForNextLevel = xpToNextLevel - xpForCurrentLevel;
  const progressPercentage = Math.min(100, (currentLevelXp / xpNeededForNextLevel) * 100);

  return (
    <div className={`flex flex-col ${className}`}>
      {label && (
        <div className="flex justify-between mb-1 text-xs text-white/80">
          <div className="flex items-center">
            <motion.div
              initial={{ scale: 1 }}
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 1.5, repeat: Infinity, repeatType: "reverse" }}
              className="inline-flex items-center justify-center text-primary bg-primary/20 border border-primary/40 rounded-full w-6 h-6 mr-1"
            >
              {level}
            </motion.div>
            <span className="font-cyber text-primary">LEVEL</span>
          </div>
          <div>
            <span className="text-secondary font-bold">{currentLevelXp}</span>
            <span className="text-white/60"> / {xpNeededForNextLevel} XP</span>
          </div>
        </div>
      )}
      
      <div className="relative">
        <Progress 
          value={progressPercentage} 
          className="h-2 bg-background border border-gray-800" 
        />
        
        {/* Animated progress glow effect */}
        <motion.div 
          className="absolute top-0 left-0 h-full bg-primary/30 rounded-full"
          style={{ width: `${progressPercentage}%` }}
          animate={{ 
            boxShadow: [
              `0 0 5px ${COLORS.primary}`, 
              `0 0 10px ${COLORS.primary}`, 
              `0 0 5px ${COLORS.primary}`
            ] 
          }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </div>
      
      {/* Visual level markers */}
      <div className="flex justify-between mt-1 px-1">
        {[0, 25, 50, 75, 100].map((mark) => (
          <div 
            key={mark} 
            className={`w-1 h-1 rounded-full ${
              progressPercentage >= mark ? 'bg-primary' : 'bg-gray-700'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default ProgressBar;
