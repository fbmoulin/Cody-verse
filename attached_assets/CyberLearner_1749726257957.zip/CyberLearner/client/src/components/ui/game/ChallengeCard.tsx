import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ChevronRight, Code, Gamepad2, Lock, Trophy } from 'lucide-react';
import { DIFFICULTY } from '@/lib/constants';

interface ChallengeCardProps {
  id: number;
  title: string;
  description: string;
  difficulty: string;
  xpReward: number;
  moduleId: number;
  completed?: boolean;
  locked?: boolean;
  onClick?: () => void;
  className?: string;
}

const ChallengeCard: React.FC<ChallengeCardProps> = ({
  id,
  title,
  description,
  difficulty,
  xpReward,
  moduleId,
  completed = false,
  locked = false,
  onClick,
  className = ''
}) => {
  const [isHovered, setIsHovered] = useState(false);
  
  // Get color based on difficulty - cores refinadas mais profissionais
  const getDifficultyColor = () => {
    switch (difficulty) {
      case DIFFICULTY.BEGINNER:
        return 'bg-gradient-to-r from-emerald-600/80 to-emerald-500/80 text-white shadow-sm';
      case DIFFICULTY.INTERMEDIATE:
        return 'bg-gradient-to-r from-blue-600/80 to-blue-500/80 text-white shadow-sm';
      case DIFFICULTY.ADVANCED:
        return 'bg-gradient-to-r from-amber-600/80 to-amber-500/80 text-white shadow-sm';
      case DIFFICULTY.EXPERT:
        return 'bg-gradient-to-r from-rose-600/80 to-rose-500/80 text-white shadow-sm';
      default:
        return 'bg-gradient-to-r from-slate-600/80 to-slate-500/80 text-white shadow-sm';
    }
  };
  
  const handleClick = () => {
    if (!locked && onClick) {
      onClick();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={locked ? {} : { scale: 1.02 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className={`${className}`}
    >
      <Card 
        className={`
          overflow-hidden border relative
          ${locked 
            ? 'bg-gray-900/60 border-border/40 opacity-80' 
            : 'bg-glass-background border-glass-border backdrop-filter backdrop-blur-lg shadow-md hover:shadow-lg transition-shadow duration-300'}
          ${completed ? 'border-primary/40 bg-gradient-to-br from-primary/5 to-background' : ''}
        `}
        style={{ 
          boxShadow: locked ? 'none' : 'var(--shadow-md)'
        }}
      >
        {/* Subtle gradiente de fundo para cards desbloqueados */}
        {!locked && !completed && (
          <div className="absolute inset-0 bg-gradient-to-br from-secondary/5 via-accent/3 to-background opacity-80 pointer-events-none" />
        )}
        
        {completed && (
          <div className="absolute top-0 right-0 m-3 z-10">
            <Badge className="bg-gradient-to-r from-primary to-primary/80 text-black font-semibold px-3 py-1 shadow-sm">
              <Trophy className="h-3.5 w-3.5 mr-1.5" />
              Completed
            </Badge>
          </div>
        )}
        
        <CardHeader className="relative p-5 pb-3">
          <div className="flex justify-between items-start">
            <div className="flex items-center space-x-3">
              <div className={`
                p-2.5 rounded-full 
                ${locked 
                  ? 'bg-gray-800 border border-gray-700' 
                  : completed 
                    ? 'bg-primary/20 border border-primary/30 text-primary' 
                    : 'bg-gradient-to-br from-secondary/20 to-secondary/10 border border-secondary/30 text-secondary'}
              `}>
                {locked ? <Lock size={18} /> : <Gamepad2 size={18} />}
              </div>
              <CardTitle className={`text-lg font-bold ${locked ? 'text-gray-400' : 'text-foreground'}`}>
                {title}
              </CardTitle>
            </div>
            
            <Badge className={`${getDifficultyColor()} px-3 py-1.5 text-xs font-medium uppercase tracking-wide`}>
              {difficulty}
            </Badge>
          </div>
          
          {/* Refined glowing border effect for active challenges */}
          {isHovered && !locked && (
            <motion.div 
              className="absolute inset-0 rounded-t-lg pointer-events-none"
              animate={{
                boxShadow: [
                  `inset 0 0 0px 0px rgba(0, 255, 255, 0)`,
                  `inset 0 0 12px 2px ${completed ? 'rgba(255, 215, 0, 0.2)' : 'rgba(0, 255, 255, 0.2)'}`,
                  `inset 0 0 0px 0px rgba(0, 255, 255, 0)`
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          )}
        </CardHeader>
        
        <CardContent className="relative p-5 pt-2">
          <p className={`text-sm ${locked 
            ? 'text-gray-500' 
            : 'text-muted-foreground font-normal'}`}
          >
            {locked 
              ? "Complete previous challenges to unlock"
              : description
            }
          </p>
        </CardContent>
        
        <CardFooter className="p-5 pt-3 flex justify-between items-center bg-gradient-to-b from-transparent to-black/5 border-t border-border/10">
          <div className="flex items-center">
            {locked ? (
              <div className="flex items-center text-gray-500">
                <Code size={18} className="text-gray-500" />
                <span className="ml-2 text-sm font-medium">
                  +{xpReward} XP
                </span>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <div className="flex items-center bg-secondary/10 text-secondary px-2.5 py-1 rounded-full border border-secondary/20">
                  <Code size={14} className="text-secondary" />
                  <span className="ml-1.5 text-xs font-medium">
                    +{xpReward} XP
                  </span>
                </div>
                <div className="text-xs text-muted-foreground">
                  Module {moduleId}
                </div>
              </div>
            )}
          </div>
          
          {locked ? (
            <Button 
              variant="outline" 
              disabled 
              className="bg-gray-800/50 text-gray-500 border-gray-700/50 opacity-80"
            >
              <Lock size={14} className="mr-1.5" />
              Locked
            </Button>
          ) : (
            onClick ? (
              <Button 
                onClick={handleClick} 
                className="bg-gradient-to-r from-secondary to-secondary/90 hover:opacity-90 hover:scale-105 text-black font-medium px-4 transition-all duration-200 shadow-md"
              >
                Start Challenge
                <ChevronRight size={16} className="ml-1.5" />
              </Button>
            ) : (
              <Button 
                asChild 
                className="bg-gradient-to-r from-secondary to-secondary/90 hover:opacity-90 hover:scale-105 text-black font-medium px-4 transition-all duration-200 shadow-md"
              >
                <Link to={`/challenge/${id}`}>
                  Start Challenge
                  <ChevronRight size={16} className="ml-1.5" />
                </Link>
              </Button>
            )
          )}
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ChallengeCard;
