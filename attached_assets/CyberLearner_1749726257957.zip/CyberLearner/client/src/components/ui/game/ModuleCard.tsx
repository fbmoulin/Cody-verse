import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { BookOpen, Clock, ChevronRight, CheckCircle, LockKeyhole, Award } from 'lucide-react';
import { ROUTES } from '@/lib/constants';

interface ModuleCardProps {
  id: number;
  title: string;
  description: string;
  difficulty: string;
  xpReward: number;
  estimatedTime: string;
  progress?: number;
  completed?: boolean;
  locked?: boolean;
  onClick?: () => void;
  className?: string;
}

const ModuleCard: React.FC<ModuleCardProps> = ({
  id,
  title,
  description,
  difficulty,
  xpReward,
  estimatedTime,
  progress = 0,
  completed = false,
  locked = false,
  onClick,
  className = ''
}) => {
  // Different background colors based on difficulty
  const getDifficultyColor = () => {
    switch (difficulty.toLowerCase()) {
      case 'beginner':
        return 'bg-green-600/70 text-white';
      case 'intermediate':
        return 'bg-blue-600/70 text-white';
      case 'advanced':
        return 'bg-orange-600/70 text-white';
      case 'expert':
        return 'bg-red-600/70 text-white';
      default:
        return 'bg-gray-600/70 text-white';
    }
  };

  const handleClick = () => {
    if (!locked && onClick) {
      onClick();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={locked ? {} : { scale: 1.02 }}
      className={`${className}`}
    >
      <Card 
        className={`
          overflow-hidden border
          ${locked 
            ? 'bg-gray-900/50 border-gray-700 opacity-80' 
            : 'bg-cardBackground border-gray-700 backdrop-filter backdrop-blur-sm'}
          ${completed ? 'border-primary/60' : ''}
        `}
      >
        {completed && (
          <div className="absolute top-0 right-0 m-3">
            <Badge className="bg-primary/90 text-black font-semibold">
              <CheckCircle className="h-3 w-3 mr-1" />
              Completed
            </Badge>
          </div>
        )}
        
        <CardHeader className="relative p-4 pb-2">
          <div className="flex justify-between items-start">
            <div className="flex items-center space-x-2">
              <div className={`
                p-2 rounded-full
                ${locked ? 'bg-gray-700' : 'bg-primary/30'}
              `}>
                {locked ? <LockKeyhole size={18} /> : <BookOpen size={18} />}
              </div>
              <CardTitle className={`text-lg ${locked ? 'text-gray-400' : 'text-white'}`}>
                {title}
              </CardTitle>
            </div>
            
            <Badge className={getDifficultyColor()}>
              {difficulty}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="p-4 pt-2">
          <p className={`text-sm ${locked ? 'text-gray-500' : 'text-gray-300'}`}>
            {locked 
              ? "Complete previous modules to unlock"
              : description
            }
          </p>
          
          {!locked && progress > 0 && progress < 100 && !completed && (
            <div className="mt-3">
              <div className="h-1.5 w-full bg-gray-800 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-primary"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                />
              </div>
              <p className="text-xs text-white/60 mt-1">{progress}% complete</p>
            </div>
          )}
        </CardContent>
        
        <CardFooter className="p-4 pt-2 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="flex items-center">
              <Award size={16} className={locked ? 'text-gray-500' : 'text-primary'} />
              <span className={`ml-1 text-sm ${locked ? 'text-gray-500' : 'text-primary'}`}>
                +{xpReward} XP
              </span>
            </div>
            
            <div className="flex items-center">
              <Clock size={16} className={locked ? 'text-gray-500' : 'text-gray-400'} />
              <span className={`ml-1 text-sm ${locked ? 'text-gray-500' : 'text-gray-400'}`}>
                {estimatedTime}
              </span>
            </div>
          </div>
          
          {locked ? (
            <Button variant="outline" disabled className="bg-gray-800 text-gray-500 border-gray-700">
              <LockKeyhole size={14} className="mr-1" />
              Locked
            </Button>
          ) : (
            onClick ? (
              <Button onClick={handleClick} className="bg-primary hover:bg-primary/80 text-black">
                {completed ? 'Review' : 'Start Learning'}
                <ChevronRight size={16} className="ml-1" />
              </Button>
            ) : (
              <Button asChild className="bg-primary hover:bg-primary/80 text-black">
                <Link to={ROUTES.LEARNING_MODULE.replace(':id', id.toString())}>
                  {completed ? 'Review' : progress > 0 ? 'Continue' : 'Start Learning'}
                  <ChevronRight size={16} className="ml-1" />
                </Link>
              </Button>
            )
          )}
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ModuleCard;
