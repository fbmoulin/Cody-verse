import React, { forwardRef } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowRight, Star, Clock, Users, TrendingUp } from 'lucide-react';

interface ModernCardProps {
  title: string;
  description: string;
  image?: string;
  badge?: string;
  badgeVariant?: 'default' | 'secondary' | 'destructive' | 'outline';
  stats?: Array<{
    icon: any;
    value: string | number;
    label: string;
  }>;
  action?: {
    label: string;
    onClick: () => void;
    variant?: 'default' | 'secondary' | 'outline';
  };
  className?: string;
  variant?: 'default' | 'elevated' | 'minimal' | 'interactive' | 'glass';
  size?: 'sm' | 'md' | 'lg';
  gradient?: boolean;
  glow?: boolean;
}

const ModernCard = forwardRef<HTMLDivElement, ModernCardProps>(
  ({ 
    title, 
    description, 
    image, 
    badge, 
    badgeVariant = 'default',
    stats = [], 
    action, 
    className,
    variant = 'default',
    size = 'md',
    gradient = false,
    glow = false,
    ...props 
  }, ref) => {
    const cardVariants = {
      default: 'bg-gray-800/50 border-gray-700 hover:border-gray-600',
      elevated: 'bg-gray-800/80 border-gray-600 shadow-lg hover:shadow-xl hover:shadow-cyan-500/10',
      minimal: 'bg-transparent border-gray-800 hover:bg-gray-800/30',
      interactive: 'bg-gray-800/50 border-gray-700 hover:border-cyan-500/50 hover:shadow-cyan-500/20 hover:shadow-lg cursor-pointer transform hover:scale-[1.02]',
      glass: 'bg-gray-800/20 backdrop-blur-md border-gray-600/50 hover:bg-gray-700/30'
    };

    const sizeVariants = {
      sm: 'p-4',
      md: 'p-6',
      lg: 'p-8'
    };

    const cardClasses = cn(
      'transition-all duration-300 ease-in-out relative overflow-hidden',
      cardVariants[variant],
      sizeVariants[size],
      gradient && 'bg-gradient-to-br from-gray-800/50 via-gray-800/30 to-gray-900/50',
      glow && 'shadow-lg shadow-cyan-500/20',
      className
    );

    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        whileHover={{ y: -2 }}
        {...props}
      >
        <Card className={cardClasses}>
          {/* Glow effect */}
          {glow && (
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 opacity-0 hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
          )}

          {image && (
            <div className="relative mb-4 overflow-hidden rounded-lg">
              <motion.img
                src={image}
                alt={title}
                className="w-full h-48 object-cover"
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
              />
              {badge && (
                <Badge 
                  variant={badgeVariant}
                  className="absolute top-3 left-3 backdrop-blur-sm"
                >
                  {badge}
                </Badge>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            </div>
          )}

          <CardHeader className="pb-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <CardTitle className="text-lg font-semibold text-white mb-2 line-clamp-2 group-hover:text-cyan-400 transition-colors">
                  {title}
                </CardTitle>
                {!image && badge && (
                  <Badge variant={badgeVariant} className="mb-3">
                    {badge}
                  </Badge>
                )}
              </div>
            </div>
          </CardHeader>

          <CardContent className="pt-0">
            <p className="text-gray-300 text-sm mb-4 line-clamp-3 leading-relaxed">
              {description}
            </p>

            {stats.length > 0 && (
              <div className="grid grid-cols-3 gap-4 mb-4 py-3 border-t border-gray-700/50">
                {stats.map((stat, index) => (
                  <motion.div 
                    key={index} 
                    className="text-center group"
                    whileHover={{ scale: 1.05 }}
                  >
                    <div className="flex items-center justify-center mb-1">
                      <stat.icon className="w-4 h-4 text-cyan-400 group-hover:text-cyan-300 transition-colors" />
                    </div>
                    <div className="text-sm font-semibold text-white">
                      {stat.value}
                    </div>
                    <div className="text-xs text-gray-400 group-hover:text-gray-300 transition-colors">
                      {stat.label}
                    </div>
                  </motion.div>
                ))}
              </div>
            )}

            {action && (
              <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Button
                  onClick={action.onClick}
                  variant={action.variant || 'default'}
                  className="w-full group bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white border-0"
                >
                  {action.label}
                  <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                </Button>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    );
  }
);

ModernCard.displayName = 'ModernCard';

export { ModernCard };

// Enhanced specialized card variants
export const LearningModuleCard = ({ module, onStart }: { 
  module: any; 
  onStart: () => void; 
}) => (
  <ModernCard
    title={module.title}
    description={module.description}
    badge={module.difficulty}
    badgeVariant={module.difficulty === 'Beginner' ? 'secondary' : 'default'}
    stats={[
      { icon: Clock, value: module.estimatedTime || '30m', label: 'Duration' },
      { icon: Star, value: module.xpReward || 100, label: 'XP' },
      { icon: TrendingUp, value: '95%', label: 'Success Rate' }
    ]}
    action={{
      label: 'Start Learning',
      onClick: onStart
    }}
    variant="interactive"
    gradient
    glow
  />
);

export const AchievementCard = ({ achievement }: { achievement: any }) => (
  <ModernCard
    title={achievement.title}
    description={achievement.description}
    badge={achievement.unlocked ? 'Unlocked' : 'Locked'}
    badgeVariant={achievement.unlocked ? 'default' : 'outline'}
    stats={[
      { icon: Star, value: achievement.xpReward, label: 'XP Reward' }
    ]}
    variant={achievement.unlocked ? 'elevated' : 'glass'}
    size="sm"
    glow={achievement.unlocked}
  />
);

export const ProgressCard = ({ 
  title, 
  progress, 
  total, 
  description,
  trend = 'stable'
}: { 
  title: string; 
  progress: number; 
  total: number; 
  description: string; 
  trend?: 'up' | 'down' | 'stable';
}) => {
  const percentage = Math.round((progress / total) * 100);
  
  return (
    <ModernCard
      title={title}
      description={description}
      stats={[
        { icon: TrendingUp, value: `${percentage}%`, label: 'Complete' },
        { icon: Star, value: `${progress}/${total}`, label: 'Progress' }
      ]}
      variant="glass"
      size="sm"
      gradient
    />
  );
};