import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useLocation } from 'wouter';
import { 
  Home, 
  BookOpen, 
  Trophy, 
  User, 
  Menu, 
  X, 
  Settings, 
  ChevronDown,
  Search,
  Bell,
  LogOut,
  Brain,
  Zap
} from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';

interface ModernLayoutProps {
  children: React.ReactNode;
  user?: {
    id: number;
    username: string;
    displayName: string;
    level: number;
    xp: number;
    avatar?: string;
  };
  showAssistant?: boolean;
}

export default function ModernLayout({ children, user, showAssistant = true }: ModernLayoutProps) {
  const [location] = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notifications] = useState([
    { id: 1, title: 'New challenge available', type: 'info' },
    { id: 2, title: 'Achievement unlocked!', type: 'success' }
  ]);
  const isMobile = useIsMobile();

  // Close sidebar on route change and handle responsive behavior
  useEffect(() => {
    setIsSidebarOpen(false);
  }, [location]);

  // Handle touch events for mobile interaction
  useEffect(() => {
    if (isMobile) {
      const handleTouchStart = (e: TouchEvent) => {
        if (isSidebarOpen && e.touches.length === 1) {
          const touch = e.touches[0];
          if (touch && touch.clientX > 280) { // Outside sidebar area
            setIsSidebarOpen(false);
          }
        }
      };

      document.addEventListener('touchstart', handleTouchStart, { passive: true });
      return () => document.removeEventListener('touchstart', handleTouchStart);
    }
    return undefined;
  }, [isSidebarOpen, isMobile]);

  const navigationItems = [
    { 
      icon: Home, 
      label: 'Home', 
      path: '/', 
      active: location === '/' 
    },
    { 
      icon: BookOpen, 
      label: 'Learning', 
      path: '/learning-module/1', 
      active: location.startsWith('/learning-module') 
    },
    { 
      icon: Trophy, 
      label: 'Achievements', 
      path: '/achievements', 
      active: location === '/achievements' 
    },
    { 
      icon: User, 
      label: 'Profile', 
      path: '/profile', 
      active: location === '/profile' 
    }
  ];

  const sidebarVariants = {
    open: { x: 0, opacity: 1 },
    closed: { x: '-100%', opacity: 0 }
  };

  const overlayVariants = {
    open: { opacity: 1 },
    closed: { opacity: 0 }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial="closed"
            animate="open"
            exit="closed"
            variants={overlayVariants}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <AnimatePresence>
        <motion.aside
          initial="closed"
          animate={isSidebarOpen ? "open" : "closed"}
          variants={sidebarVariants}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className="fixed left-0 top-0 z-50 h-full w-64 bg-card border-r border-border lg:translate-x-0 lg:opacity-100 lg:relative lg:z-auto"
        >
          <div className="flex flex-col h-full">
            {/* Logo */}
            <div className="p-6 border-b border-border">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-sm">CV</span>
                </div>
                <span className="text-foreground font-display heading-sm">Cody Verse</span>
              </div>
            </div>

            {/* Navigation */}
            <nav className="flex-1 px-4 py-6 space-y-2">
              {navigationItems.map((item) => (
                <Link key={item.path} href={item.path}>
                  <motion.div
                    whileHover={{ x: 4 }}
                    whileTap={{ scale: 0.95 }}
                    className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                      item.active
                        ? 'bg-primary/10 text-primary border border-primary/20'
                        : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                    {item.active && (
                      <motion.div
                        layoutId="activeIndicator"
                        className="ml-auto w-2 h-2 bg-primary rounded-full"
                      />
                    )}
                  </motion.div>
                </Link>
              ))}
            </nav>

            {/* User Profile Card */}
            {user && (
              <div className="p-4 border-t border-gray-700">
                <Card className="bg-gray-800/50 border-gray-600 p-4">
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={user.avatar} />
                      <AvatarFallback className="bg-cyan-500 text-white">
                        {user.displayName.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-medium truncate">{user.displayName}</p>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary" className="text-xs">
                          Level {user.level}
                        </Badge>
                        <span className="text-xs text-gray-400">{user.xp} XP</span>
                      </div>
                    </div>
                  </div>
                </Card>
              </div>
            )}
          </div>
        </motion.aside>
      </AnimatePresence>

      {/* Main Content */}
      <div className="lg:ml-64">
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-gray-900/95 backdrop-blur-md border-b border-gray-700">
          <div className="flex items-center justify-between px-4 py-4">
            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="lg:hidden text-gray-300 hover:text-white"
            >
              <Menu className="w-5 h-5" />
            </Button>

            {/* Search Bar */}
            <div className="hidden md:flex items-center flex-1 max-w-md mx-6">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search modules, challenges..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-gray-800 border-gray-600 text-white placeholder-gray-400 focus:border-cyan-500"
                />
              </div>
            </div>

            {/* Right Actions */}
            <div className="flex items-center space-x-4">
              {/* Notifications */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="relative text-gray-300 hover:text-white">
                    <Bell className="w-5 h-5" />
                    {notifications.length > 0 && (
                      <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 bg-red-500 text-xs flex items-center justify-center">
                        {notifications.length}
                      </Badge>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80 bg-gray-800 border-gray-600">
                  <div className="p-3 border-b border-gray-600">
                    <h3 className="font-medium text-white">Notifications</h3>
                  </div>
                  {notifications.map((notification) => (
                    <DropdownMenuItem key={notification.id} className="p-3 text-gray-300 hover:bg-gray-700">
                      <div>
                        <p className="font-medium">{notification.title}</p>
                        <p className="text-sm text-gray-400">Just now</p>
                      </div>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* User Menu */}
              {user && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center space-x-2 text-gray-300 hover:text-white">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={user.avatar} />
                        <AvatarFallback className="bg-cyan-500 text-white text-sm">
                          {user.displayName.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <ChevronDown className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 bg-gray-800 border-gray-600">
                    <div className="p-3 border-b border-gray-600">
                      <p className="font-medium text-white">{user.displayName}</p>
                      <p className="text-sm text-gray-400">@{user.username}</p>
                    </div>
                    <DropdownMenuItem className="text-gray-300 hover:bg-gray-700">
                      <User className="w-4 h-4 mr-2" />
                      Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-gray-300 hover:bg-gray-700">
                      <Settings className="w-4 h-4 mr-2" />
                      Settings
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-gray-600" />
                    <DropdownMenuItem className="text-red-400 hover:bg-red-500/20">
                      <LogOut className="w-4 h-4 mr-2" />
                      Sign out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-4 lg:p-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {children}
          </motion.div>
        </main>
      </div>

      {/* Mobile Search */}
      <div className="md:hidden fixed bottom-4 left-4 right-4 z-20">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-gray-800/95 backdrop-blur-md border-gray-600 text-white placeholder-gray-400 focus:border-cyan-500"
          />
        </div>
      </div>
    </div>
  );
}