import React, { useState, ReactNode, useCallback, useMemo } from 'react';
import { useLocation, Link } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import { OptimizedImage } from '@/components/ui/optimized-image';
import { 
  Home, 
  BookOpen, 
  Award, 
  User, 
  Menu, 
  X, 
  LogOut, 
  ChevronDown,
  Settings,
  Brain,
  Code
} from 'lucide-react';
import CodyVerseLogo from '@/components/ui/logo/CodyVerseLogo';
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import ProgressBar from '@/components/ui/game/ProgressBar';
import { useToast } from '@/hooks/use-toast';
import { ROUTES, LOCALIZED_CONTENT } from '@/lib/constants';
import AssistantCharacter from '@/components/characters/AssistantCharacter';
import LanguageSelector from '@/components/ui/language-selector';
import { useUserPreferences } from '@/hooks/use-preferences';

interface MainLayoutProps {
  children: ReactNode;
  title?: string;
  showAssistant?: boolean;
  assistantCharacter?: string;
  assistantContext?: string;
  className?: string;
}

const MainLayout: React.FC<MainLayoutProps> = ({
  children,
  title,
  showAssistant = true,
  assistantCharacter = "NEXUS",
  assistantContext,
  className = ''
}) => {
  const [location] = useLocation();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { language } = useUserPreferences();
  const localizedContent = LOCALIZED_CONTENT[language];
  
  // Mock user state - in a real app, this would come from authentication context
  const [user] = useState({
    username: 'cyberlearner',
    displayName: 'Cyber Learner',
    level: 3,
    xp: 2350,
  });

  // Memoize navigation items to prevent unnecessary re-renders
  const navItems = useMemo(() => [
    { path: ROUTES.HOME, label: localizedContent.nav_home, icon: <Home size={20} /> },
    { path: ROUTES.LEARNING_MODULE.replace(':id', '1'), label: localizedContent.nav_learning, icon: <BookOpen size={20} /> },
    { path: ROUTES.PROJECT_BUILDER, label: localizedContent.nav_projects, icon: <Code size={20} /> },
    { path: ROUTES.ACHIEVEMENTS, label: localizedContent.nav_achievements, icon: <Award size={20} /> },
    { path: ROUTES.PROFILE, label: localizedContent.nav_profile, icon: <User size={20} /> },
  ], [localizedContent]);

  // Memoize the isActive function to prevent unnecessary calculations
  const isActive = useCallback((path: string) => {
    if (path === '/') return location === '/';
    return location.startsWith(path.split('/:')[0]);
  }, [location]);

  const handleLogout = () => {
    // Fazer uma requisição para o endpoint de logout
    fetch('/api/auth/logout', {
      method: 'POST',
      credentials: 'include'
    })
    .then(response => {
      if (response.ok) {
        toast({
          title: localizedContent.logout_success_title || "Logged out",
          description: localizedContent.logout_success_message || "You have been logged out successfully.",
        });
        // Redirecionar para a página de login
        window.location.href = ROUTES.LOGIN;
      } else {
        toast({
          title: localizedContent.error_title || "Error",
          description: localizedContent.error_logout || "Failed to logout",
          variant: "destructive"
        });
      }
    })
    .catch(error => {
      console.error('Logout error:', error);
      toast({
        title: localizedContent.error_title || "Error",
        description: localizedContent.error_logout || "Failed to logout",
        variant: "destructive"
      });
    });
  };

  return (
    <div className="min-h-screen bg-background text-white flex flex-col">
      {/* Cyberpunk background pattern */}
      <div 
        className="fixed inset-0 bg-background z-0" 
        style={{ 
          backgroundImage: `
            linear-gradient(to bottom, rgba(26, 26, 26, 0.95), rgba(10, 10, 10, 0.98)), 
            repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255, 215, 0, 0.03) 10px, rgba(255, 215, 0, 0.03) 11px),
            repeating-linear-gradient(135deg, transparent, transparent 20px, rgba(0, 255, 255, 0.03) 20px, rgba(0, 255, 255, 0.03) 21px)
          `,
          backgroundSize: '100% 100%, 50px 50px, 50px 50px'
        }}
      />
      
      {/* Desktop Navigation - Redesenhado para aparência mais profissional */}
      <header className="fixed top-0 left-0 w-full bg-background/90 backdrop-filter backdrop-blur-lg z-30 border-b border-gray-800 shadow-sm">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Link to="/" className="flex items-center mr-8 group">
              <div className="relative overflow-hidden rounded-full p-0.5 bg-gradient-to-r from-primary via-secondary to-accent hidden md:flex mr-3">
                <OptimizedImage 
                  src="/icons/brain-icon.svg" 
                  alt="Cody Verse" 
                  className="h-10 w-10 rounded-full bg-background transform group-hover:scale-105 transition-all duration-300"
                  priority={true}
                />
              </div>
              <div className="hidden md:block">
                <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary via-secondary to-accent leading-tight">
                  Cody Verse
                </h1>
                <p className="text-xs font-medium tracking-wide text-white/70 uppercase">AI Learning Platform</p>
              </div>
              <div className="flex md:hidden items-center">
                <div className="relative overflow-hidden rounded-full p-0.5 bg-gradient-to-r from-primary to-secondary mr-2">
                  <div className="p-1 rounded-full bg-background">
                    <Brain className="w-7 h-7 text-primary" />
                  </div>
                </div>
                <h1 className="text-lg font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
                  Cody
                </h1>
              </div>
            </Link>
            
            <nav className="hidden md:flex space-x-2">
              {navItems.map((item) => (
                <Link key={item.path} to={item.path} className="relative group">
                  <Button 
                    variant={isActive(item.path) ? "default" : "ghost"} 
                    className={`py-2 px-4 text-sm h-auto rounded-md transition-all duration-200 ${
                      isActive(item.path) 
                        ? 'bg-gradient-to-r from-primary/90 to-primary text-black font-medium shadow-md' 
                        : 'text-white/85 hover:text-white hover:bg-gray-800/50 hover:shadow-sm'
                    }`}
                  >
                    <span className={`${isActive(item.path) ? 'text-black' : 'text-primary'} transition-colors duration-200`}>
                      {item.icon}
                    </span>
                    <span className="ml-2 font-medium">{item.label}</span>
                  </Button>
                  {isActive(item.path) ? (
                    <motion.div
                      layoutId="activeNavIndicator"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-primary via-secondary to-primary"
                      initial={false}
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  ) : (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-transparent group-hover:bg-primary/20 transition-colors duration-200" />
                  )}
                </Link>
              ))}
            </nav>
          </div>
          
          <div className="flex items-center">
            <div className="hidden md:block mr-5">
              <div className="relative">
                <ProgressBar level={user.level} currentXp={user.xp} className="w-48" />
                <div className="absolute -right-4 -top-1 bg-background/80 backdrop-blur-sm px-1.5 py-0.5 rounded-full border border-primary/30 shadow-sm">
                  <span className="text-xs font-semibold text-primary">Lvl {user.level}</span>
                </div>
              </div>
            </div>
            
            <div className="hidden md:block mr-3">
              <LanguageSelector />
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-9 w-9 rounded-full overflow-hidden p-0.5 bg-gradient-to-r from-primary/30 via-secondary/30 to-accent/30 hover:from-primary/50 hover:via-secondary/50 hover:to-accent/50 transition-all duration-300">
                  <Avatar className="h-full w-full border-0">
                    <AvatarFallback className="bg-gradient-to-br from-background to-muted text-primary font-bold">
                      {user.displayName.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-64 bg-popover/95 backdrop-blur-md border border-border/50 shadow-xl rounded-lg overflow-hidden" align="end" forceMount>
                <div className="bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 px-3 py-3">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10 border-2 border-primary/30 shadow-md">
                      <AvatarFallback className="bg-gradient-to-br from-background to-muted text-primary font-bold">
                        {user.displayName.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col">
                      <p className="text-sm font-semibold text-foreground">{user.displayName}</p>
                      <p className="text-xs text-muted-foreground">@{user.username}</p>
                    </div>
                  </div>
                  <div className="mt-2">
                    <ProgressBar level={user.level} currentXp={user.xp} />
                    <div className="flex justify-between mt-1">
                      <span className="text-xs text-muted-foreground">Lvl {user.level}</span>
                      <span className="text-xs text-muted-foreground">{user.xp} XP</span>
                    </div>
                  </div>
                </div>
                <DropdownMenuSeparator className="bg-border/30" />
                <div className="p-1">
                  <DropdownMenuItem asChild className="flex items-center py-2 cursor-pointer hover:bg-primary/10 hover:text-primary rounded-md transition-colors">
                    <Link to={ROUTES.PROFILE} className="cursor-pointer">
                      <User className="mr-2 h-4 w-4" />
                      <span>{localizedContent.nav_profile}</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex items-center py-2 hover:bg-primary/10 hover:text-primary rounded-md transition-colors">
                    <Settings className="mr-2 h-4 w-4" />
                    <span>{localizedContent.nav_settings}</span>
                  </DropdownMenuItem>
                </div>
                <DropdownMenuSeparator className="bg-border/30" />
                <div className="p-1">
                  <DropdownMenuItem onClick={handleLogout} className="flex items-center py-2 hover:bg-destructive/10 hover:text-destructive rounded-md transition-colors">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>{localizedContent.nav_logout}</span>
                  </DropdownMenuItem>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
            
            {/* Mobile menu trigger */}
            <div className="md:hidden ml-2">
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="relative h-9 w-9 rounded-full p-0 overflow-hidden hover:bg-muted/30 border border-border/30"
                  >
                    <span className="sr-only">Abrir menu</span>
                    <Menu className="h-5 w-5 text-primary" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-72 p-0 border-l border-gray-800 bg-background/95 backdrop-blur-md">
                  <div className="flex flex-col h-full">
                    <div className="p-4 border-b border-border/40 bg-gradient-to-r from-background to-muted/30 flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="relative overflow-hidden rounded-full p-0.5 bg-gradient-to-r from-primary via-secondary to-accent mr-2">
                          <div className="p-1 rounded-full bg-background">
                            <Brain className="w-6 h-6 text-primary" />
                          </div>
                        </div>
                        <h1 className="text-lg font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary via-secondary to-accent">
                          Cody Verse
                        </h1>
                      </div>
                      <Button variant="ghost" size="icon" className="rounded-full hover:bg-gray-800/50 transition-colors" onClick={() => setIsMobileMenuOpen(false)}>
                        <X className="h-5 w-5" />
                      </Button>
                    </div>
                    
                    <div className="p-5 border-b border-border/30 bg-gradient-to-r from-primary/5 via-secondary/5 to-accent/5">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="relative overflow-hidden rounded-full p-0.5 bg-gradient-to-r from-primary/50 via-secondary/50 to-accent/50 shadow-md">
                          <Avatar className="h-12 w-12 border-0">
                            <AvatarFallback className="bg-gradient-to-br from-background to-muted text-primary font-bold text-lg">
                              {user.displayName.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{user.displayName}</p>
                          <p className="text-xs text-muted-foreground">@{user.username}</p>
                        </div>
                      </div>
                      <div className="space-y-1.5">
                        <ProgressBar level={user.level} currentXp={user.xp} />
                        <div className="flex justify-between">
                          <span className="text-xs font-medium text-muted-foreground">Nível {user.level}</span>
                          <span className="text-xs font-medium text-primary">{user.xp} XP</span>
                        </div>
                      </div>
                    </div>
                    
                    <nav className="flex-1 p-3 overflow-y-auto">
                      <div className="space-y-1">
                        {navItems.map((item) => (
                          <Link 
                            key={item.path} 
                            to={item.path}
                            onClick={() => setIsMobileMenuOpen(false)}
                          >
                            <Button 
                              variant="ghost" 
                              className={`w-full justify-start py-2.5 px-3 rounded-md transition-all duration-200 ${
                                isActive(item.path) 
                                  ? 'bg-gradient-to-r from-primary/10 to-primary/20 text-primary font-medium shadow-sm' 
                                  : 'text-foreground hover:bg-muted/40 hover:text-primary'
                              }`}
                            >
                              <span className={`${isActive(item.path) ? 'text-primary' : 'text-primary/70'}`}>
                                {item.icon}
                              </span>
                              <span className="ml-3">{item.label}</span>
                              {isActive(item.path) && (
                                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary"></div>
                              )}
                            </Button>
                          </Link>
                        ))}
                      </div>
                      
                      <Separator className="my-4 bg-border/40" />
                      
                      <div className="mb-4">
                        <p className="text-xs uppercase font-medium text-muted-foreground mb-2 px-2 tracking-wider">Idioma / Language / Língua</p>
                        <div className="flex flex-wrap gap-2 px-2">
                          <LanguageSelector compact={true} />
                        </div>
                      </div>

                      <Button 
                        variant="outline" 
                        className="w-full justify-start text-destructive border-destructive/20 hover:bg-destructive/10 transition-colors duration-200"
                        onClick={handleLogout}
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        <span>{localizedContent.nav_logout}</span>
                      </Button>
                    </nav>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>
      
      {/* Main content */}
      <main className="flex-1 pt-[70px] pb-24 md:pb-16 relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={location}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className={`container mx-auto px-3 sm:px-4 ${className} optimize-gpu`}
          >
            {title && (
              <div className="mb-4 md:mb-6 mt-2">
                <h1 className="text-xl md:text-3xl font-bold">{title}</h1>
                <div className="w-16 md:w-20 h-1 bg-primary mt-2 rounded-full" />
              </div>
            )}
            {children}
          </motion.div>
        </AnimatePresence>
      </main>
      
      {/* Mobile navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-gray-900/90 backdrop-filter backdrop-blur-md border-t border-gray-800 z-30">
        <div className="flex justify-around py-2">
          {navItems.map((item) => (
            <Link key={item.path} to={item.path} className="flex flex-col items-center py-1 px-1 touch-manipulation">
              <div className={`p-1.5 rounded-full ${isActive(item.path) ? 'bg-primary text-black' : 'text-white/80'}`}>
                {item.icon}
              </div>
              <span className={`text-[10px] mt-0.5 ${isActive(item.path) ? 'text-primary' : 'text-white/60'}`}>
                {item.label}
              </span>
            </Link>
          ))}
        </div>
      </nav>
      
      {/* AI Assistant Character */}
      {showAssistant && (
        <AssistantCharacter 
          character={assistantCharacter} 
          context={assistantContext}
          minimized={true}
        />
      )}
    </div>
  );
};

// Memoize the entire component to prevent unnecessary re-renders
export default React.memo(MainLayout);
