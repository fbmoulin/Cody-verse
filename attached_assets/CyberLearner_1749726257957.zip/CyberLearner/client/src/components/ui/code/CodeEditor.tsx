import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Play, Copy, CheckCircle, XCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { evaluateChallengeSolution } from '@/lib/openai';

interface CodeEditorProps {
  initialCode?: string;
  language?: string;
  readOnly?: boolean;
  challengeId?: number;
  onEvaluate?: (correct: boolean) => void;
  className?: string;
}

const CodeEditor: React.FC<CodeEditorProps> = ({
  initialCode = '// Write your code here',
  language = 'javascript',
  readOnly = false,
  challengeId,
  onEvaluate,
  className = ''
}) => {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [evaluationResult, setEvaluationResult] = useState<{
    correct: boolean;
    feedback: string;
    hints?: string[];
  } | null>(null);
  const { toast } = useToast();

  const handleCodeChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (!readOnly) {
      setCode(e.target.value);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    toast({
      title: 'Code copied',
      description: 'Code has been copied to clipboard',
    });
  };

  const runCode = () => {
    setIsRunning(true);
    setOutput('');

    // This is a simulated code execution since we can't actually run code in the browser
    // In a production environment, this would send the code to a backend service
    setTimeout(() => {
      try {
        // Simulate output - in a real app this would execute on a backend
        let simulatedOutput;

        if (language === 'javascript' || language === 'typescript') {
          // Simulate JavaScript execution output
          simulatedOutput = `> Running ${language} code...\n`;
          simulatedOutput += `> Code executed successfully\n`;
          simulatedOutput += `> Output: Hello, world! This is a simulated execution.\n`;
          simulatedOutput += `> Executed in 0.24s`;
        } else if (language === 'python') {
          // Simulate Python execution output
          simulatedOutput = `>>> Running Python code...\n`;
          simulatedOutput += `>>> Code executed successfully\n`;
          simulatedOutput += `Hello, world! This is a simulated execution.\n`;
          simulatedOutput += `>>> Finished in 0.15s`;
        } else {
          simulatedOutput = `Running ${language} code is not supported in this demo.`;
        }

        setOutput(simulatedOutput);
      } catch (error) {
        setOutput(`Error: ${error instanceof Error ? error.message : String(error)}`);
      } finally {
        setIsRunning(false);
      }
    }, 1000);
  };

  const evaluateCode = async () => {
    if (!challengeId) return;
    
    setIsEvaluating(true);
    setEvaluationResult(null);
    
    try {
      const result = await evaluateChallengeSolution(challengeId, code);
      setEvaluationResult(result);
      
      if (onEvaluate) {
        onEvaluate(result.correct);
      }
      
      toast({
        title: result.correct ? 'Challenge Completed!' : 'Not Quite Right',
        description: result.correct 
          ? 'Congratulations! Your solution passed all tests.' 
          : 'Your solution needs some work. Check the feedback for hints.',
        variant: result.correct ? 'default' : 'destructive',
      });
    } catch (error) {
      toast({
        title: 'Evaluation Error',
        description: 'There was a problem evaluating your code. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsEvaluating(false);
    }
  };

  return (
    <div className={`rounded-md border border-gray-700 bg-gray-900/80 ${className}`}>
      <div className="flex items-center justify-between border-b border-gray-700 bg-gray-800 p-2">
        <div className="flex items-center">
          <span className="text-sm font-medium text-white/80">{language.toUpperCase()}</span>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleCopyCode}
            className="h-8 text-white/70 hover:text-white"
          >
            <Copy className="h-4 w-4 mr-1" />
            Copy
          </Button>
          {!readOnly && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={runCode}
                disabled={isRunning}
                className="h-8 border-primary/30 text-primary hover:bg-primary/20"
              >
                <Play className="h-4 w-4 mr-1" />
                Run
              </Button>
              {challengeId && (
                <Button
                  size="sm"
                  onClick={evaluateCode}
                  disabled={isEvaluating}
                  className="h-8 bg-secondary hover:bg-secondary/80 text-black"
                >
                  {isEvaluating ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="mr-1"
                    >
                      <Play className="h-4 w-4" />
                    </motion.div>
                  ) : (
                    <CheckCircle className="h-4 w-4 mr-1" />
                  )}
                  Evaluate
                </Button>
              )}
            </>
          )}
        </div>
      </div>
      
      <Tabs defaultValue="code">
        <TabsList className="bg-gray-800/50 border-b border-gray-700">
          <TabsTrigger value="code" className="data-[state=active]:bg-gray-900">Code</TabsTrigger>
          <TabsTrigger value="output" className="data-[state=active]:bg-gray-900">Output</TabsTrigger>
          {evaluationResult && (
            <TabsTrigger value="feedback" className="data-[state=active]:bg-gray-900">Feedback</TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value="code" className="m-0">
          <textarea
            value={code}
            onChange={handleCodeChange}
            readOnly={readOnly}
            className="w-full min-h-[300px] bg-gray-900 text-white font-mono p-4 outline-none resize-y"
            style={{ caretColor: '#FFD700' }}
          />
        </TabsContent>
        
        <TabsContent value="output" className="m-0">
          <div className="w-full min-h-[300px] bg-gray-900 text-white font-mono p-4 overflow-auto">
            {isRunning ? (
              <div className="flex items-center justify-center h-full">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="mr-2"
                >
                  <Play className="h-5 w-5 text-secondary" />
                </motion.div>
                <span>Running code...</span>
              </div>
            ) : output ? (
              <pre className="whitespace-pre-wrap">{output}</pre>
            ) : (
              <div className="flex items-center justify-center h-full text-white/50">
                Run your code to see output here
              </div>
            )}
          </div>
        </TabsContent>
        
        {evaluationResult && (
          <TabsContent value="feedback" className="m-0">
            <div className="w-full min-h-[300px] bg-gray-900 text-white p-4 overflow-auto">
              <div className="flex items-center mb-4">
                {evaluationResult.correct ? (
                  <>
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    <h3 className="text-lg font-medium text-green-500">Solution Correct!</h3>
                  </>
                ) : (
                  <>
                    <XCircle className="h-5 w-5 text-red-500 mr-2" />
                    <h3 className="text-lg font-medium text-red-500">Not Quite Right</h3>
                  </>
                )}
              </div>
              
              <div className="p-3 rounded border border-gray-700 mb-4">
                <h4 className="font-medium mb-2">Feedback:</h4>
                <p className="text-white/80">{evaluationResult.feedback}</p>
              </div>
              
              {!evaluationResult.correct && evaluationResult.hints && evaluationResult.hints.length > 0 && (
                <div className="p-3 rounded border border-secondary/30 bg-secondary/10">
                  <h4 className="font-medium mb-2 text-secondary">Hints:</h4>
                  <ul className="list-disc list-inside space-y-1 text-white/80">
                    {evaluationResult.hints.map((hint, index) => (
                      <li key={index}>{hint}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default CodeEditor;
