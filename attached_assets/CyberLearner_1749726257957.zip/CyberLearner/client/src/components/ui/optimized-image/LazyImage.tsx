import React, { useState, useEffect } from 'react';
import { useIntersectionObserver } from '@/hooks/use-intersection-observer';
import { OptimizedImage } from './index';

interface LazyImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  className?: string;
  fallbackSrc?: string;
  threshold?: number;
  rootMargin?: string;
}

/**
 * LazyImage component que carrega imagens apenas quando elas entram na viewport
 * Usa OptimizedImage para processamento de imagem e IntersectionObserver para lazy loading
 */
const LazyImage: React.FC<LazyImageProps> = ({
  src,
  alt,
  width,
  height,
  className = '',
  fallbackSrc = '/images/placeholder.jpg',
  threshold = 0.1,
  rootMargin = '200px',
}) => {
  const [ref, isVisible] = useIntersectionObserver<HTMLDivElement>({
    threshold,
    rootMargin,
    triggerOnce: true,
  });
  
  const [isLoaded, setIsLoaded] = useState(false);
  const [imageSrc, setImageSrc] = useState<string>(fallbackSrc);
  
  // Quando o componente se torna visível, carregamos a imagem real
  useEffect(() => {
    if (isVisible && !isLoaded) {
      setImageSrc(src);
      setIsLoaded(true);
    }
  }, [isVisible, src, isLoaded]);
  
  return (
    <div ref={ref} className={`relative ${className}`}>
      {isVisible ? (
        <OptimizedImage
          src={imageSrc}
          alt={alt}
          width={width}
          height={height}
          className={className}
          loading="lazy"
        />
      ) : (
        <div 
          className="bg-gray-800 animate-pulse rounded-sm" 
          style={{ width, height }}
          aria-hidden="true"
        />
      )}
    </div>
  );
};

export default React.memo(LazyImage);