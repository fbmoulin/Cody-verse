import React, { useState, useEffect } from 'react';

interface OptimizedImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  className?: string;
  priority?: boolean;
  loading?: 'lazy' | 'eager';
  onLoad?: () => void;
}

/**
 * OptimizedImage component for better performance and loading experience
 */
const OptimizedImage: React.FC<OptimizedImageProps> = ({
  src,
  alt,
  width,
  height,
  className = '',
  priority = false,
  loading = 'lazy',
  onLoad
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);

  // Use effect for image preloading when priority is true
  useEffect(() => {
    if (priority && src) {
      const img = new Image();
      img.src = src;
      img.onload = () => {
        setIsLoaded(true);
        if (onLoad) onLoad();
      };
      img.onerror = () => {
        setError(true);
      };
    }
  }, [src, priority, onLoad]);

  const handleImageLoad = () => {
    setIsLoaded(true);
    if (onLoad) onLoad();
  };

  const handleImageError = () => {
    setError(true);
  };

  return (
    <div className={`relative ${className}`} style={{ width, height }}>
      {!isLoaded && !error && (
        <div 
          className="absolute inset-0 bg-gray-800 animate-pulse rounded-sm"
          aria-hidden="true"
        />
      )}
      
      {error ? (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-800 rounded-sm">
          <div className="text-gray-400 text-sm">Imagem não disponível</div>
        </div>
      ) : (
        <img
          src={src}
          alt={alt}
          width={width}
          height={height}
          loading={priority ? 'eager' : loading}
          onLoad={handleImageLoad}
          onError={handleImageError}
          className={`${isLoaded ? 'opacity-100' : 'opacity-0'} transition-opacity duration-300 rounded-sm`}
        />
      )}
    </div>
  );
};

export default React.memo(OptimizedImage);