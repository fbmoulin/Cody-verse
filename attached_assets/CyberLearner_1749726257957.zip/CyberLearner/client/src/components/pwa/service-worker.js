// This file is a stub for development context
// The actual service worker is loaded from public/service-worker.js

// This comment helps developers understand where the actual service worker is located
// For PWA functionality, make changes to public/service-worker.js
console.log('Service worker stub - the actual implementation is in public/service-worker.js');
