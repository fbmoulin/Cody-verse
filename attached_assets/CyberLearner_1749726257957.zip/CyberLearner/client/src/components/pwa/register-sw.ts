// Service worker registration for PWA functionality with improved error handling and user feedback
import { toast } from '@/hooks/use-toast';

let registration: ServiceWorkerRegistration | null = null;
let installPrompt: any = null;

/**
 * Checks if service workers are supported in the current browser environment
 */
export function isServiceWorkerSupported(): boolean {
  return 'serviceWorker' in navigator;
}

/**
 * Registers the service worker for PWA functionality
 * Returns a promise that resolves with the registration object
 */
export function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  // Check if service workers are supported
  if (!isServiceWorkerSupported()) {
    // In development environments, this warning is expected and not a real issue
    if (import.meta.env.DEV) {
      console.info('Service workers are not supported in this development environment - this is normal');
    } else {
      console.warn('Service workers are not supported in this browser - some offline features may not work');
    }
    return Promise.resolve(null);
  }

  return navigator.serviceWorker.register('/service-worker.js')
    .then((reg) => {
      console.log('ServiceWorker registered successfully with scope:', reg.scope);
      registration = reg;

      // Listen for new content available
      reg.addEventListener('updatefound', () => {
        const newWorker = reg.installing;
        if (!newWorker) return;

        newWorker.addEventListener('statechange', () => {
          if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
            // New version available
            toast({
              title: "Application updated",
              description: "New content is available. Reload to update.",
              action: {
                label: "Reload",
                onClick: () => window.location.reload()
              }
            });
          }
        });
      });

      return reg;
    })
    .catch((error) => {
      console.error('ServiceWorker registration failed:', error);
      return null;
    });
}

/**
 * Returns true if there's a service worker active
 */
export function isServiceWorkerActive(): boolean {
  return !!registration && !!navigator.serviceWorker.controller;
}

/**
 * Setup the PWA install prompt event handler
 * Returns an object with methods to control the install prompt
 */
export function setupPWAInstallPrompt() {
  window.addEventListener('beforeinstallprompt', (e) => {
    // Prevent the default prompt
    e.preventDefault();
    // Save the event for later
    installPrompt = e;
  });
  
  // Listen for successful installation
  window.addEventListener('appinstalled', () => {
    console.log('Application was installed successfully');
    installPrompt = null;
    toast({
      title: "App Installed",
      description: "Cody Verse has been installed successfully!",
      variant: "success"
    });
  });
  
  return {
    /**
     * Shows the install prompt if available
     * @returns A promise that resolves to true if prompted, false otherwise
     */
    showInstallPrompt: async (): Promise<boolean> => {
      if (!installPrompt) return false;
      
      // Show the prompt
      installPrompt.prompt();
      
      // Wait for the user to respond
      const result = await installPrompt.userChoice;
      
      if (result.outcome === 'accepted') {
        console.log('User accepted the install prompt');
      } else {
        console.log('User dismissed the install prompt');
      }
      
      // Reset the prompt
      installPrompt = null;
      return true;
    },
    
    /**
     * Checks if the app is installable
     */
    isPWAInstallable: (): boolean => {
      return !!installPrompt;
    }
  };
}
