import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CHARACTERS, LOCALIZED_CONTENT } from '@/lib/constants';
import { sendAssistantPrompt } from '@/lib/openai';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Sparkles, MessageSquare, X, ChevronDown, ChevronUp, Zap } from 'lucide-react';
import CodyImage from '@/components/ui/characters/CodyImage';
import { useUserPreferences } from '@/hooks/use-preferences';

interface AssistantCharacterProps {
  character?: string; // Character identifier like "CODY", "NEXUS", etc.
  initialMessage?: string;
  context?: string;
  minimized?: boolean;
}

const AssistantCharacter: React.FC<AssistantCharacterProps> = ({
  character = "CODY", // Set default to Cody
  initialMessage,
  context,
  minimized = false
}) => {
  const { language } = useUserPreferences();
  const [isOpen, setIsOpen] = useState(!minimized);
  const [isExpanded, setIsExpanded] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const selectedCharacter = CHARACTERS[character as keyof typeof CHARACTERS] || CHARACTERS.CODY;
  const localizedContent = LOCALIZED_CONTENT[language];
  
  // Use localized welcome message or fallback to initial message
  const welcomeMessage = initialMessage || localizedContent.assistant_welcome;
  
  const [messages, setMessages] = useState<{text: string; isUser: boolean}[]>([
    { 
      text: welcomeMessage, 
      isUser: false 
    }
  ]);

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;
    
    // Add user message
    const newMessages = [...messages, { text: inputValue, isUser: true }];
    setMessages(newMessages);
    setInputValue('');
    setIsTyping(true);
    
    try {
      // Get assistant response from OpenAI with character context
      const response = await sendAssistantPrompt(inputValue, context, character);
      
      // Simulate typing effect
      setTimeout(() => {
        setMessages([...newMessages, { text: response, isUser: false }]);
        setIsTyping(false);
      }, 1000);
    } catch (error) {
      console.error("Error getting assistant response:", error);
      setTimeout(() => {
        setMessages([...newMessages, { text: "I'm having trouble connecting to my cyberbrain right now. Let's try again in a moment!", isUser: false }]);
        setIsTyping(false);
      }, 500);
    }
  };

  const toggleAssistant = () => {
    setIsOpen(!isOpen);
  };

  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div className="fixed bottom-20 right-4 md:bottom-4 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.8 }}
            transition={{ duration: 0.2 }}
            className="mb-4"
          >
            <Card 
              className={`w-[95vw] max-w-[320px] sm:max-w-none sm:w-96 bg-cardBackground border-primary/30 backdrop-blur-sm shadow-lg overflow-hidden
                ${isExpanded ? 'sm:w-[450px]' : 'sm:w-96'}`}
            >
              <div className="p-3 border-b border-gray-700 bg-gradient-to-r from-primary/20 to-secondary/20 flex justify-between items-center">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-primary/70 flex items-center justify-center bg-background">
                    {character === "CODY" && !selectedCharacter.imagePath ? (
                      <CodyImage />
                    ) : selectedCharacter.imagePath ? (
                      <img 
                        src={selectedCharacter.imagePath}
                        alt={selectedCharacter.name}
                        className="object-cover w-full h-full"
                      />
                    ) : (
                      <span className="text-2xl">{selectedCharacter.name[0]}</span>
                    )}
                  </div>
                  <div className="ml-2">
                    <h3 className="text-primary font-bold flex items-center">
                      {selectedCharacter.name}
                      <Sparkles size={12} className="ml-1 text-primary" />
                    </h3>
                    <p className="text-xs text-white/70">{selectedCharacter.species}</p>
                  </div>
                </div>
                <div className="flex space-x-1">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={toggleExpand} 
                    className="text-white/70 hover:text-white"
                  >
                    {isExpanded ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={toggleAssistant} 
                    className="text-white/70 hover:text-white"
                  >
                    <X size={18} />
                  </Button>
                </div>
              </div>
              
              {isExpanded && (
                <div className="px-3 py-2 border-b border-gray-700 bg-gray-900/50">
                  <p className="text-xs text-white/70 italic">
                    {selectedCharacter.description}
                  </p>
                  <div className="mt-2 flex items-center text-xs text-white/60">
                    <div className="flex items-center mr-3">
                      <div className="w-2 h-2 rounded-full bg-primary mr-1"></div>
                      <span>Tech-savvy</span>
                    </div>
                    <div className="flex items-center mr-3">
                      <div className="w-2 h-2 rounded-full bg-secondary mr-1"></div>
                      <span>AI expert</span>
                    </div>
                    <div className="flex items-center">
                      <div className="w-2 h-2 rounded-full bg-accent mr-1"></div>
                      <span>Cybersecurity guide</span>
                    </div>
                  </div>
                </div>
              )}
              
              <CardContent className="p-3">
                <div 
                  className={`${isExpanded ? 'h-80' : 'h-72'} overflow-y-auto mb-3 p-2
                    scrollbar-thin scrollbar-thumb-primary/30 scrollbar-track-background/30
                    border border-gray-800/50 rounded-md bg-background/30`}
                >
                  {messages.map((message, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      className={`mb-3 flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
                    >
                      {!message.isUser && (
                        <div className="w-8 h-8 rounded-full overflow-hidden mr-2 flex-shrink-0 border border-primary/50">
                          {character === "CODY" && !selectedCharacter.imagePath ? (
                            <CodyImage />
                          ) : selectedCharacter.imagePath ? (
                            <img 
                              src={selectedCharacter.imagePath} 
                              alt={selectedCharacter.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full bg-primary/20 flex items-center justify-center">
                              <span className="text-sm text-primary font-bold">{selectedCharacter.name[0]}</span>
                            </div>
                          )}
                        </div>
                      )}
                      
                      <div 
                        className={`p-3 rounded-md max-w-[75%] ${
                          message.isUser 
                            ? 'bg-primary/20 text-white border border-primary/40 shadow-sm shadow-primary/10' 
                            : 'bg-secondary/20 text-white border border-secondary/40 shadow-sm shadow-secondary/10'
                        }`}
                      >
                        {message.text}
                      </div>
                      
                      {message.isUser && (
                        <div className="w-8 h-8 rounded-full overflow-hidden ml-2 flex-shrink-0 bg-gray-800/80 border border-gray-700 flex items-center justify-center">
                          <span className="text-sm text-white/80">You</span>
                        </div>
                      )}
                    </motion.div>
                  ))}
                  {isTyping && (
                    <div className="flex justify-start mb-3">
                      <div className="w-8 h-8 rounded-full overflow-hidden mr-2 flex-shrink-0 border border-primary/50">
                        {character === "CODY" && !selectedCharacter.imagePath ? (
                          <CodyImage />
                        ) : selectedCharacter.imagePath ? (
                          <img 
                            src={selectedCharacter.imagePath} 
                            alt={selectedCharacter.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full bg-primary/20 flex items-center justify-center">
                            <span className="text-sm text-primary font-bold">{selectedCharacter.name[0]}</span>
                          </div>
                        )}
                      </div>
                      <div className="p-3 rounded-md bg-secondary/20 text-white border border-secondary/40">
                        <motion.div
                          animate={{ opacity: [0.4, 1, 0.4] }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                          className="flex items-center"
                        >
                          <span className="mr-2">{localizedContent.assistant_thinking}</span>
                          <span className="flex space-x-1">
                            <motion.span
                              animate={{ y: [0, -3, 0] }}
                              transition={{ duration: 0.5, repeat: Infinity, delay: 0 }}
                            >.</motion.span>
                            <motion.span
                              animate={{ y: [0, -3, 0] }}
                              transition={{ duration: 0.5, repeat: Infinity, delay: 0.2 }}
                            >.</motion.span>
                            <motion.span
                              animate={{ y: [0, -3, 0] }}
                              transition={{ duration: 0.5, repeat: Infinity, delay: 0.4 }}
                            >.</motion.span>
                          </span>
                        </motion.div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
                <div className="flex gap-2">
                  <Textarea
                    placeholder={localizedContent.assistant_placeholder}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
                    className="min-h-[60px] bg-background/50 border-gray-700 text-white placeholder:text-gray-400 focus:border-primary/50 focus:ring-1 focus:ring-primary/30"
                  />
                  <Button 
                    onClick={handleSendMessage} 
                    className="bg-primary hover:bg-primary/80 text-black font-semibold"
                  >
                    <Zap size={16} className="mr-1" />
                    {localizedContent.send_button}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {!isOpen && (
        <motion.button
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={toggleAssistant}
          className="w-16 h-16 rounded-full bg-primary text-black flex items-center justify-center shadow-lg shadow-primary/30 border-2 border-primary/70 overflow-hidden"
        >
          {character === "CODY" && !selectedCharacter.imagePath ? (
            <CodyImage />
          ) : selectedCharacter.imagePath ? (
            <img 
              src={selectedCharacter.imagePath} 
              alt={selectedCharacter.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <Sparkles size={28} />
          )}
        </motion.button>
      )}
    </div>
  );
};

export default AssistantCharacter;
