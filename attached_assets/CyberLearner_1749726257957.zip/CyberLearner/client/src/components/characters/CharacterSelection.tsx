import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CHARACTERS } from '@/lib/constants';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Check } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import CodyImage from '@/components/ui/characters/CodyImage';
import NexusImage from '@/components/ui/characters/NexusImage.jsx';
import EchoImage from '@/components/ui/characters/EchoImage.jsx';

interface CharacterSelectionProps {
  selectedCharacter: string;
  onCharacterSelect: (character: string) => void;
  userId: number;
  compact?: boolean;
}

const CharacterSelection: React.FC<CharacterSelectionProps> = ({
  selectedCharacter,
  onCharacterSelect,
  userId,
  compact = false
}) => {
  const [isLoading, setIsLoading] = useState<string | null>(null);

  // Function to handle character selection and persist to backend
  const handleSelectCharacter = async (characterId: string) => {
    if (characterId === selectedCharacter) return;
    
    setIsLoading(characterId);
    try {
      // Update user preference on backend
      await apiRequest('PATCH', `/api/users/${userId}/preferences`, {
        preferredCharacter: characterId
      });
      
      onCharacterSelect(characterId);
      toast({
        title: `${CHARACTERS[characterId as keyof typeof CHARACTERS].name} selected`,
        description: `Your new AI assistant is ready to help!`
      });
    } catch (error) {
      console.error('Failed to update character preference:', error);
      toast({
        title: 'Error',
        description: 'Could not change your assistant character. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(null);
    }
  };

  return (
    <div className={`grid ${compact ? 'grid-cols-1 gap-3' : 'grid-cols-1 md:grid-cols-3 gap-4'}`}>
      {Object.entries(CHARACTERS).map(([id, character]) => (
        <Card 
          key={id} 
          className={`border ${
            selectedCharacter === id 
              ? `border-2 border-${character.color} bg-black/40` 
              : 'border-gray-800 bg-gray-900/40'
          } transition-all hover:border-gray-700 cursor-pointer overflow-hidden`}
          onClick={() => handleSelectCharacter(id)}
        >
          <CardContent className="p-0">
            <div className="relative">
              <div 
                className="absolute inset-0 opacity-20" 
                style={{ 
                  background: `radial-gradient(circle at center, ${character.color}, transparent 70%)` 
                }}
              />
              
              <div className="px-4 py-3 border-b border-gray-800 flex justify-between items-center">
                <div className="flex items-center">
                  <div 
                    className="w-10 h-10 rounded-full overflow-hidden border-2 flex items-center justify-center"
                    style={{ borderColor: character.color }}
                  >
                    {id === "CODY" ? (
                      <CodyImage />
                    ) : id === "NEXUS" ? (
                      <NexusImage />
                    ) : id === "ECHO" ? (
                      <EchoImage />
                    ) : (
                      <Sparkles style={{ color: character.color }} size={16} />
                    )}
                  </div>
                  <div className="ml-2">
                    <h3 className="font-bold flex items-center" style={{ color: character.color }}>
                      {character.name}
                      <Sparkles size={12} className="ml-1" style={{ color: character.color }} />
                    </h3>
                    <p className="text-xs text-white/70">{character.species}</p>
                  </div>
                </div>
                
                {selectedCharacter === id && (
                  <Badge 
                    variant="outline" 
                    className="bg-primary/20 text-primary border-primary/30"
                  >
                    <Check size={12} className="mr-1" />
                    Active
                  </Badge>
                )}
              </div>
              
              <div className="p-4">
                <p className="text-sm text-white/80 mb-3">{character.description}</p>
                
                <div className="mb-3">
                  <p className="text-xs text-white/60 mb-2">Specialties:</p>
                  <div className="flex flex-wrap gap-2">
                    {character.specialties?.map((specialty, index) => (
                      <Badge 
                        key={index} 
                        variant="secondary"
                        className="bg-black/30 text-white/80 border border-gray-700"
                      >
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <Button 
                  variant={selectedCharacter === id ? "default" : "outline"} 
                  className="w-full"
                  style={{ 
                    backgroundColor: selectedCharacter === id ? character.color : 'transparent',
                    borderColor: character.color,
                    color: selectedCharacter === id ? 'black' : character.color
                  }}
                  disabled={isLoading === id}
                >
                  {isLoading === id 
                    ? 'Selecting...' 
                    : selectedCharacter === id 
                      ? 'Currently Selected' 
                      : 'Select Assistant'
                  }
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default CharacterSelection;