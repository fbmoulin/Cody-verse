import { apiRequest } from "./queryClient";

// This function sends user prompts to the backend which will handle the OpenAI calls
export async function sendAssistantPrompt(prompt: string, context?: string, character?: string): Promise<string> {
  try {
    const data = await apiRequest('POST', '/api/assistant', {
      prompt,
      context: context || null,
      character: character || "CODY"
    });
    
    // Return the response from the OpenAI API
    if (data && typeof data === 'object' && 'response' in data) {
      const responseText = data.response;
      return typeof responseText === 'string' ? responseText : String(responseText);
    }
    
    throw new Error("Invalid response format from assistant API");
  } catch (error) {
    console.error("Error sending prompt to assistant:", error);
    
    // Check if it's an API key error
    if (error instanceof Error && 
        (error.message.includes("API key") || 
         (typeof error === 'object' && error.toString().includes("needsApiKey")))) {
      return "I need an OpenAI API key to connect to my neural network. Please provide it to continue our conversation.";
    }
    
    return "I'm having trouble connecting to my cyberbrain right now. Please try again in a moment.";
  }
}

// A function to evaluate challenge solutions
export async function evaluateChallengeSolution(
  challengeId: number, 
  solution: string
): Promise<{
  correct: boolean;
  feedback: string;
  hints?: string[];
}> {
  try {
    const response = await apiRequest('POST', `/api/challenges/${challengeId}/evaluate`, {
      solution
    });
    
    // For demo purposes we'll simulate an API response
    // This would be replaced with actual OpenAI evaluation in production
    
    const isCorrect = Math.random() > 0.3; // 70% chance of success for demo
    
    if (isCorrect) {
      return {
        correct: true,
        feedback: "Great job! Your solution correctly implements the required functionality."
      };
    } else {
      return {
        correct: false,
        feedback: "Your solution is close, but there are some issues to address.",
        hints: [
          "Check if you've handled all the edge cases",
          "Make sure your agent responds correctly to all prompt types"
        ]
      };
    }
  } catch (error) {
    console.error("Error evaluating solution:", error);
    return {
      correct: false,
      feedback: "There was an error evaluating your solution. Please try again."
    };
  }
}
