// Performance optimization utilities
export class PerformanceOptimizer {
  private static instance: PerformanceOptimizer;
  private observers: Map<string, PerformanceObserver> = new Map();
  private metrics: Map<string, number[]> = new Map();

  static getInstance(): PerformanceOptimizer {
    if (!PerformanceOptimizer.instance) {
      PerformanceOptimizer.instance = new PerformanceOptimizer();
    }
    return PerformanceOptimizer.instance;
  }

  // Debounce function for expensive operations
  debounce<T extends (...args: any[]) => any>(
    func: T,
    wait: number
  ): (...args: Parameters<T>) => void {
    let timeout: NodeJS.Timeout;
    return (...args: Parameters<T>) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => func.apply(this, args), wait);
    };
  }

  // Throttle function for frequent events
  throttle<T extends (...args: any[]) => any>(
    func: T,
    limit: number
  ): (...args: Parameters<T>) => void {
    let inThrottle: boolean;
    return (...args: Parameters<T>) => {
      if (!inThrottle) {
        func.apply(this, args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  }

  // Measure component render performance
  measureRender(componentName: string, renderFn: () => void): void {
    const start = performance.now();
    renderFn();
    const end = performance.now();
    const duration = end - start;

    if (!this.metrics.has(componentName)) {
      this.metrics.set(componentName, []);
    }
    this.metrics.get(componentName)!.push(duration);

    // Keep only last 50 measurements
    const measurements = this.metrics.get(componentName)!;
    if (measurements.length > 50) {
      measurements.shift();
    }

    // Log performance warning if render takes too long
    if (duration > 16) {
      console.warn(`Slow render detected for ${componentName}: ${duration.toFixed(2)}ms`);
    }
  }

  // Get average render time for a component
  getAverageRenderTime(componentName: string): number {
    const measurements = this.metrics.get(componentName);
    if (!measurements || measurements.length === 0) return 0;
    
    return measurements.reduce((sum, time) => sum + time, 0) / measurements.length;
  }

  // Lazy load components with intersection observer
  createLazyLoader(threshold: number = 0.1) {
    return new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const element = entry.target as HTMLElement;
            const loadEvent = new CustomEvent('lazy-load', { 
              detail: { element } 
            });
            element.dispatchEvent(loadEvent);
          }
        });
      },
      { threshold }
    );
  }

  // Memory usage monitoring
  getMemoryUsage(): any {
    if ('memory' in performance) {
      return {
        used: Math.round((performance as any).memory.usedJSHeapSize / 1048576),
        total: Math.round((performance as any).memory.totalJSHeapSize / 1048576),
        limit: Math.round((performance as any).memory.jsHeapSizeLimit / 1048576)
      };
    }
    return null;
  }

  // Bundle size analyzer
  analyzeBundleSize(): void {
    if (import.meta.env.DEV) {
      console.group('Bundle Analysis');
      const scripts = Array.from(document.querySelectorAll('script[src]'));
      scripts.forEach((script: any) => {
        if (script.src.includes('localhost')) {
          console.log(`Script: ${script.src.split('/').pop()}`);
        }
      });
      console.groupEnd();
    }
  }
}

// Cache management for API responses
export class CacheManager {
  private static cache = new Map<string, { data: any; timestamp: number; ttl: number }>();

  static set(key: string, data: any, ttl: number = 5 * 60 * 1000): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
  }

  static get(key: string): any | null {
    const cached = this.cache.get(key);
    if (!cached) return null;

    if (Date.now() - cached.timestamp > cached.ttl) {
      this.cache.delete(key);
      return null;
    }

    return cached.data;
  }

  static clear(): void {
    this.cache.clear();
  }

  static size(): number {
    return this.cache.size;
  }
}

// Resource preloader for critical assets
export class ResourcePreloader {
  private static preloadedResources = new Set<string>();

  static preloadImage(src: string): Promise<void> {
    if (this.preloadedResources.has(src)) return Promise.resolve();

    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        this.preloadedResources.add(src);
        resolve();
      };
      img.onerror = reject;
      img.src = src;
    });
  }

  static preloadFont(fontFamily: string, fontWeight: string = '400'): void {
    if (this.preloadedResources.has(`${fontFamily}-${fontWeight}`)) return;

    const link = document.createElement('link');
    link.rel = 'preload';
    link.as = 'font';
    link.type = 'font/woff2';
    link.crossOrigin = 'anonymous';
    link.href = `https://fonts.googleapis.com/css2?family=${fontFamily}:wght@${fontWeight}&display=swap`;
    
    document.head.appendChild(link);
    this.preloadedResources.add(`${fontFamily}-${fontWeight}`);
  }
}

export const perf = PerformanceOptimizer.getInstance();