// Comprehensive code quality and refactoring utilities
import React from 'react';

class CodeQualityAnalyzer {
  private static metrics = new Map<string, any>();
  
  // Analyze component complexity
  static analyzeComplexity(componentName: string, props: any, state: any): number {
    let complexity = 1;
    
    // Add complexity for each prop
    complexity += Object.keys(props || {}).length * 0.5;
    
    // Add complexity for state
    complexity += Object.keys(state || {}).length;
    
    // Add complexity for nested objects
    const countNested = (obj: any, depth = 0): number => {
      if (depth > 3) return 10; // Penalize deep nesting
      if (typeof obj !== 'object' || obj === null) return 0;
      
      return Object.values(obj).reduce((acc: number, val: unknown) => {
        return acc + countNested(val, depth + 1);
      }, 1);
    };
    
    complexity += countNested(props) + countNested(state);
    
    this.metrics.set(`${componentName}_complexity`, complexity);
    return complexity;
  }
  
  // Track code quality metrics
  static trackMetric(key: string, value: number): void {
    if (!this.metrics.has(key)) {
      this.metrics.set(key, []);
    }
    
    const values = this.metrics.get(key);
    values.push(value);
    
    // Keep only last 100 measurements
    if (values.length > 100) {
      values.shift();
    }
  }
  
  // Generate quality report
  static getQualityReport(): object {
    const report: any = { components: {}, overall: {} };
    
    for (const [key, value] of Array.from(this.metrics.entries())) {
      if (key.endsWith('_complexity')) {
        const componentName = key.replace('_complexity', '');
        report.components[componentName] = {
          complexity: value,
          quality: value < 5 ? 'good' : value < 10 ? 'moderate' : 'needs_refactoring'
        };
      }
    }
    
    return report;
  }
}

// Automatic error boundary with recovery
class SmartErrorBoundary {
  private static errorCount = 0;
  private static lastError: Error | null = null;
  
  static handleError(error: Error, errorInfo: any): void {
    this.errorCount++;
    this.lastError = error;
    
    // Log error with context
    console.error('Component Error:', {
      error: error.message,
      stack: error.stack,
      info: errorInfo,
      count: this.errorCount,
      timestamp: new Date().toISOString()
    });
    
    // Suggest recovery actions
    if (this.errorCount > 3) {
      console.warn('Multiple errors detected. Consider refreshing the page.');
    }
  }
  
  static getErrorStats(): object {
    return {
      totalErrors: this.errorCount,
      lastError: this.lastError?.message || 'None',
      needsAttention: this.errorCount > 3
    };
  }
}

// Performance-aware component wrapper
export function withQualityTracking<P extends object>(
  Component: React.ComponentType<P>,
  componentName: string
) {
  return function QualityTrackedComponent(props: P) {
    const startTime = performance.now();
    
    React.useEffect(() => {
      const endTime = performance.now();
      const renderTime = endTime - startTime;
      
      // Track performance
      CodeQualityAnalyzer.trackMetric(`${componentName}_render_time`, renderTime);
      
      // Analyze complexity
      const complexity = CodeQualityAnalyzer.analyzeComplexity(
        componentName, 
        props, 
        null // State would need to be passed separately in a real implementation
      );
      
      // Warn about quality issues
      if (renderTime > 50) {
        console.warn(`Slow render: ${componentName} took ${renderTime.toFixed(2)}ms`);
      }
      
      if (complexity > 10) {
        console.warn(`High complexity: ${componentName} complexity is ${complexity}`);
      }
    });
    
    return React.createElement(Component, props);
  };
}

// Bundle size analyzer
class BundleAnalyzer {
  private static loadedModules = new Set<string>();
  
  static trackModule(moduleName: string, size?: number): void {
    this.loadedModules.add(moduleName);
    
    if (size) {
      CodeQualityAnalyzer.trackMetric('bundle_size', size);
    }
  }
  
  static getBundleReport(): object {
    return {
      totalModules: this.loadedModules.size,
      loadedModules: Array.from(this.loadedModules),
      estimatedSize: this.loadedModules.size * 50 // Rough estimate
    };
  }
}

// Accessibility checker
class AccessibilityChecker {
  static checkElement(element: HTMLElement): string[] {
    const issues: string[] = [];
    
    // Check for missing alt text on images
    if (element.tagName === 'IMG' && !element.getAttribute('alt')) {
      issues.push('Image missing alt text');
    }
    
    // Check for missing labels on form elements
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(element.tagName)) {
      const hasLabel = element.getAttribute('aria-label') || 
                      element.getAttribute('aria-labelledby') ||
                      document.querySelector(`label[for="${element.id}"]`);
      
      if (!hasLabel) {
        issues.push('Form element missing label');
      }
    }
    
    // Check color contrast (simplified)
    const styles = window.getComputedStyle(element);
    const background = styles.backgroundColor;
    const color = styles.color;
    
    if (background === 'rgb(255, 255, 255)' && color === 'rgb(255, 255, 255)') {
      issues.push('Poor color contrast detected');
    }
    
    return issues;
  }
  
  static scanPage(): object {
    const allElements = document.querySelectorAll('*');
    const issues: { [key: string]: string[] } = {};
    
    allElements.forEach((element, index) => {
      const elementIssues = this.checkElement(element as HTMLElement);
      if (elementIssues.length > 0) {
        issues[`element_${index}`] = elementIssues;
      }
    });
    
    return {
      totalElements: allElements.length,
      elementsWithIssues: Object.keys(issues).length,
      issues
    };
  }
}

// SEO optimizer
class SEOOptimizer {
  static analyzePage(): object {
    const score = {
      title: 0,
      description: 0,
      headings: 0,
      images: 0,
      total: 0
    };
    
    // Check title
    const title = document.title;
    if (title && title.length > 10 && title.length < 60) {
      score.title = 100;
    } else {
      score.title = title ? 50 : 0;
    }
    
    // Check meta description
    const description = document.querySelector('meta[name="description"]');
    if (description && description.getAttribute('content')) {
      const content = description.getAttribute('content')!;
      score.description = content.length > 120 && content.length < 160 ? 100 : 50;
    }
    
    // Check heading structure
    const h1s = document.querySelectorAll('h1');
    const h2s = document.querySelectorAll('h2');
    score.headings = h1s.length === 1 && h2s.length > 0 ? 100 : 50;
    
    // Check images
    const images = document.querySelectorAll('img');
    const imagesWithAlt = document.querySelectorAll('img[alt]');
    score.images = images.length > 0 ? (imagesWithAlt.length / images.length) * 100 : 100;
    
    score.total = (score.title + score.description + score.headings + score.images) / 4;
    
    return score;
  }
}

// Automated refactoring suggestions
class RefactoringSuggester {
  static analyzeComponent(componentCode: string): string[] {
    const suggestions: string[] = [];
    
    // Check for inline styles
    if (componentCode.includes('style={{')) {
      suggestions.push('Consider extracting inline styles to CSS classes');
    }
    
    // Check for large components
    const lines = componentCode.split('\n').length;
    if (lines > 200) {
      suggestions.push('Component is large - consider breaking into smaller components');
    }
    
    // Check for prop drilling
    const propCount = (componentCode.match(/props\./g) || []).length;
    if (propCount > 10) {
      suggestions.push('Consider using Context API to avoid prop drilling');
    }
    
    // Check for missing keys in lists
    if (componentCode.includes('.map(') && !componentCode.includes('key=')) {
      suggestions.push('Add keys to list items for better performance');
    }
    
    return suggestions;
  }
}

// Global quality monitoring
class QualityMonitor {
  private static isInitialized = false;
  
  static initialize(): void {
    if (this.isInitialized || typeof window === 'undefined') return;
    
    // Monitor uncaught errors
    window.addEventListener('error', (event) => {
      SmartErrorBoundary.handleError(event.error, {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno
      });
    });
    
    // Monitor promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      SmartErrorBoundary.handleError(
        new Error(event.reason), 
        { type: 'unhandled_promise_rejection' }
      );
    });
    
    // Periodic quality checks
    setInterval(() => {
      const accessibilityReport = AccessibilityChecker.scanPage();
      const seoReport = SEOOptimizer.analyzePage();
      const bundleReport = BundleAnalyzer.getBundleReport();
      
      console.log('Quality Report:', {
        accessibility: accessibilityReport,
        seo: seoReport,
        bundle: bundleReport,
        timestamp: new Date().toISOString()
      });
    }, 60000); // Every minute
    
    this.isInitialized = true;
  }
  
  static getOverallScore(): number {
    const seoReport = SEOOptimizer.analyzePage() as { total: number };
    const qualityReport = CodeQualityAnalyzer.getQualityReport();
    const errorStats = SmartErrorBoundary.getErrorStats() as { totalErrors: number };
    
    // Calculate weighted score
    let score = seoReport.total * 0.3; // 30% SEO
    score += (errorStats.totalErrors === 0 ? 100 : Math.max(0, 100 - errorStats.totalErrors * 10)) * 0.4; // 40% error-free
    score += 70 * 0.3; // 30% baseline quality score
    
    return Math.round(score);
  }
}

// Initialize quality monitoring
if (typeof window !== 'undefined') {
  QualityMonitor.initialize();
}

export {
  CodeQualityAnalyzer,
  SmartErrorBoundary,
  BundleAnalyzer,
  AccessibilityChecker,
  SEOOptimizer,
  RefactoringSuggester,
  QualityMonitor
};