// Theme colors
export const COLORS = {
  primary: "#FFD700", // cyber yellow
  secondary: "#00FFFF", // neon cyan
  background: "#1A1A1A", // dark grey
  accent: "#FF1493", // neon pink
  text: "#FFFFFF", // white
  darkBackground: "#0F0F0F",
  lightBackground: "#2A2A2A",
  success: "#00FF00", // neon green
  warning: "#FFA500", // orange
  error: "#FF0000", // red
  cardBackground: "rgba(26, 26, 26, 0.8)",
  highlightBg: "rgba(255, 215, 0, 0.15)",
};

// Assistant characters
export const CHARACTERS = {
  CODY: {
    name: "Cody",
    species: "Gato Cibernético",
    color: COLORS.primary,
    personality: "Inteligente e entusiasta de tecnologia",
    description: "Um gato amarelo brilhante com óculos cibernéticos, faixa tecnológica na cabeça e uma jaqueta futurista. Cody é seu companheiro de IA para o aprendizado.",
    specialties: ["Fundamentos de IA", "Orientação tecnológica", "Suporte para iniciantes"],
    imagePath: null // Usando o componente SVG incorporado
  },
  NEXUS: {
    name: "Nexus",
    species: "Raposa Digital",
    color: COLORS.secondary,
    personality: "Estratégico e analítico",
    description: "Uma raposa azul neon com interfaces holográficas avançadas. Nexus é especialista em arquitetura profunda de IA e otimização de sistemas.",
    specialties: ["Conceitos avançados de IA", "Arquitetura de sistemas", "Otimização de desempenho"],
    imagePath: null
  },
  ECHO: {
    name: "Echo",
    species: "Corvo Quântico",
    color: COLORS.accent,
    personality: "Criativo e intuitivo",
    description: "Um corvo preto elegante com destaques digitais em rosa. Echo se destaca em soluções criativas de problemas e aplicações inovadoras de IA.",
    specialties: ["Soluções criativas de IA", "Desenvolvimento de projetos", "Técnicas avançadas"],
    imagePath: null
  }
};

// Define o tipo para o conteúdo localizado
type LocalizedContent = {
  // Assistant messages
  assistant_welcome: string;
  assistant_placeholder: string;
  assistant_thinking: string;
  send_button: string;
  
  // Navigation
  nav_home: string;
  nav_learning: string;
  nav_projects: string;
  nav_achievements: string;
  nav_profile: string;
  nav_logout: string;
  nav_settings: string;
  
  // Home page
  welcome_title: string;
  welcome_subtitle: string;
  get_started: string;
  continue_learning: string;
  
  // Learning section
  modules_title: string;
  module_progress: string;
  difficulty_beginner: string;
  difficulty_intermediate: string;
  difficulty_advanced: string;
  difficulty_expert: string;
  start_module: string;
  continue_module: string;
  est_time: string;
  xp_reward: string;
  
  // Challenge section
  challenge_title: string;
  challenge_description: string;
  challenge_submit: string;
  challenge_reset: string;
  challenge_hint: string;
  challenge_complete: string;
  challenge_next: string;
  challenge_previous: string;
  
  // Authentication
  login_title: string;
  login_description: string;
  register_title: string;
  register_description: string;
  username_label: string;
  password_label: string;
  display_name_label: string;
  login_button: string;
  register_button: string;
  register_prompt: string;
  login_prompt: string;
  register_link: string;
  login_link: string;
  error_login: string;
  error_register: string;
  success_register: string;
  success_login: string;
  field_required: string;
  processing: string;
  
  // Logout
  logout_success_title: string;
  logout_success_message: string;
  error_title: string;
  error_logout: string;
  
  // Tutorial
  tutorial_welcome_title: string;
  tutorial_welcome_content: string;
  tutorial_nav_title: string;
  tutorial_nav_content: string;
  tutorial_modules_title: string;
  tutorial_modules_content: string;
  tutorial_assistant_title: string;
  tutorial_assistant_content: string;
  tutorial_profile_title: string;
  tutorial_profile_content: string;
  tutorial_prev: string;
  tutorial_next: string;
  tutorial_finish: string;
  
  // Achievements
  achievement_unlocked: string;
  achievement_progress: string;
  
  // Profile
  profile_level: string;
  profile_xp: string;
  profile_next_level: string;
  profile_achievements: string;
  profile_modules_completed: string;
  profile_challenges_completed: string;
  
  // Misc
  language_selector: string;
  tech_savvy: string;
  ai_expert: string;
  cybersecurity_guide: string;
  loading: string;
  error_generic: string;
  try_again: string;
  save: string;
  cancel: string;
  settings: string;
  theme: string;
  theme_light: string;
  theme_dark: string;
  theme_system: string;
};

// Localized content
export const LOCALIZED_CONTENT: Record<string, LocalizedContent> = {
  'en': {
    // Assistant messages
    assistant_welcome: "Welcome to Cody Verse! I'm Cody, your AI and cybersecurity assistant. I can help with AI concepts, MCP server architecture, data security, and more. How can I help with your learning journey today?",
    assistant_placeholder: "Ask Cody anything...",
    assistant_thinking: "Thinking",
    send_button: "Send",
    
    // Navigation
    nav_home: "Home",
    nav_learning: "Learning",
    nav_projects: "Projects",
    nav_achievements: "Achievements",
    nav_profile: "Profile",
    nav_logout: "Log out",
    nav_settings: "Settings",
    
    // Home page
    welcome_title: "Welcome to Cody Verse",
    welcome_subtitle: "Your AI Learning Platform",
    get_started: "Get Started",
    continue_learning: "Continue Learning",
    
    // Learning section
    modules_title: "Learning Modules",
    module_progress: "Progress",
    difficulty_beginner: "Beginner",
    difficulty_intermediate: "Intermediate",
    difficulty_advanced: "Advanced",
    difficulty_expert: "Expert",
    start_module: "Start Module",
    continue_module: "Continue",
    est_time: "Est. time",
    xp_reward: "XP Reward",
    
    // Challenge section
    challenge_title: "Challenge",
    challenge_description: "Challenge Description",
    challenge_submit: "Submit Answer",
    challenge_reset: "Reset",
    challenge_hint: "Hint",
    challenge_complete: "Challenge Completed!",
    challenge_next: "Next Challenge",
    challenge_previous: "Previous Challenge",
    
    // Logout
    logout_success_title: "Logged out",
    logout_success_message: "You have been logged out successfully.",
    error_title: "Error",
    error_logout: "Failed to logout. Please try again.",
    
    // Tutorial
    tutorial_welcome_title: "Welcome to Cody Verse!",
    tutorial_welcome_content: "Let's take a quick tour of the platform. I'm Cody, your guide on this learning journey!",
    tutorial_nav_title: "Navigation",
    tutorial_nav_content: "Here you'll find the main sections of the platform: Learning, Projects, Achievements, and Profile.",
    tutorial_modules_title: "Learning Modules",
    tutorial_modules_content: "Explore our interactive modules about AI, security, and programming, organized by difficulty level.",
    tutorial_assistant_title: "AI Assistant",
    tutorial_assistant_content: "Click on Cody's icon anytime to get help, ask questions or chat about any topic.",
    tutorial_profile_title: "Your Profile",
    tutorial_profile_content: "Track your progress, level, and achievements. The more you learn, the more XP you earn!",
    tutorial_prev: "Previous",
    tutorial_next: "Next",
    tutorial_finish: "Finish",
    
    // Achievements
    achievement_unlocked: "Achievement Unlocked!",
    achievement_progress: "Achievement Progress",
    
    // Profile
    profile_level: "Level",
    profile_xp: "Experience (XP)",
    profile_next_level: "Next level",
    profile_achievements: "Achievements",
    profile_modules_completed: "Modules Completed",
    profile_challenges_completed: "Challenges Completed",
    
    // Authentication
    login_title: "Login",
    login_description: "Welcome back to the CodyVerse platform",
    register_title: "Register",
    register_description: "Create your account on the CodyVerse platform",
    username_label: "Username",
    password_label: "Password",
    display_name_label: "Display Name",
    login_button: "Login",
    register_button: "Register",
    register_prompt: "Don't have an account?",
    login_prompt: "Already have an account?",
    register_link: "Register",
    login_link: "Login",
    error_login: "Login failed. Please check your username and password.",
    error_register: "Registration failed. This username may already be in use.",
    success_register: "Registration successful!",
    success_login: "Login successful!",
    field_required: "This field is required",
    processing: "Processing...",
    
    // Misc
    language_selector: "Language",
    tech_savvy: "Tech-savvy",
    ai_expert: "AI expert",
    cybersecurity_guide: "Cybersecurity guide",
    loading: "Loading...",
    error_generic: "An error occurred. Please try again later.",
    try_again: "Try again",
    save: "Save",
    cancel: "Cancel",
    settings: "Settings",
    theme: "Theme",
    theme_light: "Light",
    theme_dark: "Dark",
    theme_system: "System"
  },
  'pt-br': {
    // Authentication
    login_title: "Entrar",
    login_description: "Bem-vindo de volta à plataforma CodyVerse",
    register_title: "Registrar",
    register_description: "Crie sua conta na plataforma CodyVerse",
    username_label: "Nome de usuário",
    password_label: "Senha",
    display_name_label: "Nome de exibição",
    login_button: "Entrar",
    register_button: "Registrar",
    register_prompt: "Não tem uma conta?",
    login_prompt: "Já tem uma conta?",
    register_link: "Registrar",
    login_link: "Entrar",
    error_login: "Falha no login. Verifique seu nome de usuário e senha.",
    error_register: "Falha no registro. Este nome de usuário já pode estar em uso.",
    success_register: "Registro realizado com sucesso!",
    success_login: "Login realizado com sucesso!",
    field_required: "Este campo é obrigatório",
    processing: "Processando...",
    
    // Assistant messages
    assistant_welcome: "Bem-vindo ao Cody Verse! Sou Cody, seu assistente especializado em inteligência artificial e cibersegurança. Posso ajudar com conceitos de IA, arquitetura de servidores MCP, segurança de dados e muito mais. Como posso auxiliar sua jornada de aprendizado hoje?",
    assistant_placeholder: "Pergunte qualquer coisa ao Cody...",
    assistant_thinking: "Pensando",
    send_button: "Enviar",
    
    // Navigation
    nav_home: "Início",
    nav_learning: "Aprendizado",
    nav_projects: "Projetos",
    nav_achievements: "Conquistas",
    nav_profile: "Perfil",
    nav_logout: "Sair",
    nav_settings: "Configurações",
    
    // Home page
    welcome_title: "Bem-vindo ao Cody Verse",
    welcome_subtitle: "Sua Plataforma de Aprendizado com IA",
    get_started: "Começar",
    continue_learning: "Continuar Aprendendo",
    
    // Learning section
    modules_title: "Módulos de Aprendizado",
    module_progress: "Progresso",
    difficulty_beginner: "Iniciante",
    difficulty_intermediate: "Intermediário",
    difficulty_advanced: "Avançado",
    difficulty_expert: "Especialista",
    start_module: "Iniciar Módulo",
    continue_module: "Continuar",
    est_time: "Tempo est.",
    xp_reward: "Recompensa XP",
    
    // Challenge section
    challenge_title: "Desafio",
    challenge_description: "Descrição do Desafio",
    challenge_submit: "Enviar Resposta",
    challenge_reset: "Reiniciar",
    challenge_hint: "Dica",
    challenge_complete: "Desafio Concluído!",
    challenge_next: "Próximo Desafio",
    challenge_previous: "Desafio Anterior",
    
    // Tutorial
    tutorial_welcome_title: "Bem-vindo ao Cody Verse!",
    tutorial_welcome_content: "Vamos fazer um tour rápido pela plataforma. Eu sou o Cody, seu guia nessa jornada de aprendizado!",
    tutorial_nav_title: "Navegação",
    tutorial_nav_content: "Aqui você encontra as principais seções da plataforma: Aprendizado, Projetos, Conquistas e Perfil.",
    tutorial_modules_title: "Módulos de Aprendizado",
    tutorial_modules_content: "Explore nossos módulos interativos sobre IA, segurança e programação, organizados por nível de dificuldade.",
    tutorial_assistant_title: "Assistente IA",
    tutorial_assistant_content: "Clique no ícone do Cody a qualquer momento para obter ajuda, tirar dúvidas ou conversar sobre qualquer tópico.",
    tutorial_profile_title: "Seu Perfil",
    tutorial_profile_content: "Acompanhe seu progresso, nível e conquistas. Quanto mais você aprende, mais XP você ganha!",
    tutorial_prev: "Anterior",
    tutorial_next: "Próximo",
    tutorial_finish: "Concluir",
    
    // Achievements
    achievement_unlocked: "Conquista Desbloqueada!",
    achievement_progress: "Progresso de Conquistas",
    
    // Profile
    profile_level: "Nível",
    profile_xp: "Experiência (XP)",
    profile_next_level: "Próximo nível",
    profile_achievements: "Conquistas",
    profile_modules_completed: "Módulos Concluídos",
    profile_challenges_completed: "Desafios Concluídos",
    
    // Logout
    logout_success_title: "Desconectado",
    logout_success_message: "Você foi desconectado com sucesso.",
    error_title: "Erro",
    error_logout: "Falha ao sair. Por favor, tente novamente.",
    
    // Misc
    language_selector: "Idioma",
    tech_savvy: "Especialista em tecnologia",
    ai_expert: "Especialista em IA",
    cybersecurity_guide: "Guia de cibersegurança",
    loading: "Carregando...",
    error_generic: "Ocorreu um erro. Tente novamente mais tarde.",
    try_again: "Tentar novamente",
    save: "Salvar",
    cancel: "Cancelar",
    settings: "Configurações",
    theme: "Tema",
    theme_light: "Claro",
    theme_dark: "Escuro",
    theme_system: "Sistema"
  },
  'es': {
    // Assistant messages
    assistant_welcome: "¡Bienvenido a Cody Verse! Soy Cody, tu asistente en inteligencia artificial y ciberseguridad. Puedo ayudarte con conceptos de IA, arquitectura de servidores MCP, seguridad de datos y mucho más. ¿Cómo puedo ayudarte en tu viaje de aprendizaje hoy?",
    assistant_placeholder: "Pregúntale cualquier cosa a Cody...",
    assistant_thinking: "Pensando",
    send_button: "Enviar",
    
    // Navigation
    nav_home: "Inicio",
    nav_learning: "Aprendizaje",
    nav_projects: "Proyectos",
    nav_achievements: "Logros",
    nav_profile: "Perfil",
    nav_logout: "Cerrar sesión",
    nav_settings: "Ajustes",
    
    // Home page
    welcome_title: "Bienvenido a Cody Verse",
    welcome_subtitle: "Tu Plataforma de Aprendizaje con IA",
    get_started: "Comenzar",
    continue_learning: "Continuar Aprendizaje",
    
    // Learning section
    modules_title: "Módulos de Aprendizaje",
    module_progress: "Progreso",
    difficulty_beginner: "Principiante",
    difficulty_intermediate: "Intermedio",
    difficulty_advanced: "Avanzado",
    difficulty_expert: "Experto",
    start_module: "Iniciar Módulo",
    continue_module: "Continuar",
    est_time: "Tiempo est.",
    xp_reward: "Recompensa XP",
    
    // Challenge section
    challenge_title: "Desafío",
    challenge_description: "Descripción del Desafío",
    challenge_submit: "Enviar Respuesta",
    challenge_reset: "Reiniciar",
    challenge_hint: "Pista",
    challenge_complete: "¡Desafío Completado!",
    challenge_next: "Siguiente Desafío",
    challenge_previous: "Desafío Anterior",
    
    // Authentication
    login_title: "Iniciar sesión",
    login_description: "Bienvenido de nuevo a la plataforma CodyVerse",
    register_title: "Registrarse",
    register_description: "Crea tu cuenta en la plataforma CodyVerse",
    username_label: "Nombre de usuario",
    password_label: "Contraseña",
    display_name_label: "Nombre para mostrar",
    login_button: "Iniciar sesión",
    register_button: "Registrarse",
    register_prompt: "¿No tienes una cuenta?",
    login_prompt: "¿Ya tienes una cuenta?",
    register_link: "Registrarse",
    login_link: "Iniciar sesión",
    error_login: "Error al iniciar sesión. Por favor verifica tu nombre de usuario y contraseña.",
    error_register: "Error al registrarse. Este nombre de usuario puede ya estar en uso.",
    success_register: "¡Registro exitoso!",
    success_login: "¡Inicio de sesión exitoso!",
    field_required: "Este campo es obligatorio",
    processing: "Procesando...",
    
    // Logout
    logout_success_title: "Sesión cerrada",
    logout_success_message: "Has cerrado sesión exitosamente.",
    error_title: "Error",
    error_logout: "Error al cerrar sesión. Por favor intenta de nuevo.",
    
    // Tutorial
    tutorial_welcome_title: "¡Bienvenido a Cody Verse!",
    tutorial_welcome_content: "Hagamos un recorrido rápido por la plataforma. ¡Soy Cody, tu guía en este viaje de aprendizaje!",
    tutorial_nav_title: "Navegación",
    tutorial_nav_content: "Aquí encontrarás las secciones principales de la plataforma: Aprendizaje, Proyectos, Logros y Perfil.",
    tutorial_modules_title: "Módulos de Aprendizaje",
    tutorial_modules_content: "Explora nuestros módulos interactivos sobre IA, seguridad y programación, organizados por nivel de dificultad.",
    tutorial_assistant_title: "Asistente IA",
    tutorial_assistant_content: "Haz clic en el ícono de Cody en cualquier momento para obtener ayuda, hacer preguntas o chatear sobre cualquier tema.",
    tutorial_profile_title: "Tu Perfil",
    tutorial_profile_content: "Sigue tu progreso, nivel y logros. ¡Cuanto más aprendas, más XP ganarás!",
    tutorial_prev: "Anterior",
    tutorial_next: "Siguiente",
    tutorial_finish: "Finalizar",
    
    // Achievements
    achievement_unlocked: "¡Logro Desbloqueado!",
    achievement_progress: "Progreso de Logros",
    
    // Profile
    profile_level: "Nivel",
    profile_xp: "Experiencia (XP)",
    profile_next_level: "Siguiente nivel",
    profile_achievements: "Logros",
    profile_modules_completed: "Módulos Completados",
    profile_challenges_completed: "Desafíos Completados",
    
    // Misc
    language_selector: "Idioma",
    tech_savvy: "Experto en tecnología",
    ai_expert: "Experto en IA",
    cybersecurity_guide: "Guía de ciberseguridad",
    loading: "Cargando...",
    error_generic: "Ocurrió un error. Inténtalo de nuevo más tarde.",
    try_again: "Intentar de nuevo",
    save: "Guardar",
    cancel: "Cancelar",
    settings: "Configuración",
    theme: "Tema",
    theme_light: "Claro",
    theme_dark: "Oscuro",
    theme_system: "Sistema"
  }
};

// Levels and XP
export const XP_PER_LEVEL = 1000;
export const MAX_LEVEL = 50;

// Difficulty levels
export const DIFFICULTY = {
  BEGINNER: "beginner",
  INTERMEDIATE: "intermediate",
  ADVANCED: "advanced",
  EXPERT: "expert"
};

// Learning path structure
export const LEARNING_PATHS = {
  AI_FUNDAMENTALS: "ai-fundamentals",
  MCP_SERVERS: "mcp-servers",
  AI_AGENTS: "ai-agents",
  PROJECT_BUILDING: "project-building"
};

// Achievement types
export const ACHIEVEMENT_TYPES = {
  MODULE_COMPLETION: "module_completion",
  CHALLENGE_COMPLETION: "challenge_completion",
  STREAK: "learning_streak",
  LEVEL_UP: "level_up",
  PROJECT_MILESTONE: "project_milestone"
};

// Code challenge types
export const CHALLENGE_TYPES = {
  MULTIPLE_CHOICE: "multiple_choice",
  CODE_COMPLETION: "code_completion",
  DEBUGGING: "debugging",
  AI_PROMPT_ENGINEERING: "prompt_engineering",
  IMPLEMENTATION: "implementation"
};

// Tutorial content IDs
export const TUTORIAL_IDS = {
  WELCOME: "welcome",
  AI_INTRO: "ai-introduction",
  MCP_BASICS: "mcp-basics",
  AGENT_CREATION: "agent-creation",
  API_INTEGRATION: "api-integration",
  PROJECT_DEPLOYMENT: "project-deployment"
};

// Routes
export const ROUTES = {
  HOME: "/",
  LOGIN: "/login",
  REGISTER: "/register",
  LEARNING_MODULE: "/learning-module/:id",
  CHALLENGE: "/challenge/:id",
  PROJECT_BUILDER: "/project-builder",
  ACHIEVEMENTS: "/achievements",
  PROFILE: "/profile"
};
