import React, { useCallback, useRef, useEffect, useMemo, useState } from 'react';

// Enhanced performance monitoring with memory leak detection
export class AdvancedPerformanceMonitor {
  private static instance: AdvancedPerformanceMonitor;
  private memorySnapshots: number[] = [];
  private renderTimes: Map<string, number[]> = new Map();
  private leakDetector: Map<string, number> = new Map();

  static getInstance(): AdvancedPerformanceMonitor {
    if (!this.instance) {
      this.instance = new AdvancedPerformanceMonitor();
    }
    return this.instance;
  }

  trackRender(componentName: string, renderTime: number): void {
    if (!this.renderTimes.has(componentName)) {
      this.renderTimes.set(componentName, []);
    }
    
    const times = this.renderTimes.get(componentName)!;
    times.push(renderTime);
    
    // Keep only last 50 render times
    if (times.length > 50) {
      times.shift();
    }

    // Detect render performance issues
    if (renderTime > 50) {
      console.warn(`Slow render detected: ${componentName} took ${renderTime}ms`);
    }
  }

  detectMemoryLeaks(): void {
    if (typeof window !== 'undefined' && 'performance' in window && 'memory' in (window.performance as any)) {
      const memory = (window.performance as any).memory;
      this.memorySnapshots.push(memory.usedJSHeapSize);
      
      if (this.memorySnapshots.length > 20) {
        this.memorySnapshots.shift();
      }

      // Check for memory growth trend
      if (this.memorySnapshots.length >= 10) {
        const recent = this.memorySnapshots.slice(-5);
        const older = this.memorySnapshots.slice(-10, -5);
        const recentAvg = recent.reduce((a, b) => a + b) / recent.length;
        const olderAvg = older.reduce((a, b) => a + b) / older.length;
        
        if (recentAvg > olderAvg * 1.2) {
          console.warn('Potential memory leak detected - memory usage increasing');
        }
      }
    }
  }

  getPerformanceReport(): object {
    const report: any = {};
    
    for (const [component, times] of Array.from(this.renderTimes.entries())) {
      const avg = times.reduce((a: number, b: number) => a + b) / times.length;
      const max = Math.max(...times);
      const min = Math.min(...times);
      
      report[component] = {
        averageRenderTime: avg.toFixed(2),
        maxRenderTime: max.toFixed(2),
        minRenderTime: min.toFixed(2),
        renderCount: times.length
      };
    }
    
    return report;
  }
}

// Optimized state management with automatic cleanup
export function useOptimizedCallback<T extends (...args: any[]) => any>(
  callback: T,
  deps: React.DependencyList
): T {
  const memoizedCallback = useCallback(callback, deps);
  const callbackRef = useRef(memoizedCallback);
  
  useEffect(() => {
    callbackRef.current = memoizedCallback;
  }, [memoizedCallback]);

  return useCallback(((...args: any[]) => callbackRef.current(...args)) as T, []);
}

// Enhanced memoization with size limits
export function useAdvancedMemo<T>(
  factory: () => T,
  deps: React.DependencyList,
  options: { maxSize?: number; ttl?: number } = {}
): T {
  const { maxSize = 10, ttl = 5 * 60 * 1000 } = options;
  const cacheRef = useRef(new Map<string, { value: T; timestamp: number }>());
  const depsKey = JSON.stringify(deps);

  return useMemo(() => {
    const cache = cacheRef.current;
    const now = Date.now();
    
    // Clean expired entries
    for (const [key, entry] of Array.from(cache.entries())) {
      if (now - entry.timestamp > ttl) {
        cache.delete(key);
      }
    }
    
    // Check if we have a valid cached value
    const cached = cache.get(depsKey);
    if (cached && now - cached.timestamp < ttl) {
      return cached.value;
    }

    // Compute new value
    const value = factory();
    
    // Manage cache size
    if (cache.size >= maxSize) {
      const oldestKey = Array.from(cache.keys())[0];
      if (oldestKey) {
        cache.delete(oldestKey);
      }
    }
    
    cache.set(depsKey, { value, timestamp: now });
    return value;
  }, deps);
}

// Intersection observer hook with cleanup
export function useIntersectionObserver(
  ref: React.RefObject<Element>,
  options: IntersectionObserverInit = {}
): boolean {
  const [isIntersecting, setIsIntersecting] = useState(false);
  
  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => setIsIntersecting(entry.isIntersecting),
      options
    );

    observer.observe(element);

    return () => {
      observer.unobserve(element);
      observer.disconnect();
    };
  }, [ref, options.root, options.rootMargin, options.threshold]);

  return isIntersecting;
}

// Debounced value hook with cleanup
export function useDebouncedValue<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState(value);
  const timeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [value, delay]);

  return debouncedValue;
}

// Virtual scrolling for large lists
export function useVirtualScroll<T>(
  items: T[],
  itemHeight: number,
  containerHeight: number
) {
  const [scrollTop, setScrollTop] = useState(0);
  
  const visibleStart = Math.floor(scrollTop / itemHeight);
  const visibleEnd = Math.min(
    visibleStart + Math.ceil(containerHeight / itemHeight) + 1,
    items.length
  );
  
  const visibleItems = items.slice(visibleStart, visibleEnd);
  const totalHeight = items.length * itemHeight;
  const offsetY = visibleStart * itemHeight;

  return {
    visibleItems,
    totalHeight,
    offsetY,
    onScroll: (e: React.UIEvent<HTMLDivElement>) => {
      setScrollTop(e.currentTarget.scrollTop);
    }
  };
}

// Resource cleanup utility
export class ResourceManager {
  private static resources: Set<() => void> = new Set();

  static addCleanup(cleanup: () => void): void {
    this.resources.add(cleanup);
  }

  static removeCleanup(cleanup: () => void): void {
    this.resources.delete(cleanup);
  }

  static cleanup(): void {
    this.resources.forEach(cleanup => {
      try {
        cleanup();
      } catch (error) {
        console.error('Error during resource cleanup:', error);
      }
    });
    this.resources.clear();
  }
}

// Performance budget monitoring
export class PerformanceBudget {
  private static budgets = new Map<string, number>();
  
  static setBudget(metric: string, limit: number): void {
    this.budgets.set(metric, limit);
  }

  static checkBudget(metric: string, value: number): boolean {
    const budget = this.budgets.get(metric);
    if (budget && value > budget) {
      console.warn(`Performance budget exceeded for ${metric}: ${value} > ${budget}`);
      return false;
    }
    return true;
  }
}

// Initialize performance monitoring
if (typeof window !== 'undefined') {
  const monitor = AdvancedPerformanceMonitor.getInstance();
  
  // Set up automatic memory leak detection
  setInterval(() => {
    monitor.detectMemoryLeaks();
  }, 30000);

  // Set performance budgets
  PerformanceBudget.setBudget('renderTime', 16); // 60fps
  PerformanceBudget.setBudget('bundleSize', 500 * 1024); // 500KB
  PerformanceBudget.setBudget('apiResponse', 1000); // 1 second

  // Clean up resources on page unload
  window.addEventListener('beforeunload', () => {
    ResourceManager.cleanup();
  });
}