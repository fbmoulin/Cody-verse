// Tutorial step IDs
export const TUTORIAL_IDS = {
  WELCOME: "welcome",
  NAVIGATION: "navigation",
  LEARNING_MODULES: "learning_modules",
  ASSISTANT: "assistant",
  PROFILE: "profile",
  AI_INTRO: "ai_intro",
  MCP_BASICS: "mcp_basics",
  AGENT_CREATION: "agent_creation",
  API_INTEGRATION: "api_integration",
  PROJECT_DEPLOYMENT: "project_deployment",
};