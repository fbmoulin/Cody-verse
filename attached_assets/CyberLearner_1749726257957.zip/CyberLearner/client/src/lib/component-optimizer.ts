import React, { ComponentType, lazy, LazyExoticComponent } from 'react';
import { perf, CacheManager } from './performance';

// Component lazy loading with performance tracking
export function createOptimizedComponent<T extends ComponentType<any>>(
  importFn: () => Promise<{ default: T }>,
  componentName: string
): LazyExoticComponent<T> {
  return lazy(async () => {
    const start = performance.now();
    
    try {
      const module = await importFn();
      const end = performance.now();
      
      perf.measureRender(`${componentName}Load`, () => {});
      console.log(`[Optimizer] ${componentName} loaded in ${(end - start).toFixed(2)}ms`);
      
      return module;
    } catch (error) {
      console.error(`[Optimizer] Failed to load ${componentName}:`, error);
      throw error;
    }
  });
}

// HOC for automatic performance monitoring
export function withPerformanceMonitoring<P extends object>(
  Component: ComponentType<P>,
  componentName: string
) {
  return function PerformanceMonitoredComponent(props: P) {
    const startTime = performance.now();
    
    // Track render performance
    React.useEffect(() => {
      const endTime = performance.now();
      perf.measureRender(componentName, () => {});
      
      if (endTime - startTime > 16) {
        console.warn(`[Performance] ${componentName} slow render: ${(endTime - startTime).toFixed(2)}ms`);
      }
    });

    return React.createElement(Component, props);
  };
}

// Component state management optimizer
export class ComponentStateManager {
  private static stateCache = new Map<string, any>();
  private static subscriptions = new Map<string, Set<Function>>();

  static setState(key: string, value: any): void {
    this.stateCache.set(key, value);
    const subscribers = this.subscriptions.get(key);
    if (subscribers) {
      subscribers.forEach(callback => callback(value));
    }
  }

  static getState(key: string): any {
    return this.stateCache.get(key);
  }

  static subscribe(key: string, callback: Function): () => void {
    if (!this.subscriptions.has(key)) {
      this.subscriptions.set(key, new Set());
    }
    this.subscriptions.get(key)!.add(callback);
    
    return () => {
      this.subscriptions.get(key)?.delete(callback);
    };
  }

  static clearState(key?: string): void {
    if (key) {
      this.stateCache.delete(key);
      this.subscriptions.delete(key);
    } else {
      this.stateCache.clear();
      this.subscriptions.clear();
    }
  }
}

// Bundle optimization utilities
export class BundleOptimizer {
  private static loadedChunks = new Set<string>();
  
  static async preloadChunk(chunkName: string): Promise<void> {
    if (this.loadedChunks.has(chunkName)) return;
    
    try {
      // Dynamically import chunks for better code splitting
      await import(/* @vite-ignore */ `../components/${chunkName}`);
      this.loadedChunks.add(chunkName);
    } catch (error) {
      console.warn(`[BundleOptimizer] Failed to preload chunk: ${chunkName}`, error);
    }
  }

  static getLoadedChunks(): string[] {
    return Array.from(this.loadedChunks);
  }

  static analyzeBundleSize(): void {
    if (import.meta.env.DEV) {
      console.group('[Bundle Analysis]');
      console.log('Loaded chunks:', this.getLoadedChunks());
      console.log('Cache size:', CacheManager.size());
      console.log('Memory usage:', perf.getMemoryUsage());
      console.groupEnd();
    }
  }
}

// Error boundary optimization
export class ErrorBoundaryManager {
  private static errorLog: Array<{ component: string; error: Error; timestamp: number }> = [];

  static logError(component: string, error: Error): void {
    this.errorLog.push({
      component,
      error,
      timestamp: Date.now()
    });

    // Keep only last 50 errors
    if (this.errorLog.length > 50) {
      this.errorLog.shift();
    }

    console.error(`[ErrorBoundary] ${component}:`, error);
  }

  static getErrorStats(): { component: string; count: number }[] {
    const stats = new Map<string, number>();
    
    this.errorLog.forEach(({ component }) => {
      stats.set(component, (stats.get(component) || 0) + 1);
    });

    return Array.from(stats.entries()).map(([component, count]) => ({
      component,
      count
    }));
  }

  static clearErrors(): void {
    this.errorLog = [];
  }
}

// Component registry for dynamic loading
export class ComponentRegistry {
  private static components = new Map<string, ComponentType<any>>();
  private static loadingPromises = new Map<string, Promise<ComponentType<any>>>();

  static register(name: string, component: ComponentType<any>): void {
    this.components.set(name, component);
  }

  static async get(name: string): Promise<ComponentType<any> | null> {
    // Return immediately if already loaded
    if (this.components.has(name)) {
      return this.components.get(name)!;
    }

    // Return existing loading promise if in progress
    if (this.loadingPromises.has(name)) {
      return this.loadingPromises.get(name)!;
    }

    // Start new loading process
    const loadingPromise = this.loadComponent(name);
    this.loadingPromises.set(name, loadingPromise);

    try {
      const component = await loadingPromise;
      this.components.set(name, component);
      return component;
    } finally {
      this.loadingPromises.delete(name);
    }
  }

  private static async loadComponent(name: string): Promise<ComponentType<any>> {
    try {
      const module = await import(`../components/ui/interactive/${name}.tsx`);
      return module.default || module[name];
    } catch (error) {
      console.error(`[ComponentRegistry] Failed to load ${name}:`, error);
      throw error;
    }
  }

  static getRegistered(): string[] {
    return Array.from(this.components.keys());
  }
}

export { perf, CacheManager };