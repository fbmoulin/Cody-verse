import { perf, CacheManager, ResourcePreloader } from './performance';
import { ComponentRegistry, BundleOptimizer } from './component-optimizer';

// Global optimization manager for the entire application
class GlobalOptimizer {
  private static instance: GlobalOptimizer;
  private isInitialized = false;
  private performanceMetrics = new Map<string, number[]>();

  static getInstance(): GlobalOptimizer {
    if (!GlobalOptimizer.instance) {
      GlobalOptimizer.instance = new GlobalOptimizer();
    }
    return GlobalOptimizer.instance;
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    console.log('[GlobalOptimizer] Initializing optimization systems...');
    
    // Initialize performance monitoring
    this.setupPerformanceObserver();
    
    // Preload critical resources
    await this.preloadCriticalResources();
    
    // Setup automatic cache management
    this.setupCacheManagement();
    
    // Initialize component registry
    this.setupComponentRegistry();
    
    // Setup error monitoring
    this.setupErrorMonitoring();
    
    this.isInitialized = true;
    console.log('[GlobalOptimizer] Optimization systems initialized');
  }

  private setupPerformanceObserver(): void {
    if (typeof PerformanceObserver !== 'undefined') {
      const observer = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach((entry) => {
          if (entry.entryType === 'navigation') {
            console.log(`[Performance] Page load: ${entry.duration.toFixed(2)}ms`);
          } else if (entry.entryType === 'paint') {
            console.log(`[Performance] ${entry.name}: ${entry.startTime.toFixed(2)}ms`);
          }
        });
      });
      
      observer.observe({ entryTypes: ['navigation', 'paint', 'largest-contentful-paint'] });
    }
  }

  private async preloadCriticalResources(): Promise<void> {
    const criticalAssets = [
      // Preload critical fonts
      'Inter:400,500,600,700',
      'JetBrains Mono:400,500'
    ];

    const preloadPromises = criticalAssets.map(font => 
      ResourcePreloader.preloadFont(font)
    );

    try {
      await Promise.all(preloadPromises);
      console.log('[GlobalOptimizer] Critical resources preloaded');
    } catch (error) {
      console.warn('[GlobalOptimizer] Some critical resources failed to preload:', error);
    }
  }

  private setupCacheManagement(): void {
    // Automatic cache cleanup every 5 minutes
    setInterval(() => {
      const cacheSize = CacheManager.size();
      if (cacheSize > 100) {
        CacheManager.clear();
        console.log('[GlobalOptimizer] Cache cleared due to size limit');
      }
    }, 5 * 60 * 1000);
  }

  private setupComponentRegistry(): void {
    // Component registry setup completed
    console.log('[GlobalOptimizer] Component registry configured');
  }

  private setupErrorMonitoring(): void {
    // Global error handler
    window.addEventListener('error', (event) => {
      console.error('[GlobalOptimizer] Global error:', event.error);
      this.trackError('global', event.error);
    });

    // Unhandled promise rejection handler
    window.addEventListener('unhandledrejection', (event) => {
      console.error('[GlobalOptimizer] Unhandled promise rejection:', event.reason);
      this.trackError('promise', event.reason);
    });
  }

  private trackError(type: string, error: any): void {
    const errorData = {
      type,
      message: error?.message || 'Unknown error',
      stack: error?.stack,
      timestamp: Date.now(),
      url: window.location.href
    };

    // In production, this would send to error tracking service
    console.error('[Error Tracking]', errorData);
  }

  recordMetric(name: string, value: number): void {
    if (!this.performanceMetrics.has(name)) {
      this.performanceMetrics.set(name, []);
    }
    
    const metrics = this.performanceMetrics.get(name)!;
    metrics.push(value);
    
    // Keep only last 50 measurements
    if (metrics.length > 50) {
      metrics.shift();
    }
  }

  getMetricSummary(name: string): { avg: number; min: number; max: number } | null {
    const metrics = this.performanceMetrics.get(name);
    if (!metrics || metrics.length === 0) return null;

    const avg = metrics.reduce((sum, val) => sum + val, 0) / metrics.length;
    const min = Math.min(...metrics);
    const max = Math.max(...metrics);

    return { avg, min, max };
  }

  generatePerformanceReport(): void {
    if (!import.meta.env.DEV) return;

    console.group('[Performance Report]');
    
    // Memory usage
    const memory = perf.getMemoryUsage();
    if (memory) {
      console.log(`Memory: ${memory.used}MB / ${memory.total}MB (${memory.limit}MB limit)`);
    }

    // Cache statistics
    console.log(`Cache entries: ${CacheManager.size()}`);

    // Component metrics
    console.log('Component Performance:');
    this.performanceMetrics.forEach((metrics, name) => {
      const summary = this.getMetricSummary(name);
      if (summary) {
        console.log(`  ${name}: avg ${summary.avg.toFixed(2)}ms, min ${summary.min.toFixed(2)}ms, max ${summary.max.toFixed(2)}ms`);
      }
    });

    // Bundle analysis
    BundleOptimizer.analyzeBundleSize();
    
    console.groupEnd();
  }

  optimizeForProduction(): void {
    if (import.meta.env.PROD) {
      // Disable console logs in production
      console.log = () => {};
      console.warn = () => {};
      
      // Enable aggressive caching
      CacheManager.clear();
      
      console.info('[GlobalOptimizer] Production optimizations applied');
    }
  }
}

// Export singleton instance
export const globalOptimizer = GlobalOptimizer.getInstance();

// Auto-initialize on import
if (typeof window !== 'undefined') {
  globalOptimizer.initialize().catch(console.error);
}

export { GlobalOptimizer };