import { useState, useCallback, useRef, useEffect } from 'react';
import { perf } from '@/lib/performance';

// Optimized state hook with automatic memoization
export function useOptimizedState<T>(
  initialValue: T,
  componentName?: string
) {
  const [state, setState] = useState<T>(initialValue);
  const renderCountRef = useRef(0);
  
  useEffect(() => {
    renderCountRef.current++;
    if (componentName && renderCountRef.current > 1) {
      perf.measureRender(componentName, () => {});
    }
  });

  const optimizedSetState = useCallback((value: T | ((prev: T) => T)) => {
    setState(prevState => {
      const newValue = typeof value === 'function' ? (value as (prev: T) => T)(prevState) : value;
      // Only update if value actually changed using shallow comparison for objects
      if (typeof newValue === 'object' && newValue !== null && typeof prevState === 'object' && prevState !== null) {
        const newKeys = Object.keys(newValue as any);
        const prevKeys = Object.keys(prevState as any);
        if (newKeys.length !== prevKeys.length) return newValue;
        for (const key of newKeys) {
          if ((newValue as any)[key] !== (prevState as any)[key]) return newValue;
        }
        return prevState;
      }
      return newValue !== prevState ? newValue : prevState;
    });
  }, []);

  return [state, optimizedSetState] as const;
}

// Debounced state hook for expensive operations
export function useDebouncedState<T>(
  initialValue: T,
  delay: number = 300
) {
  const [state, setState] = useState<T>(initialValue);
  const [debouncedState, setDebouncedState] = useState<T>(initialValue);
  
  const debouncedSetState = useCallback(
    perf.debounce((value: T) => {
      setDebouncedState(value);
    }, delay),
    [delay]
  );

  useEffect(() => {
    debouncedSetState(state);
  }, [state, debouncedSetState]);

  return [debouncedState, setState] as const;
}

// Local storage state hook with automatic persistence
export function usePersistedState<T>(
  key: string,
  initialValue: T
): [T, (value: T | ((prev: T) => T)) => void] {
  const [state, setState] = useState<T>(() => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch {
      return initialValue;
    }
  });

  const setPersistedState = useCallback((value: T | ((prev: T) => T)) => {
    setState(prevState => {
      const newValue = typeof value === 'function' ? (value as (prev: T) => T)(prevState) : value;
      try {
        localStorage.setItem(key, JSON.stringify(newValue));
      } catch (error) {
        console.warn(`Failed to persist state to localStorage:`, error);
      }
      return newValue;
    });
  }, [key]);

  return [state, setPersistedState];
}

// Async state hook with loading and error handling
export function useAsyncState<T>() {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const execute = useCallback(async (asyncFunction: () => Promise<T>) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await asyncFunction();
      setData(result);
      return result;
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      setError(error);
      throw error;
    } finally {
      setLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setData(null);
    setError(null);
    setLoading(false);
  }, []);

  return { data, loading, error, execute, reset };
}

// Form state hook with validation
export function useFormState<T extends Record<string, any>>(
  initialValues: T,
  validationSchema?: (values: T) => Record<keyof T, string | null>
) {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<Record<keyof T, string | null>>({} as Record<keyof T, string | null>);
  const [touched, setTouched] = useState<Record<keyof T, boolean>>({} as Record<keyof T, boolean>);

  const setValue = useCallback((name: keyof T, value: any) => {
    setValues(prev => ({ ...prev, [name]: value }));
    setTouched(prev => ({ ...prev, [name]: true }));
    
    if (validationSchema) {
      const newErrors = validationSchema({ ...values, [name]: value });
      setErrors(prev => ({ ...prev, [name]: newErrors[name] }));
    }
  }, [values, validationSchema]);

  const validate = useCallback(() => {
    if (!validationSchema) return true;
    
    const newErrors = validationSchema(values);
    setErrors(newErrors);
    
    return Object.values(newErrors).every(error => !error);
  }, [values, validationSchema]);

  const reset = useCallback(() => {
    setValues(initialValues);
    setErrors({} as Record<keyof T, string | null>);
    setTouched({} as Record<keyof T, boolean>);
  }, [initialValues]);

  return {
    values,
    errors,
    touched,
    setValue,
    validate,
    reset,
    isValid: Object.values(errors).every(error => !error)
  };
}