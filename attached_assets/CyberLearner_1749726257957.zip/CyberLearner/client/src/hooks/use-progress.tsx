import { useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { XP_PER_LEVEL } from '@/lib/constants';

interface UseProgressOptions {
  userId: number;
}

export function useProgress({ userId }: UseProgressOptions) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Get user progress data
  const { 
    data: modules,
    isLoading: isLoadingModules,
    error: modulesError
  } = useQuery({
    queryKey: [`/api/users/${userId}/progress`],
  });
  
  // Get user challenges
  const {
    data: challenges,
    isLoading: isLoadingChallenges, 
    error: challengesError
  } = useQuery({
    queryKey: [`/api/users/${userId}/challenges`],
  });
  
  // Get user achievements
  const {
    data: achievements,
    isLoading: isLoadingAchievements,
    error: achievementsError
  } = useQuery({
    queryKey: [`/api/users/${userId}/achievements`],
  });
  
  // Update module progress
  const updateModuleProgress = useMutation({
    mutationFn: async ({ 
      moduleId, 
      progress, 
      completed 
    }: { 
      moduleId: number;
      progress: number;
      completed: boolean;
    }) => {
      return apiRequest('POST', `/api/users/${userId}/modules/${moduleId}/progress`, {
        progress,
        completed,
        lastAccessed: new Date()
      });
    },
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/progress`] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to update progress. Please try again.',
        variant: 'destructive',
      });
      console.error('Error updating module progress:', error);
    }
  });
  
  // Update challenge status
  const updateChallengeStatus = useMutation({
    mutationFn: async ({
      challengeId,
      completed,
      attempts
    }: {
      challengeId: number;
      completed: boolean;
      attempts: number;
    }) => {
      return apiRequest('POST', `/api/users/${userId}/challenges/${challengeId}`, {
        completed,
        attempts,
        lastAttempt: new Date()
      });
    },
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/challenges`] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to update challenge status. Please try again.',
        variant: 'destructive',
      });
      console.error('Error updating challenge status:', error);
    }
  });
  
  // Unlock achievement
  const unlockAchievement = useMutation({
    mutationFn: async ({ achievementId }: { achievementId: number }) => {
      return apiRequest('POST', `/api/users/${userId}/achievements/${achievementId}`, {
        unlockedAt: new Date()
      });
    },
    onSuccess: (data) => {
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/achievements`] });
      
      // Show a toast notification
      toast({
        title: 'Achievement Unlocked!',
        description: 'You\'ve earned a new achievement and XP reward.',
        variant: 'default',
      });
    },
    onError: (error: any) => {
      // Don't show error for already unlocked achievements
      if (error.message?.includes('already has this achievement')) {
        return;
      }
      
      toast({
        title: 'Error',
        description: 'Failed to unlock achievement. Please try again.',
        variant: 'destructive',
      });
      console.error('Error unlocking achievement:', error);
    }
  });
  
  // Calculate overall progress
  const calculateOverallProgress = useCallback(() => {
    if (!modules || modules.length === 0) return 0;
    
    let totalProgress = 0;
    let completedModules = 0;
    
    for (const moduleProgress of modules) {
      totalProgress += moduleProgress.progress;
      if (moduleProgress.completed) {
        completedModules++;
      }
    }
    
    return Math.floor(totalProgress / modules.length);
  }, [modules]);
  
  // Calculate completed modules count
  const getCompletedModulesCount = useCallback(() => {
    if (!modules) return 0;
    return modules.filter(m => m.completed).length;
  }, [modules]);
  
  // Calculate completed challenges count
  const getCompletedChallengesCount = useCallback(() => {
    if (!challenges) return 0;
    return challenges.filter(c => c.completed).length;
  }, [challenges]);
  
  // Calculate achievements count
  const getUnlockedAchievementsCount = useCallback(() => {
    if (!achievements) return 0;
    return achievements.length;
  }, [achievements]);
  
  // Format XP progress information
  const formatXpProgress = useCallback((xp: number) => {
    const level = Math.floor(xp / XP_PER_LEVEL) + 1;
    const levelXp = xp % XP_PER_LEVEL;
    const xpNeeded = XP_PER_LEVEL;
    const percentage = Math.floor((levelXp / xpNeeded) * 100);
    
    return {
      level,
      currentXp: levelXp,
      xpNeeded,
      percentage,
      totalXp: xp
    };
  }, []);
  
  // Check if achievement should be unlocked based on current progress
  const checkAndUnlockAchievements = useCallback((allAchievements = []) => {
    if (!allAchievements || allAchievements.length === 0) return;
    
    const moduleCount = getCompletedModulesCount();
    const challengeCount = getCompletedChallengesCount();
    
    for (const achievement of allAchievements) {
      if (achievements?.find(a => a.achievementId === achievement.id)) {
        // Already unlocked
        continue;
      }
      
      let shouldUnlock = false;
      const condition = typeof achievement.condition === 'string' 
        ? JSON.parse(achievement.condition) 
        : achievement.condition;
      
      if (condition.type === 'module_completion' && moduleCount >= condition.count) {
        shouldUnlock = true;
      } else if (condition.type === 'challenge_completion' && challengeCount >= condition.count) {
        shouldUnlock = true;
      }
      
      if (shouldUnlock) {
        unlockAchievement.mutate({ achievementId: achievement.id });
      }
    }
  }, [getCompletedModulesCount, getCompletedChallengesCount, achievements, unlockAchievement]);
  
  return {
    moduleProgress: modules,
    challengeProgress: challenges,
    achievements,
    isLoading: isLoadingModules || isLoadingChallenges || isLoadingAchievements,
    error: modulesError || challengesError || achievementsError,
    updateModuleProgress,
    updateChallengeStatus,
    unlockAchievement,
    calculateOverallProgress,
    getCompletedModulesCount,
    getCompletedChallengesCount,
    getUnlockedAchievementsCount,
    formatXpProgress,
    checkAndUnlockAchievements
  };
}
