import { useState, useEffect, createContext, useContext, ReactNode } from 'react';

// Available languages
export type Language = 'en' | 'pt-br' | 'es';
export type ThemeOption = 'light' | 'dark' | 'system';

interface UserPreferencesContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  theme: ThemeOption;
  setTheme: (theme: ThemeOption) => void;
}

// Create a safer initial context value
const defaultPreferences: UserPreferencesContextType = {
  language: 'en',
  setLanguage: () => {},
  theme: 'dark',
  setTheme: () => {},
};

// Create context with default value
const UserPreferencesContext = createContext<UserPreferencesContextType>(defaultPreferences);

// Helper function to safely get values from localStorage
const getSafeLocalStorageItem = (key: string, defaultValue: string): string => {
  if (typeof window === 'undefined' || !window.localStorage) {
    return defaultValue;
  }
  
  try {
    const item = localStorage.getItem(key);
    return item || defaultValue;
  } catch (error) {
    console.error(`Error accessing localStorage for key ${key}:`, error);
    return defaultValue;
  }
};

// Helper function to safely set values in localStorage
const setSafeLocalStorageItem = (key: string, value: string): void => {
  if (typeof window === 'undefined' || !window.localStorage) {
    return;
  }
  
  try {
    localStorage.setItem(key, value);
  } catch (error) {
    console.error(`Error setting localStorage for key ${key}:`, error);
  }
};

// Validate language value is one of our expected values
const isValidLanguage = (lang: string): lang is Language => {
  return ['en', 'pt-br', 'es'].includes(lang);
};

// Validate theme value is one of our expected values
const isValidTheme = (theme: string): theme is ThemeOption => {
  return ['light', 'dark', 'system'].includes(theme);
};

// Provider component
export const UserPreferencesProvider = ({ children }: { children: ReactNode }) => {
  // Initialize state from localStorage if available, with safer initialization
  const [language, setLanguageState] = useState<Language>(() => {
    const savedLanguage = getSafeLocalStorageItem('userLanguage', 'en');
    return isValidLanguage(savedLanguage) ? savedLanguage : 'en';
  });

  const [theme, setThemeState] = useState<ThemeOption>(() => {
    const savedTheme = getSafeLocalStorageItem('userTheme', 'dark');
    return isValidTheme(savedTheme) ? savedTheme : 'dark';
  });

  // Update localStorage when preferences change
  useEffect(() => {
    setSafeLocalStorageItem('userLanguage', language);
  }, [language]);

  useEffect(() => {
    setSafeLocalStorageItem('userTheme', theme);
  }, [theme]);

  // Set document lang attribute
  useEffect(() => {
    if (typeof document !== 'undefined' && document.documentElement) {
      document.documentElement.lang = language.split('-')[0];
    }
  }, [language]);

  // Wrapper functions to update state
  const setLanguage = (newLanguage: Language) => {
    if (isValidLanguage(newLanguage)) {
      setLanguageState(newLanguage);
    }
  };

  const setTheme = (newTheme: ThemeOption) => {
    if (isValidTheme(newTheme)) {
      setThemeState(newTheme);
    }
  };

  // Memoize the context value to prevent unnecessary re-renders
  const contextValue = {
    language,
    setLanguage,
    theme,
    setTheme
  };

  return (
    <UserPreferencesContext.Provider value={contextValue}>
      {children}
    </UserPreferencesContext.Provider>
  );
};

// Hook for components to consume context
export const useUserPreferences = () => useContext(UserPreferencesContext);