/**
 * Utilitários para SEO e meta tags
 */

/**
 * Atualiza o título da página
 * @param title Título a ser definido
 * @param includeAppName Se deve incluir o nome do app no título
 */
export function setPageTitle(title: string, includeAppName: boolean = true): void {
  document.title = includeAppName ? `${title} | Cody Verse` : title;
}

/**
 * Configura meta tags para SEO e compartilhamento social
 * @param config Configuração de meta tags
 */
export function setMetaTags(config: {
  title?: string;
  description?: string;
  image?: string;
  url?: string;
  type?: string;
  locale?: string;
}): void {
  const { 
    title, 
    description, 
    image = '/icons/og-image.jpg', 
    url = window.location.href,
    type = 'website',
    locale = 'pt-BR'
  } = config;

  // Função auxiliar para criar ou atualizar meta tags
  const setMetaTag = (name: string, content: string) => {
    let meta = document.querySelector(`meta[name="${name}"]`) || 
               document.querySelector(`meta[property="${name}"]`);
               
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute(name.startsWith('og:') ? 'property' : 'name', name);
      document.head.appendChild(meta);
    }
    
    meta.setAttribute('content', content);
  };

  // Básico
  if (description) {
    setMetaTag('description', description);
  }

  // Open Graph
  if (title) {
    setMetaTag('og:title', title);
  }
  
  if (description) {
    setMetaTag('og:description', description);
  }
  
  setMetaTag('og:image', image);
  setMetaTag('og:url', url);
  setMetaTag('og:type', type);
  setMetaTag('og:locale', locale);

  // Twitter
  setMetaTag('twitter:card', 'summary_large_image');
  
  if (title) {
    setMetaTag('twitter:title', title);
  }
  
  if (description) {
    setMetaTag('twitter:description', description);
  }
  
  setMetaTag('twitter:image', image);
}

/**
 * Configura as meta tags para uma página específica
 * @param pageName Nome da página para configurar
 * @param customData Dados customizados para substituir os padrões
 */
export function setupSEO(
  pageName: 'home' | 'learning' | 'profile' | 'achievements' | 'projects',
  customData?: {
    title?: string;
    description?: string;
    image?: string;
  }
): void {
  // Dados padrão para cada página
  const pageData = {
    home: {
      title: 'Início',
      description: 'Plataforma de aprendizado imersiva de IA com interface cyberpunk. Aprenda sobre IA, ML e arquitetura de servidores com assistentes personalizados.',
      image: '/icons/og-home.jpg'
    },
    learning: {
      title: 'Módulos de Aprendizado',
      description: 'Explore nossos módulos de aprendizado interativos para dominar conceitos de IA e aprendizado de máquina.',
      image: '/icons/og-learning.jpg'
    },
    profile: {
      title: 'Perfil',
      description: 'Acompanhe seu progresso e conquistas na plataforma Cody Verse.',
      image: '/icons/og-profile.jpg'
    },
    achievements: {
      title: 'Conquistas',
      description: 'Veja suas conquistas e medalhas em sua jornada de aprendizado na Cody Verse.',
      image: '/icons/og-achievements.jpg'
    },
    projects: {
      title: 'Projetos',
      description: 'Construa projetos interativos para aplicar seus conhecimentos de IA e ML.',
      image: '/icons/og-projects.jpg'
    }
  };

  // Mescla dados padrão com personalizados
  const data = {
    ...pageData[pageName],
    ...customData
  };

  // Configura título e meta tags
  setPageTitle(data.title);
  setMetaTags({
    title: data.title,
    description: data.description,
    image: data.image
  });
}