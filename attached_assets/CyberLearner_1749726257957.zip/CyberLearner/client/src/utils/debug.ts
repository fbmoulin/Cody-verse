// Comprehensive debugging and error monitoring system
export class DebugMonitor {
  private static errors: Array<{
    timestamp: Date;
    message: string;
    stack?: string;
    component?: string;
    severity: 'low' | 'medium' | 'high' | 'critical';
  }> = [];

  private static warnings: Array<{
    timestamp: Date;
    message: string;
    component?: string;
  }> = [];

  static logError(error: Error | string, component?: string, severity: 'low' | 'medium' | 'high' | 'critical' = 'medium') {
    const errorEntry = {
      timestamp: new Date(),
      message: typeof error === 'string' ? error : error.message,
      stack: typeof error === 'object' && error.stack ? error.stack : undefined,
      component: component || undefined,
      severity
    };

    this.errors.push(errorEntry);
    
    // Log to console in development
    if (import.meta.env.DEV) {
      console.error(`[${component || 'Unknown'}] ${errorEntry.message}`, errorEntry.stack);
    }

    // Critical errors should be handled immediately
    if (severity === 'critical') {
      this.handleCriticalError(errorEntry);
    }
  }

  static logWarning(message: string, component?: string) {
    const warningEntry = {
      timestamp: new Date(),
      message,
      component
    };

    this.warnings.push(warningEntry);
    
    if (import.meta.env.DEV) {
      console.warn(`[${component || 'Unknown'}] ${message}`);
    }
  }

  static getErrors() {
    return [...this.errors];
  }

  static getWarnings() {
    return [...this.warnings];
  }

  static clearLogs() {
    this.errors = [];
    this.warnings = [];
  }

  private static handleCriticalError(error: any) {
    // In a real application, this would send to error reporting service
    console.error('CRITICAL ERROR:', error);
  }

  static generateReport() {
    return {
      errors: this.errors.length,
      warnings: this.warnings.length,
      criticalErrors: this.errors.filter(e => e.severity === 'critical').length,
      recentErrors: this.errors.slice(-10),
      recentWarnings: this.warnings.slice(-10)
    };
  }
}

// Error handling utilities for debugging
export function createErrorLogger(componentName: string) {
  return {
    logError: (error: Error | string, severity: 'low' | 'medium' | 'high' | 'critical' = 'medium') => {
      DebugMonitor.logError(error, componentName, severity);
    },
    logWarning: (message: string) => {
      DebugMonitor.logWarning(message, componentName);
    }
  };
}

// Performance debugging utilities
export class PerformanceDebugger {
  private static renderTimes: Map<string, number[]> = new Map();
  
  static measureRender(componentName: string, renderTime: number) {
    if (!this.renderTimes.has(componentName)) {
      this.renderTimes.set(componentName, []);
    }
    
    const times = this.renderTimes.get(componentName)!;
    times.push(renderTime);
    
    // Keep only last 50 measurements
    if (times.length > 50) {
      times.shift();
    }
    
    // Warn about slow renders
    if (renderTime > 16.67) { // More than one frame at 60fps
      DebugMonitor.logWarning(
        `Slow render detected in ${componentName}: ${renderTime.toFixed(2)}ms`,
        'PerformanceDebugger'
      );
    }
  }
  
  static getAverageRenderTime(componentName: string): number {
    const times = this.renderTimes.get(componentName) || [];
    return times.length > 0 ? times.reduce((a, b) => a + b, 0) / times.length : 0;
  }
  
  static getSlowComponents(threshold: number = 10): Array<{ name: string; avgTime: number }> {
    const slow: Array<{ name: string; avgTime: number }> = [];
    
    for (const [name, times] of this.renderTimes.entries()) {
      const avg = times.reduce((a, b) => a + b, 0) / times.length;
      if (avg > threshold) {
        slow.push({ name, avgTime: avg });
      }
    }
    
    return slow.sort((a, b) => b.avgTime - a.avgTime);
  }
}

// Network request monitoring
export class NetworkMonitor {
  private static requests: Array<{
    url: string;
    method: string;
    status: number;
    duration: number;
    timestamp: Date;
  }> = [];
  
  static logRequest(url: string, method: string, status: number, duration: number) {
    this.requests.push({
      url,
      method,
      status,
      duration,
      timestamp: new Date()
    });
    
    // Warn about slow requests
    if (duration > 3000) {
      DebugMonitor.logWarning(
        `Slow network request: ${method} ${url} took ${duration}ms`,
        'NetworkMonitor'
      );
    }
    
    // Log failed requests
    if (status >= 400) {
      DebugMonitor.logError(
        `Network request failed: ${method} ${url} returned ${status}`,
        'NetworkMonitor',
        status >= 500 ? 'high' : 'medium'
      );
    }
  }
  
  static getFailedRequests() {
    return this.requests.filter(req => req.status >= 400);
  }
  
  static getSlowRequests(threshold: number = 2000) {
    return this.requests.filter(req => req.duration > threshold);
  }
}

// Memory leak detection
export class MemoryLeakDetector {
  private static componentCounts: Map<string, number> = new Map();
  private static intervalId: NodeJS.Timeout | null = null;
  
  static registerComponent(componentName: string) {
    const current = this.componentCounts.get(componentName) || 0;
    this.componentCounts.set(componentName, current + 1);
  }
  
  static unregisterComponent(componentName: string) {
    const current = this.componentCounts.get(componentName) || 0;
    this.componentCounts.set(componentName, Math.max(0, current - 1));
  }
  
  static startMonitoring(intervalMs: number = 60000) {
    if (this.intervalId) return;
    
    this.intervalId = setInterval(() => {
      for (const [component, count] of this.componentCounts.entries()) {
        if (count > 100) {
          DebugMonitor.logWarning(
            `Possible memory leak: ${component} has ${count} instances`,
            'MemoryLeakDetector'
          );
        }
      }
    }, intervalMs);
  }
  
  static stopMonitoring() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }
}

import React from 'react';