import React, { useCallback, useMemo, useRef } from 'react';

// Performance monitoring utilities
export class PerformanceMonitor {
  private static metrics: Map<string, number[]> = new Map();
  
  static measure<T>(name: string, fn: () => T): T {
    const start = performance.now();
    const result = fn();
    const end = performance.now();
    
    if (!this.metrics.has(name)) {
      this.metrics.set(name, []);
    }
    this.metrics.get(name)!.push(end - start);
    
    return result;
  }
  
  static async measureAsync<T>(name: string, fn: () => Promise<T>): Promise<T> {
    const start = performance.now();
    const result = await fn();
    const end = performance.now();
    
    if (!this.metrics.has(name)) {
      this.metrics.set(name, []);
    }
    this.metrics.get(name)!.push(end - start);
    
    return result;
  }
  
  static getAverageTime(name: string): number {
    const times = this.metrics.get(name) || [];
    return times.length > 0 ? times.reduce((a, b) => a + b, 0) / times.length : 0;
  }
  
  static getMetrics(): Record<string, { avg: number; count: number; total: number }> {
    const result: Record<string, { avg: number; count: number; total: number }> = {};
    
    for (const [name, times] of this.metrics.entries()) {
      const total = times.reduce((a, b) => a + b, 0);
      result[name] = {
        avg: times.length > 0 ? total / times.length : 0,
        count: times.length,
        total
      };
    }
    
    return result;
  }
}

// Optimized hooks for better performance
export function useDebounced<T extends (...args: any[]) => any>(
  callback: T,
  delay: number
): T {
  const timeoutRef = useRef<NodeJS.Timeout>();
  
  return useCallback((...args: Parameters<T>) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    timeoutRef.current = setTimeout(() => {
      callback(...args);
    }, delay);
  }, [callback, delay]) as T;
}

export function useThrottled<T extends (...args: any[]) => any>(
  callback: T,
  delay: number
): T {
  const lastCall = useRef<number>(0);
  
  return useCallback((...args: Parameters<T>) => {
    const now = Date.now();
    if (now - lastCall.current >= delay) {
      lastCall.current = now;
      callback(...args);
    }
  }, [callback, delay]) as T;
}

// Memoized content parser
export const useMemoizedContentParser = (content: any) => {
  return useMemo(() => {
    if (typeof content === 'string') {
      try {
        return JSON.parse(content);
      } catch {
        return { sections: [] };
      }
    } else if (typeof content === 'object' && content !== null) {
      return content;
    }
    return { sections: [] };
  }, [content]);
};

// Error boundary for performance issues
export class PerformanceError extends Error {
  constructor(message: string, public metric: string, public value: number) {
    super(message);
    this.name = 'PerformanceError';
  }
}

// Memory usage monitoring
export class MemoryMonitor {
  private static checkInterval: NodeJS.Timeout | null = null;
  
  static startMonitoring(intervalMs: number = 30000): void {
    if (this.checkInterval) return;
    
    this.checkInterval = setInterval(() => {
      if ('memory' in performance) {
        const memory = (performance as any).memory;
        if (memory.usedJSHeapSize > memory.jsHeapSizeLimit * 0.9) {
          console.warn('High memory usage detected:', {
            used: memory.usedJSHeapSize,
            limit: memory.jsHeapSizeLimit,
            percentage: (memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100
          });
        }
      }
    }, intervalMs);
  }
  
  static stopMonitoring(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
  }
}

// Lazy loading utilities
export function createLazyComponent<T extends React.ComponentType<any>>(
  importFn: () => Promise<{ default: T }>
): React.LazyExoticComponent<T> {
  return React.lazy(() => 
    PerformanceMonitor.measureAsync('lazy-load', importFn)
  );
}