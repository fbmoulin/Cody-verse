import { useQuery, useMutation, useQueryClient, UseQueryOptions } from '@tanstack/react-query';
import { useCallback, useMemo } from 'react';

// Optimized query hooks with caching and error handling
export function useOptimizedQuery<T>(
  queryKey: string | readonly unknown[],
  queryFn: () => Promise<T>,
  options?: Partial<UseQueryOptions<T>>
) {
  return useQuery({
    queryKey: Array.isArray(queryKey) ? queryKey : [queryKey],
    queryFn,
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000,
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
    ...options,
  });
}

// Optimized module data fetching
export function useModuleData(moduleId: number) {
  return useOptimizedQuery(
    ['module', moduleId],
    async () => {
      const response = await fetch(`/api/modules/${moduleId}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch module ${moduleId}`);
      }
      return response.json();
    },
    {
      enabled: !!moduleId,
      staleTime: 10 * 60 * 1000, // Modules don't change often
    }
  );
}

// Optimized user progress fetching
export function useUserProgress(userId: number) {
  return useOptimizedQuery(
    ['userProgress', userId],
    async () => {
      const response = await fetch(`/api/users/${userId}/progress`);
      if (!response.ok) {
        throw new Error(`Failed to fetch user progress`);
      }
      return response.json();
    },
    {
      enabled: !!userId,
      staleTime: 2 * 60 * 1000, // Progress updates more frequently
    }
  );
}

// Optimized modules list fetching
export function useModulesList() {
  return useOptimizedQuery(
    ['modules'],
    async () => {
      const response = await fetch('/api/modules');
      if (!response.ok) {
        throw new Error('Failed to fetch modules');
      }
      return response.json();
    },
    {
      staleTime: 15 * 60 * 1000, // Module list is fairly static
    }
  );
}

// Batch progress updates
export function useProgressMutation() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ moduleId, progress, completed }: {
      moduleId: number;
      progress: number;
      completed: boolean;
    }) => {
      const response = await fetch('/api/user/progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ moduleId, progress, completed }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to update progress');
      }
      
      return response.json();
    },
    onSuccess: (data, variables) => {
      // Invalidate and refetch relevant queries
      queryClient.invalidateQueries({ queryKey: ['userProgress'] });
      queryClient.invalidateQueries({ queryKey: ['modules'] });
      
      // Optimistically update cache
      queryClient.setQueryData(['userProgress', 1], (old: any) => {
        if (!old) return old;
        return old.map((item: any) => 
          item.moduleId === variables.moduleId
            ? { ...item, progress: variables.progress, completed: variables.completed }
            : item
        );
      });
    },
  });
}

// Debounced search for content
export function useDebouncedSearch(searchTerm: string, delay: number = 300) {
  const debouncedTerm = useMemo(() => {
    const handler = setTimeout(() => searchTerm, delay);
    return () => clearTimeout(handler);
  }, [searchTerm, delay]);

  return useOptimizedQuery(
    ['search', searchTerm],
    async () => {
      if (!searchTerm || searchTerm.length < 2) return [];
      
      const response = await fetch(`/api/search?q=${encodeURIComponent(searchTerm)}`);
      if (!response.ok) {
        throw new Error('Search failed');
      }
      return response.json();
    },
    {
      enabled: !!(searchTerm && searchTerm.length >= 2),
      staleTime: 5 * 60 * 1000,
    }
  );
}

// Prefetch utility for better UX
export function usePrefetch() {
  const queryClient = useQueryClient();
  
  const prefetchModule = useCallback((moduleId: number) => {
    queryClient.prefetchQuery({
      queryKey: ['module', moduleId],
      queryFn: async () => {
        const response = await fetch(`/api/modules/${moduleId}`);
        return response.json();
      },
      staleTime: 10 * 60 * 1000,
    });
  }, [queryClient]);
  
  const prefetchUserProgress = useCallback((userId: number) => {
    queryClient.prefetchQuery({
      queryKey: ['userProgress', userId],
      queryFn: async () => {
        const response = await fetch(`/api/users/${userId}/progress`);
        return response.json();
      },
      staleTime: 2 * 60 * 1000,
    });
  }, [queryClient]);
  
  return { prefetchModule, prefetchUserProgress };
}