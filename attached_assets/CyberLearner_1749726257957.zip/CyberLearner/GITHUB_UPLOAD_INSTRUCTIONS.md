# How to Upload Your Project to GitHub

Follow these steps to upload your CodyVerse project to GitHub:

## 1. Create a New Repository on GitHub

1. Go to [GitHub](https://github.com) and log in to your account
2. Click the "+" icon in the top right corner and select "New repository"
3. Name your repository (e.g., "cody-verse")
4. Add a description (optional)
5. Choose whether to make it public or private
6. Do NOT initialize with a README, .gitignore, or license as we already have those
7. Click "Create repository"

## 2. Download Your Project

Since you're working in Replit, you'll need to:

1. In the Replit interface, click on the three dots menu (⋮) in the files panel
2. Select "Download as zip"
3. Extract the zip file to a folder on your computer

## 3. Initialize Git and Push to GitHub

Open a terminal or command prompt on your computer and navigate to your project folder:

```bash
# Navigate to your project folder
cd path/to/extracted/project

# Initialize Git repository
git init

# Add all files to staging
git add .

# Create your first commit
git commit -m "Initial commit"

# Add GitHub as remote origin (replace with your repository URL)
git remote add origin https://github.com/yourusername/cody-verse.git

# Push to GitHub
git push -u origin main
```

Note: If your default branch is called "master" instead of "main", use:

```bash
git push -u origin master
```

## 4. Verify Your Upload

1. Refresh your GitHub repository page
2. You should see all your project files listed

## 5. Important Security Note

- Make sure your `.env` file with sensitive information like API keys is listed in `.gitignore`
- If you accidentally uploaded sensitive information, change your API keys and passwords immediately

## Next Steps

Once your code is on GitHub, you can:

1. Set up GitHub Actions for CI/CD
2. Add collaborators to your project
3. Create issues for future enhancements
4. Enable GitHub Pages if you want to showcase your project