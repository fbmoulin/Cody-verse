// Memory optimization and garbage collection management
export class MemoryOptimizer {
  private static memoryThreshold = 90; // Memory usage percentage threshold
  private static gcInterval: NodeJS.Timeout | null = null;
  private static lastGCTime = Date.now();
  
  static startMonitoring(intervalMs: number = 30000) {
    if (this.gcInterval) return;
    
    this.gcInterval = setInterval(() => {
      this.checkAndOptimizeMemory();
    }, intervalMs);
    
    console.log('Memory optimization monitoring started');
  }
  
  static stopMonitoring() {
    if (this.gcInterval) {
      clearInterval(this.gcInterval);
      this.gcInterval = null;
    }
  }
  
  private static checkAndOptimizeMemory() {
    const usage = process.memoryUsage();
    const heapUsagePercent = (usage.heapUsed / usage.heapTotal) * 100;
    
    if (heapUsagePercent > this.memoryThreshold) {
      console.warn(`High memory usage detected: ${Math.round(heapUsagePercent)}%`);
      this.performGarbageCollection();
    }
    
    // Log memory stats periodically
    if (Date.now() - this.lastGCTime > 300000) { // Every 5 minutes
      console.log(`Memory stats - Heap: ${Math.round(usage.heapUsed / 1024 / 1024)}MB / ${Math.round(usage.heapTotal / 1024 / 1024)}MB`);
      this.lastGCTime = Date.now();
    }
  }
  
  private static performGarbageCollection() {
    try {
      if (global.gc) {
        global.gc();
        console.log('Manual garbage collection performed');
      } else {
        console.warn('Garbage collection not available - run with --expose-gc flag');
      }
    } catch (error) {
      console.error('Failed to perform garbage collection:', error);
    }
  }
  
  static getMemoryStats() {
    const usage = process.memoryUsage();
    return {
      heapUsed: Math.round(usage.heapUsed / 1024 / 1024),
      heapTotal: Math.round(usage.heapTotal / 1024 / 1024),
      heapUsagePercent: Math.round((usage.heapUsed / usage.heapTotal) * 100),
      external: Math.round(usage.external / 1024 / 1024),
      rss: Math.round(usage.rss / 1024 / 1024)
    };
  }
  
  static optimizeQueryCache() {
    // Clear old query cache entries to free memory
    if (global.queryCache) {
      const oldEntries = [];
      const now = Date.now();
      
      for (const [key, entry] of global.queryCache.entries()) {
        if (now - entry.timestamp > entry.ttl) {
          oldEntries.push(key);
        }
      }
      
      oldEntries.forEach(key => global.queryCache.delete(key));
      
      if (oldEntries.length > 0) {
        console.log(`Cleared ${oldEntries.length} expired cache entries`);
      }
    }
  }
}

// Enhanced request cleanup
export class RequestCleanup {
  private static activeRequests = new Map<string, { start: number; path: string }>();
  
  static trackRequest(requestId: string, path: string) {
    this.activeRequests.set(requestId, { start: Date.now(), path });
  }
  
  static completeRequest(requestId: string) {
    const request = this.activeRequests.get(requestId);
    if (request) {
      const duration = Date.now() - request.start;
      if (duration > 10000) {
        console.warn(`Long-running request completed: ${request.path} took ${duration}ms`);
      }
      this.activeRequests.delete(requestId);
    }
  }
  
  static getActiveRequests() {
    return Array.from(this.activeRequests.entries()).map(([id, data]) => ({
      id,
      ...data,
      duration: Date.now() - data.start
    }));
  }
  
  static cleanupStaleRequests(maxAgeMs = 60000) {
    const now = Date.now();
    const staleRequests = [];
    
    for (const [id, data] of this.activeRequests.entries()) {
      if (now - data.start > maxAgeMs) {
        staleRequests.push(id);
      }
    }
    
    staleRequests.forEach(id => {
      console.warn(`Cleaning up stale request: ${id}`);
      this.activeRequests.delete(id);
    });
  }
}

// Connection pool optimization
export class ConnectionPoolManager {
  static optimizePool() {
    // Implementation depends on the database pool being used
    console.log('Optimizing database connection pool...');
    
    // Force connection cleanup
    if (process.env.NODE_ENV === 'development') {
      // In development, be more aggressive about closing idle connections
      this.schedulePoolCleanup();
    }
  }
  
  private static schedulePoolCleanup() {
    setInterval(() => {
      // This would call pool-specific cleanup methods
      console.log('Performing connection pool maintenance');
    }, 120000); // Every 2 minutes in development
  }
}

// Global memory optimization initialization
export function initializeMemoryOptimizations() {
  MemoryOptimizer.startMonitoring(30000);
  
  // Schedule periodic cleanups
  setInterval(() => {
    MemoryOptimizer.optimizeQueryCache();
    RequestCleanup.cleanupStaleRequests();
  }, 60000); // Every minute
  
  // Handle process warnings
  process.on('warning', (warning) => {
    if (warning.name === 'MaxListenersExceededWarning') {
      console.warn('MaxListeners warning detected - potential memory leak');
    }
  });
  
  console.log('Memory optimization systems initialized');
}