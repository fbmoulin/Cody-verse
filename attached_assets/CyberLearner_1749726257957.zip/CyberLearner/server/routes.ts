import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { RobustStorageWrapper } from "./robust-db";
import { ServerTypeUtils } from "./type-utils";
import { 
  insertUserSchema,
  insertUserProgressSchema,
  insertUserChallengeSchema,
  insertUserAchievementSchema,
  insertUserTutorialSchema,
  insertUserAlchemyProgressSchema
} from "@shared/schema";
import { z } from "zod";
import OpenAI from "openai";
import { 
  integrationStabilityMiddleware, 
  createHealthEndpoint, 
  initializeHealthChecks,
  CircuitBreaker,
  RetryHandler
} from "./integration-health";
import { initializeMemoryOptimizations, MemoryOptimizer } from "./memory-optimizer";
import { ErrorRecoverySystem, ResilientStorageWrapper, setupGlobalErrorHandling } from "./error-recovery";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = (route: string) => `/api${route}`;

  // Initialize comprehensive stability systems
  initializeHealthChecks();
  initializeMemoryOptimizations();
  ErrorRecoverySystem.initialize();
  setupGlobalErrorHandling();

  // Add stability middleware to all routes
  app.use(integrationStabilityMiddleware);

  // Initialize resilient storage wrapper
  const resilientStorage = new ResilientStorageWrapper();

  // Circuit breakers for external services
  const openaiCircuitBreaker = new CircuitBreaker('openai', 3, 30000);
  const dbCircuitBreaker = new CircuitBreaker('database', 5, 60000);

  // Health check endpoint
  app.get('/health', createHealthEndpoint());
  
  // Memory stats endpoint
  app.get('/memory-stats', (req: Request, res: Response) => {
    const stats = MemoryOptimizer.getMemoryStats();
    res.json(stats);
  });

  // System status endpoint
  app.get('/system-status', (req: Request, res: Response) => {
    const systemHealth = ErrorRecoverySystem.getSystemHealth();
    const memoryStats = MemoryOptimizer.getMemoryStats();
    
    res.json({
      timestamp: new Date(),
      system: systemHealth,
      memory: memoryStats,
      uptime: process.uptime()
    });
  });

  // Optimized authentication middleware for demo environment
  const requireAuth = (req: Request, res: Response, next: NextFunction): void => {
    const userId = req.headers['x-user-id'];
    
    // For demo purposes, auto-authenticate with user ID 1 if no auth provided
    const authenticatedUserId = userId ? parseInt(userId as string) : 1;
    
    if (isNaN(authenticatedUserId)) {
      res.status(401).json({ message: "Invalid authentication" });
      return;
    }
    
    // Store userId in request for use in routes
    (req as any).userId = authenticatedUserId;
    next();
  };

  // Optimized ownership middleware for demo environment
  const requireOwnership = (req: Request, res: Response, next: NextFunction) => {
    const requestedUserId = ServerTypeUtils.parseNumberParam(req.params.userId, 'userId');
    const authenticatedUserId = (req as any).userId;
    
    // For demo purposes, allow access to user 1 data
    if (requestedUserId === 1 || requestedUserId === authenticatedUserId) {
      next();
      return;
    }
    
    return res.status(403).json({ message: "Access denied" });
  };

  // Authentication routes
  app.post(apiRouter("/auth/register"), async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      return res.status(201).json({
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        progress: user.progress,
        level: user.level,
        xp: user.xp,
        preferredCharacter: user.preferredCharacter
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.post(apiRouter("/auth/logout"), async (req, res) => {
    // Since we're using localStorage for authentication in the frontend,
    // we don't need to manage server-side sessions for now
    // The client will handle removing the userId from localStorage
    return res.status(200).json({ message: "Logged out successfully" });
  });

  app.post(apiRouter("/auth/login"), async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      
      // In a real app, use bcrypt or similar to compare hashed passwords
      // For now, we'll use a simple comparison as placeholder
      // A proper implementation would be: await bcrypt.compare(password, user.password)
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      return res.status(200).json({
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        progress: user.progress,
        level: user.level,
        xp: user.xp,
        preferredCharacter: user.preferredCharacter
      });
    } catch (error) {
      return res.status(500).json({ message: "Login failed" });
    }
  });

  // Module routes
  app.get(apiRouter("/modules"), async (_req, res) => {
    try {
      const modules = await storage.getModules();
      return res.status(200).json(modules);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch modules" });
    }
  });

  app.get(apiRouter("/modules/:id"), async (req, res) => {
    try {
      const moduleId = ServerTypeUtils.parseNumberParam(req.params.id, 'moduleId');
      if (isNaN(moduleId)) {
        return res.status(400).json({ message: "Invalid module ID" });
      }
      
      const module = await storage.getModule(moduleId);
      
      if (!module) {
        return res.status(404).json({ message: "Module not found" });
      }
      
      return res.status(200).json(module);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch module" });
    }
  });

  // Challenge routes
  app.get(apiRouter("/challenges"), async (_req, res) => {
    try {
      const challenges = await storage.getChallenges();
      return res.status(200).json(challenges);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch challenges" });
    }
  });

  app.get(apiRouter("/modules/:moduleId/challenges"), async (req, res) => {
    try {
      const moduleId = parseInt(req.params.moduleId || '');
      if (isNaN(moduleId)) {
        return res.status(400).json({ message: "Invalid module ID" });
      }
      
      const challenges = await storage.getChallengesByModule(moduleId);
      return res.status(200).json(challenges);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch challenges for module" });
    }
  });

  // Alternative route for frontend compatibility
  app.get(apiRouter("/challenges/module"), async (req, res) => {
    try {
      const moduleId = parseInt(req.query.moduleId as string);
      if (isNaN(moduleId)) {
        return res.status(400).json({ message: "Invalid module ID" });
      }
      
      const challenges = await storage.getChallengesByModule(moduleId);
      return res.status(200).json(challenges);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch challenges" });
    }
  });

  app.get(apiRouter("/challenges/:id"), async (req, res) => {
    try {
      const challengeId = ServerTypeUtils.parseNumberParam(req.params.id, 'challengeId');
      if (isNaN(challengeId)) {
        return res.status(400).json({ message: "Invalid challenge ID" });
      }
      
      const challenge = await storage.getChallenge(challengeId);
      
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found" });
      }
      
      return res.status(200).json(challenge);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch challenge" });
    }
  });

  // Achievement routes
  app.get(apiRouter("/achievements"), async (_req, res) => {
    try {
      const achievements = await storage.getAchievements();
      return res.status(200).json(achievements);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  // User Progress routes
  app.get(apiRouter("/users/:userId/progress"), requireAuth, requireOwnership, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId || '');
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const progress = await storage.getUserProgress(userId);
      return res.status(200).json(progress);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch user progress" });
    }
  });

  app.post(apiRouter("/users/:userId/modules/:moduleId/progress"), requireAuth, requireOwnership, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId || '');
      const moduleId = parseInt(req.params.moduleId || '');
      
      if (isNaN(userId) || isNaN(moduleId)) {
        return res.status(400).json({ message: "Invalid user ID or module ID" });
      }
      
      const progressData = insertUserProgressSchema.parse({
        ...req.body,
        userId,
        moduleId,
        lastAccessed: new Date()
      });
      
      const updatedProgress = await storage.updateUserModuleProgress(progressData);
      
      // Check if completing this module should award XP
      if (progressData.completed) {
        const module = await storage.getModule(moduleId);
        if (module) {
          const user = await storage.getUser(userId);
          if (user) {
            // Add XP reward to user
            const newXp = user.xp + module.xpReward;
            // Simple level calculation: level up every 1000 XP
            const newLevel = Math.floor(newXp / 1000) + 1;
            await storage.updateUserProgress(userId, user.progress + 1, newLevel, newXp);
          }
        }
      }
      
      return res.status(200).json(updatedProgress);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid progress data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to update progress" });
    }
  });

  // User Challenge routes
  app.get(apiRouter("/users/:userId/challenges"), requireAuth, requireOwnership, async (req, res) => {
    try {
      const userId = ServerTypeUtils.parseNumberParam(req.params.userId, 'userId');
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const challenges = await storage.getUserChallenges(userId);
      return res.status(200).json(challenges);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch user challenges" });
    }
  });

  app.post(apiRouter("/users/:userId/challenges/:challengeId"), requireAuth, requireOwnership, async (req, res) => {
    try {
      const userId = ServerTypeUtils.parseNumberParam(req.params.userId, 'userId');
      const challengeId = ServerTypeUtils.parseNumberParam(req.params.challengeId, 'challengeId');
      
      if (isNaN(userId) || isNaN(challengeId)) {
        return res.status(400).json({ message: "Invalid user ID or challenge ID" });
      }
      
      const challengeData = insertUserChallengeSchema.parse({
        ...req.body,
        userId,
        challengeId,
        lastAttempt: new Date()
      });
      
      const updatedChallenge = await storage.updateUserChallenge(challengeData);
      
      // Check if completing this challenge should award XP
      if (challengeData.completed) {
        const challenge = await storage.getChallenge(challengeId);
        if (challenge) {
          const user = await storage.getUser(userId);
          if (user) {
            // Add XP reward to user
            const newXp = user.xp + challenge.xpReward;
            // Simple level calculation: level up every 1000 XP
            const newLevel = Math.floor(newXp / 1000) + 1;
            await storage.updateUserProgress(userId, user.progress, newLevel, newXp);
          }
        }
      }
      
      return res.status(200).json(updatedChallenge);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid challenge data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to update challenge progress" });
    }
  });

  // User Achievement routes
  app.get(apiRouter("/users/:userId/achievements"), requireAuth, requireOwnership, async (req, res) => {
    try {
      const userId = ServerTypeUtils.parseNumberParam(req.params.userId, 'userId');
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const achievements = await storage.getUserAchievements(userId);
      return res.status(200).json(achievements);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch user achievements" });
    }
  });

  app.post(apiRouter("/users/:userId/achievements/:achievementId"), requireAuth, requireOwnership, async (req, res) => {
    try {
      const userId = ServerTypeUtils.parseNumberParam(req.params.userId, 'userId');
      const achievementId = ServerTypeUtils.parseNumberParam(req.params.achievementId, 'achievementId');
      
      if (isNaN(userId) || isNaN(achievementId)) {
        return res.status(400).json({ message: "Invalid user ID or achievement ID" });
      }
      
      const achievementData = insertUserAchievementSchema.parse({
        userId,
        achievementId,
        unlockedAt: new Date()
      });
      
      const newAchievement = await storage.addUserAchievement(achievementData);
      
      // Add XP reward to user
      const achievement = await storage.getAchievement(achievementId);
      if (achievement) {
        const user = await storage.getUser(userId);
        if (user) {
          const newXp = user.xp + achievement.xpReward;
          const newLevel = Math.floor(newXp / 1000) + 1;
          await storage.updateUserProgress(userId, user.progress, newLevel, newXp);
        }
      }
      
      return res.status(201).json(newAchievement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid achievement data", errors: error.errors });
      }
      if (error instanceof Error && error.message === "User already has this achievement") {
        return res.status(409).json({ message: error.message });
      }
      return res.status(500).json({ message: "Failed to add achievement" });
    }
  });

  // User Preferences
  app.patch(apiRouter("/users/:userId/preferences"), requireAuth, requireOwnership, async (req, res) => {
    try {
      const userId = ServerTypeUtils.parseNumberParam(req.params.userId, 'userId');
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const { preferredCharacter } = req.body;
      
      if (!preferredCharacter) {
        return res.status(400).json({ message: "Preferred character is required" });
      }
      
      const updatedUser = await storage.setPreferredCharacter(userId, preferredCharacter);
      
      return res.status(200).json({
        id: updatedUser.id,
        username: updatedUser.username,
        displayName: updatedUser.displayName,
        progress: updatedUser.progress,
        level: updatedUser.level,
        xp: updatedUser.xp,
        preferredCharacter: updatedUser.preferredCharacter
      });
    } catch (error) {
      return res.status(500).json({ message: "Failed to update preferences" });
    }
  });
  
  // Tutorial routes
  app.get(apiRouter("/users/:userId/tutorial-status"), requireAuth, requireOwnership, async (req, res) => {
    try {
      const userId = ServerTypeUtils.parseNumberParam(req.params.userId, 'userId');
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const tutorialStatus = await storage.getUserTutorialStatus(userId);
      
      if (!tutorialStatus) {
        // Return a default tutorial status if none exists
        return res.status(200).json({
          userId,
          completed: false,
          completedSteps: [],
          lastUpdated: new Date()
        });
      }
      
      return res.status(200).json(tutorialStatus);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch tutorial status" });
    }
  });
  
  app.post(apiRouter("/users/:userId/tutorial-status"), requireAuth, requireOwnership, async (req, res) => {
    try {
      const userId = ServerTypeUtils.parseNumberParam(req.params.userId, 'userId');
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const tutorialData = insertUserTutorialSchema.parse({
        ...req.body,
        userId,
        lastUpdated: new Date()
      });
      
      const updatedTutorial = await storage.updateUserTutorialStatus(tutorialData);
      
      return res.status(200).json(updatedTutorial);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid tutorial data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to update tutorial status" });
    }
  });

  // AI Assistant endpoint
  app.post(apiRouter("/assistant"), async (req, res) => {
    try {
      const { prompt, context, character } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ message: "Prompt is required" });
      }

      // Initialize OpenAI client with API key from environment variable
      const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
      });

      // Prepare character context based on selected character
      let characterContext = "";
      if (character === "CODY") {
        characterContext = "You are Cody, a bright yellow cybernetic cat assistant with a tech-savvy personality. You specialize in AI fundamentals, tech guidance, and beginner support. Your tone is helpful, enthusiastic, and slightly playful.";
      } else if (character === "NEXUS") {
        characterContext = "You are Nexus, a neon blue digital fox with advanced analytical abilities. You specialize in advanced AI concepts, system architecture, and performance optimization. Your tone is precise, strategic, and knowledgeable.";
      } else if (character === "ECHO") {
        characterContext = "You are Echo, a sleek black quantum raven with pink digital highlights. You specialize in creative AI solutions, project development, and expert techniques. Your tone is intuitive, creative, and thoughtful.";
      } else {
        characterContext = "You are an AI assistant in CodyVerse, a cyberpunk learning environment.";
      }

      // Add user-provided context if available
      if (context) {
        characterContext += ` Additional context: ${context}`;
      }

      // Make API call to OpenAI
      const response = await openai.chat.completions.create({
        model: "gpt-4o",  // Using the latest model (May 2025)
        messages: [
          { role: "system", content: characterContext },
          { role: "user", content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 500
      });

      // Get and send the response text
      const responseText = response.choices[0]?.message?.content || "I'm having trouble connecting to my cyberbrain right now. Let's try again in a moment!";
      return res.status(200).json({ response: responseText });
    } catch (error) {
      console.error("OpenAI API error:", error);
      
      // Check for API key issues
      if (error instanceof Error && error.message.includes("API key")) {
        return res.status(401).json({ 
          message: "OpenAI API key is missing or invalid", 
          needsApiKey: true 
        });
      }
      
      return res.status(500).json({ 
        message: "Failed to get assistant response", 
        error: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Alchemy Elements routes
  app.get(apiRouter("/alchemy/elements"), async (req, res) => {
    try {
      const elements = await storage.getAllAlchemyElements();
      return res.status(200).json(elements);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch alchemy elements" });
    }
  });

  app.get(apiRouter("/alchemy/elements/:elementId"), async (req, res) => {
    try {
      const elementId = ServerTypeUtils.parseStringParam(req.params.elementId, 'elementId');
      const element = await storage.getAlchemyElement(elementId);
      
      if (!element) {
        return res.status(404).json({ message: "Element not found" });
      }
      
      return res.status(200).json(element);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch alchemy element" });
    }
  });

  // Alchemy Recipes routes
  app.get(apiRouter("/alchemy/recipes"), async (req, res) => {
    try {
      const recipes = await storage.getAllAlchemyRecipes();
      return res.status(200).json(recipes);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch alchemy recipes" });
    }
  });

  // User Alchemy Progress routes
  app.get(apiRouter("/users/:userId/alchemy"), async (req, res) => {
    try {
      const userId = ServerTypeUtils.parseNumberParam(req.params.userId, 'userId');
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const progress = await storage.getUserAlchemyProgress(userId);
      return res.status(200).json(progress);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch user alchemy progress" });
    }
  });

  // Element combination endpoint
  app.post(apiRouter("/users/:userId/alchemy/combine"), async (req, res) => {
    try {
      const userId = ServerTypeUtils.parseNumberParam(req.params.userId, 'userId');
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const { element1, element2 } = req.body;
      
      if (!element1 || !element2) {
        return res.status(400).json({ message: "Two elements are required for combination" });
      }
      
      const result = await storage.checkElementDiscovery(userId, element1, element2);
      
      if (!result) {
        return res.status(404).json({ message: "No combination found for these elements" });
      }
      
      return res.status(200).json({
        success: true,
        newElement: result,
        message: `You discovered ${result.name}!`
      });
    } catch (error) {
      return res.status(500).json({ message: "Failed to combine elements" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
