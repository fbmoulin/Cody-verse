import { pool } from './db';
import { storage } from './storage';
import { Request, Response, NextFunction } from 'express';

// Comprehensive integration health monitoring system
export class IntegrationHealthMonitor {
  private static healthChecks = new Map<string, HealthCheck>();
  private static lastFullCheck = new Date();
  private static checkInterval: NodeJS.Timeout | null = null;

  static registerHealthCheck(name: string, check: HealthCheck) {
    this.healthChecks.set(name, check);
  }

  static async runHealthChecks(): Promise<HealthReport> {
    const results: HealthCheckResult[] = [];
    const startTime = Date.now();

    for (const [name, check] of this.healthChecks.entries()) {
      try {
        const checkStart = Date.now();
        const result = await Promise.race([
          check.execute(),
          new Promise<HealthCheckResult>((_, reject) => 
            setTimeout(() => reject(new Error('Health check timeout')), check.timeout || 5000)
          )
        ]);
        
        results.push({
          ...result,
          name,
          duration: Date.now() - checkStart,
          timestamp: new Date()
        });
      } catch (error) {
        results.push({
          name,
          status: 'unhealthy',
          message: error instanceof Error ? error.message : 'Unknown error',
          duration: 0,
          timestamp: new Date()
        });
      }
    }

    const report: HealthReport = {
      overall: results.every(r => r.status === 'healthy') ? 'healthy' : 'degraded',
      checks: results,
      duration: Date.now() - startTime,
      timestamp: new Date()
    };

    this.lastFullCheck = new Date();
    return report;
  }

  static startMonitoring(intervalMs: number = 30000) {
    if (this.checkInterval) return;

    this.checkInterval = setInterval(async () => {
      try {
        const report = await this.runHealthChecks();
        if (report.overall !== 'healthy') {
          console.warn('Integration health degraded:', report);
        }
      } catch (error) {
        console.error('Health monitoring failed:', error);
      }
    }, intervalMs);
  }

  static stopMonitoring() {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
  }

  static getLastCheckTime(): Date {
    return this.lastFullCheck;
  }
}

// Database integration health check
export class DatabaseHealthCheck implements HealthCheck {
  timeout = 5000;

  async execute(): Promise<HealthCheckResult> {
    try {
      // Test basic connectivity
      const client = await pool.connect();
      
      // Test query execution
      const start = Date.now();
      await client.query('SELECT 1 as health_check');
      const queryTime = Date.now() - start;
      
      // Test connection pool stats
      const poolStats = {
        totalCount: pool.totalCount,
        idleCount: pool.idleCount,
        waitingCount: pool.waitingCount
      };
      
      client.release();

      return {
        name: 'database',
        status: queryTime > 1000 ? 'degraded' : 'healthy',
        message: `Query time: ${queryTime}ms, Pool: ${poolStats.idleCount}/${poolStats.totalCount}`,
        metadata: { queryTime, poolStats }
      };
    } catch (error) {
      return {
        name: 'database',
        status: 'unhealthy',
        message: error instanceof Error ? error.message : 'Database connection failed'
      };
    }
  }
}

// Storage layer health check
export class StorageHealthCheck implements HealthCheck {
  timeout = 3000;

  async execute(): Promise<HealthCheckResult> {
    try {
      // Test storage operations
      const modules = await storage.getModules();
      
      if (!modules || modules.length === 0) {
        return {
          name: 'storage',
          status: 'degraded',
          message: 'No modules found in storage'
        };
      }

      return {
        name: 'storage',
        status: 'healthy',
        message: `Storage operational, ${modules.length} modules available`
      };
    } catch (error) {
      return {
        name: 'storage',
        status: 'unhealthy',
        message: error instanceof Error ? error.message : 'Storage operation failed'
      };
    }
  }
}

// Memory health check
export class MemoryHealthCheck implements HealthCheck {
  timeout = 1000;

  async execute(): Promise<HealthCheckResult> {
    const usage = process.memoryUsage();
    const heapUsedMB = Math.round(usage.heapUsed / 1024 / 1024);
    const heapTotalMB = Math.round(usage.heapTotal / 1024 / 1024);
    const heapUsagePercent = Math.round((usage.heapUsed / usage.heapTotal) * 100);

    let status: 'healthy' | 'degraded' | 'unhealthy' = 'healthy';
    let message = `Heap: ${heapUsedMB}MB/${heapTotalMB}MB (${heapUsagePercent}%)`;

    if (heapUsagePercent > 90) {
      status = 'unhealthy';
      message += ' - Critical memory usage';
    } else if (heapUsagePercent > 70) {
      status = 'degraded';
      message += ' - High memory usage';
    }

    return {
      name: 'memory',
      status,
      message,
      metadata: usage
    };
  }
}

// External API health check (for OpenAI if configured)
export class ExternalAPIHealthCheck implements HealthCheck {
  timeout = 10000;

  async execute(): Promise<HealthCheckResult> {
    // Check if OpenAI API key is configured
    if (!process.env.OPENAI_API_KEY) {
      return {
        name: 'external_apis',
        status: 'degraded',
        message: 'OpenAI API key not configured'
      };
    }

    try {
      // Simple connectivity test to OpenAI
      const response = await fetch('https://api.openai.com/v1/models', {
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        },
        signal: AbortSignal.timeout(8000)
      });

      if (response.ok) {
        return {
          name: 'external_apis',
          status: 'healthy',
          message: 'External APIs accessible'
        };
      } else {
        return {
          name: 'external_apis',
          status: 'degraded',
          message: `API returned ${response.status}`
        };
      }
    } catch (error) {
      return {
        name: 'external_apis',
        status: 'unhealthy',
        message: error instanceof Error ? error.message : 'External API unreachable'
      };
    }
  }
}

// Circuit breaker for external integrations
export class CircuitBreaker {
  private failures = 0;
  private lastFailureTime: Date | null = null;
  private state: 'closed' | 'open' | 'half-open' = 'closed';

  constructor(
    private name: string,
    private failureThreshold = 5,
    private recoveryTimeMs = 60000
  ) {}

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'open') {
      if (this.shouldAttemptReset()) {
        this.state = 'half-open';
      } else {
        throw new Error(`Circuit breaker open for ${this.name}`);
      }
    }

    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess() {
    this.failures = 0;
    this.state = 'closed';
  }

  private onFailure() {
    this.failures++;
    this.lastFailureTime = new Date();

    if (this.failures >= this.failureThreshold) {
      this.state = 'open';
      console.warn(`Circuit breaker opened for ${this.name} after ${this.failures} failures`);
    }
  }

  private shouldAttemptReset(): boolean {
    return this.lastFailureTime !== null && 
           Date.now() - this.lastFailureTime.getTime() > this.recoveryTimeMs;
  }

  getState() {
    return {
      state: this.state,
      failures: this.failures,
      lastFailure: this.lastFailureTime
    };
  }
}

// Request retry mechanism with exponential backoff
export class RetryHandler {
  static async withRetry<T>(
    operation: () => Promise<T>,
    maxRetries = 3,
    baseDelayMs = 1000,
    maxDelayMs = 10000
  ): Promise<T> {
    let lastError: Error;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error instanceof Error ? error : new Error('Unknown error');
        
        if (attempt === maxRetries) {
          throw lastError;
        }

        const delay = Math.min(baseDelayMs * Math.pow(2, attempt), maxDelayMs);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    throw lastError!;
  }
}

// Robust middleware for integration stability
export function integrationStabilityMiddleware(req: Request, res: Response, next: NextFunction) {
  // Add request tracking
  const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  (req as any).requestId = requestId;

  // Add response time tracking
  const startTime = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    if (duration > 5000) {
      console.warn(`Slow request detected: ${req.method} ${req.path} took ${duration}ms`);
    }
  });

  // Add error boundary
  const originalSend = res.send;
  res.send = function(data) {
    try {
      return originalSend.call(this, data);
    } catch (error) {
      console.error(`Response error for request ${requestId}:`, error);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Internal server error' });
      }
      return this;
    }
  };

  next();
}

// Health check endpoint
export function createHealthEndpoint() {
  return async (req: Request, res: Response) => {
    try {
      const report = await IntegrationHealthMonitor.runHealthChecks();
      const statusCode = report.overall === 'healthy' ? 200 : 503;
      res.status(statusCode).json(report);
    } catch (error) {
      res.status(500).json({
        overall: 'unhealthy',
        error: error instanceof Error ? error.message : 'Health check failed'
      });
    }
  };
}

// Initialize all health checks
export function initializeHealthChecks() {
  IntegrationHealthMonitor.registerHealthCheck('database', new DatabaseHealthCheck());
  IntegrationHealthMonitor.registerHealthCheck('storage', new StorageHealthCheck());
  IntegrationHealthMonitor.registerHealthCheck('memory', new MemoryHealthCheck());
  IntegrationHealthMonitor.registerHealthCheck('external_apis', new ExternalAPIHealthCheck());
  
  IntegrationHealthMonitor.startMonitoring(30000); // Check every 30 seconds
}

// Type definitions
interface HealthCheck {
  timeout?: number;
  execute(): Promise<HealthCheckResult>;
}

interface HealthCheckResult {
  name: string;
  status: 'healthy' | 'degraded' | 'unhealthy';
  message: string;
  duration?: number;
  timestamp?: Date;
  metadata?: any;
}

interface HealthReport {
  overall: 'healthy' | 'degraded' | 'unhealthy';
  checks: HealthCheckResult[];
  duration: number;
  timestamp: Date;
}