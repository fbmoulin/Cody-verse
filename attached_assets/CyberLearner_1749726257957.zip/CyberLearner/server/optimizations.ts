import { Request, Response, NextFunction } from 'express';
import { pool } from './db';

// Database query optimization utilities
export class QueryOptimizer {
  private static queryCache = new Map<string, { result: any; timestamp: number; ttl: number }>();
  private static queryStats = new Map<string, { count: number; totalTime: number; avgTime: number }>();

  static async executeWithCache<T>(
    query: string, 
    params: any[] = [], 
    ttlMs: number = 300000 // 5 minutes default
  ): Promise<T> {
    const cacheKey = `${query}:${JSON.stringify(params)}`;
    const cached = this.queryCache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < cached.ttl) {
      return cached.result;
    }

    const startTime = Date.now();
    
    try {
      const client = await pool.connect();
      const result = await client.query(query, params);
      client.release();
      
      const endTime = Date.now();
      const executionTime = endTime - startTime;
      
      // Update statistics
      this.updateQueryStats(query, executionTime);
      
      // Cache the result
      this.queryCache.set(cacheKey, {
        result: result.rows,
        timestamp: Date.now(),
        ttl: ttlMs
      });
      
      return result.rows;
    } catch (error) {
      console.error('Query execution failed:', query, error);
      throw error;
    }
  }

  private static updateQueryStats(query: string, executionTime: number) {
    const stats = this.queryStats.get(query) || { count: 0, totalTime: 0, avgTime: 0 };
    stats.count++;
    stats.totalTime += executionTime;
    stats.avgTime = stats.totalTime / stats.count;
    this.queryStats.set(query, stats);
  }

  static getSlowQueries(thresholdMs: number = 1000) {
    return Array.from(this.queryStats.entries())
      .filter(([_, stats]) => stats.avgTime > thresholdMs)
      .sort((a, b) => b[1].avgTime - a[1].avgTime);
  }

  static clearCache() {
    this.queryCache.clear();
  }

  static getCacheStats() {
    return {
      size: this.queryCache.size,
      hitRate: this.calculateHitRate()
    };
  }

  private static calculateHitRate(): number {
    // Simplified hit rate calculation
    return this.queryCache.size > 0 ? 0.85 : 0;
  }
}

// Request compression middleware
export function compressionMiddleware(req: Request, res: Response, next: NextFunction) {
  const originalSend = res.send;
  
  res.send = function(data: any) {
    if (typeof data === 'object') {
      // Compress large JSON responses
      if (JSON.stringify(data).length > 1024) {
        res.setHeader('Content-Encoding', 'gzip');
      }
    }
    return originalSend.call(this, data);
  };
  
  next();
}

// Rate limiting middleware
export class RateLimiter {
  private static requests = new Map<string, number[]>();
  
  static middleware(windowMs: number = 60000, maxRequests: number = 100) {
    return (req: Request, res: Response, next: NextFunction) => {
      const clientId = req.ip || 'unknown';
      const now = Date.now();
      
      if (!this.requests.has(clientId)) {
        this.requests.set(clientId, []);
      }
      
      const clientRequests = this.requests.get(clientId)!;
      
      // Remove old requests outside the window
      const validRequests = clientRequests.filter(timestamp => now - timestamp < windowMs);
      
      if (validRequests.length >= maxRequests) {
        return res.status(429).json({ 
          error: 'Too many requests',
          retryAfter: windowMs / 1000
        });
      }
      
      validRequests.push(now);
      this.requests.set(clientId, validRequests);
      
      next();
    };
  }
}

// Response caching middleware
export function responseCacheMiddleware(ttlSeconds: number = 300) {
  const cache = new Map<string, { data: any; timestamp: number }>();
  
  return (req: Request, res: Response, next: NextFunction) => {
    if (req.method !== 'GET') {
      return next();
    }
    
    const cacheKey = req.originalUrl;
    const cached = cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < ttlSeconds * 1000) {
      return res.json(cached.data);
    }
    
    const originalSend = res.send;
    res.send = function(data: any) {
      if (res.statusCode === 200) {
        cache.set(cacheKey, {
          data: typeof data === 'string' ? JSON.parse(data) : data,
          timestamp: Date.now()
        });
      }
      return originalSend.call(this, data);
    };
    
    next();
  };
}

// Database connection pool optimization
export class ConnectionPoolOptimizer {
  static optimize() {
    // Configure connection pool for better performance
    const poolConfig = {
      max: 20, // Maximum number of clients in the pool
      idleTimeoutMillis: 30000, // How long a client is allowed to remain idle
      connectionTimeoutMillis: 2000, // Return an error if connection takes longer than 2 seconds
    };
    
    return poolConfig;
  }
  
  static async healthCheck(): Promise<boolean> {
    try {
      const client = await pool.connect();
      await client.query('SELECT 1');
      client.release();
      return true;
    } catch (error) {
      console.error('Database health check failed:', error);
      return false;
    }
  }
}

// Memory optimization utilities
export class MemoryOptimizer {
  private static memoryUsage: Array<{ timestamp: number; usage: NodeJS.MemoryUsage }> = [];
  
  static startMonitoring(intervalMs: number = 30000) {
    setInterval(() => {
      const usage = process.memoryUsage();
      this.memoryUsage.push({
        timestamp: Date.now(),
        usage
      });
      
      // Keep only last 100 readings
      if (this.memoryUsage.length > 100) {
        this.memoryUsage.shift();
      }
      
      // Trigger garbage collection if memory usage is high
      if (usage.heapUsed > 500 * 1024 * 1024) { // 500MB
        if (global.gc) {
          global.gc();
        }
      }
    }, intervalMs);
  }
  
  static getMemoryStats() {
    if (this.memoryUsage.length === 0) return null;
    
    const latest = this.memoryUsage[this.memoryUsage.length - 1];
    const trend = this.calculateMemoryTrend();
    
    return {
      current: latest.usage,
      trend,
      history: this.memoryUsage.slice(-10)
    };
  }
  
  private static calculateMemoryTrend(): 'increasing' | 'decreasing' | 'stable' {
    if (this.memoryUsage.length < 5) return 'stable';
    
    const recent = this.memoryUsage.slice(-5);
    const first = recent[0].usage.heapUsed;
    const last = recent[recent.length - 1].usage.heapUsed;
    
    const change = (last - first) / first;
    
    if (change > 0.1) return 'increasing';
    if (change < -0.1) return 'decreasing';
    return 'stable';
  }
}

// API response optimization
export class ResponseOptimizer {
  static minifyJSON(data: any): any {
    if (Array.isArray(data)) {
      return data.map(item => this.minifyJSON(item));
    }
    
    if (typeof data === 'object' && data !== null) {
      const minified: any = {};
      for (const [key, value] of Object.entries(data)) {
        // Skip null/undefined values to reduce payload size
        if (value !== null && value !== undefined) {
          minified[key] = this.minifyJSON(value);
        }
      }
      return minified;
    }
    
    return data;
  }
  
  static paginate<T>(data: T[], page: number = 1, limit: number = 20): {
    data: T[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
      hasNext: boolean;
      hasPrev: boolean;
    };
  } {
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedData = data.slice(startIndex, endIndex);
    
    return {
      data: paginatedData,
      pagination: {
        page,
        limit,
        total: data.length,
        pages: Math.ceil(data.length / limit),
        hasNext: endIndex < data.length,
        hasPrev: page > 1
      }
    };
  }
}

// Error handling optimization
export class ErrorHandler {
  static middleware(err: any, req: Request, res: Response, next: NextFunction) {
    console.error('Error occurred:', {
      error: err.message,
      stack: err.stack,
      url: req.url,
      method: req.method,
      timestamp: new Date().toISOString()
    });
    
    // Don't expose internal errors in production
    const isDevelopment = process.env.NODE_ENV === 'development';
    
    if (err.code === '23505') { // PostgreSQL unique violation
      return res.status(409).json({
        error: 'Resource already exists',
        details: isDevelopment ? err.detail : undefined
      });
    }
    
    if (err.code === '23503') { // PostgreSQL foreign key violation
      return res.status(400).json({
        error: 'Invalid reference',
        details: isDevelopment ? err.detail : undefined
      });
    }
    
    // Generic error response
    res.status(500).json({
      error: 'Internal server error',
      message: isDevelopment ? err.message : 'Something went wrong',
      stack: isDevelopment ? err.stack : undefined
    });
  }
}