import { 
  users, type User, type InsertUser, 
  modules, type Module, type InsertModule,
  challenges, type Challenge, type InsertChallenge,
  achievements, type Achievement, type InsertAchievement,
  userProgress, type UserProgress, type InsertUserProgress,
  userChallenges, type UserChallenge, type InsertUserChallenge,
  userAchievements, type UserAchievement, type InsertUserAchievement,
  userTutorials, type UserTutorial, type InsertUserTutorial,
  alchemyElements, type AlchemyElement, type InsertAlchemyElement,
  alchemyRecipes, type AlchemyRecipe, type InsertAlchemyRecipe,
  userAlchemyProgress, type UserAlchemyProgress, type InsertUserAlchemyProgress
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";
import { ServerTypeUtils } from "./type-utils";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserProgress(userId: number, progress: number, level: number, xp: number): Promise<User>;
  setPreferredCharacter(userId: number, character: string): Promise<User>;

  // Module operations
  getModules(): Promise<Module[]>;
  getModule(id: number): Promise<Module | undefined>;
  createModule(module: InsertModule): Promise<Module>;

  // Challenge operations
  getChallenges(): Promise<Challenge[]>;
  getChallengesByModule(moduleId: number): Promise<Challenge[]>;
  getChallenge(id: number): Promise<Challenge | undefined>;
  createChallenge(challenge: InsertChallenge): Promise<Challenge>;

  // Achievement operations
  getAchievements(): Promise<Achievement[]>;
  getAchievement(id: number): Promise<Achievement | undefined>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;

  // User Progress operations
  getUserProgress(userId: number): Promise<UserProgress[]>;
  getUserModuleProgress(userId: number, moduleId: number): Promise<UserProgress | undefined>;
  updateUserModuleProgress(progressData: InsertUserProgress): Promise<UserProgress>;

  // User Challenge operations
  getUserChallenges(userId: number): Promise<UserChallenge[]>;
  getUserChallenge(userId: number, challengeId: number): Promise<UserChallenge | undefined>;
  updateUserChallenge(challengeData: InsertUserChallenge): Promise<UserChallenge>;

  // User Achievement operations
  getUserAchievements(userId: number): Promise<UserAchievement[]>;
  addUserAchievement(achievementData: InsertUserAchievement): Promise<UserAchievement>;
  
  // User Tutorial operations
  getUserTutorialStatus(userId: number): Promise<UserTutorial | undefined>;
  updateUserTutorialStatus(tutorialData: InsertUserTutorial): Promise<UserTutorial>;
  
  // Alchemy operations
  getAllAlchemyElements(): Promise<AlchemyElement[]>;
  getAlchemyElement(elementId: string): Promise<AlchemyElement | undefined>;
  getAllAlchemyRecipes(): Promise<AlchemyRecipe[]>;
  getAlchemyRecipe(resultId: string): Promise<AlchemyRecipe | undefined>;
  
  // User Alchemy operations
  getUserAlchemyProgress(userId: number): Promise<UserAlchemyProgress[]>;
  addUserAlchemyProgress(userId: number, elementId: string): Promise<UserAlchemyProgress>;
  checkElementDiscovery(userId: number, element1: string, element2: string): Promise<AlchemyElement | undefined>;
}

export class DatabaseStorage implements IStorage {
  private db = db;

  async initializeData(): Promise<void> {
    try {
      // Check if module already exists
      const existingModules = await this.getModules();
      if (existingModules.length > 0) {
        return; // Data already initialized
      }

      // Create comprehensive introductory module with expanded Portuguese content
      const introModule: InsertModule = {
        title: "Introduction to AI and MCP Servers",
        description: "Master the fundamentals of AI and Model Context Protocol through hands-on learning and interactive examples",
        order: 1,
        content: JSON.stringify({
          sections: [
            {
              title: "Bem-vindos à Revolução da IA",
              content: "A Inteligência Artificial está transformando fundamentalmente como resolvemos problemas e construímos software. Este módulo abrangente irá guiá-lo através dos conceitos essenciais de IA e MCP (Model Context Protocol), desde os fundamentos teóricos até implementações práticas do mundo real. Você aprenderá a criar sistemas inteligentes que podem raciocinar, aprender e interagir com o ambiente de forma autônoma."
            },
            {
              title: "Fundamentos da Inteligência Artificial",
              content: "A Inteligência Artificial representa uma das maiores revoluções tecnológicas da história humana. IA refere-se a sistemas computacionais capazes de realizar tarefas que tradicionalmente requerem inteligência humana, incluindo percepção, raciocínio, aprendizado e tomada de decisão. Tipos principais incluem IA Reativa (como Deep Blue), IA com Memória Limitada (carros autônomos), Teoria da Mente (robôs sociais avançados) e IA Autoconsciente (ainda teórica)."
            },
            {
              title: "Introdução ao Model Context Protocol (MCP)",
              content: "O Model Context Protocol representa um marco na evolução da IA, fornecendo uma interface padronizada para que modelos de linguagem interajam com ferramentas e sistemas externos de forma segura e eficiente. O MCP é um protocolo aberto que permite que modelos de IA acessem dados e executem ações no mundo real através de uma interface padronizada, resolvendo o problema fundamental de conectar a inteligência dos modelos de linguagem com sistemas práticos."
            },
            {
              title: "Implementação Prática de Servidores MCP",
              content: "Vamos construir um servidor MCP funcional que demonstra os conceitos fundamentais através de exemplos práticos. Um servidor MCP básico inclui: estrutura de servidor, registro de ferramentas, gerenciamento de estado interno, e tratamento de erros. Exemplo: TaskManagerMCPServer que cria e lista tarefas, demonstrando como conectar IA com sistemas reais de forma segura e eficiente."
            },
            {
              title: "Casos de Uso Avançados do MCP",
              content: "Explore implementações do MCP em cenários empresariais reais, demonstrando seu potencial transformador. Empresas de e-commerce usam MCP para sistemas de atendimento inteligente, reduzindo tempo de resposta em 70% e resolvendo 85% das consultas automaticamente. Bancos utilizam MCP para análise financeira automatizada, aumentando velocidade de análise de risco em 10x e melhorando detecção de fraudes."
            },
            {
              title: "Fundamentos Técnicos Avançados",
              content: "Compreenda os aspectos técnicos profundos que tornam o MCP uma tecnologia robusta e escalável. O MCP implementa múltiplas camadas de segurança: autenticação JWT, autorização granular, criptografia TLS 1.3, sandboxing de execução e auditoria completa. Para otimização de performance, usa cache inteligente, compressão adaptativa, pool de conexões persistentes, balanceamento de carga automático e monitoramento de latência em tempo real."
            },
            {
              title: "Arquitetura e Design de Sistemas MCP",
              content: "Aprenda a projetar sistemas MCP escaláveis e resilientes. A arquitetura MCP segue princípios de microserviços com separação clara de responsabilidades: camada de transporte, camada de protocolo, camada de segurança e camada de aplicação. Padrões de design incluem Registry Pattern para descoberta de recursos, Strategy Pattern para diferentes tipos de ferramentas, e Observer Pattern para monitoramento de eventos."
            },
            {
              title: "Integração com Modelos de IA Modernos",
              content: "Explore como integrar MCP com os principais modelos de IA do mercado. Suporte nativo para GPT-4, Claude, Gemini e modelos open-source como Llama. Técnicas de fine-tuning para otimizar performance em tarefas específicas. Implementação de pipelines de RAG (Retrieval-Augmented Generation) para melhorar precisão e relevância das respostas."
            },
            {
              title: "Monitoramento e Observabilidade",
              content: "Implementação de sistemas de monitoramento abrangentes para ambientes MCP em produção. Métricas essenciais: latência de resposta, taxa de erro, throughput, utilização de recursos. Integração com ferramentas como Prometheus, Grafana, ELK Stack. Alertas inteligentes baseados em machine learning para detecção proativa de anomalias."
            },
            {
              title: "Escalabilidade e Performance",
              content: "Estratégias para escalar sistemas MCP em ambientes de alta demanda. Implementação de clusters distribuídos, load balancing inteligente, caching multinível. Otimizações de rede: compressão de dados, multiplexing de conexões, reutilização de recursos. Técnicas de particionamento de dados e sharding para grandes volumes."
            },
            {
              title: "Segurança e Compliance",
              content: "Implementação de práticas de segurança robustas em sistemas MCP. Conformidade com regulamentações como GDPR, LGPD, SOX. Implementação de zero-trust architecture, criptografia end-to-end, gestão de identidades e acessos (IAM). Auditoria completa de operações e logs de segurança para compliance."
            },
            {
              title: "DevOps e Deployment",
              content: "Práticas modernas de DevOps para sistemas MCP. CI/CD pipelines automatizados, testes de integração, deployment blue-green. Containerização com Docker e orquestração com Kubernetes. Infrastructure as Code (IaC) usando Terraform. Monitoramento de deployment e rollback automático em caso de falhas."
            },
            {
              title: "Troubleshooting e Debug",
              content: "Técnicas avançadas para diagnóstico e resolução de problemas em sistemas MCP. Ferramentas de profiling de performance, análise de memory leaks, debugging distribuído. Implementação de circuit breakers e retry mechanisms. Estratégias de graceful degradation e failover automático."
            },
            {
              title: "Machine Learning e IA Aplicada",
              content: "Implementação de algoritmos de machine learning em sistemas MCP. Técnicas de aprendizado supervisionado, não-supervisionado e por reforço. Redes neurais profundas, processamento de linguagem natural, visão computacional. Integração com frameworks como TensorFlow, PyTorch, Scikit-learn para análise preditiva e automação inteligente."
            },
            {
              title: "Ecosistema e Ferramentas",
              content: "Explore o rico ecosistema de ferramentas e bibliotecas MCP. SDKs oficiais para diferentes linguagens, ferramentas de desenvolvimento, debuggers especializados. Integração com IDEs populares, extensões do VS Code, plugins para diferentes editores. Comunidade open-source e contribuições para o projeto MCP."
            },
            {
              title: "Futuro da IA e MCP",
              content: "Tendências futuras em IA e evolução do protocolo MCP. Integração com computação quântica, edge computing, IoT. Desenvolvimentos em AGI (Artificial General Intelligence), multimodalidade, reasoning avançado. Implicações éticas, governança de IA, impacto social e transformação digital das empresas."
            },
            {
              title: "Projeto Final e Certificação",
              content: "Desenvolva um projeto completo integrando todos os conceitos aprendidos. Construa um sistema MCP de produção com múltiplas ferramentas, integração com IA, monitoramento e segurança. Apresente seu projeto, receba feedback da comunidade e obtenha certificação em tecnologias MCP e IA avançada."
            }
          ]
        }),
        difficulty: "beginner",
        xpReward: 100,
        estimatedTime: "45 minutes",
        prerequisites: JSON.stringify([])
      };

      await this.createModule(introModule);

      // Create sample challenge
      const basicChallenge: InsertChallenge = {
        title: "AI Concept Quiz",
        description: "Test your understanding of AI fundamentals",
        content: JSON.stringify({
          type: "quiz",
          questions: [
            {
              question: "What does AI stand for?",
              options: ["Artificial Intelligence", "Automated Interface", "Advanced Integration", "Applied Information"],
              correct: 0
            }
          ]
        }),
        difficulty: "beginner", 
        xpReward: 50,
        moduleId: 1,
        hints: JSON.stringify(["AI is about making machines smart", "Think about human-like intelligence"])
      };

      await this.createChallenge(basicChallenge);

      // Create achievement
      const firstStepsAchievement: InsertAchievement = {
        title: "First Steps",
        description: "Complete your first lesson",
        xpReward: 25,
        icon: "🎯",
        condition: JSON.stringify({
          type: "lesson_complete",
          moduleId: 1
        })
      };

      await this.createAchievement(firstStepsAchievement);

      // Initialize default alchemy elements if empty
      if ((await this.getAllAlchemyElements()).length === 0) {
        const basicElements = [
          { elementId: "water", name: "Water", description: "Essential for life", emoji: "💧", discovered: true },
          { elementId: "fire", name: "Fire", description: "Energy and transformation", emoji: "🔥", discovered: true },
          { elementId: "earth", name: "Earth", description: "Solid foundation", emoji: "🌍", discovered: true },
          { elementId: "air", name: "Air", description: "Breath of life", emoji: "💨", discovered: true },
          { elementId: "steam", name: "Steam", description: "Water meets fire", emoji: "♨️", discovered: false },
          { elementId: "mud", name: "Mud", description: "Earth and water combined", emoji: "🏔️", discovered: false }
        ];

        for (const element of basicElements) {
          await this.createAlchemyElement(element);
        }

        // Add some basic recipes
        const basicRecipes = [
          { element1: "water", element2: "fire", result: "steam" },
          { element1: "water", element2: "earth", result: "mud" }
        ];

        for (const recipe of basicRecipes) {
          await this.createAlchemyRecipe(recipe);
        }
      }
    } catch (error) {
      console.error('Error initializing default data:', error);
    }
  }

  private async createAlchemyElement(element: any) {
    const result = await this.db.insert(alchemyElements).values(element).returning();
    return result[0];
  }

  private async createAlchemyRecipe(recipe: any) {
    const result = await this.db.insert(alchemyRecipes).values(recipe).returning();
    return result[0];
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await this.db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async updateUserProgress(userId: number, progress: number, level: number, xp: number): Promise<User> {
    const result = await this.db.update(users)
      .set({ progress, level, xp })
      .where(eq(users.id, userId))
      .returning();
    return result[0];
  }

  async setPreferredCharacter(userId: number, character: string): Promise<User> {
    const result = await this.db.update(users)
      .set({ preferredCharacter: character })
      .where(eq(users.id, userId))
      .returning();
    return result[0];
  }

  // Module operations
  async getModules(): Promise<Module[]> {
    return await this.db.select().from(modules);
  }

  async getModule(id: number): Promise<Module | undefined> {
    const result = await this.db.select().from(modules).where(eq(modules.id, id));
    return result[0];
  }

  async createModule(moduleData: InsertModule): Promise<Module> {
    const result = await this.db.insert(modules).values(moduleData).returning();
    return result[0];
  }

  // Challenge operations
  async getChallenges(): Promise<Challenge[]> {
    return await this.db.select().from(challenges);
  }

  async getChallengesByModule(moduleId: number): Promise<Challenge[]> {
    return await this.db.select().from(challenges).where(eq(challenges.moduleId, moduleId));
  }

  async getChallenge(id: number): Promise<Challenge | undefined> {
    const result = await this.db.select().from(challenges).where(eq(challenges.id, id));
    return result[0];
  }

  async createChallenge(challengeData: InsertChallenge): Promise<Challenge> {
    const result = await this.db.insert(challenges).values(challengeData).returning();
    return result[0];
  }

  // Achievement operations
  async getAchievements(): Promise<Achievement[]> {
    return await this.db.select().from(achievements);
  }

  async getAchievement(id: number): Promise<Achievement | undefined> {
    const result = await this.db.select().from(achievements).where(eq(achievements.id, id));
    return result[0];
  }

  async createAchievement(achievementData: InsertAchievement): Promise<Achievement> {
    const result = await this.db.insert(achievements).values(achievementData).returning();
    return result[0];
  }

  // User Progress operations
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return await this.db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async getUserModuleProgress(userId: number, moduleId: number): Promise<UserProgress | undefined> {
    const result = await this.db.select()
      .from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.moduleId, moduleId)));
    return result[0];
  }

  async updateUserModuleProgress(progressData: InsertUserProgress): Promise<UserProgress> {
    const existing = await this.getUserModuleProgress(progressData.userId, progressData.moduleId);
    
    if (existing) {
      const result = await this.db.update(userProgress)
        .set({
          progress: progressData.progress,
          completed: progressData.completed,
          lastAccessed: new Date()
        })
        .where(and(eq(userProgress.userId, progressData.userId), eq(userProgress.moduleId, progressData.moduleId)))
        .returning();
      return result[0];
    } else {
      const result = await this.db.insert(userProgress)
        .values({
          ...progressData,
          lastAccessed: new Date()
        })
        .returning();
      return result[0];
    }
  }

  // User Challenge operations
  async getUserChallenges(userId: number): Promise<UserChallenge[]> {
    return await this.db.select().from(userChallenges).where(eq(userChallenges.userId, userId));
  }

  async getUserChallenge(userId: number, challengeId: number): Promise<UserChallenge | undefined> {
    const result = await this.db.select()
      .from(userChallenges)
      .where(and(eq(userChallenges.userId, userId), eq(userChallenges.challengeId, challengeId)));
    return result[0];
  }

  async updateUserChallenge(challengeData: InsertUserChallenge): Promise<UserChallenge> {
    const existing = await this.getUserChallenge(challengeData.userId, challengeData.challengeId);
    
    if (existing) {
      const result = await this.db.update(userChallenges)
        .set({
          completed: challengeData.completed,
          attempts: challengeData.attempts,
          lastAttempt: new Date()
        })
        .where(and(eq(userChallenges.userId, challengeData.userId), eq(userChallenges.challengeId, challengeData.challengeId)))
        .returning();
      return result[0];
    } else {
      const result = await this.db.insert(userChallenges)
        .values({
          ...challengeData,
          lastAttempt: new Date()
        })
        .returning();
      return result[0];
    }
  }

  // User Achievement operations
  async getUserAchievements(userId: number): Promise<UserAchievement[]> {
    return await this.db.select().from(userAchievements).where(eq(userAchievements.userId, userId));
  }

  async addUserAchievement(achievementData: InsertUserAchievement): Promise<UserAchievement> {
    const result = await this.db.insert(userAchievements)
      .values({
        ...achievementData,
        unlockedAt: new Date()
      })
      .returning();
    return result[0];
  }
  
  // User Tutorial operations
  async getUserTutorialStatus(userId: number): Promise<UserTutorial | undefined> {
    const result = await this.db.select().from(userTutorials).where(eq(userTutorials.userId, userId));
    return result[0];
  }

  async updateUserTutorialStatus(tutorialData: InsertUserTutorial): Promise<UserTutorial> {
    const existing = await this.getUserTutorialStatus(tutorialData.userId);
    
    if (existing) {
      const result = await this.db.update(userTutorials)
        .set({
          completed: tutorialData.completed,
          completedSteps: tutorialData.completedSteps,
          lastUpdated: new Date()
        })
        .where(eq(userTutorials.userId, tutorialData.userId))
        .returning();
      return result[0];
    } else {
      const result = await this.db.insert(userTutorials)
        .values({
          ...tutorialData,
          lastUpdated: new Date()
        })
        .returning();
      return result[0];
    }
  }
  
  // Alchemy operations
  async getAllAlchemyElements(): Promise<AlchemyElement[]> {
    return await this.db.select().from(alchemyElements);
  }

  async getAlchemyElement(elementId: string): Promise<AlchemyElement | undefined> {
    const result = await this.db.select().from(alchemyElements).where(eq(alchemyElements.elementId, elementId));
    return result[0];
  }

  async getAllAlchemyRecipes(): Promise<AlchemyRecipe[]> {
    return await this.db.select().from(alchemyRecipes);
  }

  async getAlchemyRecipe(resultId: string): Promise<AlchemyRecipe | undefined> {
    const result = await this.db.select().from(alchemyRecipes).where(eq(alchemyRecipes.result, resultId));
    return result[0];
  }
  
  // User Alchemy operations
  async getUserAlchemyProgress(userId: number): Promise<UserAlchemyProgress[]> {
    return await this.db.select().from(userAlchemyProgress).where(eq(userAlchemyProgress.userId, userId));
  }

  async addUserAlchemyProgress(userId: number, elementId: string): Promise<UserAlchemyProgress> {
    const result = await this.db.insert(userAlchemyProgress)
      .values({
        userId,
        elementId,
        discoveredAt: new Date()
      })
      .returning();
    return result[0];
  }

  async checkElementDiscovery(userId: number, element1: string, element2: string): Promise<AlchemyElement | undefined> {
    // Check if there's a recipe for these elements
    const recipe = await this.db.select()
      .from(alchemyRecipes)
      .where(
        and(
          eq(alchemyRecipes.element1, element1),
          eq(alchemyRecipes.element2, element2)
        )
      );

    if (recipe.length > 0) {
      const resultElement = await this.getAlchemyElement(recipe[0].result);
      if (resultElement) {
        // Add to user's discovered elements
        await this.addUserAlchemyProgress(userId, resultElement.elementId);
        return resultElement;
      }
    }

    return undefined;
  }
}

export const storage = new DatabaseStorage();