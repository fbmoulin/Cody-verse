import { storage } from './storage';
import { CircuitBreaker, RetryHandler } from './integration-health';

// Comprehensive error recovery and fallback system
export class ErrorRecoverySystem {
  private static circuitBreakers = new Map<string, CircuitBreaker>();
  private static fallbackCache = new Map<string, { data: any; timestamp: number; ttl: number }>();
  
  static initialize() {
    // Initialize circuit breakers for different service types
    this.circuitBreakers.set('database', new CircuitBreaker('database', 5, 60000));
    this.circuitBreakers.set('storage', new CircuitBreaker('storage', 3, 30000));
    this.circuitBreakers.set('external_api', new CircuitBreaker('external_api', 3, 45000));
    
    console.log('Error recovery system initialized');
  }
  
  static async executeWithFallback<T>(
    operation: () => Promise<T>,
    fallbackKey: string,
    circuitBreakerType: string = 'default',
    fallbackTtl: number = 300000 // 5 minutes
  ): Promise<T> {
    const circuitBreaker = this.circuitBreakers.get(circuitBreakerType) || 
                          new CircuitBreaker(circuitBreakerType, 3, 30000);
    
    try {
      // Try the operation with circuit breaker protection
      const result = await circuitBreaker.execute(operation);
      
      // Cache successful result as fallback
      this.fallbackCache.set(fallbackKey, {
        data: result,
        timestamp: Date.now(),
        ttl: fallbackTtl
      });
      
      return result;
    } catch (error) {
      console.warn(`Operation failed for ${fallbackKey}, attempting fallback:`, error instanceof Error ? error.message : error);
      
      // Try to use cached fallback data
      const fallback = this.fallbackCache.get(fallbackKey);
      if (fallback && Date.now() - fallback.timestamp < fallback.ttl) {
        console.log(`Using cached fallback data for ${fallbackKey}`);
        return fallback.data;
      }
      
      // If no fallback available, try degraded service
      return this.attemptDegradedService(fallbackKey, error);
    }
  }
  
  private static async attemptDegradedService<T>(fallbackKey: string, originalError: any): Promise<T> {
    // Provide minimal functionality based on the operation type
    if (fallbackKey.includes('modules')) {
      console.log('Providing minimal module data as fallback');
      return [{
        id: 1,
        title: 'Sistema Indisponível',
        description: 'O sistema está temporariamente indisponível. Tente novamente em alguns minutos.',
        content: { type: 'error', message: 'Serviço temporariamente indisponível' },
        difficulty: 'beginner',
        estimatedTime: 0,
        prerequisites: [],
        tags: ['sistema']
      }] as any;
    }
    
    if (fallbackKey.includes('progress')) {
      console.log('Providing empty progress data as fallback');
      return [] as any;
    }
    
    if (fallbackKey.includes('user')) {
      console.log('Providing default user data as fallback');
      return {
        id: 1,
        username: 'usuario_padrao',
        progress: 0,
        level: 1,
        xp: 0,
        preferredCharacter: 'alex'
      } as any;
    }
    
    // If no specific fallback is available, throw the original error
    throw originalError;
  }
  
  static clearExpiredFallbacks() {
    const now = Date.now();
    const expiredKeys = [];
    
    for (const [key, fallback] of this.fallbackCache.entries()) {
      if (now - fallback.timestamp > fallback.ttl) {
        expiredKeys.push(key);
      }
    }
    
    expiredKeys.forEach(key => this.fallbackCache.delete(key));
    
    if (expiredKeys.length > 0) {
      console.log(`Cleared ${expiredKeys.length} expired fallback entries`);
    }
  }
  
  static getSystemHealth() {
    const breakerStates = Array.from(this.circuitBreakers.entries()).map(([name, breaker]) => ({
      name,
      state: breaker.getState()
    }));
    
    const cacheStats = {
      entries: this.fallbackCache.size,
      totalSize: JSON.stringify(Array.from(this.fallbackCache.values())).length
    };
    
    return {
      circuitBreakers: breakerStates,
      fallbackCache: cacheStats,
      timestamp: new Date()
    };
  }
}

// Enhanced storage wrapper with comprehensive error recovery
export class ResilientStorageWrapper {
  private recovery = ErrorRecoverySystem;
  
  async getModules() {
    return this.recovery.executeWithFallback(
      () => storage.getModules(),
      'modules_list',
      'storage',
      600000 // 10 minutes cache for modules
    );
  }
  
  async getModule(id: number) {
    return this.recovery.executeWithFallback(
      () => storage.getModule(id),
      `module_${id}`,
      'storage',
      300000 // 5 minutes cache for individual modules
    );
  }
  
  async getUser(id: number) {
    return this.recovery.executeWithFallback(
      () => storage.getUser(id),
      `user_${id}`,
      'storage',
      180000 // 3 minutes cache for user data
    );
  }
  
  async getUserProgress(userId: number) {
    return this.recovery.executeWithFallback(
      () => storage.getUserProgress(userId),
      `user_progress_${userId}`,
      'storage',
      120000 // 2 minutes cache for progress data
    );
  }
  
  async updateUserProgress(userId: number, progress: number, level: number, xp: number) {
    return RetryHandler.withRetry(
      () => storage.updateUserProgress(userId, progress, level, xp),
      3, // max retries for critical operations
      2000, // base delay
      10000 // max delay
    );
  }
  
  async updateUserModuleProgress(progressData: any) {
    return RetryHandler.withRetry(
      () => storage.updateUserModuleProgress(progressData),
      3,
      1500,
      8000
    );
  }
  
  async getChallenges() {
    return this.recovery.executeWithFallback(
      () => storage.getChallenges(),
      'challenges_list',
      'storage',
      900000 // 15 minutes cache for challenges
    );
  }
  
  async getChallengesByModule(moduleId: number) {
    return this.recovery.executeWithFallback(
      () => storage.getChallengesByModule(moduleId),
      `challenges_module_${moduleId}`,
      'storage',
      600000 // 10 minutes cache
    );
  }
  
  async getAchievements() {
    return this.recovery.executeWithFallback(
      () => storage.getAchievements(),
      'achievements_list',
      'storage',
      1800000 // 30 minutes cache for achievements
    );
  }
  
  async getUserAchievements(userId: number) {
    return this.recovery.executeWithFallback(
      () => storage.getUserAchievements(userId),
      `user_achievements_${userId}`,
      'storage',
      300000 // 5 minutes cache
    );
  }
  
  async getAllAlchemyElements() {
    return this.recovery.executeWithFallback(
      () => storage.getAllAlchemyElements(),
      'alchemy_elements',
      'storage',
      3600000 // 1 hour cache for alchemy elements
    );
  }
  
  async getUserAlchemyProgress(userId: number) {
    return this.recovery.executeWithFallback(
      () => storage.getUserAlchemyProgress(userId),
      `user_alchemy_${userId}`,
      'storage',
      300000 // 5 minutes cache
    );
  }
  
  async addUserAlchemyProgress(userId: number, elementId: string) {
    return RetryHandler.withRetry(
      () => storage.addUserAlchemyProgress(userId, elementId),
      3,
      1000,
      5000
    );
  }
  
  async checkElementDiscovery(userId: number, element1: string, element2: string) {
    return this.recovery.executeWithFallback(
      () => storage.checkElementDiscovery(userId, element1, element2),
      `alchemy_check_${userId}_${element1}_${element2}`,
      'storage',
      60000 // 1 minute cache for discovery checks
    );
  }
}

// Request timeout handler
export class RequestTimeoutHandler {
  static withTimeout<T>(
    operation: () => Promise<T>,
    timeoutMs: number = 30000,
    timeoutMessage = 'Operation timed out'
  ): Promise<T> {
    return Promise.race([
      operation(),
      new Promise<T>((_, reject) => 
        setTimeout(() => reject(new Error(timeoutMessage)), timeoutMs)
      )
    ]);
  }
}

// Global error handler for unhandled promises
export function setupGlobalErrorHandling() {
  process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
    // Log to monitoring system if available
  });
  
  process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    // Perform graceful shutdown
    process.exit(1);
  });
  
  console.log('Global error handling configured');
}