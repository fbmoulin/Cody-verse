// Server-side TypeScript utilities for robust type safety

export class ServerTypeUtils {
  static sanitizeStringArray(input: unknown): string[] {
    if (Array.isArray(input)) {
      return input.filter(item => typeof item === 'string');
    }
    if (typeof input === 'string') {
      return [input];
    }
    return [];
  }

  static ensureValidNumber(input: unknown, defaultValue = 0): number {
    const num = Number(input);
    return isNaN(num) ? defaultValue : num;
  }

  static sanitizeText(input: unknown, maxLength = 1000): string {
    const text = String(input || '').trim();
    return text.substring(0, maxLength);
  }

  static isValidId(id: unknown): boolean {
    return typeof id === 'number' && id > 0 && Number.isInteger(id);
  }

  static parseBoolean(input: unknown): boolean {
    if (typeof input === 'boolean') return input;
    if (typeof input === 'string') {
      return input.toLowerCase() === 'true' || input === '1';
    }
    if (typeof input === 'number') return input !== 0;
    return false;
  }

  static assertDefined<T>(value: T | undefined, errorMessage: string): T {
    if (value === undefined) {
      throw new Error(errorMessage);
    }
    return value;
  }

  static parseStringParam(param: string | undefined, name: string): string {
    if (!param) {
      throw new Error(`Missing required parameter: ${name}`);
    }
    return param;
  }

  static parseNumberParam(param: string | undefined, name: string): number {
    if (!param) {
      throw new Error(`Missing required parameter: ${name}`);
    }
    const num = parseInt(param, 10);
    if (isNaN(num)) {
      throw new Error(`Invalid number parameter: ${name}`);
    }
    return num;
  }

  static safeParseNumberParam(param: string | undefined): number {
    if (!param) return 0;
    const num = parseInt(param, 10);
    return isNaN(num) ? 0 : num;
  }

  static safeParseStringParam(param: string | undefined): string {
    return param || '';
  }

  static safeDbResult<T>(result: T | undefined, operation: string): T {
    if (result === undefined) {
      throw new Error(`Database operation failed: ${operation}`);
    }
    return result;
  }

  static safeParseInt(value: string | undefined, fallback: number = 0): number {
    if (!value) return fallback;
    const parsed = parseInt(value, 10);
    return isNaN(parsed) ? fallback : parsed;
  }
}