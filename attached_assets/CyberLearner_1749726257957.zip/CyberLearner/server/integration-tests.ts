import { RobustDatabase } from './robust-db';
import { storage } from './storage';
import OpenAI from 'openai';

// Comprehensive integration testing framework
export class IntegrationTester {
  private results: TestResult[] = [];
  
  async runAllTests(): Promise<TestSuite> {
    console.log('Starting comprehensive integration tests...');
    
    const tests = [
      this.testDatabaseConnectivity(),
      this.testStorageOperations(),
      this.testOpenAIIntegration(),
      this.testMemoryUsage(),
      this.testResponseTimes(),
      this.testErrorHandling()
    ];
    
    const results = await Promise.allSettled(tests);
    
    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        this.results.push(result.value);
      } else {
        this.results.push({
          name: `test_${index}`,
          status: 'failed',
          message: result.reason?.message || 'Unknown error',
          duration: 0
        });
      }
    });
    
    const passed = this.results.filter(r => r.status === 'passed').length;
    const failed = this.results.filter(r => r.status === 'failed').length;
    
    return {
      summary: {
        total: this.results.length,
        passed,
        failed,
        success_rate: (passed / this.results.length) * 100
      },
      tests: this.results,
      timestamp: new Date()
    };
  }
  
  private async testDatabaseConnectivity(): Promise<TestResult> {
    const start = Date.now();
    
    try {
      const isHealthy = await RobustDatabase.healthCheck();
      const stats = await RobustDatabase.getConnectionStats();
      
      if (!isHealthy) {
        return {
          name: 'database_connectivity',
          status: 'failed',
          message: 'Database health check failed',
          duration: Date.now() - start
        };
      }
      
      return {
        name: 'database_connectivity',
        status: 'passed',
        message: `Database healthy. Pool: ${stats.idleCount}/${stats.totalCount} connections`,
        duration: Date.now() - start,
        metadata: stats
      };
    } catch (error) {
      return {
        name: 'database_connectivity',
        status: 'failed',
        message: error instanceof Error ? error.message : 'Database test failed',
        duration: Date.now() - start
      };
    }
  }
  
  private async testStorageOperations(): Promise<TestResult> {
    const start = Date.now();
    
    try {
      // Test basic storage operations
      const modules = await storage.getModules();
      const user = await storage.getUser(1);
      const progress = await storage.getUserProgress(1);
      
      if (!modules || modules.length === 0) {
        return {
          name: 'storage_operations',
          status: 'failed',
          message: 'No modules found in storage',
          duration: Date.now() - start
        };
      }
      
      if (!user) {
        return {
          name: 'storage_operations',
          status: 'failed',
          message: 'Test user not found',
          duration: Date.now() - start
        };
      }
      
      return {
        name: 'storage_operations',
        status: 'passed',
        message: `Storage operational. ${modules.length} modules, user progress: ${progress.length} entries`,
        duration: Date.now() - start,
        metadata: {
          modules_count: modules.length,
          progress_entries: progress.length
        }
      };
    } catch (error) {
      return {
        name: 'storage_operations',
        status: 'failed',
        message: error instanceof Error ? error.message : 'Storage test failed',
        duration: Date.now() - start
      };
    }
  }
  
  private async testOpenAIIntegration(): Promise<TestResult> {
    const start = Date.now();
    
    if (!process.env.OPENAI_API_KEY) {
      return {
        name: 'openai_integration',
        status: 'skipped',
        message: 'OpenAI API key not configured',
        duration: Date.now() - start
      };
    }
    
    try {
      const openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY
      });
      
      // Test basic connectivity
      const models = await openai.models.list();
      
      if (!models.data || models.data.length === 0) {
        return {
          name: 'openai_integration',
          status: 'failed',
          message: 'No models available from OpenAI',
          duration: Date.now() - start
        };
      }
      
      return {
        name: 'openai_integration',
        status: 'passed',
        message: `OpenAI integration working. ${models.data.length} models available`,
        duration: Date.now() - start,
        metadata: {
          models_count: models.data.length
        }
      };
    } catch (error) {
      return {
        name: 'openai_integration',
        status: 'failed',
        message: error instanceof Error ? error.message : 'OpenAI test failed',
        duration: Date.now() - start
      };
    }
  }
  
  private async testMemoryUsage(): Promise<TestResult> {
    const start = Date.now();
    
    try {
      const usage = process.memoryUsage();
      const heapUsedMB = Math.round(usage.heapUsed / 1024 / 1024);
      const heapTotalMB = Math.round(usage.heapTotal / 1024 / 1024);
      const heapUsagePercent = Math.round((usage.heapUsed / usage.heapTotal) * 100);
      
      let status: 'passed' | 'warning' | 'failed' = 'passed';
      let message = `Memory usage: ${heapUsedMB}MB/${heapTotalMB}MB (${heapUsagePercent}%)`;
      
      if (heapUsagePercent > 90) {
        status = 'failed';
        message += ' - Critical memory usage';
      } else if (heapUsagePercent > 70) {
        status = 'warning';
        message += ' - High memory usage';
      }
      
      return {
        name: 'memory_usage',
        status,
        message,
        duration: Date.now() - start,
        metadata: usage
      };
    } catch (error) {
      return {
        name: 'memory_usage',
        status: 'failed',
        message: error instanceof Error ? error.message : 'Memory test failed',
        duration: Date.now() - start
      };
    }
  }
  
  private async testResponseTimes(): Promise<TestResult> {
    const start = Date.now();
    
    try {
      const tests = [
        { name: 'getModules', fn: () => storage.getModules() },
        { name: 'getUser', fn: () => storage.getUser(1) },
        { name: 'getUserProgress', fn: () => storage.getUserProgress(1) }
      ];
      
      const results = await Promise.all(
        tests.map(async (test) => {
          const testStart = Date.now();
          await test.fn();
          return {
            name: test.name,
            duration: Date.now() - testStart
          };
        })
      );
      
      const slowOperations = results.filter(r => r.duration > 1000);
      const avgResponseTime = results.reduce((sum, r) => sum + r.duration, 0) / results.length;
      
      let status: 'passed' | 'warning' | 'failed' = 'passed';
      let message = `Average response time: ${Math.round(avgResponseTime)}ms`;
      
      if (slowOperations.length > 0) {
        status = 'warning';
        message += `. Slow operations: ${slowOperations.map(op => `${op.name}(${op.duration}ms)`).join(', ')}`;
      }
      
      return {
        name: 'response_times',
        status,
        message,
        duration: Date.now() - start,
        metadata: {
          average_response_time: avgResponseTime,
          slow_operations: slowOperations,
          all_results: results
        }
      };
    } catch (error) {
      return {
        name: 'response_times',
        status: 'failed',
        message: error instanceof Error ? error.message : 'Response time test failed',
        duration: Date.now() - start
      };
    }
  }
  
  private async testErrorHandling(): Promise<TestResult> {
    const start = Date.now();
    
    try {
      // Test error handling with invalid operations
      const tests = [
        {
          name: 'invalid_user',
          fn: () => storage.getUser(-1),
          expectError: false // Should return undefined, not throw
        },
        {
          name: 'invalid_module',
          fn: () => storage.getModule(-1),
          expectError: false // Should return undefined, not throw
        }
      ];
      
      let passedTests = 0;
      
      for (const test of tests) {
        try {
          const result = await test.fn();
          if (test.expectError) {
            // Expected error but didn't get one
            continue;
          } else {
            // Expected no error and didn't get one
            passedTests++;
          }
        } catch (error) {
          if (test.expectError) {
            // Expected error and got one
            passedTests++;
          } else {
            // Didn't expect error but got one
            continue;
          }
        }
      }
      
      const successRate = (passedTests / tests.length) * 100;
      
      return {
        name: 'error_handling',
        status: successRate === 100 ? 'passed' : 'warning',
        message: `Error handling: ${passedTests}/${tests.length} tests passed (${Math.round(successRate)}%)`,
        duration: Date.now() - start,
        metadata: {
          success_rate: successRate,
          tests_run: tests.length
        }
      };
    } catch (error) {
      return {
        name: 'error_handling',
        status: 'failed',
        message: error instanceof Error ? error.message : 'Error handling test failed',
        duration: Date.now() - start
      };
    }
  }
}

// Auto-run integration tests on startup
export async function runStartupIntegrationTests(): Promise<void> {
  try {
    console.log('Running startup integration tests...');
    const tester = new IntegrationTester();
    const results = await tester.runAllTests();
    
    console.log(`Integration Tests Summary:`);
    console.log(`- Total: ${results.summary.total}`);
    console.log(`- Passed: ${results.summary.passed}`);
    console.log(`- Failed: ${results.summary.failed}`);
    console.log(`- Success Rate: ${Math.round(results.summary.success_rate)}%`);
    
    if (results.summary.failed > 0) {
      console.warn('Some integration tests failed:');
      results.tests
        .filter(t => t.status === 'failed')
        .forEach(t => console.warn(`- ${t.name}: ${t.message}`));
    }
    
    if (results.summary.success_rate < 80) {
      console.error('Integration test success rate below 80% - system may be unstable');
    }
  } catch (error) {
    console.error('Failed to run startup integration tests:', error);
  }
}

// Types
interface TestResult {
  name: string;
  status: 'passed' | 'failed' | 'warning' | 'skipped';
  message: string;
  duration: number;
  metadata?: any;
}

interface TestSuite {
  summary: {
    total: number;
    passed: number;
    failed: number;
    success_rate: number;
  };
  tests: TestResult[];
  timestamp: Date;
}