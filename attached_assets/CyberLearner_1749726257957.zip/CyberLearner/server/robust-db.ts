import { pool, db } from './db';
import { RetryHandler, CircuitBreaker } from './integration-health';

// Robust database wrapper with automatic retries and circuit breaker
export class RobustDatabase {
  private static circuitBreaker = new CircuitBreaker('database', 5, 60000);
  
  static async executeQuery<T>(
    operation: () => Promise<T>,
    operationName: string = 'database_operation'
  ): Promise<T> {
    return this.circuitBreaker.execute(async () => {
      return RetryHandler.withRetry(
        async () => {
          const start = Date.now();
          try {
            const result = await operation();
            const duration = Date.now() - start;
            
            if (duration > 2000) {
              console.warn(`Slow database operation detected: ${operationName} took ${duration}ms`);
            }
            
            return result;
          } catch (error) {
            console.error(`Database operation failed: ${operationName}`, error);
            throw error;
          }
        },
        3, // max retries
        1000, // base delay
        5000 // max delay
      );
    });
  }
  
  static async healthCheck(): Promise<boolean> {
    try {
      await this.executeQuery(async () => {
        const client = await pool.connect();
        await client.query('SELECT 1');
        client.release();
      }, 'health_check');
      return true;
    } catch (error) {
      console.error('Database health check failed:', error);
      return false;
    }
  }
  
  static async getConnectionStats() {
    return {
      totalCount: pool.totalCount,
      idleCount: pool.idleCount,
      waitingCount: pool.waitingCount
    };
  }
}

// Enhanced storage wrapper with robust error handling
export class RobustStorageWrapper {
  private storage: any;
  
  constructor(storage: any) {
    this.storage = storage;
  }
  
  async getUser(id: number) {
    return RobustDatabase.executeQuery(
      () => this.storage.getUser(id),
      `getUser_${id}`
    );
  }
  
  async getUserByUsername(username: string) {
    return RobustDatabase.executeQuery(
      () => this.storage.getUserByUsername(username),
      `getUserByUsername_${username}`
    );
  }
  
  async createUser(user: any) {
    return RobustDatabase.executeQuery(
      () => this.storage.createUser(user),
      'createUser'
    );
  }
  
  async updateUserProgress(userId: number, progress: number, level: number, xp: number) {
    return RobustDatabase.executeQuery(
      () => this.storage.updateUserProgress(userId, progress, level, xp),
      `updateUserProgress_${userId}`
    );
  }
  
  async getModules() {
    return RobustDatabase.executeQuery(
      () => this.storage.getModules(),
      'getModules'
    );
  }
  
  async getModule(id: number) {
    return RobustDatabase.executeQuery(
      () => this.storage.getModule(id),
      `getModule_${id}`
    );
  }
  
  async getUserProgress(userId: number) {
    return RobustDatabase.executeQuery(
      () => this.storage.getUserProgress(userId),
      `getUserProgress_${userId}`
    );
  }
  
  async updateUserModuleProgress(progressData: any) {
    return RobustDatabase.executeQuery(
      () => this.storage.updateUserModuleProgress(progressData),
      `updateUserModuleProgress_${progressData.userId}_${progressData.moduleId}`
    );
  }
  
  async getChallenges() {
    return RobustDatabase.executeQuery(
      () => this.storage.getChallenges(),
      'getChallenges'
    );
  }
  
  async getChallengesByModule(moduleId: number) {
    return RobustDatabase.executeQuery(
      () => this.storage.getChallengesByModule(moduleId),
      `getChallengesByModule_${moduleId}`
    );
  }
  
  async getAchievements() {
    return RobustDatabase.executeQuery(
      () => this.storage.getAchievements(),
      'getAchievements'
    );
  }
  
  async getUserAchievements(userId: number) {
    return RobustDatabase.executeQuery(
      () => this.storage.getUserAchievements(userId),
      `getUserAchievements_${userId}`
    );
  }
  
  async getAllAlchemyElements() {
    return RobustDatabase.executeQuery(
      () => this.storage.getAllAlchemyElements(),
      'getAllAlchemyElements'
    );
  }
  
  async getUserAlchemyProgress(userId: number) {
    return RobustDatabase.executeQuery(
      () => this.storage.getUserAlchemyProgress(userId),
      `getUserAlchemyProgress_${userId}`
    );
  }
  
  async addUserAlchemyProgress(userId: number, elementId: string) {
    return RobustDatabase.executeQuery(
      () => this.storage.addUserAlchemyProgress(userId, elementId),
      `addUserAlchemyProgress_${userId}_${elementId}`
    );
  }
  
  async checkElementDiscovery(userId: number, element1: string, element2: string) {
    return RobustDatabase.executeQuery(
      () => this.storage.checkElementDiscovery(userId, element1, element2),
      `checkElementDiscovery_${userId}_${element1}_${element2}`
    );
  }
}