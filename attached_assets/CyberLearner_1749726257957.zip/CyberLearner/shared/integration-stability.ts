// Comprehensive integration stability and monitoring system

export interface StabilityMetrics {
  errorCount: number;
  lastError: Date | null;
  responseTime: number;
  uptime: number;
  throughput: number;
}

export interface ComponentHealth {
  name: string;
  status: 'healthy' | 'degraded' | 'failing';
  metrics: StabilityMetrics;
  lastCheck: Date;
}

export class IntegrationStabilizer {
  private static componentHealth = new Map<string, ComponentHealth>();
  private static monitoringInterval: NodeJS.Timeout | null = null;

  static registerComponent(componentName: string): void {
    this.componentHealth.set(componentName, {
      name: componentName,
      status: 'healthy',
      metrics: {
        errorCount: 0,
        lastError: null,
        responseTime: 0,
        uptime: Date.now(),
        throughput: 0
      },
      lastCheck: new Date()
    });
  }

  static recordError(componentName: string, error: Error): void {
    const health = this.componentHealth.get(componentName);
    if (health) {
      health.metrics.errorCount++;
      health.metrics.lastError = new Date();
      health.lastCheck = new Date();
      
      // Update status based on error frequency
      if (health.metrics.errorCount > 10) {
        health.status = 'failing';
      } else if (health.metrics.errorCount > 5) {
        health.status = 'degraded';
      }
    }
  }

  static recordResponse(componentName: string, responseTime: number): void {
    const health = this.componentHealth.get(componentName);
    if (health) {
      health.metrics.responseTime = responseTime;
      health.metrics.throughput++;
      health.lastCheck = new Date();
      
      // Update status based on response time
      if (responseTime > 5000) {
        health.status = 'degraded';
      } else if (health.status === 'degraded' && responseTime < 1000) {
        health.status = 'healthy';
      }
    }
  }

  static getComponentHealth(componentName: string): ComponentHealth | undefined {
    return this.componentHealth.get(componentName);
  }

  static getAllHealth(): ComponentHealth[] {
    return Array.from(this.componentHealth.values());
  }

  static startMonitoring(): void {
    if (this.monitoringInterval) return;

    this.monitoringInterval = setInterval(() => {
      this.performHealthCheck();
    }, 30000); // Check every 30 seconds
  }

  static stopMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
  }

  private static performHealthCheck(): void {
    const now = new Date();
    
    this.componentHealth.forEach((health, componentName) => {
      const timeSinceLastCheck = now.getTime() - health.lastCheck.getTime();
      
      // Mark as failing if no activity for 5 minutes
      if (timeSinceLastCheck > 300000) {
        health.status = 'failing';
      }
      
      // Reset error count if no errors for 10 minutes
      if (health.metrics.lastError && 
          now.getTime() - health.metrics.lastError.getTime() > 600000) {
        health.metrics.errorCount = Math.max(0, health.metrics.errorCount - 1);
        if (health.metrics.errorCount === 0) {
          health.status = 'healthy';
        }
      }
    });
  }
}

export class PerformanceOptimizer {
  private static performanceData = new Map<string, number[]>();
  
  static trackMetric(name: string, value: number): void {
    if (!this.performanceData.has(name)) {
      this.performanceData.set(name, []);
    }
    
    const values = this.performanceData.get(name)!;
    values.push(value);
    
    // Keep only last 100 measurements
    if (values.length > 100) {
      values.shift();
    }
  }

  static getAverageMetric(name: string): number {
    const values = this.performanceData.get(name);
    if (!values || values.length === 0) return 0;
    
    return values.reduce((sum, val) => sum + val, 0) / values.length;
  }

  static getMetricTrend(name: string): 'improving' | 'stable' | 'degrading' {
    const values = this.performanceData.get(name);
    if (!values || values.length < 10) return 'stable';
    
    const recent = values.slice(-10);
    const older = values.slice(-20, -10);
    
    if (older.length === 0) return 'stable';
    
    const recentAvg = recent.reduce((sum, val) => sum + val, 0) / recent.length;
    const olderAvg = older.reduce((sum, val) => sum + val, 0) / older.length;
    
    if (recentAvg < olderAvg * 0.9) return 'improving';
    if (recentAvg > olderAvg * 1.1) return 'degrading';
    return 'stable';
  }

  static optimizeMemory(): void {
    // Clean up old performance data
    this.performanceData.forEach((values, key) => {
      if (values.length > 50) {
        this.performanceData.set(key, values.slice(-50));
      }
    });

    // Force garbage collection if available
    if (global.gc) {
      global.gc();
    }
  }
}

export class DatabaseConnectionMonitor {
  private static connectionStatus = 'unknown';
  private static lastCheck = new Date();
  private static errorHistory: Array<{error: string, timestamp: Date}> = [];

  static setConnectionStatus(status: 'connected' | 'disconnected' | 'error'): void {
    this.connectionStatus = status;
    this.lastCheck = new Date();
    
    IntegrationStabilizer.registerComponent('database');
    
    if (status === 'error') {
      IntegrationStabilizer.recordError('database', new Error('Database connection failed'));
    }
  }

  static recordQueryTime(duration: number): void {
    IntegrationStabilizer.recordResponse('database', duration);
    PerformanceOptimizer.trackMetric('database_query_time', duration);
  }

  static recordError(error: string): void {
    this.errorHistory.push({
      error,
      timestamp: new Date()
    });

    // Keep only last 50 errors
    if (this.errorHistory.length > 50) {
      this.errorHistory.shift();
    }

    IntegrationStabilizer.recordError('database', new Error(error));
  }

  static getStatus(): {
    status: string;
    lastCheck: Date;
    recentErrors: Array<{error: string, timestamp: Date}>;
  } {
    return {
      status: this.connectionStatus,
      lastCheck: this.lastCheck,
      recentErrors: this.errorHistory.slice(-5)
    };
  }
}

// Initialize monitoring
if (typeof process !== 'undefined') {
  IntegrationStabilizer.startMonitoring();
  
  // Register core components
  IntegrationStabilizer.registerComponent('server');
  IntegrationStabilizer.registerComponent('api');
  IntegrationStabilizer.registerComponent('authentication');
  
  // Clean up on exit
  process.on('SIGINT', () => {
    IntegrationStabilizer.stopMonitoring();
  });
  
  process.on('SIGTERM', () => {
    IntegrationStabilizer.stopMonitoring();
  });
}