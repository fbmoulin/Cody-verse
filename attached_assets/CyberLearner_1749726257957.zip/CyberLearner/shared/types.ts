// Comprehensive TypeScript optimization and type safety utilities

import { z } from 'zod';

// Enhanced type guards for runtime type checking
export const TypeGuards = {
  isString: (value: unknown): value is string => typeof value === 'string',
  isNumber: (value: unknown): value is number => typeof value === 'number' && !isNaN(value),
  isBoolean: (value: unknown): value is boolean => typeof value === 'boolean',
  isArray: <T>(value: unknown, itemGuard?: (item: unknown) => item is T): value is T[] => {
    if (!Array.isArray(value)) return false;
    if (!itemGuard) return true;
    return value.every(itemGuard);
  },
  isStringArray: (value: unknown): value is string[] => 
    TypeGuards.isArray(value, TypeGuards.isString),
  isObject: (value: unknown): value is Record<string, unknown> => 
    typeof value === 'object' && value !== null && !Array.isArray(value),
  isNonNull: <T>(value: T | null | undefined): value is T => 
    value !== null && value !== undefined
};

// Safe array conversion utilities
export const ArrayUtils = {
  toStringArray: (value: unknown): string[] => {
    if (TypeGuards.isStringArray(value)) return value;
    if (TypeGuards.isString(value)) return [value];
    if (TypeGuards.isArray(value)) return value.map(String);
    return [];
  },
  
  safeMap: <T, U>(
    array: unknown, 
    mapper: (item: T, index: number) => U,
    guard: (item: unknown) => item is T
  ): U[] => {
    if (!TypeGuards.isArray(array)) return [];
    return array
      .filter(guard)
      .map(mapper);
  },

  safePush: <T>(array: T[], ...items: T[]): T[] => {
    return [...array, ...items.filter(TypeGuards.isNonNull)];
  }
};

// Database type utilities
export const DatabaseUtils = {
  sanitizeCompletedSteps: (steps: unknown): string[] => {
    return ArrayUtils.toStringArray(steps);
  },
  
  ensureValidId: (id: unknown): number => {
    if (TypeGuards.isNumber(id) && id > 0) return id;
    throw new Error(`Invalid ID: ${id}`);
  },
  
  sanitizeUserInput: (input: unknown): string => {
    if (TypeGuards.isString(input)) {
      return input.trim().substring(0, 1000); // Limit length
    }
    return String(input || '').trim().substring(0, 1000);
  }
};

// Enhanced error handling types
export class TypedError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly context?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'TypedError';
  }
}

export const ErrorCodes = {
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  TYPE_ERROR: 'TYPE_ERROR',
  DATABASE_ERROR: 'DATABASE_ERROR',
  AUTHENTICATION_ERROR: 'AUTHENTICATION_ERROR',
  AUTHORIZATION_ERROR: 'AUTHORIZATION_ERROR',
  NOT_FOUND: 'NOT_FOUND',
  INTERNAL_ERROR: 'INTERNAL_ERROR'
} as const;

export type ErrorCode = typeof ErrorCodes[keyof typeof ErrorCodes];

// Performance monitoring types
export interface PerformanceMetric {
  name: string;
  value: number;
  timestamp: Date;
  context?: Record<string, unknown>;
}

export interface ComponentMetrics {
  renderTime: number;
  complexity: number;
  errorCount: number;
  memoryUsage?: number;
}

// API response types
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: {
    code: ErrorCode;
    message: string;
    details?: Record<string, unknown>;
  };
  meta?: {
    timestamp: string;
    version: string;
    requestId?: string;
  };
}

// Enhanced validation schemas
export const ValidationSchemas = {
  id: z.number().int().positive(),
  userId: z.number().int().positive(),
  username: z.string().min(1).max(50).regex(/^[a-zA-Z0-9_-]+$/),
  email: z.string().email().max(255),
  password: z.string().min(8).max(128),
  completedSteps: z.array(z.string()).default([]),
  moduleTitle: z.string().min(1).max(200),
  challengeContent: z.string().min(1).max(10000)
};

// Type-safe event system
export interface TypedEvent<T = unknown> {
  type: string;
  payload: T;
  timestamp: Date;
  source?: string;
}

export class TypedEventEmitter<EventMap extends Record<string, unknown>> {
  private listeners = new Map<keyof EventMap, Set<(payload: EventMap[keyof EventMap]) => void>>();

  on<K extends keyof EventMap>(event: K, listener: (payload: EventMap[K]) => void): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)?.add(listener as any);
  }

  emit<K extends keyof EventMap>(event: K, payload: EventMap[K]): void {
    const eventListeners = this.listeners.get(event);
    if (eventListeners) {
      eventListeners.forEach(listener => {
        try {
          listener(payload);
        } catch (error) {
          console.error('Event listener error:', error);
        }
      });
    }
  }

  off<K extends keyof EventMap>(event: K, listener: (payload: EventMap[K]) => void): void {
    this.listeners.get(event)?.delete(listener as any);
  }
}

// Integration stability utilities
export const IntegrationUtils = {
  withRetry: async <T>(
    operation: () => Promise<T>,
    maxRetries: number = 3,
    delay: number = 1000
  ): Promise<T> => {
    let lastError: Error = new Error('No attempts made');
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        
        if (attempt === maxRetries) break;
        
        await new Promise(resolve => setTimeout(resolve, delay * attempt));
      }
    }
    
    throw new TypedError(
      `Operation failed after ${maxRetries} attempts`,
      ErrorCodes.INTERNAL_ERROR,
      { lastError: lastError.message }
    );
  },

  withTimeout: <T>(
    promise: Promise<T>,
    timeoutMs: number,
    timeoutMessage: string = 'Operation timed out'
  ): Promise<T> => {
    return Promise.race([
      promise,
      new Promise<never>((_, reject) => {
        setTimeout(() => {
          reject(new TypedError(timeoutMessage, ErrorCodes.INTERNAL_ERROR));
        }, timeoutMs);
      })
    ]);
  },

  safeJsonParse: <T = unknown>(json: string, fallback: T): T => {
    try {
      return JSON.parse(json);
    } catch {
      return fallback;
    }
  }
};

// Memory management utilities
export const MemoryUtils = {
  createWeakCache: <K extends object, V>() => new WeakMap<K, V>(),
  
  createLRUCache: <T>(maxSize: number) => {
    const cache = new Map<string, T>();
    
    return {
      get: (key: string): T | undefined => {
        const value = cache.get(key);
        if (value !== undefined) {
          // Move to end (most recently used)
          cache.delete(key);
          cache.set(key, value);
        }
        return value;
      },
      
      set: (key: string, value: T): void => {
        if (cache.has(key)) {
          cache.delete(key);
        } else if (cache.size >= maxSize) {
          // Remove least recently used
          const firstKey = cache.keys().next().value;
          if (firstKey !== undefined) {
            cache.delete(firstKey);
          }
        }
        cache.set(key, value);
      },
      
      clear: (): void => cache.clear(),
      size: (): number => cache.size
    };
  }
};

// Export utilities as default to avoid conflicts