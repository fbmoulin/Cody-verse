import { pgTable, text, serial, integer, jsonb, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  progress: integer("progress").default(0).notNull(),
  level: integer("level").default(1).notNull(),
  xp: integer("xp").default(0).notNull(),
  preferredCharacter: text("preferred_character").default("nexus"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
});

// Learning Modules
export const modules = pgTable("modules", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  order: integer("order").notNull(),
  content: jsonb("content").notNull(),
  difficulty: text("difficulty").notNull(),
  xpReward: integer("xp_reward").notNull(),
  estimatedTime: text("estimated_time").notNull(),
  prerequisites: jsonb("prerequisites").notNull(),
});

export const insertModuleSchema = createInsertSchema(modules).pick({
  title: true,
  description: true,
  order: true,
  content: true,
  difficulty: true,
  xpReward: true,
  estimatedTime: true,
  prerequisites: true,
});

// Challenges
export const challenges = pgTable("challenges", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  moduleId: integer("module_id").notNull(),
  difficulty: text("difficulty").notNull(),
  content: jsonb("content").notNull(),
  xpReward: integer("xp_reward").notNull(),
  hints: jsonb("hints").notNull(),
});

export const insertChallengeSchema = createInsertSchema(challenges).pick({
  title: true,
  description: true,
  moduleId: true,
  difficulty: true,
  content: true,
  xpReward: true,
  hints: true,
});

// Achievements
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  xpReward: integer("xp_reward").notNull(),
  condition: jsonb("condition").notNull(),
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  title: true,
  description: true,
  icon: true,
  xpReward: true,
  condition: true,
});

// User Progress
export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  moduleId: integer("module_id").notNull(),
  completed: boolean("completed").default(false).notNull(),
  progress: integer("progress").default(0).notNull(),
  lastAccessed: timestamp("last_accessed").notNull(),
});

export const insertUserProgressSchema = createInsertSchema(userProgress).pick({
  userId: true,
  moduleId: true,
  completed: true,
  progress: true,
  lastAccessed: true,
});

// User Challenges
export const userChallenges = pgTable("user_challenges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  challengeId: integer("challenge_id").notNull(),
  completed: boolean("completed").default(false).notNull(),
  attempts: integer("attempts").default(0).notNull(),
  lastAttempt: timestamp("last_attempt"),
});

export const insertUserChallengeSchema = createInsertSchema(userChallenges).pick({
  userId: true,
  challengeId: true,
  completed: true,
  attempts: true,
  lastAttempt: true,
});

// User Achievements
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementId: integer("achievement_id").notNull(),
  unlockedAt: timestamp("unlocked_at").notNull(),
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).pick({
  userId: true,
  achievementId: true,
  unlockedAt: true,
});

// User Tutorial Progress
export const userTutorials = pgTable("user_tutorials", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  completed: boolean("completed").default(false).notNull(),
  completedSteps: jsonb("completed_steps").$type<string[]>().default([]),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const insertUserTutorialSchema = createInsertSchema(userTutorials).pick({
  userId: true,
  completed: true,
  completedSteps: true,
  lastUpdated: true,
});

// Alchemy Elements
export const alchemyElements = pgTable("alchemy_elements", {
  id: serial("id").primaryKey(),
  elementId: text("element_id").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  category: text("category").notNull(),
  discovered: boolean("discovered").default(false).notNull(),
});

export const insertAlchemyElementSchema = createInsertSchema(alchemyElements).pick({
  elementId: true,
  name: true,
  description: true,
  icon: true,
  category: true,
  discovered: true,
});

// Alchemy Recipes
export const alchemyRecipes = pgTable("alchemy_recipes", {
  id: serial("id").primaryKey(),
  resultId: text("result_id").notNull().unique(),
  ingredients: jsonb("ingredients").$type<string[]>().notNull(),
});

export const insertAlchemyRecipeSchema = createInsertSchema(alchemyRecipes).pick({
  resultId: true,
  ingredients: true,
});

// User Alchemy Progress
export const userAlchemyProgress = pgTable("user_alchemy_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  elementId: text("element_id").notNull(),
  discoveredAt: timestamp("discovered_at").defaultNow().notNull(),
});

export const insertUserAlchemyProgressSchema = createInsertSchema(userAlchemyProgress).pick({
  userId: true,
  elementId: true,
  discoveredAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Module = typeof modules.$inferSelect;
export type InsertModule = z.infer<typeof insertModuleSchema>;

export type Challenge = typeof challenges.$inferSelect;
export type InsertChallenge = z.infer<typeof insertChallengeSchema>;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;

export type UserChallenge = typeof userChallenges.$inferSelect;
export type InsertUserChallenge = z.infer<typeof insertUserChallengeSchema>;

export type UserAchievement = typeof userAchievements.$inferSelect;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;

export type UserTutorial = typeof userTutorials.$inferSelect;
export type InsertUserTutorial = z.infer<typeof insertUserTutorialSchema>;

export type AlchemyElement = typeof alchemyElements.$inferSelect;
export type InsertAlchemyElement = z.infer<typeof insertAlchemyElementSchema>;

export type AlchemyRecipe = typeof alchemyRecipes.$inferSelect;
export type InsertAlchemyRecipe = z.infer<typeof insertAlchemyRecipeSchema>;

export type UserAlchemyProgress = typeof userAlchemyProgress.$inferSelect;
export type InsertUserAlchemyProgress = z.infer<typeof insertUserAlchemyProgressSchema>;
