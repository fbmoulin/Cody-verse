import React, { createContext, useContext, useEffect, useState } from 'react'

const ThemeContext = createContext()

export const useTheme = () => {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}

export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState(() => {
    // Check localStorage first, then system preference
    const stored = localStorage.getItem('codyverse-theme')
    if (stored) return stored
    
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  })
  
  const [ageGroup, setAgeGroup] = useState(() => {
    return localStorage.getItem('codyverse-age-group') || 'adult'
  })

  const [reducedMotion, setReducedMotion] = useState(() => {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches
  })

  const [highContrast, setHighContrast] = useState(() => {
    return localStorage.getItem('codyverse-high-contrast') === 'true'
  })

  useEffect(() => {
    const root = document.documentElement
    
    // Apply theme
    root.classList.remove('light', 'dark')
    root.classList.add(theme)
    
    // Apply age group theme
    root.classList.remove('theme-child', 'theme-teen', 'theme-adult')
    root.classList.add(`theme-${ageGroup}`)
    
    // Apply accessibility preferences
    if (reducedMotion) {
      root.classList.add('reduce-motion')
    } else {
      root.classList.remove('reduce-motion')
    }
    
    if (highContrast) {
      root.classList.add('high-contrast')
    } else {
      root.classList.remove('high-contrast')
    }
    
    // Store preferences
    localStorage.setItem('codyverse-theme', theme)
    localStorage.setItem('codyverse-age-group', ageGroup)
    localStorage.setItem('codyverse-high-contrast', highContrast.toString())
  }, [theme, ageGroup, reducedMotion, highContrast])

  useEffect(() => {
    // Listen for system theme changes
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
    const handleChange = (e) => {
      if (!localStorage.getItem('codyverse-theme')) {
        setTheme(e.matches ? 'dark' : 'light')
      }
    }
    
    mediaQuery.addEventListener('change', handleChange)
    return () => mediaQuery.removeEventListener('change', handleChange)
  }, [])

  useEffect(() => {
    // Listen for reduced motion preference changes
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)')
    const handleChange = (e) => setReducedMotion(e.matches)
    
    mediaQuery.addEventListener('change', handleChange)
    return () => mediaQuery.removeEventListener('change', handleChange)
  }, [])

  const updateTheme = (newTheme) => {
    setTheme(newTheme)
  }

  const updateAgeGroup = (newAgeGroup) => {
    setAgeGroup(newAgeGroup)
  }

  const toggleHighContrast = () => {
    setHighContrast(prev => !prev)
  }

  const getThemeColors = () => {
    const colors = {
      child: {
        primary: '#FF6B6B',
        secondary: '#4ECDC4',
        accent: '#FFE66D'
      },
      teen: {
        primary: '#6C5CE7',
        secondary: '#00B894',
        accent: '#FDCB6E'
      },
      adult: {
        primary: '#4F46E5',
        secondary: '#06B6D4',
        accent: '#F59E0B'
      }
    }
    
    return colors[ageGroup] || colors.adult
  }

  const value = {
    theme,
    ageGroup,
    reducedMotion,
    highContrast,
    updateTheme,
    updateAgeGroup,
    toggleHighContrast,
    getThemeColors,
    isDark: theme === 'dark',
    isChild: ageGroup === 'child',
    isTeen: ageGroup === 'teen',
    isAdult: ageGroup === 'adult'
  }

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  )
}

