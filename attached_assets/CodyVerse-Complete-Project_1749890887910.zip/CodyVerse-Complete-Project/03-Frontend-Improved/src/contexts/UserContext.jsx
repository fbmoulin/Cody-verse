import React, { createContext, useContext, useState, useEffect } from 'react'
import apiService from '../services/api'

const UserContext = createContext()

export const useUser = () => {
  const context = useContext(UserContext)
  if (!context) {
    throw new Error('useUser must be used within a UserProvider')
  }
  return context
}

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  // Check if user is logged in on app start
  useEffect(() => {
    checkAuthStatus()
  }, [])

  const checkAuthStatus = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem('auth_token')
      
      if (token) {
        apiService.setToken(token)
        const response = await apiService.getCurrentUser()
        setUser(response.user)
        setIsAuthenticated(true)
      }
    } catch (error) {
      console.error('Auth check failed:', error)
      // Token might be expired, clear it
      localStorage.removeItem('auth_token')
      apiService.setToken(null)
      setIsAuthenticated(false)
      setUser(null)
    } finally {
      setLoading(false)
    }
  }

  const login = async (credentials) => {
    try {
      setLoading(true)
      setError(null)
      
      const response = await apiService.login(credentials)
      setUser(response.user)
      setIsAuthenticated(true)
      
      return response
    } catch (error) {
      setError(error.message)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const register = async (userData) => {
    try {
      setLoading(true)
      setError(null)
      
      const response = await apiService.register(userData)
      setUser(response.user)
      setIsAuthenticated(true)
      
      return response
    } catch (error) {
      setError(error.message)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const logout = async () => {
    try {
      await apiService.logout()
    } catch (error) {
      console.error('Logout error:', error)
    } finally {
      setUser(null)
      setIsAuthenticated(false)
      setError(null)
    }
  }

  const updateUser = async (userData) => {
    try {
      setLoading(true)
      setError(null)
      
      const response = await apiService.updateUser(userData)
      setUser(response.user)
      
      return response
    } catch (error) {
      setError(error.message)
      throw error
    } finally {
      setLoading(false)
    }
  }

  const refreshUserData = async () => {
    try {
      if (isAuthenticated) {
        const response = await apiService.getCurrentUser()
        setUser(response.user)
      }
    } catch (error) {
      console.error('Failed to refresh user data:', error)
    }
  }

  // Helper functions for gamification
  const addXP = (amount) => {
    if (user) {
      const newXP = user.xp + amount
      const newLevel = Math.floor(Math.sqrt(newXP / 100)) + 1
      const levelUp = newLevel > user.level
      
      setUser(prev => ({
        ...prev,
        xp: newXP,
        level: newLevel
      }))
      
      return { levelUp, newLevel, newXP }
    }
    return { levelUp: false }
  }

  const getXPForNextLevel = () => {
    if (!user) return 0
    const nextLevel = user.level + 1
    return (nextLevel - 1) ** 2 * 100
  }

  const getProgressToNextLevel = () => {
    if (!user) return 0
    const currentLevelXP = (user.level - 1) ** 2 * 100
    const nextLevelXP = getXPForNextLevel()
    const progress = ((user.xp - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100
    return Math.min(100, Math.max(0, progress))
  }

  const value = {
    // State
    user,
    loading,
    error,
    isAuthenticated,
    
    // Actions
    login,
    register,
    logout,
    updateUser,
    refreshUserData,
    
    // Gamification helpers
    addXP,
    getXPForNextLevel,
    getProgressToNextLevel,
    
    // Utilities
    clearError: () => setError(null)
  }

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  )
}

