import React, { createContext, useContext, useState, useEffect } from 'react'

const LanguageContext = createContext()

export const useLanguage = () => {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}

const translations = {
  'pt-BR': {
    nav: {
      dashboard: 'Dashboard',
      courses: 'Cursos',
      progress: 'Progresso',
      achievements: 'Conquistas',
      leaderboard: 'Ranking',
      profile: 'Perfil'
    },
    dashboard: {
      welcome: 'Bem-vindo de volta',
      continuelearning: 'Continue Aprendendo',
      recentactivity: 'Atividade Recente',
      quickactions: 'Ações Rápidas',
      achievements: 'Conquistas',
      progress: 'Seu Progresso'
    },
    gamification: {
      level: 'Nível',
      xp: 'XP',
      coins: 'Moedas',
      gems: 'Gemas',
      streak: 'Sequência',
      badges: 'Badges'
    },
    actions: {
      start: 'Começar',
      continue: 'Continuar',
      complete: 'Completar',
      retry: 'Tentar Novamente',
      next: 'Próximo',
      previous: 'Anterior',
      save: 'Salvar',
      cancel: 'Cancelar'
    },
    accessibility: {
      menu: 'Menu principal',
      close: 'Fechar',
      expand: 'Expandir',
      collapse: 'Recolher',
      loading: 'Carregando',
      error: 'Erro'
    }
  },
  'en-US': {
    nav: {
      dashboard: 'Dashboard',
      courses: 'Courses',
      progress: 'Progress',
      achievements: 'Achievements',
      leaderboard: 'Leaderboard',
      profile: 'Profile'
    },
    dashboard: {
      welcome: 'Welcome back',
      continuelearning: 'Continue Learning',
      recentactivity: 'Recent Activity',
      quickactions: 'Quick Actions',
      achievements: 'Achievements',
      progress: 'Your Progress'
    },
    gamification: {
      level: 'Level',
      xp: 'XP',
      coins: 'Coins',
      gems: 'Gems',
      streak: 'Streak',
      badges: 'Badges'
    },
    actions: {
      start: 'Start',
      continue: 'Continue',
      complete: 'Complete',
      retry: 'Retry',
      next: 'Next',
      previous: 'Previous',
      save: 'Save',
      cancel: 'Cancel'
    },
    accessibility: {
      menu: 'Main menu',
      close: 'Close',
      expand: 'Expand',
      collapse: 'Collapse',
      loading: 'Loading',
      error: 'Error'
    }
  },
  'es-ES': {
    nav: {
      dashboard: 'Panel',
      courses: 'Cursos',
      progress: 'Progreso',
      achievements: 'Logros',
      leaderboard: 'Clasificación',
      profile: 'Perfil'
    },
    dashboard: {
      welcome: 'Bienvenido de vuelta',
      continuelearning: 'Continuar Aprendiendo',
      recentactivity: 'Actividad Reciente',
      quickactions: 'Acciones Rápidas',
      achievements: 'Logros',
      progress: 'Tu Progreso'
    },
    gamification: {
      level: 'Nivel',
      xp: 'XP',
      coins: 'Monedas',
      gems: 'Gemas',
      streak: 'Racha',
      badges: 'Insignias'
    },
    actions: {
      start: 'Comenzar',
      continue: 'Continuar',
      complete: 'Completar',
      retry: 'Reintentar',
      next: 'Siguiente',
      previous: 'Anterior',
      save: 'Guardar',
      cancel: 'Cancelar'
    },
    accessibility: {
      menu: 'Menú principal',
      close: 'Cerrar',
      expand: 'Expandir',
      collapse: 'Contraer',
      loading: 'Cargando',
      error: 'Error'
    }
  }
}

const availableLanguages = [
  { code: 'pt-BR', name: 'Português', flag: '🇧🇷' },
  { code: 'en-US', name: 'English', flag: '🇺🇸' },
  { code: 'es-ES', name: 'Español', flag: '🇪🇸' }
]

export const LanguageProvider = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState(() => {
    // Check localStorage first, then browser language
    const stored = localStorage.getItem('codyverse-language')
    if (stored && translations[stored]) return stored
    
    const browserLang = navigator.language
    if (translations[browserLang]) return browserLang
    
    // Fallback to Portuguese (Brazilian)
    return 'pt-BR'
  })

  useEffect(() => {
    localStorage.setItem('codyverse-language', currentLanguage)
    document.documentElement.lang = currentLanguage.split('-')[0]
  }, [currentLanguage])

  const changeLanguage = (languageCode) => {
    if (translations[languageCode]) {
      setCurrentLanguage(languageCode)
    }
  }

  const t = (key) => {
    const keys = key.split('.')
    let value = translations[currentLanguage]
    
    for (const k of keys) {
      value = value?.[k]
    }
    
    return value || key
  }

  const formatNumber = (number) => {
    return new Intl.NumberFormat(currentLanguage).format(number)
  }

  const formatDate = (date) => {
    return new Intl.DateTimeFormat(currentLanguage, {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date)
  }

  const formatRelativeTime = (date) => {
    const rtf = new Intl.RelativeTimeFormat(currentLanguage, { numeric: 'auto' })
    const diff = date - new Date()
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    
    if (Math.abs(days) < 1) {
      const hours = Math.floor(diff / (1000 * 60 * 60))
      if (Math.abs(hours) < 1) {
        const minutes = Math.floor(diff / (1000 * 60))
        return rtf.format(minutes, 'minute')
      }
      return rtf.format(hours, 'hour')
    }
    
    return rtf.format(days, 'day')
  }

  const isRTL = () => {
    // Add RTL languages here when supported
    return false
  }

  const value = {
    currentLanguage,
    availableLanguages,
    changeLanguage,
    t,
    formatNumber,
    formatDate,
    formatRelativeTime,
    isRTL,
    translations: translations[currentLanguage]
  }

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  )
}

