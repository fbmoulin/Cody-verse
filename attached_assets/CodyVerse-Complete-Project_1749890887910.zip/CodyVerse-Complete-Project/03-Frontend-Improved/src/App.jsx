import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ThemeProvider } from './contexts/ThemeContext'
import { LanguageProvider } from './contexts/LanguageContext'
import { UserProvider, useUser } from './contexts/UserContext'
import { Sidebar } from './components/Layout/Sidebar'
import { MobileHeader } from './components/Layout/MobileHeader'
import { Dashboard } from './components/Pages/Dashboard'
import { Courses } from './components/Pages/Courses'
import { Progress } from './components/Pages/Progress'
import { Achievements } from './components/Pages/Achievements'
import { Leaderboard } from './components/Pages/Leaderboard'
import { Profile } from './components/Pages/Profile'
import { LoadingScreen } from './components/UI/LoadingScreen'
import { NotificationContainer } from './components/UI/NotificationContainer'
import { ErrorBoundary } from './components/UI/ErrorBoundary'
import AuthModal from './components/UI/AuthModal'
import './App.css'

const AppContent = () => {
  const [currentPage, setCurrentPage] = useState('dashboard')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [appLoading, setAppLoading] = useState(true)

  const { user, loading, isAuthenticated } = useUser()

  useEffect(() => {
    // Simulate app initialization
    const timer = setTimeout(() => {
      setAppLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    // Show auth modal if not authenticated and app is loaded
    if (!appLoading && !loading && !isAuthenticated) {
      setShowAuthModal(true)
    } else {
      setShowAuthModal(false)
    }
  }, [appLoading, loading, isAuthenticated])

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />
      case 'courses':
        return <Courses />
      case 'progress':
        return <Progress />
      case 'achievements':
        return <Achievements />
      case 'leaderboard':
        return <Leaderboard />
      case 'profile':
        return <Profile />
      default:
        return <Dashboard />
    }
  }

  if (appLoading || loading) {
    return <LoadingScreen />
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Desktop Layout */}
      <div className="hidden md:flex">
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          currentPage={currentPage}
          onPageChange={setCurrentPage}
        />
        
        <main 
          className={`flex-1 transition-all duration-300 ${
            sidebarCollapsed ? 'ml-16' : 'ml-64'
          }`}
        >
          <div className="p-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentPage}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                {renderPage()}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Mobile Layout */}
      <div className="md:hidden">
        <MobileHeader
          currentPage={currentPage}
          onPageChange={setCurrentPage}
        />
        
        <main className="pb-16">
          <div className="p-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentPage}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
              >
                {renderPage()}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>

      {/* Auth Modal */}
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
      />

      {/* Notifications */}
      <NotificationContainer />
    </div>
  )
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <LanguageProvider>
          <UserProvider>
            <AppContent />
          </UserProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  )
}

export default App

