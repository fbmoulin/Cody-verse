// API Configuration
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api'

class ApiService {
  constructor() {
    this.baseURL = API_BASE_URL
    this.token = localStorage.getItem('auth_token')
  }

  // Set authentication token
  setToken(token) {
    this.token = token
    if (token) {
      localStorage.setItem('auth_token', token)
    } else {
      localStorage.removeItem('auth_token')
    }
  }

  // Get authentication headers
  getHeaders() {
    const headers = {
      'Content-Type': 'application/json',
    }
    
    if (this.token) {
      headers.Authorization = `Bearer ${this.token}`
    }
    
    return headers
  }

  // Generic API request method
  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`
    const config = {
      headers: this.getHeaders(),
      ...options,
    }

    try {
      const response = await fetch(url, config)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || `HTTP error! status: ${response.status}`)
      }

      return data
    } catch (error) {
      console.error('API request failed:', error)
      throw error
    }
  }

  // GET request
  async get(endpoint) {
    return this.request(endpoint, { method: 'GET' })
  }

  // POST request
  async post(endpoint, data) {
    return this.request(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
    })
  }

  // PUT request
  async put(endpoint, data) {
    return this.request(endpoint, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  }

  // DELETE request
  async delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' })
  }

  // Authentication methods
  async register(userData) {
    const response = await this.post('/auth/register', userData)
    if (response.token) {
      this.setToken(response.token)
    }
    return response
  }

  async login(credentials) {
    const response = await this.post('/auth/login', credentials)
    if (response.token) {
      this.setToken(response.token)
    }
    return response
  }

  async logout() {
    this.setToken(null)
    return { message: 'Logged out successfully' }
  }

  async getCurrentUser() {
    return this.get('/auth/me')
  }

  async updateUser(userData) {
    return this.put('/auth/me', userData)
  }

  async refreshToken() {
    return this.post('/auth/refresh')
  }

  // Course methods
  async getCourses(filters = {}) {
    const params = new URLSearchParams(filters)
    const endpoint = `/courses${params.toString() ? `?${params.toString()}` : ''}`
    return this.get(endpoint)
  }

  async getCourse(courseId) {
    return this.get(`/courses/${courseId}`)
  }

  async enrollCourse(courseId) {
    return this.post(`/courses/${courseId}/enroll`)
  }

  async getMyCourses() {
    return this.get('/my-courses')
  }

  async getLesson(courseId, lessonId) {
    return this.get(`/courses/${courseId}/lessons/${lessonId}`)
  }

  async completeLesson(courseId, lessonId, completionData = {}) {
    return this.post(`/courses/${courseId}/lessons/${lessonId}/complete`, completionData)
  }

  async getProgress() {
    return this.get('/progress')
  }

  // AI methods
  async chatWithCody(message, type = 'question') {
    return this.post('/ai/chat', { message, type })
  }

  async getRecommendations() {
    return this.get('/ai/recommendations')
  }

  async analyzeCode(code, language = 'python') {
    return this.post('/ai/analyze-code', { code, language })
  }

  async generateExercise(topic, difficulty = 'beginner') {
    return this.post('/ai/generate-exercise', { topic, difficulty })
  }

  async getChatHistory(limit = 20) {
    return this.get(`/ai/chat/history?limit=${limit}`)
  }

  async getAIStatus() {
    return this.get('/ai/status')
  }

  // Health check
  async healthCheck() {
    return this.get('/health')
  }
}

// Create and export a singleton instance
const apiService = new ApiService()
export default apiService

// Export individual methods for convenience
export const {
  register,
  login,
  logout,
  getCurrentUser,
  updateUser,
  getCourses,
  getCourse,
  enrollCourse,
  getMyCourses,
  getLesson,
  completeLesson,
  getProgress,
  chatWithCody,
  getRecommendations,
  analyzeCode,
  generateExercise,
  getChatHistory,
  getAIStatus,
  healthCheck
} = apiService

