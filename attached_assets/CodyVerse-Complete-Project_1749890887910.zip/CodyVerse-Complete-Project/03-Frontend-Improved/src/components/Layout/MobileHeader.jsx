import React, { useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Home, BookOpen, TrendingUp, Trophy, Medal, User, 
  Menu, X, Zap, Bell, Search, MessageCircle
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useLanguage } from '../../contexts/LanguageContext'
import { useUser } from '../../contexts/UserContext'

const navigation = [
  { name: 'nav.dashboard', href: '/', icon: Home },
  { name: 'nav.courses', href: '/courses', icon: BookOpen },
  { name: 'nav.progress', href: '/progress', icon: TrendingUp },
  { name: 'nav.achievements', href: '/achievements', icon: Trophy },
  { name: 'nav.leaderboard', href: '/leaderboard', icon: Medal }
]

export const MobileHeader = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { t } = useLanguage()
  const { user } = useUser()
  const location = useLocation()

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)

  return (
    <>
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-background/95 backdrop-blur-sm border-b border-border z-50">
        <div className="flex items-center justify-between h-full px-4">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-bold">CodyVerse</span>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="w-9 h-9 p-0">
              <Search className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className="w-9 h-9 p-0 relative">
              <Bell className="w-4 h-4" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full text-xs" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={toggleMenu}
              className="w-9 h-9 p-0"
              aria-expanded={isMenuOpen}
              aria-label={isMenuOpen ? t('accessibility.close') : t('accessibility.menu')}
            >
              {isMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </header>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 h-20 bg-background/95 backdrop-blur-sm border-t border-border z-50">
        <div className="flex items-center justify-around h-full px-2">
          {navigation.map((item) => {
            const isActive = location.pathname === item.href
            const Icon = item.icon
            
            return (
              <NavLink
                key={item.name}
                to={item.href}
                className={({ isActive }) => `
                  flex flex-col items-center justify-center gap-1 p-2 rounded-lg transition-all duration-200 min-w-0 flex-1
                  ${isActive 
                    ? 'text-primary' 
                    : 'text-muted-foreground hover:text-foreground'
                  }
                `}
                aria-current={isActive ? 'page' : undefined}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs font-medium truncate">
                  {t(item.name)}
                </span>
                {isActive && (
                  <motion.div
                    className="w-1 h-1 bg-primary rounded-full"
                    layoutId="mobileActiveIndicator"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
              </NavLink>
            )
          })}
          
          {/* Profile */}
          <NavLink
            to="/profile"
            className={({ isActive }) => `
              flex flex-col items-center justify-center gap-1 p-2 rounded-lg transition-all duration-200 min-w-0 flex-1
              ${isActive 
                ? 'text-primary' 
                : 'text-muted-foreground hover:text-foreground'
              }
            `}
          >
            <div className="w-6 h-6 rounded-full overflow-hidden border border-border">
              <img 
                src={user.avatar} 
                alt={user.name}
                className="w-full h-full object-cover"
              />
            </div>
            <span className="text-xs font-medium">Perfil</span>
          </NavLink>
        </div>
      </nav>

      {/* Floating Action Button */}
      <motion.div
        className="fixed bottom-24 right-4 z-40"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Button
          size="lg"
          className="w-14 h-14 rounded-full shadow-lg"
          aria-label="Chat com Cody"
        >
          <MessageCircle className="w-6 h-6" />
        </Button>
      </motion.div>

      {/* Slide-out Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              className="fixed inset-0 bg-black/50 z-40"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={toggleMenu}
            />
            
            {/* Menu Panel */}
            <motion.div
              className="fixed top-16 right-0 bottom-0 w-80 max-w-[80vw] bg-background border-l border-border z-50 overflow-y-auto"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
            >
              <div className="p-6 space-y-6">
                {/* User Info */}
                <div className="flex items-center gap-3 p-4 bg-muted rounded-lg">
                  <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-primary">
                    <img 
                      src={user.avatar} 
                      alt={user.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold truncate">{user.name}</h3>
                    <p className="text-sm text-muted-foreground">Nível {user.level}</p>
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-muted rounded-lg text-center">
                    <div className="text-lg font-bold text-primary">{user.xp}</div>
                    <div className="text-xs text-muted-foreground">XP Total</div>
                  </div>
                  <div className="p-3 bg-muted rounded-lg text-center">
                    <div className="text-lg font-bold text-secondary">{user.currentStreak}</div>
                    <div className="text-xs text-muted-foreground">Sequência</div>
                  </div>
                </div>

                {/* Menu Items */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                    Menu
                  </h4>
                  {[
                    { icon: User, label: 'Meu Perfil', href: '/profile' },
                    { icon: Trophy, label: 'Conquistas', href: '/achievements' },
                    { icon: Medal, label: 'Ranking', href: '/leaderboard' },
                  ].map((item) => (
                    <NavLink
                      key={item.label}
                      to={item.href}
                      onClick={toggleMenu}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors"
                    >
                      <item.icon className="w-5 h-5 text-muted-foreground" />
                      <span>{item.label}</span>
                    </NavLink>
                  ))}
                </div>

                {/* Settings */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                    Configurações
                  </h4>
                  <button className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors w-full text-left">
                    <span>Notificações</span>
                  </button>
                  <button className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors w-full text-left">
                    <span>Privacidade</span>
                  </button>
                  <button className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors w-full text-left">
                    <span>Ajuda</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}

