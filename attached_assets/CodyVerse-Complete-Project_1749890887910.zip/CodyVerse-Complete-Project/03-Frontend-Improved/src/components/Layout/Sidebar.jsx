import React from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Home, BookOpen, TrendingUp, Trophy, Medal, User, 
  Settings, Menu, X, Zap, Globe, Moon, Sun, 
  ChevronRight, LogOut
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useLanguage } from '../../contexts/LanguageContext'
import { useTheme } from '../../contexts/ThemeContext'
import { useUser } from '../../contexts/UserContext'

const navigation = [
  { name: 'nav.dashboard', href: '/', icon: Home },
  { name: 'nav.courses', href: '/courses', icon: BookOpen },
  { name: 'nav.progress', href: '/progress', icon: TrendingUp },
  { name: 'nav.achievements', href: '/achievements', icon: Trophy },
  { name: 'nav.leaderboard', href: '/leaderboard', icon: Medal },
  { name: 'nav.profile', href: '/profile', icon: User }
]

export const Sidebar = ({ collapsed, onToggle }) => {
  const { t, changeLanguage, currentLanguage, availableLanguages } = useLanguage()
  const { theme, updateTheme, ageGroup, updateAgeGroup } = useTheme()
  const { user, progressToNextLevel } = useUser()
  const location = useLocation()

  const sidebarVariants = {
    expanded: { width: 320 },
    collapsed: { width: 80 }
  }

  const contentVariants = {
    expanded: { opacity: 1, x: 0 },
    collapsed: { opacity: 0, x: -20 }
  }

  return (
    <motion.aside
      className="fixed left-0 top-0 h-screen bg-sidebar border-r border-sidebar-border z-40 flex flex-col"
      variants={sidebarVariants}
      animate={collapsed ? "collapsed" : "expanded"}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      role="navigation"
      aria-label={t('accessibility.menu')}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-sidebar-border">
        <motion.div
          className="flex items-center gap-3"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Zap className="w-6 h-6 text-primary-foreground" />
          </div>
          <AnimatePresence>
            {!collapsed && (
              <motion.span
                className="text-xl font-bold text-sidebar-foreground"
                variants={contentVariants}
                initial="collapsed"
                animate="expanded"
                exit="collapsed"
              >
                CodyVerse
              </motion.span>
            )}
          </AnimatePresence>
        </motion.div>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggle}
          className="w-8 h-8 p-0"
          aria-expanded={!collapsed}
          aria-controls="sidebar-content"
          aria-label={collapsed ? t('accessibility.expand') : t('accessibility.collapse')}
        >
          {collapsed ? <Menu className="w-4 h-4" /> : <X className="w-4 h-4" />}
        </Button>
      </div>

      {/* User Profile */}
      <div className="p-6 border-b border-sidebar-border">
        <UserProfile collapsed={collapsed} user={user} progressToNextLevel={progressToNextLevel} />
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 overflow-y-auto" id="sidebar-content">
        <ul className="space-y-2" role="menubar">
          {navigation.map((item) => {
            const isActive = location.pathname === item.href
            const Icon = item.icon
            
            return (
              <li key={item.name} role="none">
                <NavLink
                  to={item.href}
                  className={({ isActive }) => `
                    group relative flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200
                    ${isActive 
                      ? 'bg-sidebar-accent text-sidebar-accent-foreground' 
                      : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                    }
                  `}
                  role="menuitem"
                  aria-current={isActive ? 'page' : undefined}
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  <AnimatePresence>
                    {!collapsed && (
                      <motion.span
                        className="font-medium"
                        variants={contentVariants}
                        initial="collapsed"
                        animate="expanded"
                        exit="collapsed"
                      >
                        {t(item.name)}
                      </motion.span>
                    )}
                  </AnimatePresence>
                  
                  {isActive && (
                    <motion.div
                      className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-primary rounded-l"
                      layoutId="activeIndicator"
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    />
                  )}
                </NavLink>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Settings */}
      <AnimatePresence>
        {!collapsed && (
          <motion.div
            className="p-6 border-t border-sidebar-border space-y-6"
            variants={contentVariants}
            initial="collapsed"
            animate="expanded"
            exit="collapsed"
          >
            <LanguageSelector 
              currentLanguage={currentLanguage}
              availableLanguages={availableLanguages}
              changeLanguage={changeLanguage}
            />
            
            <ThemeSelector 
              theme={theme}
              updateTheme={updateTheme}
            />
            
            <AgeGroupSelector 
              ageGroup={ageGroup}
              updateAgeGroup={updateAgeGroup}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border">
        <AnimatePresence>
          {!collapsed ? (
            <motion.div
              className="text-center space-y-2"
              variants={contentVariants}
              initial="collapsed"
              animate="expanded"
              exit="collapsed"
            >
              <p className="text-xs text-sidebar-foreground/60">CodyVerse v2.0</p>
              <div className="flex justify-center gap-4 text-xs">
                <button className="text-sidebar-foreground/60 hover:text-sidebar-foreground">
                  Ajuda
                </button>
                <button className="text-sidebar-foreground/60 hover:text-sidebar-foreground">
                  Sobre
                </button>
              </div>
            </motion.div>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              className="w-full"
              aria-label="Sair"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          )}
        </AnimatePresence>
      </div>
    </motion.aside>
  )
}

const UserProfile = ({ collapsed, user, progressToNextLevel }) => {
  if (collapsed) {
    return (
      <div className="flex justify-center">
        <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-primary">
          <img 
            src={user.avatar} 
            alt={user.name}
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    )
  }

  return (
    <motion.div
      className="text-center space-y-3"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
    >
      <div className="flex justify-center">
        <div className="relative">
          <div className="w-16 h-16 rounded-full overflow-hidden border-3 border-primary">
            <img 
              src={user.avatar} 
              alt={user.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-sidebar" />
        </div>
      </div>
      
      <div>
        <h3 className="font-semibold text-sidebar-foreground">{user.name}</h3>
        <div className="flex items-center justify-center gap-2 mt-1">
          <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded-full">
            Nível {user.level}
          </span>
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between text-xs text-sidebar-foreground/80">
          <span>{user.xp} XP</span>
          <span>{user.xpToNextLevel} XP</span>
        </div>
        <div className="w-full bg-sidebar-accent/30 rounded-full h-2 overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-primary to-secondary rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progressToNextLevel}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
          />
        </div>
        <p className="text-xs text-sidebar-foreground/60">
          {progressToNextLevel}% para o próximo nível
        </p>
      </div>
    </motion.div>
  )
}

const LanguageSelector = ({ currentLanguage, availableLanguages, changeLanguage }) => (
  <div className="space-y-3">
    <h4 className="text-sm font-medium text-sidebar-foreground flex items-center gap-2">
      <Globe className="w-4 h-4" />
      Idioma
    </h4>
    <div className="grid grid-cols-1 gap-2">
      {availableLanguages.map((lang) => (
        <Button
          key={lang.code}
          variant={currentLanguage === lang.code ? "default" : "ghost"}
          size="sm"
          onClick={() => changeLanguage(lang.code)}
          className="justify-start gap-2 h-8"
        >
          <span>{lang.flag}</span>
          <span className="text-xs">{lang.name}</span>
        </Button>
      ))}
    </div>
  </div>
)

const ThemeSelector = ({ theme, updateTheme }) => (
  <div className="space-y-3">
    <h4 className="text-sm font-medium text-sidebar-foreground flex items-center gap-2">
      {theme === 'dark' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
      Tema
    </h4>
    <div className="grid grid-cols-2 gap-2">
      <Button
        variant={theme === 'light' ? "default" : "ghost"}
        size="sm"
        onClick={() => updateTheme('light')}
        className="justify-start gap-2 h-8"
      >
        <Sun className="w-3 h-3" />
        <span className="text-xs">Claro</span>
      </Button>
      <Button
        variant={theme === 'dark' ? "default" : "ghost"}
        size="sm"
        onClick={() => updateTheme('dark')}
        className="justify-start gap-2 h-8"
      >
        <Moon className="w-3 h-3" />
        <span className="text-xs">Escuro</span>
      </Button>
    </div>
  </div>
)

const AgeGroupSelector = ({ ageGroup, updateAgeGroup }) => (
  <div className="space-y-3">
    <h4 className="text-sm font-medium text-sidebar-foreground flex items-center gap-2">
      <User className="w-4 h-4" />
      Faixa Etária
    </h4>
    <div className="grid grid-cols-3 gap-1">
      {[
        { key: 'child', label: '7-12' },
        { key: 'teen', label: '13-18' },
        { key: 'adult', label: '19+' }
      ].map((age) => (
        <Button
          key={age.key}
          variant={ageGroup === age.key ? "default" : "ghost"}
          size="sm"
          onClick={() => updateAgeGroup(age.key)}
          className="h-8 text-xs"
        >
          {age.label}
        </Button>
      ))}
    </div>
  </div>
)

