import React from 'react'
import { motion } from 'framer-motion'
import { BookOpen, Play, Clock, Star, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'

const courses = [
  {
    id: 1,
    title: 'Introdução ao Python',
    description: 'Aprenda os fundamentos da programação com Python',
    progress: 65,
    lessons: 12,
    duration: '4 horas',
    difficulty: 'Iniciante',
    image: '🐍',
    color: 'bg-blue-500'
  },
  {
    id: 2,
    title: 'JavaScript Essencial',
    description: 'Domine JavaScript para desenvolvimento web',
    progress: 30,
    lessons: 15,
    duration: '6 horas',
    difficulty: 'Iniciante',
    image: '⚡',
    color: 'bg-yellow-500'
  },
  {
    id: 3,
    title: 'React Fundamentals',
    description: 'Construa interfaces modernas com React',
    progress: 0,
    lessons: 18,
    duration: '8 horas',
    difficulty: 'Intermediário',
    image: '⚛️',
    color: 'bg-cyan-500'
  },
  {
    id: 4,
    title: 'Machine Learning Básico',
    description: 'Introdução aos conceitos de IA e ML',
    progress: 0,
    lessons: 20,
    duration: '10 horas',
    difficulty: 'Avançado',
    image: '🤖',
    color: 'bg-purple-500'
  }
]

export const Courses = () => {
  return (
    <motion.div
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div>
        <h1 className="text-3xl font-bold">Cursos</h1>
        <p className="text-muted-foreground mt-2">
          Explore nossa biblioteca de cursos e continue sua jornada de aprendizado
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course, index) => (
          <motion.div
            key={course.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <CourseCard course={course} />
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

const CourseCard = ({ course }) => {
  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Iniciante': return 'text-green-500 bg-green-500/10'
      case 'Intermediário': return 'text-yellow-500 bg-yellow-500/10'
      case 'Avançado': return 'text-red-500 bg-red-500/10'
      default: return 'text-gray-500 bg-gray-500/10'
    }
  }

  return (
    <Card className="hover:shadow-lg transition-all duration-300 group">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className={`w-12 h-12 ${course.color} rounded-lg flex items-center justify-center text-2xl`}>
            {course.image}
          </div>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(course.difficulty)}`}>
            {course.difficulty}
          </span>
        </div>
        <CardTitle className="text-lg group-hover:text-primary transition-colors">
          {course.title}
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          {course.description}
        </p>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {course.progress > 0 && (
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Progresso</span>
              <span>{course.progress}%</span>
            </div>
            <Progress value={course.progress} />
          </div>
        )}
        
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <BookOpen className="w-4 h-4" />
            <span>{course.lessons} lições</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{course.duration}</span>
          </div>
        </div>
        
        <Button className="w-full group-hover:bg-primary/90 transition-colors">
          {course.progress > 0 ? (
            <>
              Continuar
              <Play className="w-4 h-4 ml-2" />
            </>
          ) : (
            <>
              Começar
              <ChevronRight className="w-4 h-4 ml-2" />
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}

