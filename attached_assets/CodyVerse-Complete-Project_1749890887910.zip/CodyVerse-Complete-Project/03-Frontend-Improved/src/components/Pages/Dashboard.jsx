import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { useUser } from '../../contexts/UserContext'
import { useLanguage } from '../../contexts/LanguageContext'
import apiService from '../../services/api'
import { 
  BookOpen, 
  Zap, 
  Target, 
  Calendar,
  Play,
  Plus,
  MessageCircle,
  Trophy,
  Clock,
  TrendingUp
} from 'lucide-react'

export const Dashboard = () => {
  const { user } = useUser()
  const { t } = useLanguage()
  const [dashboardData, setDashboardData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    loadDashboardData()
  }, [])

  const loadDashboardData = async () => {
    try {
      setLoading(true)
      const [progressData, coursesData, recommendationsData] = await Promise.all([
        apiService.getProgress(),
        apiService.getMyCourses(),
        apiService.getRecommendations().catch(() => ({ recommendations: [] }))
      ])

      setDashboardData({
        progress: progressData,
        enrollments: coursesData.enrollments || [],
        recommendations: recommendationsData.recommendations || []
      })
    } catch (error) {
      console.error('Failed to load dashboard data:', error)
      setError(error.message)
    } finally {
      setLoading(false)
    }
  }

  const getGreeting = () => {
    const hour = new Date().getHours()
    const name = user?.first_name || user?.username || 'Estudante'
    
    if (hour < 12) return `Bom dia, ${name}! 🌅`
    if (hour < 18) return `Boa tarde, ${name}! ☀️`
    return `Boa noite, ${name}! 🌙`
  }

  const handleContinueLearning = async () => {
    if (dashboardData?.enrollments?.length > 0) {
      const currentEnrollment = dashboardData.enrollments.find(e => !e.completed_at)
      if (currentEnrollment) {
        // Navigate to course or lesson
        console.log('Continue learning:', currentEnrollment)
      }
    }
  }

  const handleStartNewCourse = () => {
    // Navigate to courses page
    console.log('Start new course')
  }

  const handleChatWithCody = () => {
    // Open chat modal or navigate to chat
    console.log('Chat with Cody')
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 dark:bg-gray-700 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-500 mb-4">Erro ao carregar dados do dashboard</div>
        <button 
          onClick={loadDashboardData}
          className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark"
        >
          Tentar novamente
        </button>
      </div>
    )
  }

  const stats = dashboardData?.progress?.stats || {}
  const currentEnrollment = dashboardData?.enrollments?.find(e => !e.completed_at)

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-primary to-secondary rounded-2xl p-6 text-white"
      >
        <h1 className="text-2xl md:text-3xl font-bold mb-2">
          {getGreeting()}
        </h1>
        <p className="text-white/90">
          Pronto para continuar sua jornada de aprendizado?
        </p>
        
        {user && (
          <div className="mt-4 flex items-center space-x-4">
            <div className="text-sm">
              <span className="text-white/80">Próximo nível em </span>
              <span className="font-semibold">
                {user.xp_to_next_level - user.xp} XP
              </span>
            </div>
          </div>
        )}
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card rounded-xl p-6 border border-border"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">Nível Atual</p>
              <p className="text-2xl font-bold text-foreground">{user?.level || 1}</p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/20 rounded-lg flex items-center justify-center">
              <Trophy className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card rounded-xl p-6 border border-border"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">XP Total</p>
              <p className="text-2xl font-bold text-foreground">{user?.xp?.toLocaleString() || 0}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-xl p-6 border border-border"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">Sequência</p>
              <p className="text-2xl font-bold text-foreground">{user?.current_streak || 0} dias</p>
            </div>
            <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/20 rounded-lg flex items-center justify-center">
              <Target className="w-6 h-6 text-orange-600 dark:text-orange-400" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-card rounded-xl p-6 border border-border"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-muted-foreground text-sm">Lições</p>
              <p className="text-2xl font-bold text-foreground">{stats.weekly_lessons || 0}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Continue Learning */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="lg:col-span-2 bg-card rounded-xl p-6 border border-border"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-foreground flex items-center">
              <Play className="w-5 h-5 mr-2" />
              Continue Aprendendo
            </h2>
          </div>

          {currentEnrollment ? (
            <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg p-4 border border-primary/20">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center text-white font-bold">
                  {currentEnrollment.course?.icon || '📚'}
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground mb-1">
                    {currentEnrollment.course?.title}
                  </h3>
                  <p className="text-muted-foreground text-sm mb-3">
                    Lição: {currentEnrollment.current_lesson_id || 'Próxima lição'}
                  </p>
                  
                  {/* Progress Bar */}
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-3">
                    <div 
                      className="bg-gradient-to-r from-primary to-secondary h-2 rounded-full transition-all duration-300"
                      style={{ width: `${currentEnrollment.progress_percentage || 0}%` }}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      {Math.round(currentEnrollment.progress_percentage || 0)}% concluído
                    </span>
                    <button
                      onClick={handleContinueLearning}
                      className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors flex items-center space-x-2"
                    >
                      <Play className="w-4 h-4" />
                      <span>Continuar</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">
                Nenhum curso em andamento
              </h3>
              <p className="text-muted-foreground mb-4">
                Comece um novo curso para continuar aprendendo
              </p>
              <button
                onClick={handleStartNewCourse}
                className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors flex items-center space-x-2 mx-auto"
              >
                <Plus className="w-5 h-5" />
                <span>Explorar Cursos</span>
              </button>
            </div>
          )}
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-card rounded-xl p-6 border border-border"
        >
          <h2 className="text-xl font-semibold text-foreground mb-4">
            Ações Rápidas
          </h2>
          
          <div className="space-y-3">
            <button
              onClick={handleStartNewCourse}
              className="w-full p-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg hover:from-green-600 hover:to-emerald-600 transition-all flex items-center space-x-3"
            >
              <Plus className="w-5 h-5" />
              <span>Novo Curso</span>
            </button>

            <button className="w-full p-3 bg-gradient-to-r from-pink-500 to-rose-500 text-white rounded-lg hover:from-pink-600 hover:to-rose-600 transition-all flex items-center space-x-3">
              <Target className="w-5 h-5" />
              <span>Praticar</span>
            </button>

            <button className="w-full p-3 bg-gradient-to-r from-purple-500 to-indigo-500 text-white rounded-lg hover:from-purple-600 hover:to-indigo-600 transition-all flex items-center space-x-3">
              <Calendar className="w-5 h-5" />
              <span>Agendar Estudo</span>
            </button>

            <button
              onClick={handleChatWithCody}
              className="w-full p-3 bg-gradient-to-r from-orange-500 to-amber-500 text-white rounded-lg hover:from-orange-600 hover:to-amber-600 transition-all flex items-center space-x-3"
            >
              <MessageCircle className="w-5 h-5" />
              <span>Chat com Cody</span>
            </button>
          </div>
        </motion.div>
      </div>

      {/* Recent Activities */}
      {dashboardData?.progress?.recent_activities?.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-card rounded-xl p-6 border border-border"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-foreground flex items-center">
              <Clock className="w-5 h-5 mr-2" />
              Atividade Recente
            </h2>
          </div>

          <div className="space-y-3">
            {dashboardData.progress.recent_activities.slice(0, 5).map((activity, index) => (
              <div key={activity.id} className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg">
                <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-foreground">{activity.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(activity.created_at).toLocaleDateString('pt-BR')}
                  </p>
                </div>
                {activity.xp_gained > 0 && (
                  <div className="text-xs bg-yellow-100 dark:bg-yellow-900/20 text-yellow-600 dark:text-yellow-400 px-2 py-1 rounded">
                    +{activity.xp_gained} XP
                  </div>
                )}
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  )
}

