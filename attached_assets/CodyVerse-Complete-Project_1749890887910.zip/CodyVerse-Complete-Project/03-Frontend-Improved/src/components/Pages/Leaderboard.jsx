import React from 'react'
import { motion } from 'framer-motion'

export const Leaderboard = () => {
  return (
    <motion.div
      className="space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div>
        <h1 className="text-3xl font-bold">Ranking</h1>
        <p className="text-muted-foreground mt-2">
          Compare seu progresso com outros estudantes
        </p>
      </div>
      
      <div className="text-center py-20">
        <p className="text-muted-foreground">Página em desenvolvimento...</p>
      </div>
    </motion.div>
  )
}

