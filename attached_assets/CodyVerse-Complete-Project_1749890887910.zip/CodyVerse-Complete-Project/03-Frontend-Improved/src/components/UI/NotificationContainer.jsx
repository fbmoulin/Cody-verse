import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from 'lucide-react'
import { Button } from '@/components/ui/button'

const notificationTypes = {
  success: {
    icon: CheckCircle,
    className: 'bg-green-50 border-green-200 text-green-800 dark:bg-green-900/20 dark:border-green-800 dark:text-green-200'
  },
  error: {
    icon: AlertCircle,
    className: 'bg-red-50 border-red-200 text-red-800 dark:bg-red-900/20 dark:border-red-800 dark:text-red-200'
  },
  warning: {
    icon: AlertTriangle,
    className: 'bg-yellow-50 border-yellow-200 text-yellow-800 dark:bg-yellow-900/20 dark:border-yellow-800 dark:text-yellow-200'
  },
  info: {
    icon: Info,
    className: 'bg-blue-50 border-blue-200 text-blue-800 dark:bg-blue-900/20 dark:border-blue-800 dark:text-blue-200'
  }
}

// Global notification state
let notificationId = 0
const notificationListeners = new Set()

export const addNotification = (notification) => {
  const id = ++notificationId
  const newNotification = {
    id,
    type: 'info',
    duration: 5000,
    ...notification,
    timestamp: Date.now()
  }
  
  notificationListeners.forEach(listener => listener(newNotification))
  return id
}

export const removeNotification = (id) => {
  notificationListeners.forEach(listener => listener({ id, remove: true }))
}

// Convenience methods
export const showSuccess = (message, options = {}) => 
  addNotification({ ...options, type: 'success', message })

export const showError = (message, options = {}) => 
  addNotification({ ...options, type: 'error', message })

export const showWarning = (message, options = {}) => 
  addNotification({ ...options, type: 'warning', message })

export const showInfo = (message, options = {}) => 
  addNotification({ ...options, type: 'info', message })

const Notification = ({ notification, onRemove }) => {
  const { icon: Icon, className } = notificationTypes[notification.type]

  useEffect(() => {
    if (notification.duration > 0) {
      const timer = setTimeout(() => {
        onRemove(notification.id)
      }, notification.duration)

      return () => clearTimeout(timer)
    }
  }, [notification.id, notification.duration, onRemove])

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -50, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -20, scale: 0.9 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className={`
        relative flex items-start gap-3 p-4 rounded-lg border shadow-lg backdrop-blur-sm
        ${className}
      `}
      role="alert"
      aria-live="polite"
    >
      <Icon className="w-5 h-5 mt-0.5 flex-shrink-0" />
      
      <div className="flex-1 min-w-0">
        {notification.title && (
          <h4 className="font-semibold text-sm mb-1">
            {notification.title}
          </h4>
        )}
        <p className="text-sm">
          {notification.message}
        </p>
        
        {notification.action && (
          <div className="mt-3">
            <Button
              size="sm"
              variant="outline"
              onClick={notification.action.onClick}
              className="text-xs"
            >
              {notification.action.label}
            </Button>
          </div>
        )}
      </div>

      <Button
        size="sm"
        variant="ghost"
        onClick={() => onRemove(notification.id)}
        className="w-6 h-6 p-0 hover:bg-black/10 dark:hover:bg-white/10"
        aria-label="Fechar notificação"
      >
        <X className="w-4 h-4" />
      </Button>

      {/* Progress bar for timed notifications */}
      {notification.duration > 0 && (
        <motion.div
          className="absolute bottom-0 left-0 h-1 bg-current opacity-30 rounded-b-lg"
          initial={{ width: "100%" }}
          animate={{ width: "0%" }}
          transition={{ 
            duration: notification.duration / 1000,
            ease: "linear"
          }}
        />
      )}
    </motion.div>
  )
}

export const NotificationContainer = () => {
  const [notifications, setNotifications] = useState([])

  useEffect(() => {
    const handleNotification = (notification) => {
      if (notification.remove) {
        setNotifications(prev => prev.filter(n => n.id !== notification.id))
      } else {
        setNotifications(prev => {
          // Limit to 5 notifications max
          const newNotifications = [notification, ...prev].slice(0, 5)
          return newNotifications
        })
      }
    }

    notificationListeners.add(handleNotification)
    return () => notificationListeners.delete(handleNotification)
  }, [])

  const handleRemove = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
  }

  return (
    <div 
      className="fixed top-4 right-4 z-50 space-y-2 max-w-sm w-full"
      aria-label="Notificações"
    >
      <AnimatePresence mode="popLayout">
        {notifications.map((notification) => (
          <Notification
            key={notification.id}
            notification={notification}
            onRemove={handleRemove}
          />
        ))}
      </AnimatePresence>
    </div>
  )
}

// Hook for using notifications in components
export const useNotifications = () => {
  return {
    addNotification,
    removeNotification,
    showSuccess,
    showError,
    showWarning,
    showInfo
  }
}

