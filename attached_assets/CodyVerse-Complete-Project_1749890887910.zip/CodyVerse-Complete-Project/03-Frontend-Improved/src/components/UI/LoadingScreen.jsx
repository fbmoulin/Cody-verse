import React from 'react'
import { motion } from 'framer-motion'
import { Zap } from 'lucide-react'

export const LoadingScreen = () => {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center space-y-8">
        {/* Logo Animation */}
        <motion.div
          className="flex justify-center"
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ 
            duration: 0.8, 
            ease: "easeOut",
            type: "spring",
            stiffness: 100
          }}
        >
          <div className="relative">
            <motion.div
              className="w-20 h-20 bg-primary/20 rounded-full absolute inset-0"
              animate={{ 
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.6, 0.3]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
            <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center relative z-10">
              <Zap className="w-10 h-10 text-primary-foreground" />
            </div>
          </div>
        </motion.div>

        {/* Brand Name */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            CodyVerse
          </h1>
          <p className="text-muted-foreground mt-2">
            Sua jornada de aprendizado está começando...
          </p>
        </motion.div>

        {/* Loading Animation */}
        <motion.div
          className="flex justify-center space-x-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.4 }}
        >
          {[0, 1, 2].map((index) => (
            <motion.div
              key={index}
              className="w-3 h-3 bg-primary rounded-full"
              animate={{
                y: [0, -10, 0],
                opacity: [0.5, 1, 0.5]
              }}
              transition={{
                duration: 0.8,
                repeat: Infinity,
                delay: index * 0.2,
                ease: "easeInOut"
              }}
            />
          ))}
        </motion.div>

        {/* Progress Bar */}
        <motion.div
          className="w-64 mx-auto"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8, duration: 0.4 }}
        >
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-primary to-secondary"
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ 
                delay: 1,
                duration: 1.5,
                ease: "easeInOut"
              }}
            />
          </div>
        </motion.div>

        {/* Loading Tips */}
        <motion.div
          className="max-w-sm mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.4 }}
        >
          <LoadingTips />
        </motion.div>
      </div>
    </div>
  )
}

const LoadingTips = () => {
  const tips = [
    "💡 Dica: Use o modo foco para se concentrar melhor nos estudos",
    "🎯 Mantenha sua sequência diária para ganhar mais XP",
    "🏆 Complete desafios para desbloquear conquistas especiais",
    "🤖 Converse com o Cody para tirar suas dúvidas",
    "📚 Explore diferentes cursos para ampliar seus conhecimentos"
  ]

  const [currentTip, setCurrentTip] = React.useState(0)

  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % tips.length)
    }, 2000)

    return () => clearInterval(interval)
  }, [tips.length])

  return (
    <motion.div
      key={currentTip}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4 }}
      className="text-sm text-muted-foreground"
    >
      {tips[currentTip]}
    </motion.div>
  )
}

