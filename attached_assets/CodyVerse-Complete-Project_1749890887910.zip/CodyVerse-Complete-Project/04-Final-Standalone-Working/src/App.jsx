import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar.jsx'
import { 
  BookOpen, 
  Zap, 
  Trophy, 
  User, 
  Mail, 
  Lock, 
  LogIn, 
  UserPlus,
  Star,
  Target,
  Award,
  MessageCircle,
  TrendingUp,
  Play,
  CheckCircle,
  Clock,
  Users,
  Brain,
  Code,
  Rocket,
  Settings,
  LogOut,
  Home,
  GraduationCap,
  BarChart3,
  Crown,
  Coins,
  Flame,
  Calendar,
  Send
} from 'lucide-react'
import './App.css'

// Dados mockados para demonstração
const MOCK_COURSES = [
  {
    id: 1,
    title: "Python para Iniciantes",
    description: "Aprenda os fundamentos da programação Python",
    icon: "🐍",
    difficulty: "Iniciante",
    duration: "4 semanas",
    lessons: 12,
    progress: 75,
    students: 1250,
    rating: 4.8
  },
  {
    id: 2,
    title: "JavaScript Moderno",
    description: "Domine JavaScript ES6+ e desenvolvimento web",
    icon: "⚡",
    difficulty: "Intermediário",
    duration: "6 semanas",
    lessons: 18,
    progress: 45,
    students: 980,
    rating: 4.9
  },
  {
    id: 3,
    title: "React Development",
    description: "Construa aplicações web modernas com React",
    icon: "⚛️",
    difficulty: "Intermediário",
    duration: "8 semanas",
    lessons: 24,
    progress: 20,
    students: 750,
    rating: 4.7
  },
  {
    id: 4,
    title: "Machine Learning",
    description: "Introdução ao aprendizado de máquina com Python",
    icon: "🤖",
    difficulty: "Avançado",
    duration: "10 semanas",
    lessons: 30,
    progress: 0,
    students: 420,
    rating: 4.9
  }
]

const MOCK_ACHIEVEMENTS = [
  { id: 1, title: "Primeiro Login", description: "Bem-vindo ao CodyVerse!", icon: "🎉", unlocked: true },
  { id: 2, title: "Primeira Lição", description: "Complete sua primeira lição", icon: "📚", unlocked: true },
  { id: 3, title: "Sequência de 7 dias", description: "Estude por 7 dias consecutivos", icon: "🔥", unlocked: true },
  { id: 4, title: "Mestre Python", description: "Complete o curso de Python", icon: "🐍", unlocked: false },
  { id: 5, title: "Colecionador", description: "Ganhe 10 conquistas", icon: "🏆", unlocked: false },
  { id: 6, title: "Mentor", description: "Ajude 5 outros estudantes", icon: "👨‍🏫", unlocked: false }
]

const MOCK_LEADERBOARD = [
  { id: 1, name: "Ana Silva", xp: 15420, level: 12, avatar: "AS" },
  { id: 2, name: "Carlos Santos", xp: 14890, level: 11, avatar: "CS" },
  { id: 3, name: "Maria Oliveira", xp: 13650, level: 11, avatar: "MO" },
  { id: 4, name: "João Pedro", xp: 12340, level: 10, avatar: "JP" },
  { id: 5, name: "Você", xp: 8750, level: 8, avatar: "VC" }
]

function App() {
  const [currentUser, setCurrentUser] = useState(null)
  const [currentPage, setCurrentPage] = useState('dashboard')
  const [chatMessages, setChatMessages] = useState([
    { id: 1, sender: 'Cody', message: 'Olá! Eu sou o Cody, seu assistente de IA. Como posso ajudar você hoje?', timestamp: new Date() }
  ])
  const [newMessage, setNewMessage] = useState('')

  // Simular login automático para demonstração
  useEffect(() => {
    setTimeout(() => {
      setCurrentUser({
        id: 1,
        name: "Estudante Demo",
        email: "demo@codyverse.com",
        level: 8,
        xp: 8750,
        coins: 1250,
        streak: 12,
        coursesCompleted: 2,
        lessonsCompleted: 45,
        avatar: "ED"
      })
    }, 2000)
  }, [])

  const handleSendMessage = () => {
    if (!newMessage.trim()) return
    
    const userMessage = {
      id: chatMessages.length + 1,
      sender: 'Você',
      message: newMessage,
      timestamp: new Date()
    }
    
    setChatMessages(prev => [...prev, userMessage])
    setNewMessage('')
    
    // Simular resposta do Cody
    setTimeout(() => {
      const responses = [
        "Ótima pergunta! Vou te ajudar com isso.",
        "Entendi! Aqui está uma explicação detalhada...",
        "Isso é muito interessante! Vamos explorar esse conceito.",
        "Perfeito! Você está no caminho certo.",
        "Excelente! Continue assim que você vai longe."
      ]
      
      const codyResponse = {
        id: chatMessages.length + 2,
        sender: 'Cody',
        message: responses[Math.floor(Math.random() * responses.length)],
        timestamp: new Date()
      }
      
      setChatMessages(prev => [...prev, codyResponse])
    }, 1000)
  }

  // Tela de loading
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
            <Zap className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">CodyVerse</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">Carregando sua jornada de aprendizado...</p>
          <div className="w-64 h-2 bg-gray-200 dark:bg-gray-700 rounded-full mx-auto">
            <div className="h-2 bg-indigo-600 rounded-full animate-pulse" style={{width: '70%'}}></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center mr-3">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">CodyVerse</h1>
            </div>
            
            {/* Navigation */}
            <nav className="hidden md:flex space-x-8">
              <button 
                onClick={() => setCurrentPage('dashboard')}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                  currentPage === 'dashboard' 
                    ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300' 
                    : 'text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white'
                }`}
              >
                <Home className="w-4 h-4 mr-2" />
                Dashboard
              </button>
              <button 
                onClick={() => setCurrentPage('courses')}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                  currentPage === 'courses' 
                    ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300' 
                    : 'text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white'
                }`}
              >
                <BookOpen className="w-4 h-4 mr-2" />
                Cursos
              </button>
              <button 
                onClick={() => setCurrentPage('progress')}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                  currentPage === 'progress' 
                    ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300' 
                    : 'text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white'
                }`}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Progresso
              </button>
              <button 
                onClick={() => setCurrentPage('leaderboard')}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                  currentPage === 'leaderboard' 
                    ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300' 
                    : 'text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white'
                }`}
              >
                <Trophy className="w-4 h-4 mr-2" />
                Ranking
              </button>
            </nav>

            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className="flex items-center">
                <Crown className="w-4 h-4 mr-1 text-yellow-600" />
                Nível {currentUser.level}
              </Badge>
              <Badge variant="outline" className="flex items-center">
                <Coins className="w-4 h-4 mr-1 text-yellow-600" />
                {currentUser.coins}
              </Badge>
              <Badge variant="outline" className="flex items-center">
                <Flame className="w-4 h-4 mr-1 text-orange-600" />
                {currentUser.streak} dias
              </Badge>
              <Avatar className="w-8 h-8">
                <AvatarFallback>{currentUser.avatar}</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard */}
        {currentPage === 'dashboard' && (
          <div className="space-y-8">
            {/* Welcome Section */}
            <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg p-6 text-white">
              <h2 className="text-2xl font-bold mb-2">Bem-vindo de volta, {currentUser.name}! 👋</h2>
              <p className="text-indigo-100">Continue sua jornada de aprendizado. Você está indo muito bem!</p>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Target className="w-8 h-8 text-indigo-600 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">XP Total</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">{currentUser.xp.toLocaleString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Coins className="w-8 h-8 text-yellow-600 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Moedas</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">{currentUser.coins}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Flame className="w-8 h-8 text-orange-600 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Sequência</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">{currentUser.streak} dias</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <GraduationCap className="w-8 h-8 text-green-600 mr-3" />
                    <div>
                      <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Lições</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">{currentUser.lessonsCompleted}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Continue Learning & Chat */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Continue Aprendendo</CardTitle>
                    <CardDescription>Seus cursos em andamento</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {MOCK_COURSES.filter(course => course.progress > 0).map(course => (
                      <div key={course.id} className="flex items-center space-x-4 p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                        <div className="text-2xl">{course.icon}</div>
                        <div className="flex-1">
                          <h3 className="font-semibold">{course.title}</h3>
                          <div className="flex items-center space-x-2 mt-1">
                            <Progress value={course.progress} className="flex-1" />
                            <span className="text-sm text-gray-600 dark:text-gray-400">{course.progress}%</span>
                          </div>
                        </div>
                        <Button size="sm">
                          <Play className="w-4 h-4 mr-1" />
                          Continuar
                        </Button>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Conquistas Recentes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {MOCK_ACHIEVEMENTS.filter(achievement => achievement.unlocked).map(achievement => (
                        <div key={achievement.id} className="text-center p-4 border rounded-lg">
                          <div className="text-2xl mb-2">{achievement.icon}</div>
                          <h4 className="font-semibold text-sm">{achievement.title}</h4>
                          <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">{achievement.description}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Chat with Cody */}
              <div className="space-y-6">
                <Card className="h-96">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Brain className="w-5 h-5 mr-2 text-indigo-600" />
                      Chat com Cody
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex flex-col h-full">
                    <div className="flex-1 overflow-y-auto space-y-3 mb-4">
                      {chatMessages.map(message => (
                        <div key={message.id} className={`flex ${message.sender === 'Você' ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                            message.sender === 'Você' 
                              ? 'bg-indigo-600 text-white' 
                              : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white'
                          }`}>
                            <p className="font-semibold text-xs mb-1">{message.sender}</p>
                            <p>{message.message}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Digite sua mensagem..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        className="flex-1"
                      />
                      <Button onClick={handleSendMessage} size="sm">
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Progresso do Nível</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Nível {currentUser.level}</span>
                        <span>{currentUser.xp} / {(currentUser.level + 1) * 1000} XP</span>
                      </div>
                      <Progress value={(currentUser.xp % 1000) / 10} />
                      <p className="text-xs text-gray-600 dark:text-gray-400">
                        {(currentUser.level + 1) * 1000 - currentUser.xp} XP para o próximo nível
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        )}

        {/* Courses Page */}
        {currentPage === 'courses' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Cursos Disponíveis</h2>
              <p className="text-gray-600 dark:text-gray-400">Escolha um curso e comece sua jornada de aprendizado</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {MOCK_COURSES.map(course => (
                <Card key={course.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="text-3xl">{course.icon}</div>
                      <Badge variant={
                        course.difficulty === 'Iniciante' ? 'secondary' :
                        course.difficulty === 'Intermediário' ? 'default' : 'destructive'
                      }>
                        {course.difficulty}
                      </Badge>
                    </div>
                    <CardTitle className="text-lg">{course.title}</CardTitle>
                    <CardDescription>{course.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {course.duration}
                      </span>
                      <span className="flex items-center">
                        <BookOpen className="w-4 h-4 mr-1" />
                        {course.lessons} lições
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                      <span className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {course.students} estudantes
                      </span>
                      <span className="flex items-center">
                        <Star className="w-4 h-4 mr-1 text-yellow-500" />
                        {course.rating}
                      </span>
                    </div>

                    {course.progress > 0 && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progresso</span>
                          <span>{course.progress}%</span>
                        </div>
                        <Progress value={course.progress} />
                      </div>
                    )}

                    <Button className="w-full">
                      {course.progress > 0 ? (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Continuar
                        </>
                      ) : (
                        <>
                          <Rocket className="w-4 h-4 mr-2" />
                          Começar
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Progress Page */}
        {currentPage === 'progress' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Seu Progresso</h2>
              <p className="text-gray-600 dark:text-gray-400">Acompanhe sua evolução e conquistas</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Estatísticas Gerais</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{currentUser.coursesCompleted}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Cursos Completos</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{currentUser.lessonsCompleted}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Lições Completas</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">{currentUser.xp.toLocaleString()}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">XP Total</div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">{currentUser.streak}</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Dias Consecutivos</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Conquistas</CardTitle>
                  <CardDescription>
                    {MOCK_ACHIEVEMENTS.filter(a => a.unlocked).length} de {MOCK_ACHIEVEMENTS.length} desbloqueadas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    {MOCK_ACHIEVEMENTS.map(achievement => (
                      <div 
                        key={achievement.id} 
                        className={`p-3 border rounded-lg text-center ${
                          achievement.unlocked 
                            ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                            : 'bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 opacity-60'
                        }`}
                      >
                        <div className="text-xl mb-1">{achievement.icon}</div>
                        <h4 className="font-semibold text-xs">{achievement.title}</h4>
                        <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">{achievement.description}</p>
                        {achievement.unlocked && (
                          <CheckCircle className="w-4 h-4 text-green-600 mx-auto mt-2" />
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Progresso por Curso</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {MOCK_COURSES.map(course => (
                    <div key={course.id} className="flex items-center space-x-4">
                      <div className="text-2xl">{course.icon}</div>
                      <div className="flex-1">
                        <div className="flex justify-between items-center mb-1">
                          <h3 className="font-semibold">{course.title}</h3>
                          <span className="text-sm text-gray-600 dark:text-gray-400">{course.progress}%</span>
                        </div>
                        <Progress value={course.progress} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Leaderboard Page */}
        {currentPage === 'leaderboard' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Ranking Global</h2>
              <p className="text-gray-600 dark:text-gray-400">Veja como você se compara com outros estudantes</p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="w-5 h-5 mr-2 text-yellow-600" />
                  Top Estudantes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {MOCK_LEADERBOARD.map((user, index) => (
                    <div 
                      key={user.id} 
                      className={`flex items-center space-x-4 p-4 rounded-lg ${
                        user.name === 'Você' 
                          ? 'bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-200 dark:border-indigo-800' 
                          : 'bg-gray-50 dark:bg-gray-800'
                      }`}
                    >
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 font-bold">
                        {index + 1}
                      </div>
                      <Avatar>
                        <AvatarFallback>{user.avatar}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="font-semibold">{user.name}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Nível {user.level}</p>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">{user.xp.toLocaleString()} XP</div>
                        {index < 3 && (
                          <div className="text-xs text-yellow-600">
                            {index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉'}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}

export default App

