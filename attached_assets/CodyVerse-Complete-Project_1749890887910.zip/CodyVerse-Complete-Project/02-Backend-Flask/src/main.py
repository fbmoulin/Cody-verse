import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from src.models.user import db
from src.routes.user import user_bp
from src.routes.auth import auth_bp
from src.routes.courses import courses_bp

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))

# Configuration
app.config['SECRET_KEY'] = 'codyverse-secret-key-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Enable CORS for all routes
CORS(app, origins="*")

# Register blueprints
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(courses_bp, url_prefix='/api')

# Try to import AI routes, but don't fail if dependencies are missing
try:
    from src.routes.ai import ai_bp
    app.register_blueprint(ai_bp, url_prefix='/api/ai')
    AI_AVAILABLE = True
except ImportError as e:
    print(f"AI features disabled due to missing dependencies: {e}")
    AI_AVAILABLE = False

# Initialize database
db.init_app(app)

def create_sample_data():
    """Create sample data for development"""
    from src.models.user import Course, Lesson, Achievement
    
    # Check if data already exists
    if Course.query.first():
        return
    
    # Create sample courses
    courses_data = [
        {
            'title': 'Introdução ao Python',
            'description': 'Aprenda os fundamentos da programação com Python, uma das linguagens mais populares do mundo.',
            'short_description': 'Aprenda os fundamentos da programação com Python',
            'difficulty': 'beginner',
            'category': 'programming',
            'estimated_duration': 240,
            'color': '#3776ab',
            'icon': '🐍',
            'is_published': True,
            'is_featured': True
        },
        {
            'title': 'JavaScript Essencial',
            'description': 'Domine JavaScript para desenvolvimento web moderno e interativo.',
            'short_description': 'Domine JavaScript para desenvolvimento web',
            'difficulty': 'beginner',
            'category': 'web',
            'estimated_duration': 300,
            'color': '#f7df1e',
            'icon': '⚡',
            'is_published': True,
            'is_featured': True
        },
        {
            'title': 'React Fundamentals',
            'description': 'Construa interfaces modernas e reativas com React.',
            'short_description': 'Construa interfaces modernas com React',
            'difficulty': 'intermediate',
            'category': 'web',
            'estimated_duration': 480,
            'color': '#61dafb',
            'icon': '⚛️',
            'is_published': True,
            'is_featured': False
        },
        {
            'title': 'Machine Learning Básico',
            'description': 'Introdução aos conceitos de IA e ML.',
            'short_description': 'Introdução aos conceitos de IA e ML',
            'difficulty': 'advanced',
            'category': 'ai',
            'estimated_duration': 600,
            'color': '#ff6b6b',
            'icon': '🤖',
            'is_published': True,
            'is_featured': False
        }
    ]
    
    courses = []
    for course_data in courses_data:
        course = Course(**course_data)
        db.session.add(course)
        courses.append(course)
    
    db.session.flush()  # Get IDs
    
    # Create sample lessons for Python course
    python_lessons = [
        {
            'course_id': courses[0].id,
            'title': 'O que é Python?',
            'description': 'Introdução à linguagem Python e suas aplicações.',
            'content': 'Python é uma linguagem de programação de alto nível...',
            'order': 1,
            'duration': 15,
            'xp_reward': 50,
            'coins_reward': 10,
            'lesson_type': 'text',
            'is_published': True
        },
        {
            'course_id': courses[0].id,
            'title': 'Instalando Python',
            'description': 'Como instalar Python no seu computador.',
            'content': 'Vamos aprender a instalar Python...',
            'order': 2,
            'duration': 20,
            'xp_reward': 75,
            'coins_reward': 15,
            'lesson_type': 'text',
            'is_published': True
        },
        {
            'course_id': courses[0].id,
            'title': 'Variáveis e Tipos de Dados',
            'description': 'Aprenda sobre variáveis e tipos de dados em Python.',
            'content': 'Em Python, uma variável é um nome que se refere a um valor...',
            'order': 3,
            'duration': 30,
            'xp_reward': 100,
            'coins_reward': 20,
            'lesson_type': 'interactive',
            'is_published': True
        }
    ]
    
    # Create sample lessons for JavaScript course
    js_lessons = [
        {
            'course_id': courses[1].id,
            'title': 'Introdução ao JavaScript',
            'description': 'O que é JavaScript e onde é usado.',
            'content': 'JavaScript é a linguagem da web...',
            'order': 1,
            'duration': 20,
            'xp_reward': 50,
            'coins_reward': 10,
            'lesson_type': 'text',
            'is_published': True
        },
        {
            'course_id': courses[1].id,
            'title': 'Variáveis em JavaScript',
            'description': 'Como declarar e usar variáveis.',
            'content': 'Em JavaScript, você pode declarar variáveis com var, let ou const...',
            'order': 2,
            'duration': 25,
            'xp_reward': 75,
            'coins_reward': 15,
            'lesson_type': 'interactive',
            'is_published': True
        }
    ]
    
    all_lessons = python_lessons + js_lessons
    for lesson_data in all_lessons:
        lesson = Lesson(**lesson_data)
        db.session.add(lesson)
    
    # Create sample achievements
    achievements_data = [
        {
            'name': 'First Steps',
            'description': 'Complete sua primeira lição',
            'icon': '🎯',
            'category': 'learning',
            'rarity': 'common',
            'xp_reward': 100,
            'coins_reward': 50,
            'conditions': '{"lessons_completed": 1}',
            'is_active': True
        },
        {
            'name': 'Week Warrior',
            'description': 'Estude por 7 dias consecutivos',
            'icon': '🔥',
            'category': 'streak',
            'rarity': 'rare',
            'xp_reward': 500,
            'coins_reward': 200,
            'conditions': '{"streak_days": 7}',
            'is_active': True
        },
        {
            'name': 'Knowledge Seeker',
            'description': 'Complete 10 lições',
            'icon': '📚',
            'category': 'learning',
            'rarity': 'common',
            'xp_reward': 300,
            'coins_reward': 100,
            'conditions': '{"lessons_completed": 10}',
            'is_active': True
        },
        {
            'name': 'Python Master',
            'description': 'Complete o curso de Python',
            'icon': '🐍',
            'category': 'course',
            'rarity': 'epic',
            'xp_reward': 1000,
            'coins_reward': 500,
            'conditions': '{"course_completed": "Introdução ao Python"}',
            'is_active': True
        }
    ]
    
    for achievement_data in achievements_data:
        achievement = Achievement(**achievement_data)
        db.session.add(achievement)
    
    db.session.commit()
    print("Sample data created successfully!")

with app.app_context():
    db.create_all()
    create_sample_data()

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

@app.route('/api/health', methods=['GET'])
def health_check():
    return {
        'status': 'healthy',
        'service': 'CodyVerse Backend',
        'version': '1.0.0',
        'ai_available': AI_AVAILABLE
    }

# Simple AI fallback routes if AI is not available
if not AI_AVAILABLE:
    from flask import Blueprint, request, jsonify
    from src.routes.auth import token_required
    
    ai_fallback_bp = Blueprint('ai_fallback', __name__)
    
    @ai_fallback_bp.route('/chat', methods=['POST'])
    @token_required
    def chat_fallback(current_user):
        data = request.get_json()
        message = data.get('message', '')
        
        # Simple fallback responses
        responses = [
            f"Olá {current_user.username}! Estou aqui para ajudar com programação!",
            "Que pergunta interessante! Continue praticando e você vai longe!",
            "Programação é sobre resolver problemas. Que tal tentarmos juntos?",
            "Excelente pergunta! Lembre-se: a prática leva à perfeição!",
            "Estou aqui para apoiar sua jornada de aprendizado!"
        ]
        
        import random
        response = random.choice(responses)
        
        return jsonify({
            'message': 'Chat response generated',
            'response': response,
            'fallback': True
        }), 200
    
    @ai_fallback_bp.route('/recommendations', methods=['GET'])
    @token_required
    def recommendations_fallback(current_user):
        recommendations = [
            {
                "title": "Introdução ao Python",
                "reason": "Python é uma linguagem amigável para iniciantes",
                "difficulty": "beginner",
                "category": "programming"
            },
            {
                "title": "JavaScript Essencial",
                "reason": "Domine a linguagem da web",
                "difficulty": "beginner",
                "category": "web"
            }
        ]
        
        return jsonify({'recommendations': recommendations}), 200
    
    @ai_fallback_bp.route('/status', methods=['GET'])
    def ai_status_fallback():
        return jsonify({
            'ai_available': False,
            'service': 'Fallback responses',
            'features': {
                'chat': True,
                'recommendations': True,
                'code_analysis': False,
                'exercise_generation': False
            }
        }), 200
    
    app.register_blueprint(ai_fallback_bp, url_prefix='/api/ai')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

