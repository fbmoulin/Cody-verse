import os
from openai import OpenAI
from typing import List, Dict, Optional
import json

class CodyAIService:
    def __init__(self, api_key: Optional[str] = None):
        # Use environment variable or provided key
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        if self.api_key:
            self.client = OpenAI(api_key=self.api_key)
        else:
            self.client = None
    
    def is_available(self) -> bool:
        """Check if AI service is available"""
        return self.client is not None
    
    def get_cody_personality(self) -> str:
        """Get Cody's personality prompt"""
        return """
        Você é Cody, um assistente de IA especializado em ensino de programação e tecnologia. 
        Sua personalidade é:
        - Amigável e encorajador
        - Paciente e didático
        - Entusiasmado com tecnologia
        - Adaptável à idade do usuário (criança, adolescente, adulto)
        - Usa exemplos práticos e analogias
        - Celebra conquistas e progresso
        - Oferece dicas e truques úteis
        
        Sempre responda em português brasileiro, seja claro e conciso, e mantenha um tom positivo.
        Se o usuário fizer perguntas fora do escopo de programação/tecnologia, redirecione gentilmente para tópicos educacionais.
        """
    
    async def chat_with_cody(self, message: str, user_context: Dict = None) -> Dict:
        """
        Chat with Cody AI assistant
        """
        if not self.is_available():
            return {
                'response': 'Desculpe, o Cody está temporariamente indisponível. Tente novamente mais tarde!',
                'fallback': True
            }
        
        try:
            # Build context
            context = self.get_cody_personality()
            
            if user_context:
                context += f"\n\nContexto do usuário:\n"
                context += f"- Nível: {user_context.get('level', 1)}\n"
                context += f"- XP: {user_context.get('xp', 0)}\n"
                context += f"- Faixa etária: {user_context.get('age_group', 'adult')}\n"
                context += f"- Idioma: {user_context.get('language', 'pt-BR')}\n"
                
                if user_context.get('current_course'):
                    context += f"- Curso atual: {user_context['current_course']}\n"
                
                if user_context.get('recent_activities'):
                    context += f"- Atividades recentes: {user_context['recent_activities']}\n"
            
            # Make API call
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": context},
                    {"role": "user", "content": message}
                ],
                max_tokens=500,
                temperature=0.7
            )
            
            return {
                'response': response.choices[0].message.content.strip(),
                'model': 'gpt-3.5-turbo',
                'fallback': False
            }
            
        except Exception as e:
            # Fallback responses
            fallback_responses = [
                "Opa! Parece que estou com um pequeno problema técnico. Que tal tentarmos novamente?",
                "Hmm, algo deu errado aqui. Mas não desista! A programação é sobre resolver problemas, assim como este!",
                "Oops! Estou passando por uma pequena manutenção. Volte em alguns minutos e continuamos nossa conversa!",
                "Parece que minha conexão está instável. Mas lembre-se: todo programador enfrenta bugs - é parte do aprendizado!"
            ]
            
            import random
            return {
                'response': random.choice(fallback_responses),
                'error': str(e),
                'fallback': True
            }
    
    async def get_course_recommendations(self, user_context: Dict) -> List[Dict]:
        """
        Get personalized course recommendations
        """
        if not self.is_available():
            return self._get_fallback_recommendations(user_context)
        
        try:
            # Build prompt for recommendations
            prompt = f"""
            Com base no perfil do usuário, sugira 3 cursos de programação mais adequados:
            
            Perfil do usuário:
            - Nível: {user_context.get('level', 1)}
            - XP: {user_context.get('xp', 0)}
            - Faixa etária: {user_context.get('age_group', 'adult')}
            - Cursos concluídos: {user_context.get('completed_courses', [])}
            - Interesses: {user_context.get('interests', [])}
            
            Responda em formato JSON com esta estrutura:
            {{
                "recommendations": [
                    {{
                        "title": "Nome do Curso",
                        "reason": "Por que é recomendado",
                        "difficulty": "beginner|intermediate|advanced",
                        "category": "categoria"
                    }}
                ]
            }}
            """
            
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "Você é um especialista em educação de programação. Responda apenas em JSON válido."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=400,
                temperature=0.5
            )
            
            # Parse JSON response
            recommendations_data = json.loads(response.choices[0].message.content.strip())
            return recommendations_data.get('recommendations', [])
            
        except Exception as e:
            return self._get_fallback_recommendations(user_context)
    
    def _get_fallback_recommendations(self, user_context: Dict) -> List[Dict]:
        """Fallback recommendations when AI is not available"""
        level = user_context.get('level', 1)
        age_group = user_context.get('age_group', 'adult')
        
        if level <= 3:
            return [
                {
                    "title": "Introdução ao Python",
                    "reason": "Python é uma linguagem amigável para iniciantes",
                    "difficulty": "beginner",
                    "category": "programming"
                },
                {
                    "title": "Lógica de Programação",
                    "reason": "Base fundamental para qualquer linguagem",
                    "difficulty": "beginner", 
                    "category": "fundamentals"
                },
                {
                    "title": "HTML e CSS Básico",
                    "reason": "Crie suas primeiras páginas web",
                    "difficulty": "beginner",
                    "category": "web"
                }
            ]
        elif level <= 10:
            return [
                {
                    "title": "JavaScript Essencial",
                    "reason": "Domine a linguagem da web",
                    "difficulty": "intermediate",
                    "category": "web"
                },
                {
                    "title": "Python Avançado",
                    "reason": "Aprofunde seus conhecimentos em Python",
                    "difficulty": "intermediate",
                    "category": "programming"
                },
                {
                    "title": "Banco de Dados SQL",
                    "reason": "Aprenda a gerenciar dados",
                    "difficulty": "intermediate",
                    "category": "database"
                }
            ]
        else:
            return [
                {
                    "title": "React Fundamentals",
                    "reason": "Construa interfaces modernas",
                    "difficulty": "advanced",
                    "category": "web"
                },
                {
                    "title": "Machine Learning Básico",
                    "reason": "Entre no mundo da IA",
                    "difficulty": "advanced",
                    "category": "ai"
                },
                {
                    "title": "DevOps e Deploy",
                    "reason": "Coloque seus projetos no ar",
                    "difficulty": "advanced",
                    "category": "devops"
                }
            ]
    
    async def analyze_code(self, code: str, language: str = "python") -> Dict:
        """
        Analyze code and provide feedback
        """
        if not self.is_available():
            return {
                'feedback': 'Análise de código temporariamente indisponível.',
                'suggestions': [],
                'fallback': True
            }
        
        try:
            prompt = f"""
            Analise este código {language} e forneça feedback construtivo:
            
            ```{language}
            {code}
            ```
            
            Forneça:
            1. Feedback geral sobre o código
            2. Sugestões de melhoria
            3. Possíveis bugs ou problemas
            4. Boas práticas que podem ser aplicadas
            
            Responda em português brasileiro de forma didática e encorajadora.
            """
            
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "Você é um mentor de programação experiente e didático."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=600,
                temperature=0.3
            )
            
            return {
                'feedback': response.choices[0].message.content.strip(),
                'language': language,
                'fallback': False
            }
            
        except Exception as e:
            return {
                'feedback': 'Não consegui analisar o código no momento, mas continue praticando!',
                'error': str(e),
                'fallback': True
            }
    
    async def generate_exercise(self, topic: str, difficulty: str = "beginner") -> Dict:
        """
        Generate a coding exercise
        """
        if not self.is_available():
            return self._get_fallback_exercise(topic, difficulty)
        
        try:
            prompt = f"""
            Crie um exercício de programação sobre "{topic}" com dificuldade "{difficulty}".
            
            Inclua:
            1. Título do exercício
            2. Descrição clara do problema
            3. Exemplo de entrada e saída
            4. Dicas para resolução
            
            Responda em formato JSON:
            {{
                "title": "Título",
                "description": "Descrição do problema",
                "example_input": "Exemplo de entrada",
                "example_output": "Exemplo de saída",
                "hints": ["dica1", "dica2"]
            }}
            """
            
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "Você é um criador de exercícios de programação. Responda apenas em JSON válido."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                temperature=0.7
            )
            
            exercise_data = json.loads(response.choices[0].message.content.strip())
            exercise_data['fallback'] = False
            return exercise_data
            
        except Exception as e:
            return self._get_fallback_exercise(topic, difficulty)
    
    def _get_fallback_exercise(self, topic: str, difficulty: str) -> Dict:
        """Fallback exercise when AI is not available"""
        exercises = {
            "python": {
                "beginner": {
                    "title": "Calculadora Simples",
                    "description": "Crie uma função que receba dois números e uma operação (+, -, *, /) e retorne o resultado.",
                    "example_input": "calculadora(10, 5, '+')",
                    "example_output": "15",
                    "hints": ["Use if/elif para verificar a operação", "Não esqueça de tratar a divisão por zero"]
                }
            }
        }
        
        default_exercise = {
            "title": "Exercício de Prática",
            "description": f"Pratique conceitos de {topic} com dificuldade {difficulty}",
            "example_input": "Varie conforme o exercício",
            "example_output": "Resultado esperado",
            "hints": ["Leia o problema com atenção", "Teste com exemplos simples primeiro"],
            "fallback": True
        }
        
        return exercises.get(topic, {}).get(difficulty, default_exercise)

# Global AI service instance
ai_service = CodyAIService()

