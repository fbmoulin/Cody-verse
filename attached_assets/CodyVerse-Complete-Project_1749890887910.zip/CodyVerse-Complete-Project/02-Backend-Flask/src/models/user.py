from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
from datetime import datetime, timedelta

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    
    # Profile information
    first_name = db.Column(db.String(50), nullable=True)
    last_name = db.Column(db.String(50), nullable=True)
    avatar_url = db.Column(db.String(255), nullable=True)
    bio = db.Column(db.Text, nullable=True)
    
    # Gamification
    level = db.Column(db.Integer, default=1)
    xp = db.Column(db.Integer, default=0)
    coins = db.Column(db.Integer, default=0)
    gems = db.Column(db.Integer, default=0)
    current_streak = db.Column(db.Integer, default=0)
    longest_streak = db.Column(db.Integer, default=0)
    
    # Preferences
    language = db.Column(db.String(10), default='pt-BR')
    theme = db.Column(db.String(10), default='light')
    age_group = db.Column(db.String(10), default='adult')
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_active = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    enrollments = db.relationship('Enrollment', backref='user', lazy=True, cascade='all, delete-orphan')
    achievements = db.relationship('UserAchievement', backref='user', lazy=True, cascade='all, delete-orphan')
    activities = db.relationship('Activity', backref='user', lazy=True, cascade='all, delete-orphan')
    chat_messages = db.relationship('ChatMessage', backref='user', lazy=True, cascade='all, delete-orphan')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def generate_token(self, secret_key, expires_in=3600):
        payload = {
            'user_id': self.id,
            'exp': datetime.utcnow() + timedelta(seconds=expires_in)
        }
        return jwt.encode(payload, secret_key, algorithm='HS256')

    @staticmethod
    def verify_token(token, secret_key):
        try:
            payload = jwt.decode(token, secret_key, algorithms=['HS256'])
            return payload['user_id']
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None

    def add_xp(self, amount):
        self.xp += amount
        # Calculate level based on XP (simple formula: level = sqrt(xp/100))
        new_level = int((self.xp / 100) ** 0.5) + 1
        if new_level > self.level:
            self.level = new_level
            return True  # Level up occurred
        return False

    def get_xp_for_next_level(self):
        next_level = self.level + 1
        return (next_level - 1) ** 2 * 100

    def get_progress_to_next_level(self):
        current_level_xp = (self.level - 1) ** 2 * 100
        next_level_xp = self.get_xp_for_next_level()
        progress = ((self.xp - current_level_xp) / (next_level_xp - current_level_xp)) * 100
        return min(100, max(0, progress))

    def update_streak(self):
        # Check if user was active yesterday
        yesterday = datetime.utcnow().date() - timedelta(days=1)
        if self.last_active and self.last_active.date() == yesterday:
            self.current_streak += 1
            if self.current_streak > self.longest_streak:
                self.longest_streak = self.current_streak
        elif self.last_active and self.last_active.date() < yesterday:
            self.current_streak = 1
        else:
            self.current_streak = 1
        
        self.last_active = datetime.utcnow()

    def __repr__(self):
        return f'<User {self.username}>'

    def to_dict(self, include_sensitive=False):
        data = {
            'id': self.id,
            'username': self.username,
            'email': self.email if include_sensitive else None,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'avatar_url': self.avatar_url,
            'bio': self.bio,
            'level': self.level,
            'xp': self.xp,
            'coins': self.coins,
            'gems': self.gems,
            'current_streak': self.current_streak,
            'longest_streak': self.longest_streak,
            'language': self.language,
            'theme': self.theme,
            'age_group': self.age_group,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_active': self.last_active.isoformat() if self.last_active else None,
            'xp_to_next_level': self.get_xp_for_next_level(),
            'progress_to_next_level': self.get_progress_to_next_level()
        }
        return {k: v for k, v in data.items() if v is not None}


class Course(db.Model):
    __tablename__ = 'courses'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    short_description = db.Column(db.String(500), nullable=True)
    
    # Course metadata
    difficulty = db.Column(db.String(20), default='beginner')  # beginner, intermediate, advanced
    category = db.Column(db.String(50), nullable=True)
    language = db.Column(db.String(10), default='pt-BR')
    estimated_duration = db.Column(db.Integer, nullable=True)  # in minutes
    
    # Visual
    image_url = db.Column(db.String(255), nullable=True)
    color = db.Column(db.String(7), default='#4F46E5')  # hex color
    icon = db.Column(db.String(10), nullable=True)  # emoji or icon name
    
    # Status
    is_published = db.Column(db.Boolean, default=False)
    is_featured = db.Column(db.Boolean, default=False)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    lessons = db.relationship('Lesson', backref='course', lazy=True, cascade='all, delete-orphan')
    enrollments = db.relationship('Enrollment', backref='course', lazy=True, cascade='all, delete-orphan')

    def get_lesson_count(self):
        return len(self.lessons)

    def get_enrollment_count(self):
        return len(self.enrollments)

    def __repr__(self):
        return f'<Course {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'short_description': self.short_description,
            'difficulty': self.difficulty,
            'category': self.category,
            'language': self.language,
            'estimated_duration': self.estimated_duration,
            'image_url': self.image_url,
            'color': self.color,
            'icon': self.icon,
            'is_published': self.is_published,
            'is_featured': self.is_featured,
            'lesson_count': self.get_lesson_count(),
            'enrollment_count': self.get_enrollment_count(),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class Lesson(db.Model):
    __tablename__ = 'lessons'
    
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    content = db.Column(db.Text, nullable=True)  # JSON or HTML content
    
    # Lesson metadata
    order = db.Column(db.Integer, nullable=False)
    duration = db.Column(db.Integer, nullable=True)  # in minutes
    xp_reward = db.Column(db.Integer, default=50)
    coins_reward = db.Column(db.Integer, default=10)
    
    # Content type
    lesson_type = db.Column(db.String(20), default='text')  # text, video, interactive, quiz
    video_url = db.Column(db.String(255), nullable=True)
    
    # Status
    is_published = db.Column(db.Boolean, default=False)
    is_free = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    completions = db.relationship('LessonCompletion', backref='lesson', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Lesson {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'course_id': self.course_id,
            'title': self.title,
            'description': self.description,
            'content': self.content,
            'order': self.order,
            'duration': self.duration,
            'xp_reward': self.xp_reward,
            'coins_reward': self.coins_reward,
            'lesson_type': self.lesson_type,
            'video_url': self.video_url,
            'is_published': self.is_published,
            'is_free': self.is_free,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class Enrollment(db.Model):
    __tablename__ = 'enrollments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('courses.id'), nullable=False)
    
    # Progress tracking
    progress_percentage = db.Column(db.Float, default=0.0)
    current_lesson_id = db.Column(db.Integer, db.ForeignKey('lessons.id'), nullable=True)
    
    # Timestamps
    enrolled_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_accessed = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    current_lesson = db.relationship('Lesson', foreign_keys=[current_lesson_id])
    lesson_completions = db.relationship('LessonCompletion', backref='enrollment', lazy=True, cascade='all, delete-orphan')

    def update_progress(self):
        total_lessons = len(self.course.lessons)
        completed_lessons = len([lc for lc in self.lesson_completions if lc.completed])
        
        if total_lessons > 0:
            self.progress_percentage = (completed_lessons / total_lessons) * 100
            if self.progress_percentage >= 100 and not self.completed_at:
                self.completed_at = datetime.utcnow()

    def __repr__(self):
        return f'<Enrollment User:{self.user_id} Course:{self.course_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'course_id': self.course_id,
            'progress_percentage': self.progress_percentage,
            'current_lesson_id': self.current_lesson_id,
            'enrolled_at': self.enrolled_at.isoformat() if self.enrolled_at else None,
            'last_accessed': self.last_accessed.isoformat() if self.last_accessed else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'course': self.course.to_dict() if self.course else None
        }


class LessonCompletion(db.Model):
    __tablename__ = 'lesson_completions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    lesson_id = db.Column(db.Integer, db.ForeignKey('lessons.id'), nullable=False)
    enrollment_id = db.Column(db.Integer, db.ForeignKey('enrollments.id'), nullable=False)
    
    # Completion data
    completed = db.Column(db.Boolean, default=False)
    score = db.Column(db.Float, nullable=True)  # for quizzes
    time_spent = db.Column(db.Integer, nullable=True)  # in seconds
    
    # Timestamps
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f'<LessonCompletion User:{self.user_id} Lesson:{self.lesson_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'lesson_id': self.lesson_id,
            'enrollment_id': self.enrollment_id,
            'completed': self.completed,
            'score': self.score,
            'time_spent': self.time_spent,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }


class Achievement(db.Model):
    __tablename__ = 'achievements'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    icon = db.Column(db.String(10), nullable=True)  # emoji
    
    # Achievement metadata
    category = db.Column(db.String(50), nullable=True)  # learning, streak, social, etc.
    rarity = db.Column(db.String(20), default='common')  # common, rare, epic, legendary
    xp_reward = db.Column(db.Integer, default=100)
    coins_reward = db.Column(db.Integer, default=50)
    
    # Unlock conditions (JSON)
    conditions = db.Column(db.Text, nullable=True)  # JSON string with conditions
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    user_achievements = db.relationship('UserAchievement', backref='achievement', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Achievement {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'icon': self.icon,
            'category': self.category,
            'rarity': self.rarity,
            'xp_reward': self.xp_reward,
            'coins_reward': self.coins_reward,
            'conditions': self.conditions,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class UserAchievement(db.Model):
    __tablename__ = 'user_achievements'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    achievement_id = db.Column(db.Integer, db.ForeignKey('achievements.id'), nullable=False)
    
    # Progress tracking
    progress = db.Column(db.Float, default=0.0)  # 0-100
    unlocked = db.Column(db.Boolean, default=False)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    unlocked_at = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f'<UserAchievement User:{self.user_id} Achievement:{self.achievement_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'achievement_id': self.achievement_id,
            'progress': self.progress,
            'unlocked': self.unlocked,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'unlocked_at': self.unlocked_at.isoformat() if self.unlocked_at else None,
            'achievement': self.achievement.to_dict() if self.achievement else None
        }


class Activity(db.Model):
    __tablename__ = 'activities'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Activity data
    activity_type = db.Column(db.String(50), nullable=False)  # lesson_completed, achievement_unlocked, etc.
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    
    # Metadata
    xp_gained = db.Column(db.Integer, default=0)
    coins_gained = db.Column(db.Integer, default=0)
    related_id = db.Column(db.Integer, nullable=True)  # ID of related object (lesson, achievement, etc.)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Activity {self.activity_type}: {self.title}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'activity_type': self.activity_type,
            'title': self.title,
            'description': self.description,
            'xp_gained': self.xp_gained,
            'coins_gained': self.coins_gained,
            'related_id': self.related_id,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class ChatMessage(db.Model):
    __tablename__ = 'chat_messages'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Message data
    message = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text, nullable=True)
    message_type = db.Column(db.String(20), default='question')  # question, help, feedback
    
    # AI metadata
    ai_model = db.Column(db.String(50), nullable=True)
    processing_time = db.Column(db.Float, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    responded_at = db.Column(db.DateTime, nullable=True)

    def __repr__(self):
        return f'<ChatMessage User:{self.user_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'message': self.message,
            'response': self.response,
            'message_type': self.message_type,
            'ai_model': self.ai_model,
            'processing_time': self.processing_time,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'responded_at': self.responded_at.isoformat() if self.responded_at else None
        }

