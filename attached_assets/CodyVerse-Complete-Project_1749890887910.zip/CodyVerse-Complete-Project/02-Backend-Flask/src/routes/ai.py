from flask import Blueprint, request, jsonify
from src.models.user import db, ChatMessage, Activity
from src.routes.auth import token_required
from src.services.ai_service import ai_service
from datetime import datetime
import asyncio

ai_bp = Blueprint('ai', __name__)

def run_async(coro):
    """Helper to run async functions in sync context"""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    return loop.run_until_complete(coro)

@ai_bp.route('/chat', methods=['POST'])
@token_required
def chat_with_cody(current_user):
    try:
        data = request.get_json()
        message = data.get('message', '').strip()
        
        if not message:
            return jsonify({'message': 'Message is required'}), 400
        
        # Build user context
        user_context = {
            'level': current_user.level,
            'xp': current_user.xp,
            'age_group': current_user.age_group,
            'language': current_user.language,
            'username': current_user.username
        }
        
        # Get current course if enrolled
        from src.models.user import Enrollment
        current_enrollment = Enrollment.query.filter_by(
            user_id=current_user.id
        ).filter(Enrollment.completed_at.is_(None)).first()
        
        if current_enrollment:
            user_context['current_course'] = current_enrollment.course.title
        
        # Get recent activities
        recent_activities = Activity.query.filter_by(
            user_id=current_user.id
        ).order_by(Activity.created_at.desc()).limit(3).all()
        
        user_context['recent_activities'] = [
            f"{activity.activity_type}: {activity.title}" 
            for activity in recent_activities
        ]
        
        # Create chat message record
        chat_message = ChatMessage(
            user_id=current_user.id,
            message=message,
            message_type=data.get('type', 'question')
        )
        db.session.add(chat_message)
        
        # Get AI response
        start_time = datetime.utcnow()
        ai_response = run_async(ai_service.chat_with_cody(message, user_context))
        end_time = datetime.utcnow()
        
        # Update chat message with response
        chat_message.response = ai_response['response']
        chat_message.ai_model = ai_response.get('model', 'fallback')
        chat_message.processing_time = (end_time - start_time).total_seconds()
        chat_message.responded_at = end_time
        
        # Create activity for chat interaction
        activity = Activity(
            user_id=current_user.id,
            activity_type='chat_interaction',
            title='Conversa com Cody',
            description=f'Você fez uma pergunta para o Cody: "{message[:50]}..."'
        )
        db.session.add(activity)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Chat response generated',
            'response': ai_response['response'],
            'chat_id': chat_message.id,
            'processing_time': chat_message.processing_time,
            'fallback': ai_response.get('fallback', False)
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Error in chat: {str(e)}'}), 500

@ai_bp.route('/recommendations', methods=['GET'])
@token_required
def get_recommendations(current_user):
    try:
        # Build user context for recommendations
        user_context = {
            'level': current_user.level,
            'xp': current_user.xp,
            'age_group': current_user.age_group,
            'language': current_user.language
        }
        
        # Get completed courses
        from src.models.user import Enrollment
        completed_enrollments = Enrollment.query.filter_by(
            user_id=current_user.id
        ).filter(Enrollment.completed_at.isnot(None)).all()
        
        user_context['completed_courses'] = [
            enrollment.course.title for enrollment in completed_enrollments
        ]
        
        # Get user interests based on activities
        activities = Activity.query.filter_by(
            user_id=current_user.id,
            activity_type='lesson_completed'
        ).limit(10).all()
        
        # Simple interest detection based on recent activities
        interests = []
        for activity in activities:
            if 'python' in activity.title.lower():
                interests.append('python')
            elif 'javascript' in activity.title.lower():
                interests.append('javascript')
            elif 'web' in activity.title.lower():
                interests.append('web')
        
        user_context['interests'] = list(set(interests))
        
        # Get AI recommendations
        recommendations = run_async(ai_service.get_course_recommendations(user_context))
        
        return jsonify({
            'recommendations': recommendations,
            'user_context': user_context
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Error getting recommendations: {str(e)}'}), 500

@ai_bp.route('/analyze-code', methods=['POST'])
@token_required
def analyze_code(current_user):
    try:
        data = request.get_json()
        code = data.get('code', '').strip()
        language = data.get('language', 'python')
        
        if not code:
            return jsonify({'message': 'Code is required'}), 400
        
        # Get AI analysis
        analysis = run_async(ai_service.analyze_code(code, language))
        
        # Create activity for code analysis
        activity = Activity(
            user_id=current_user.id,
            activity_type='code_analysis',
            title='Análise de Código',
            description=f'Você analisou código {language} com o Cody'
        )
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({
            'message': 'Code analyzed successfully',
            'analysis': analysis
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Error analyzing code: {str(e)}'}), 500

@ai_bp.route('/generate-exercise', methods=['POST'])
@token_required
def generate_exercise(current_user):
    try:
        data = request.get_json()
        topic = data.get('topic', 'python')
        difficulty = data.get('difficulty', 'beginner')
        
        # Get AI-generated exercise
        exercise = run_async(ai_service.generate_exercise(topic, difficulty))
        
        # Create activity for exercise generation
        activity = Activity(
            user_id=current_user.id,
            activity_type='exercise_generated',
            title='Exercício Gerado',
            description=f'Você gerou um exercício de {topic} ({difficulty})'
        )
        db.session.add(activity)
        db.session.commit()
        
        return jsonify({
            'message': 'Exercise generated successfully',
            'exercise': exercise
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Error generating exercise: {str(e)}'}), 500

@ai_bp.route('/chat/history', methods=['GET'])
@token_required
def get_chat_history(current_user):
    try:
        limit = request.args.get('limit', 20, type=int)
        
        chat_messages = ChatMessage.query.filter_by(
            user_id=current_user.id
        ).order_by(ChatMessage.created_at.desc()).limit(limit).all()
        
        return jsonify({
            'chat_history': [msg.to_dict() for msg in chat_messages]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Error getting chat history: {str(e)}'}), 500

@ai_bp.route('/status', methods=['GET'])
def get_ai_status():
    try:
        return jsonify({
            'ai_available': ai_service.is_available(),
            'service': 'OpenAI GPT-3.5-turbo' if ai_service.is_available() else 'Fallback responses',
            'features': {
                'chat': True,
                'recommendations': True,
                'code_analysis': ai_service.is_available(),
                'exercise_generation': ai_service.is_available()
            }
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Error getting AI status: {str(e)}'}), 500

