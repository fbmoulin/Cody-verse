from flask import Blueprint, request, jsonify
from src.models.user import db, Course, Lesson, Enrollment, LessonCompletion, Activity
from src.routes.auth import token_required
from datetime import datetime

courses_bp = Blueprint('courses', __name__)

@courses_bp.route('/courses', methods=['GET'])
def get_courses():
    try:
        # Get query parameters
        difficulty = request.args.get('difficulty')
        category = request.args.get('category')
        featured = request.args.get('featured')
        
        # Build query
        query = Course.query.filter_by(is_published=True)
        
        if difficulty:
            query = query.filter_by(difficulty=difficulty)
        if category:
            query = query.filter_by(category=category)
        if featured:
            query = query.filter_by(is_featured=True)
        
        courses = query.all()
        
        return jsonify({
            'courses': [course.to_dict() for course in courses]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Error getting courses: {str(e)}'}), 500

@courses_bp.route('/courses/<int:course_id>', methods=['GET'])
def get_course(course_id):
    try:
        course = Course.query.get_or_404(course_id)
        
        if not course.is_published:
            return jsonify({'message': 'Course not found'}), 404
        
        # Get lessons
        lessons = Lesson.query.filter_by(
            course_id=course_id, 
            is_published=True
        ).order_by(Lesson.order).all()
        
        course_data = course.to_dict()
        course_data['lessons'] = [lesson.to_dict() for lesson in lessons]
        
        return jsonify({'course': course_data}), 200
        
    except Exception as e:
        return jsonify({'message': f'Error getting course: {str(e)}'}), 500

@courses_bp.route('/courses/<int:course_id>/enroll', methods=['POST'])
@token_required
def enroll_course(current_user, course_id):
    try:
        course = Course.query.get_or_404(course_id)
        
        if not course.is_published:
            return jsonify({'message': 'Course not available'}), 404
        
        # Check if already enrolled
        existing_enrollment = Enrollment.query.filter_by(
            user_id=current_user.id,
            course_id=course_id
        ).first()
        
        if existing_enrollment:
            return jsonify({'message': 'Already enrolled in this course'}), 400
        
        # Create enrollment
        enrollment = Enrollment(
            user_id=current_user.id,
            course_id=course_id
        )
        
        # Set first lesson as current
        first_lesson = Lesson.query.filter_by(
            course_id=course_id,
            is_published=True
        ).order_by(Lesson.order).first()
        
        if first_lesson:
            enrollment.current_lesson_id = first_lesson.id
        
        db.session.add(enrollment)
        
        # Create activity
        activity = Activity(
            user_id=current_user.id,
            activity_type='course_enrolled',
            title=f'Inscrito no curso: {course.title}',
            description=f'Você se inscreveu no curso {course.title}',
            related_id=course_id
        )
        db.session.add(activity)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Enrolled successfully',
            'enrollment': enrollment.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Error enrolling in course: {str(e)}'}), 500

@courses_bp.route('/my-courses', methods=['GET'])
@token_required
def get_my_courses(current_user):
    try:
        enrollments = Enrollment.query.filter_by(user_id=current_user.id).all()
        
        return jsonify({
            'enrollments': [enrollment.to_dict() for enrollment in enrollments]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Error getting enrollments: {str(e)}'}), 500

@courses_bp.route('/courses/<int:course_id>/lessons/<int:lesson_id>', methods=['GET'])
@token_required
def get_lesson(current_user, course_id, lesson_id):
    try:
        # Check enrollment
        enrollment = Enrollment.query.filter_by(
            user_id=current_user.id,
            course_id=course_id
        ).first()
        
        if not enrollment:
            return jsonify({'message': 'Not enrolled in this course'}), 403
        
        lesson = Lesson.query.filter_by(
            id=lesson_id,
            course_id=course_id,
            is_published=True
        ).first_or_404()
        
        # Get or create lesson completion
        completion = LessonCompletion.query.filter_by(
            user_id=current_user.id,
            lesson_id=lesson_id,
            enrollment_id=enrollment.id
        ).first()
        
        if not completion:
            completion = LessonCompletion(
                user_id=current_user.id,
                lesson_id=lesson_id,
                enrollment_id=enrollment.id
            )
            db.session.add(completion)
            db.session.commit()
        
        lesson_data = lesson.to_dict()
        lesson_data['completion'] = completion.to_dict()
        
        return jsonify({'lesson': lesson_data}), 200
        
    except Exception as e:
        return jsonify({'message': f'Error getting lesson: {str(e)}'}), 500

@courses_bp.route('/courses/<int:course_id>/lessons/<int:lesson_id>/complete', methods=['POST'])
@token_required
def complete_lesson(current_user, course_id, lesson_id):
    try:
        data = request.get_json() or {}
        
        # Check enrollment
        enrollment = Enrollment.query.filter_by(
            user_id=current_user.id,
            course_id=course_id
        ).first()
        
        if not enrollment:
            return jsonify({'message': 'Not enrolled in this course'}), 403
        
        lesson = Lesson.query.filter_by(
            id=lesson_id,
            course_id=course_id,
            is_published=True
        ).first_or_404()
        
        # Get lesson completion
        completion = LessonCompletion.query.filter_by(
            user_id=current_user.id,
            lesson_id=lesson_id,
            enrollment_id=enrollment.id
        ).first()
        
        if not completion:
            completion = LessonCompletion(
                user_id=current_user.id,
                lesson_id=lesson_id,
                enrollment_id=enrollment.id
            )
            db.session.add(completion)
        
        # Mark as completed
        if not completion.completed:
            completion.completed = True
            completion.completed_at = datetime.utcnow()
            completion.score = data.get('score')
            completion.time_spent = data.get('time_spent')
            
            # Award XP and coins
            level_up = current_user.add_xp(lesson.xp_reward)
            current_user.coins += lesson.coins_reward
            
            # Create activity
            activity = Activity(
                user_id=current_user.id,
                activity_type='lesson_completed',
                title=f'Lição concluída: {lesson.title}',
                description=f'Você concluiu a lição "{lesson.title}" e ganhou {lesson.xp_reward} XP',
                xp_gained=lesson.xp_reward,
                coins_gained=lesson.coins_reward,
                related_id=lesson_id
            )
            db.session.add(activity)
            
            # Update enrollment progress
            enrollment.update_progress()
            enrollment.last_accessed = datetime.utcnow()
            
            # Move to next lesson
            next_lesson = Lesson.query.filter_by(
                course_id=course_id,
                is_published=True
            ).filter(Lesson.order > lesson.order).order_by(Lesson.order).first()
            
            if next_lesson:
                enrollment.current_lesson_id = next_lesson.id
            
            db.session.commit()
            
            response_data = {
                'message': 'Lesson completed successfully',
                'completion': completion.to_dict(),
                'xp_gained': lesson.xp_reward,
                'coins_gained': lesson.coins_reward,
                'level_up': level_up,
                'user': current_user.to_dict()
            }
            
            if next_lesson:
                response_data['next_lesson'] = next_lesson.to_dict()
            
            return jsonify(response_data), 200
        else:
            return jsonify({'message': 'Lesson already completed'}), 400
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'message': f'Error completing lesson: {str(e)}'}), 500

@courses_bp.route('/progress', methods=['GET'])
@token_required
def get_progress(current_user):
    try:
        enrollments = Enrollment.query.filter_by(user_id=current_user.id).all()
        
        total_courses = len(enrollments)
        completed_courses = len([e for e in enrollments if e.completed_at])
        
        # Get recent activities
        recent_activities = Activity.query.filter_by(
            user_id=current_user.id
        ).order_by(Activity.created_at.desc()).limit(10).all()
        
        # Calculate weekly progress
        from datetime import timedelta
        week_ago = datetime.utcnow() - timedelta(days=7)
        weekly_activities = Activity.query.filter(
            Activity.user_id == current_user.id,
            Activity.created_at >= week_ago
        ).all()
        
        weekly_xp = sum(a.xp_gained for a in weekly_activities)
        weekly_lessons = len([a for a in weekly_activities if a.activity_type == 'lesson_completed'])
        
        return jsonify({
            'user': current_user.to_dict(),
            'stats': {
                'total_courses': total_courses,
                'completed_courses': completed_courses,
                'weekly_xp': weekly_xp,
                'weekly_lessons': weekly_lessons
            },
            'enrollments': [e.to_dict() for e in enrollments],
            'recent_activities': [a.to_dict() for a in recent_activities]
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Error getting progress: {str(e)}'}), 500

