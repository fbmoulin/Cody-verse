import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  BookOpen, 
  Zap, 
  Trophy, 
  User, 
  Mail, 
  Lock, 
  LogIn, 
  UserPlus,
  Star,
  Target,
  Award,
  MessageCircle,
  TrendingUp
} from 'lucide-react'
import './App.css'

const API_URL = 'https://mzhyi8cqn19m.manus.space/api'

function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(false)
  const [courses, setCourses] = useState([])
  const [stats, setStats] = useState({
    totalXP: 0,
    level: 1,
    coins: 0,
    streak: 0,
    coursesCompleted: 0,
    lessonsCompleted: 0
  })

  // Função para fazer login
  const handleLogin = async (email, password) => {
    setLoading(true)
    try {
      const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      })
      
      if (response.ok) {
        const data = await response.json()
        localStorage.setItem('token', data.token)
        setUser(data.user)
        await loadUserData()
      } else {
        alert('Erro no login. Verifique suas credenciais.')
      }
    } catch (error) {
      console.error('Erro no login:', error)
      alert('Erro de conexão. Tente novamente.')
    }
    setLoading(false)
  }

  // Função para fazer registro
  const handleRegister = async (username, email, password) => {
    setLoading(true)
    try {
      const response = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, email, password }),
      })
      
      if (response.ok) {
        const data = await response.json()
        localStorage.setItem('token', data.token)
        setUser(data.user)
        await loadUserData()
      } else {
        const error = await response.json()
        alert(error.message || 'Erro no registro.')
      }
    } catch (error) {
      console.error('Erro no registro:', error)
      alert('Erro de conexão. Tente novamente.')
    }
    setLoading(false)
  }

  // Carregar dados do usuário
  const loadUserData = async () => {
    const token = localStorage.getItem('token')
    if (!token) return

    try {
      // Carregar cursos
      const coursesResponse = await fetch(`${API_URL}/courses`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      })
      if (coursesResponse.ok) {
        const coursesData = await coursesResponse.json()
        setCourses(coursesData.courses || [])
      }

      // Carregar estatísticas do usuário
      const userResponse = await fetch(`${API_URL}/user/profile`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      })
      if (userResponse.ok) {
        const userData = await userResponse.json()
        setStats({
          totalXP: userData.user?.total_xp || 0,
          level: userData.user?.level || 1,
          coins: userData.user?.coins || 0,
          streak: userData.user?.streak_days || 0,
          coursesCompleted: userData.user?.courses_completed || 0,
          lessonsCompleted: userData.user?.lessons_completed || 0
        })
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
    }
  }

  // Verificar se usuário está logado ao carregar
  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      // Simular usuário logado
      setUser({ username: 'Usuário' })
      loadUserData()
    }
  }, [])

  // Logout
  const handleLogout = () => {
    localStorage.removeItem('token')
    setUser(null)
    setCourses([])
    setStats({
      totalXP: 0,
      level: 1,
      coins: 0,
      streak: 0,
      coursesCompleted: 0,
      lessonsCompleted: 0
    })
  }

  // Se não estiver logado, mostrar tela de login
  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold">CodyVerse</CardTitle>
            <CardDescription>
              Sua jornada de aprendizado em programação e IA
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Registro</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <LoginForm onLogin={handleLogin} loading={loading} />
              </TabsContent>
              
              <TabsContent value="register">
                <RegisterForm onRegister={handleRegister} loading={loading} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Dashboard principal
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center mr-3">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">CodyVerse</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className="flex items-center">
                <Trophy className="w-4 h-4 mr-1" />
                Nível {stats.level}
              </Badge>
              <Badge variant="outline" className="flex items-center">
                <Star className="w-4 h-4 mr-1" />
                {stats.totalXP} XP
              </Badge>
              <Button variant="outline" onClick={handleLogout}>
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Target className="w-8 h-8 text-indigo-600 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">XP Total</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.totalXP}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Award className="w-8 h-8 text-yellow-600 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Moedas</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.coins}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <TrendingUp className="w-8 h-8 text-green-600 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Sequência</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.streak} dias</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <BookOpen className="w-8 h-8 text-blue-600 mr-3" />
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Lições</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.lessonsCompleted}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Cursos Disponíveis */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Cursos Disponíveis</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {courses.map((course) => (
                <Card key={course.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{course.title}</CardTitle>
                      <Badge 
                        variant={course.difficulty === 'beginner' ? 'secondary' : 
                                course.difficulty === 'intermediate' ? 'default' : 'destructive'}
                      >
                        {course.difficulty}
                      </Badge>
                    </div>
                    <CardDescription>{course.short_description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        {course.estimated_duration} min
                      </span>
                      <span className="text-2xl">{course.icon}</span>
                    </div>
                    <Progress value={0} className="mb-4" />
                    <Button className="w-full">Começar Curso</Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Chat com Cody
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  Precisa de ajuda? Converse com nosso assistente IA!
                </p>
                <Button className="w-full">Iniciar Chat</Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Progresso do Nível</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Nível {stats.level}</span>
                    <span>{stats.totalXP} / {stats.level * 1000} XP</span>
                  </div>
                  <Progress value={(stats.totalXP % 1000) / 10} />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

// Componente de Login
function LoginForm({ onLogin, loading }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    onLogin(email, password)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="password">Senha</Label>
        <Input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
      </div>
      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? 'Entrando...' : 'Entrar'}
      </Button>
    </form>
  )
}

// Componente de Registro
function RegisterForm({ onRegister, loading }) {
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    onRegister(username, email, password)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="username">Nome de usuário</Label>
        <Input
          id="username"
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="reg-email">Email</Label>
        <Input
          id="reg-email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="reg-password">Senha</Label>
        <Input
          id="reg-password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
      </div>
      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? 'Criando conta...' : 'Criar conta'}
      </Button>
    </form>
  )
}

export default App

